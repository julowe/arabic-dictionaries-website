#!/usr/bin/env python
# -*- coding:utf-8 -*-


import Tkinter as tk
import os.path
import glob
import sys


class WindowMain(tk.Tk):
    
    
    def __init__(self):
        
        tk.Tk.__init__(self)
        
        
        self.som = []   # liste du sommaire (Sections et clefs)
        
        
        # Chemin complet du répertoire des langues
        self.lgdir = os.path.dirname(os.path.realpath(sys.argv[0]))
        
        # liste des codes de langue
        self.lgs = [] 
        for f in glob.glob(os.path.join(self.lgdir, "*.py")):
            f = os.path.basename(f)[:-3]
            if not f.startswith("_") and not f.endswith("verto") :
                self.lgs.append(f)
        
        
        # --------------------------
        # --- Interface graphique   
        # --------------------------
        
        self.title("Verto")
        
        fr_som = tk.Frame(self)
        fr_som.pack(expand=True, fill="both", side="left")
        
        # Liste des éléments
        self.lst_item = tk.Listbox(fr_som, height=30)
        self.lst_item.pack(expand=True, fill="both", side="left")
        self.lst_item.bind('<ButtonRelease-1>', self.__onclickSom)
        
        # Scrollbar de la liste des éléments
        self.scr = tk.Scrollbar(fr_som, command=self.lst_item.yview)
        self.lst_item['yscrollcommand'] = self.scr.set
        self.scr.pack(side="left", fill="y")
        
        fr_saisie = tk.Frame(self)
        fr_saisie.pack()
        
        
        # ------------------------------------------
        # --- Construire les cases de traduction    
        # ------------------------------------------
        n=0
        for lg in self.lgs:
            
            tk.Label(fr_saisie, text=lg).grid(row=n, column=0)
            
            exec("self.txt_" + lg +"= tk.Entry(fr_saisie)")
            txt = eval("self.txt_" + lg)
            txt.config(width=60)
            txt.grid(row=n, column=1, pady=3, padx=2)
            
            n += 1
        
        
        # ---------------------------------------
        # --- Construire la liste de sommaire    
        # ---------------------------------------
        
        
        import fr   # Langue de référence
        
        
        tmp = []
        
        for section in fr.__dict__:
            # ne scanner que les variables dictionnaires
            if isinstance(eval("fr." + section), dict):
                # sauter les dictionnaires système
                if not section.startswith("_"):
                    tmp.append(section)
        
        tmp.sort()  # trier les sections           
        
        
        for section in tmp:
            self.som.append("# --- [" + section + "] -------------------")
            tmp2 = []
            for clef in eval("fr." + section):
                tmp2.append(clef)
            tmp2.sort()
            for it in tmp2:
                self.som.append(" " + section + "  |  " + it)
        
        
        # -----------------------------------------
        # --- Afficher le sommaire                 
        # -----------------------------------------
        
        self.__displaySom()
        
        
        
        return
    
    
    
    def __displaySom(self, section="", clef=""):
        u"""
        |
        |   ARGUMENTS :
        |       'section' : nom de la section à expandre dans la liste
        """
        
        self.lst_item.delete(0, "end")
        
        for it in self.som:
            
            if it.startswith("#"):
                self.lst_item.insert("end", it)
            elif it.startswith(" " + section + " "):
                self.lst_item.insert("end", it)    
        
        return
    
    
    def __onclickSom(self, event):
        
        u"""
        | Clic sur une ligne de sommaire
        """
        
        self.update()
        i = int(self.lst_item.curselection()[0])    # Index du mot cliqué
        k = self.lst_item.get(i)
        
        # extraire la section et la clef et afficher
        if k.startswith("#"):
            section = k.strip("#-[] ")
            clef = ""
        else:
            section = k.split()[0]
            clef = k.split("|")[1].strip()
        
        self.__displaySom(section, clef)
        self.__displayData(section, clef)
        
        return
    
    
    
    def __displayData(self, section, clef):
        
        if clef != "":
            for lg in self.lgs:
                exec("import " + lg)
                exec("v = " + lg + "." + section + "['" + clef + "']")
                exec("self.txt_" + lg + ".delete(0, 'end')")
                exec("self.txt_" + lg + ".insert('end', v)")
        else:
            for lg in self.lgs:
                exec("self.txt_" + lg + ".delete(0, 'end')")
        
        return
    

# //////////////////////////////////////////////////////////

app = WindowMain()

app.mainloop()

    
