#!/usr/bin/env python
# -*- coding:utf-8 -*-
# ============================================================================================
# ===                                                                                         
# ===   INTERFACE LANGUAGE MODULE                                                             
# ===                                                                                         
# ===   The strings are stocked in pyDictionaries                                             
# ===   emulating a structure : [section] key=value                                           
# ===                                                                                         
# === The trivial name (to be displayed) of the language is in the pseudo comment #lg_name#   
# ===                                                                                         
# ============================================================================================
#lg_name# English
g = {
 "close"    : "Close",
 "hlp"      : "Help",
 "cncl"     : "Cancel",
 "brw"      : "Browse...",
 "cpy"      : "Copy",
 "pst"      : "Paste",
 "opn"      : "Open",
 "adv"      : "Advanced",
 "basic"    : "Basical",
 "loadfst"  : u"Load first a dictionary!",
 "enclst"   : u"\tcp1252 (Windows - Western Europe)\n\tcp1250 (Windows - Central Europe)\n\tcp1251 (Windows - Cyrillic\n\tcp1253 (Windows - Greek)\n\tcp1254 (Windows - Turkish)\n\tetc...",
 "id1"      : u"is an ID already existing in the dictionary.\n\nEach ID must be unique in the dictionary.",
 "msg1"     : u"The audio features of this application need the Snack library (licence GNU-GPL) to be installed.",
 "msg2"     : u"Snack for Windows is included in the package of Linguae and its manual installation is very simple",
 "msg3"     : u"All the audio features of Linguae will be deactivated while this library is not installed.\n\nDo you wish to display the help for more details?",
 "msg4"     : u"Audio library can't be accessed",
 "msg5"     : u"(1 of 2)",
 "msg6"     : u"(2 of 2)",
 "fmp3"     : "MP3 files",
 "fwav"     : "Wave files",
 "faudio"   : "Audio files",
 "fgif"     : "GIF files",
 "fjpeg"    : "JPEG files",
 "fpng"     : "PNG files",
 "fbmp"     : "BMP files",
 "ftiff"    : "TIFF files",
 "fgraph"   : "Graphic files",
 "fall"     : "All the files",
 "ftxt"     : "Text files",
 "fling"    : "Ling files",
 "fwb"      : "WB files",
 "fdict"    : "Stardict files",
 "fddz"     : "Compressed Stardict files",
 "flim"     : "Delimited files",
 "fini"     : "INI files",
 "fxdxf"    : "XDXF files",
 "ftei"     : "TEI files",
 "fdictd"   : "Freedict files",
 "fsup"     : "Files of all supported formats",
 "fpy"      : "Python files",
 "fsqlite"  : "SQLite-3 files",
}
# ----------------------------------------
# --- Messages of the dictionary object  
# ----------------------------------------
dic = {
 "msg1"     : u"Load a dictionary",
 "msg2"     : u"Unable to link the progress bar",
 "msg3"     : u"Failure of the dictionary loading.",
 "msg4"     : u"This file can't be found!",
 "msg5"     : u"This file has not a format supported by Linguae.",
 "msg6"     : u"The ID",
 "msg7"     : u"is duplicated.\n\nEach ID must be unique in one dictionnary!\nPlease correct the data (menu Edit) or notice this error to the author of the dictionary.\n\nContinue loading the dictionary?",
 "msg8"     : u"Can't load *.ifo file",
 "msg9"     : u"This dictionary has subtype",
 "msg10"    : u"This subtype of the DICT format is not already supported by Linguae.",
 "msg11"    : u"Can't load the index file *.idx",
 "msg12"    : u"Can't load the data file  *.dict",
 "msg14"    : u"Error while loading a compressed DICT dictionary: unable to open the temporary file.",
 "msg15"    : u"Opening a WB file",
 "msg16"    : u"WB files are encoded on 8-bits\nand included no information about characters encoding...\n\nFor a correct displaying, it is hence necessary to manually specify the encoding of the source language AND that of the target language.\n\nThe commonest encodings used for this format are:",
 "msg17"    : u"Specify at first the encoding of the SOURCE LANGUAGE in this WB file:",
 "msg18"    : u"Then specify the encoding of the TARGET LANGUAGE in this WB file:",
 "msg19"    : u"This WB file has opened successfully but the selected encoding for the source language is not correct\nthe displaying of some characters will be probably wrong.\n\nTo fix that, close this dictionary and reopen it while selecting another encoding.\n\nSelected encoding:",
 "msg20"    : u"The delimited files don't include any information\nabout characters encoding...\n\nFor a correct displaying, it is hence necessary to manually specify the original encoding of this file.\n\nNb: the commonest encodings used for this format are:",  
 "msg21"    : u"Can't define the field separator in this file.\n\nLoading failure!", 
 "msg22"    : u"This file has opened successfully but the selected encoding is not correct\nthe displaying of some characters will be probably wrong.\n\nTo fix that, close this dictionnary and reopen it while selecting another encoding.\n\nSelected encoding:",
 "msg23"    : u"Loading an INI file",
 "msg24"    : u"INI files don't include any information\nabout characters encoding...\n\nFor a correct displaying, it is hence necessary to manually specify the original encoding of this file.",
 "msg25"    : u"A decoding/encoding error occurred for the item with index",
 "msg26"    : u"! Decoding error",
 "msg27"    : u"! Preling > Ling : Line without a translation:",
 "msg28"    : u"Adding the short translation has failed:",
 "msg29"    : u"! Preling concatenation error !",
 "msg30"    : u"This dictionary has the compressed DICT format, it can't be modified.\n\nTo move one of its items, you must at first converting it to not compressed DICT format\nor any other format supported by Linguae (Menu 'File' > 'Export').",
 "msg31"    : u"Moving an item",
 "msg32"    : u"The items of this type of dictionary are not movable",
 "msg33"    : u"Because of its hierarchical structure, a dictionary with the INI format can't be sorted",
 "msg34"    : u"This dictionary has the compressed DICT format, it can't be modified.\n\nTo sort it, you must at first converting it to not compressed DICT format\nor any other format supported by Linguae (Menu 'File' > 'Export').",
 "msg35"    : u"This type of dictionary can't be sorted",
 "msg36"    : u"this file is not a valid Ling file!",
 "msg37"    : u"Loding will continue but this property is not correct:",
}
# -------------------------------------------
# --- Main window (except dropping menus) ---
# -------------------------------------------
win1 = {
 "msg1"     : u"Listening the pronunciation",
 "msg2"     : u"The audio features of Linguae are deactivated.\n\nCheck the correct installation of the audio library 'Snack'.",
 "msg3"     : u"Can't read the audio file!",
 "msg4"     : u"Checking the version of the dictionary",
 "msg6"     : u"Looking for a newer version of the dictionary",
 "msg7"     : u"Internet connection failure for this dictionary",
 "msg8"     : u"The present version of the dictionary is the most recent available.",
 "msg9"     : u"A newer version is available for downloading\n\nLocal version:",
 "msg10"    : u"Version to download:",
 "msg11"    : u"Do you want to connect the Website of the dictionary?",
 "msg12"    : u"Internet connection failure.\n\nChecking program version number can't succeed.",
 "msg13"    : u"The current local version of the program is the newest one:",
 "msg14"    : u"Looking for a newer version of the program",
 "msg15"    : u"Do you want to connect the Website of Linguae to download it?",
 "msg16"    : u"Downloading a new version of Linguae",
 "msg17"    : u"Can't connect to the Website of Linguae.",
 "msg18"    : u"Connection to the Website of Linguae",
 "msg19"    : u"Dictionaries on the Web",
 "msg20"    : u"Linguae will connect you to the French Website of the POLYGLOTTE project.\n\nIts goal is, among others, to gather most of the links to free and open digital dictionnaries.\n\nHave especially a look to the section 'Dictionnaires bilingues' of this site.\n\nContinue?", 
 "msg21"    : u"Feature not available on this platform.\n\nPlease contact the author at",
 "msg22"    : u"with your e-mailing software.",
 "msg23"    : u"Delete a dictionary item",
 "msg24"    : u"Move a dictionary item",
 "msg25"    : u"Select at first a headword!",
 "msg26"    : u"Current index of the item:",
 "msg27"    : u"Specify the new index\nin the following range:",
 "msg28"    : u"Wrong value!\n\nThe target index must be a number between 0 and",
 "msg29"    : u"Are you sure to want to delete the item with index n°",
 "msg30"    : u"Deleting will be irreversible.\n\nConfirm?",
 "msg31"    : u"This dictionary has the compressed DICT format, it can't be modified.\n\nTo edit it, you must at first converting it to not compressed DICT format\nor any other format supported by Linguae (Menu 'File' > 'Export').",
 "msg32"    : u"Open the reverse dictionary",
 "msg33"    : u"Chargez d'abord un dictionnaire de référence !",
 "msg34"    : u"Can't load the dictionary:",
 "msg35"    : u"Automatic opening a dictionary has failed.",
 "msg36"    : u"Open a dictionary",
 "msg37"    : u"Can't load the plugin",
 "msg38"    : u"Loading the plugin",
 "msg39"    : u"has failed.",
 "msg40"    : u"Convert a graphic file into a base64 string",
 "msg41"    : u"This tool allow to convert any graphic file into text format following the standard encoding \"base64\". This text format is that Linguae needs for inserting the dictionary icons in a text file to import a dictionary.\n\nContinue?",
 "msg42"    : u"This file is not a standard GIF file",
 "msg43"    : u"This file is not a GIF file!",
 "msg44"    : u"Conversion successful.\n\nThe base64 text was copied to the clipboard.",
 "msg46"    : u"Quit Linguae",
 "msg47"    : u"Please report any problems encountered to:\n\n\tlinguae@stalikez.info",
 "msg48"    : "Good bye...",
 "msg49"    : u"CAUTION, some dictionaries may be licensed and subject to copyright law.\n Distribution in a form other than the original file maybe forbidden.\n\nIn this case, any modification of contents or format can be made only in a strictly private context \nand without any further distribution.\n\nIf doubt, please refer to the licences of those dictionaries that are not your own personal creations.\n\nContinue?", 
 "msg50"    : u"Because of the hierarchical structure of the INI format\na reverse dictionary can't be build", 
 "msg51"    : u"Type of dictionary not specified.\nCan't extract!",
 "msg52"    : u"Extracting the modifications is possible only for a dictionary with the Ling format.",
 "msg53"    : u"Type of dictionary not specified. Can't export!",
 "msg54"    : u"Adding or modifying icons is possible only for dictionaries with the Ling format.\n\nVous must at first convert the dictionary to this format before adding icons at this dictionary.",
 "msg55"    : u"This function is available only after having defined a folder for the dictionaries (See: Options)",
 "msg57"    : u"The plugin was successfully installed.\nIt is available in the menu 'Plugins'.",
 "msg58"    : u"The reverse dictionary can't be found!\n\nDo you want to build the reverse dictionary now?\n\nNB: if not, it will be always possible to build the reverse dictionary\nby using the appropriate command in the menu 'File'.",
 "msg59"    : u"Do you want to copy this dictionary in your storage folder of dictionaries?",
 "msg60"    : u"The version number of this reverse dictionary doesn't match that of the source dictionary.\n\nIt would be better maybe to get an updated version of the reverse dictionary.\n\nIf a new version is not available, you can rebuilt automaticaly the reverse dictionary (see Menu File).",
 "msg61"    : u"This feature is available only for a dictionary in Ling format.",
 "ib1"      : "Quick searching: type the beginning of a word",
 "ib7"      : "Index of the selected item",
 "ib8"      : "ID of the selected item",
 "ib9"      : "Encodings of the selected item",
 "ib10"     : "Dictionary not protected",
 "ib11"     : "Open a dictionary",
 "ib12"     : "Properties of the dictionary",
 "ib13"     : "Export the dictionary",
 "ib14"     : "Open the reverse dictionary",
 "ib15"     : "Searching in the dictionary items",
 "ib16"     : "Edit the dictionary item",
 "ib17"     : "Add a new dictionary item",
 "ib18"     : "Delete the selected item",
 "ib19"     : "Sorting the dictionary",
 "ib20"     : "Display the characters chart",
 "ib21"     : "See the help of Linguae",
 "ib22"     : "Protected dictionary",
 "ib23"     : "Source language:",
 "ib24"     : "Target language:",
 "ib25"     : "Navigation History",
 "s1"       : "Translation & Definition",
 "s2"       : "(plugin: none)",
 "s3"       : "Listen",
 "s5"       : "Roots:",
 "s6"       : "Synonyms:",
 "s7"       : "Antonyms:",
 "s8"       : "See also:",
 "s9"       : "No plugin is currently loaded.\n\nTo load a plugin, use the menu 'Plugins'.\n\nTo add a plugin to Linguae, use the menu 'Plugins'>'Import a plugin...'.",
 "s10"      : "About your dictionary",
}
# ----------------------
# --- Dropping Menus ---
# ----------------------
menu = {
 "mfich"    : "File",
    "m1"    : "Open a dictionary...",
    "m2"    : "Create a new dictionary...",
    "m3"    : "Properties...",
    "m3b"   : "Copy as...",
    "m4"    : "Import Preling...",
    "m4b"   : "Import...",
    "m5"    : "Export...",
    "m6"    : "Build the reverse dictionary...",
    "m7"    : "See the reverse dictionary...",
    "m7b"   : "Download dictionaries...",
    "m8"    : "Quit",
 "mdic"     : "Dictionaries",
    "m9"    : "(no dictionary)",
    "m9b"   : "Open the folder of the dictionaries...",
    "m34"   : '(path not set: see "Options")',
 "msearch"  : "Searching",
 "medit"    : "Edit",
    "m10"   : "Sorting the dictionary...",
    "m11"   : "Edit the dictionary item...",
    "m12"   : "Delete the item...",
    "m13"   : "Move the item...",
    "m14"   : "Add a new item...",
    "m15"   : "Characters chart...",
    "m16"   : "Modify the icons of the dictionary...",
 "mopt"     : "Options",
    "m17"   : 'Line feed for " ; "',
    "m17a"  : "Always on top",
    "m18"   : "Transparency...",
    "m19"   : "Preferences...",
 "mtools"   : "Tools",
    "m20"   : "Translation helper...",
    "m21"   : "Build a inherited dictionary...",
    "m21b"  : "Check the links in the dictionary...",
    "m22"   : "Extract the modifications of the dictionary...",
    "m23"   : "Converting a picture into base64...",
 "mplug"    : "Plugins",
    "m24"   : "None",
    "m24a"  : "Import a plugin...",
 "mhlp"     : "Help",
    "m25"   : "About Linguae...",
    "m26"   : "Linguae help...",
    "m27"   : "Linguae Website...",
    "m28"   : "Check an update of Linguae...",
    "m29"   : "About this dictionary...",
    "m30"   : "Contact the author of this dictionary...",
    "m31"   : "Website of this dictionary...",
    "m32"   : "Check an update of this dictionary...",
    "m33"   : "Searching dictionaries on the Web..."
}
# ------------------------------
# --- Window of transparency ---
# ------------------------------
winalpha = {
 "title"     : u"Setting the transparency",
 "warning"   : "Nb : the transparency command doesn't work on every platforms\n and gives results of variable intensity according to the graphical cards",
 "fail"      : "Transparency activation has failed",
}
# -----------------------------------
# --- Fenêtre d'inversion de dico ---
# -----------------------------------
winrev = {
 "title"    : u"Building the reverse dictionary",
 "msg1"     : u"This dictionnary is already a dictionnary build by automatic reversing!",
 "msg2"     : u"The properties of this dictionary don't notify that its data are intended to be reversed.",
 "msg3"     : u"Its reversing can lead to very poor results.\n\nContinue nevertheless?",
 "msg4"     : u"The data of this dictionary are protected,\nthe format of the reverse dictionary will be the Ling format\nand the reverse dictionary will be itself a protected dictionary.", 
 "msg5"     : u"A file already exists under this name. Do you want to replace it?",
 "msg6"     : u"Creating a new WB file",
 "msg7"     : u"WB files are encoded on 8-bits\nand  don't include any information about characters encoding...\n\nFor a correct display, it is hence necessary to specify manually\nthe encoding of the source language and that of the target language.\n\nSpecify at first the encoding for the SOURCE LANGUAGE of the WB file to create:",
 "msg9"     : u"Précisez ensuite l'encodage désiré pour la LANGUE CIBLE dans ce nouveau fichier WB :",
 "msg10"    : u"Can't build the reverse file",
 "msg11"    : u"Can't write the name of the reverse dictionary in the source dictionary\nfor the following reason:",
 "msg12"    : u"The dictionary was successfully reversed",
 "s1"       : "Format of the reverse dictionary:",
 "s2"       : "CSV (tab-delimited text-file)",
 "s3"       : "Separator of the individual translations inside the source dictionnary:",
 "s4"       : "Semicolon",
 "s5"       : "Comma",
 "s6"       : "Mode of reversal:",
 "s7"       : "Reversing while neglecting the long translations/informations",
 "s8"       : "Reversing while keeping, without reversing, the long translations/informations",
 "s9"       : "Folder of the reverse dictionary:",
 "s11"      : "Save in the folder of the dictionaries",
 "s12"      : "File name of the reverse dictionary:",
 "s13"      : "Build",
 "s14"      : "! Encoding failure !",
 "s15"      : "New reverse dictionary",
 "s16"      : "(Automatic reverse dictionary - Refer to the original dictionary for licence information)",
 "s17"      : "This dictionary was built by an automatic process and can't aspire to the precision and correctness of a manually written dictionary.",
 "s18"      : "(Automatic reverse dictionary)",
 "s19"      : "! Utf-8 encoding failure in the *.ifo file !",
}
# -----------------------------------
# --- Window of the UNICODE chart ---
# -----------------------------------
winuni = {
 "title"    : u"UNICODE characters chart",
 "s1"       : "Font of the source language",
 "s2"       : "Font of the target language",
 "s3"       : "Select a sub-table in the list",
 "s4"       : "If this font doesn't include the expected characters,\nyou must select another font for default displaying (Options)\nor modify the specific fonts of the dictionary (Dictionary properties)",
 "s5"       : "Double-click on a character to add it",
}
# -------------------------------------
# --- Window of dictionary sorting ---
# -------------------------------------
winsort = {
 "title"    : u"Sorting the dictionary",
 "s1"       : "You can personalize the dictionary sorting\nby adding in the list at left side some equivalences\nof characters for the alphabetic sorting, according to\nthe following syntax:\n\n <character pattern in the dictionary>=<equivalent character pattern>\nOne equivalence per one line.\n\nExample : ö = oe\n(means that the character ö will be sorted as it would be 'oe')\n\nSymbols :\n\t'$$' : space\n\t'%%' : no character",
 "s2"       : "If the list remains empty, the default criteria of alphabetic sorting\nof your platform will applied to the dictionary.",
 "s3"       : "Save the sorting parameters",
 "s4"       : "Sort",
 "s5"       : "Restore the previous sorting order",
 "s6"       : "Sort in strict Ascii order (discard the sorting equivalences)",
 "msg1"     : u"Can't save the sorting equivalences because the folder of the resources can't be created.\n\nCheck the writing rights for the folder of the dictionary.",
}
# -------------------------------------------------
# --- Fenêtre de recherche dans le dictionnaire ---
# -------------------------------------------------
winfnd = {
 "title"    : u"Searching in the dictionary",
 "msg1"     : u"the start of the dictionary is reached.",
 "msg2"     : u"the end of the dictionary is reached.",
 "msg3"     : u"The string",
 "msg4"     : u"can't be found",
 "msg5"     : u"Save search results as...",
 "s1"       : "Previous",
 "s2"       : "Next",
 "s3"       : "Options",
 "s4"       : "Case sensitive searching",
 "s5"       : "Searching in the beginning of the headwords",
 "s6"       : "Ligature sensitive searching (œ, æ, ...)",
 "s7"       : "Searching domain",
 "s8"       : "Headwords",
 "s9"       : "Data",
 "s10"      : "Identifiers (IDs)",
 "s11"      : "Searching by Regular Expression",
 "s12"      : "Find all",
 "s13"      : "Searching mode",
 "s14"      : "Iterative searching",
 "s15"      : "Display the results as a list",
 "s16"      : "Whole word only",
 "s17"      : "Attributes",
}
# ------------------------------------------------
# --- Fenêtre de gestion des images ressources ---
# ------------------------------------------------
winimg = {
 "title"    : u"Manage the pictures",
 "s1"       : "Pictures list:",
 "msg1"     : u"Delete the selected picture?",
}
# -----------------------------
# --- Window of importation ---
# -----------------------------
winimp = {
 "title"    : "Import a formatted pre-dictionary",
 "msg1"     : u"You must select a file to import!",
 "msg2"     : u"This target file already exist.\n\nDo you want to replace it?",
 "msg3"     : u"Enter the path of the source file to import!\n\nPress the button 'Browse' to search on the disk.\n\nAny tab-dlimited text file, CSV or at Preling format is valid.",
 "msg4"     : u"Cant' find the source document!",
 "msg5"     : u"Converting to Ling has failed, for the following reason:",
 "msg6"     : u"Can't save the file,\ncheck the validity of the file name.",
 "msg7"     : u"Importing and converting to Ling format was successful.\n\nDo you want to open the new dictionary?",
 "s1"       : "(see the help for the specifications of the importation format CSV or Preling)",
 "s2"       : "Source file",
 "s3"       : "Path of the formatted text file to import:",
 "s4"       : "Nb: this encoding and this separator will be take in account only if the document\ndoesn't include any specification about them.",
 "s5"       : "Target file",
 "s6"       : "Name of the target file:",
 "s7"       : "Save the file *.ling in the folder of the file to import",
 "s8"       : "Save the file *.ling in the folder of the dictionaries",
 "s9"       : "[NOT YET DEFINED]",
 "s10"      : "Import",
 "s11"      : "Import the contents of the clipboard",
 "s12"      : "Encoding of the text to import:",
 "s13"      : "Data separator:",
}
# ---------------------------------------------
# --- Fenêtre d'importation format non géré ---
# ---------------------------------------------
winimpx = {
 "title"    : "Import a dictionary",
 "s1"       : "IMPORTANT : this module allows to open dictionaries under format able to be imported by Linguae\nbut NOT natively supported by this last.\nTo open a dictionary with supported format, use the menu 'File > Open'.\nTo import a pre-dictionary, use the menu 'File > Import Preling'.",
}
# -----------------------------------------
# --- Fenêtre des infos du dictionnaire ---
# -----------------------------------------
wininf = {
 "title"    : u"About this dictionary...",
 "s1"       : "Version",
 "s2"       : "Information:",
 "s3"       : "Status and Licence:",
 "s4"       : "Author(s):",
 "s5"       : "Other author(s):",
 "s6"       : "Contact:",
 "s7"       : "Bibliographical References:",
 "s8"       : "More information...",
}
# -----------------------------------------------------
# --- Fenêtre de création d'un nouveau dictionnaire ---
# -----------------------------------------------------
winnew = {
 "title"    : "Create a new dictionary",
 "s1"       : "Format of the new dictionary:",
 "s2"       : "(tab-delimited text file)",
 "s3"       : "Folder of the new dictionary:",
 "s4"       : "Save in the dictionary folder",
 "s5"       : "File name of the new dictionary:",
 "s6"       : "Create",
 "msg1"     : u"Can't create the new dictionary.\nA file already exists with this name!",
 "msg2"     : u"Creating the new dictionary has failed:\nUtf-8 encoding errors in the file *.ifo",
}
# ---------------------------
# --- Fenêtre des options ---
# ---------------------------
winopt = {
 "title"    : u"Preferences",
 "s1"       : "Fonts",
 "s2"       : "Paths",
 "s2b"      : "Colours",
 "s3"       : "Miscellaneous",
 "s4"       : "Current font of the dictionaries:",
 "s5"       : "New font of the dictionaries:",
 "s6"       : "Size:",
 "s7"       : "Current font of the translations:",
 "s8"       : "New font of the translations:",
 "s8b"      : "Default fonts",
 "s9"       : "Default path for searching dictionaries:",
 "s10"      : "Path of the folder linked to the menu \"Dictionaries\"\n(All the dictionaries included in this folder and its subfolders will be displayed in the menu):",
 "s11"      : "Actions at start-up:",
 "s12"      : "Check for an updated version.",
 "s13"      : "Re-open the last open dictionary.",
 "s14"      : "Re-open the last open plugin.",
 "s15"      : "Click on a colour box to modify the item:",
 "s16"      : "List word",
 "s17"      : "Headword",
 "s18"      : "Phonetics",
 "s19"      : "Short translations",
 "s20"      : "Long translations",
 "s21"      : "Notice background",
 "s22"      : "Default colors",
 "s24"      : "Display the convivial names of the dictionaries in the menu",
 "s25"      : "Display the file names of the dictionaries in the menu",
}
# ----------------------------------------------
# --- Fenêtre des propriètés du dictionnaire ---
# ----------------------------------------------
winprop = {
 "title"    : u"Properties of the dictionary",
 "s1"       : "File path:",
 "s2"       : "File size:",
 "s3"       : "Modify at:",
 "s4"       : "Number of items:",
 "s5"       : "Format of the dictionnary:",
 "s6"       : "Contents of the file header:",
 "s7"       : "Contents of the ifo file:",
 "s8"       : "Delimited text file",
 "s9"       : "INI file",
 "s10"      : "Validate",
 "s11"      : "Edit",
 "msg1"     : u"Edit the dictionary properties",
 "msg2"     : u"Editing the properties is only for the experienced users\nwell versed in the specifications of the format in question(see Help).\n\nAssigning some wrong properties or wrongly formatted ones can make the dictionary unreadable.\n\nFor this reason, a backup copy of the dictionary will be automatically saved.\n\nContinue?",
}
# ----------------------------------------------
# --- Fenêtre d'extraction des modifications ---
# ----------------------------------------------
winext = {
 "title"    : u"Extracting the modifications",
 "msg1"     : u"Extracting to a new Ling document has failed, for the following reason:",
 "msg2"     : u"Can't save the file of the modifications.",
 "msg3"     : u"Extracting was successful.",
 "s1"       : "The modifications made to this dictionary (items added or modified) will be saved in a new file in Ling format. Then, if you like, you can send this file to the author of the original dictionary.",
 "s2"       : "Extract the items added and modified",
 "s3"       : "Extract only the items added",
 "s4"       : "Extract",
}
# -----------------------------------------
# --- Fenêtre d'encodage des caractères ---
# -----------------------------------------
winenc = {
 "title"    : "Select characters encodings",
 "s1"       : "Encoding language",
}
# ---------------------------------------------
# --- Fenêtre d'exportation du dictionnaire ---
# ---------------------------------------------
winexp = {
 "title"    : u"Exporting the dictionary",
 "msg1"     : u"The data of this dictionary are protected,\nexporting to another format is hence impossible.",
 "msg2"     : u"Exporting from a Ling dictionary",
 "msg3"     : u"The Ling format differentiates a field of translations called \"short\" and a field of translations called \"long\" (including information, examples, etc.).\n\nDo you want to merge these two fields in the new dictionary?\nIf you select 'No', only the short translations will be integrated in the new dictionary.",
 "msg4"     : u"Exporting to XDXF",
 "msg5"     : u"Vous must specify a folder AND a name.",
 "msg6"     : u"Can't create the folder of the XDXF dictionary",
 "msg7"     : u"Exporting a dictionary under...",
 "msg8"     : u"Exporting encountered the following problem:",
 "msg9"     : u"The dictionary was successfully exported",
 "msg10"    : u"in personalized binary format.",
 "msg11"    : u"in Preling text format.",
 "msg12"    : u"Do you want to open this new dictionary?",
 "msg13"    : u"Can't save the file",
 "msg14"    : u"is an encoding which doesn't allow to convert this dictionary\n\nSelect another encoding and try again...\n\nIf Unicode is supported by the program(s) planned for reading these data,\nprefer 'utf-8' as encoding.",
 "msg15"    : u"Can't encode the source language with the selected encoding:",
 "msg16"    : u"Can't encode the target language with the selected encoding:",
 "msg17"    : u"Select other encodings and try again...",
 "msg18"    : u"Can't export to WB format",
 "msg19"    : u"The dictionary was exported to WB format,\nbut some data were truncated.",
 "msg20"    : u"The headwords list was exported successfully.",
 "msg21"    : u"in TEI format.",
 "msg22"    : u"in SQLite database.",
 "s1"       : "Select an export format in the left side list",
 "s2"       : "Exporting to Ling format",
 "s3"       : "Encoding of the text data will be Utf-8,\nwhatever the encoding of the source dictionary.",
 "s4"       : "Protect the headwords",
 "s5"       : "Protect the translations/definitions",
 "s6"       : "Exporting to Preling format",
 "s7"       : "The Preling format is a text format used as a bridge to the Ling binary format\nit allows to edit the dictionary in a simple text editor\nand to access all the capacities of the Ling format.",
 "s8"       : "Line End:",
 "s9"       : "Exporting to WB format",
 "s10"      : "WB is a 8-bits format (extended Ascii), the encoding must hence\nbe compatible. Ex. : 'latin-1', 'cp1242' for W-Europe.",
 "s11"      : "CAUTION, the fields of the WB format are limited\nto 30/31 characters for the source language\n and to 50/53 characters for the target language.\nThe data exceeding these lengths will be truncated...",
 "s12"      : "Exporting to DICT format",
 "s13"      : "The dictionary will be made up of three files, encoded in Utf-8 :\n\tDicName.ifo\n\tDicName.idx\n\tDicName.dict\nThe extension that you'll select for the name of the exportation file is without importance, these three files will be saved in the folder with the same base name.",
 "s14"      : "Transfer the contents between square brackets of the headword field\nto the beginning of  the translation field (helps the use\nof the screen reading by programs allowing that)",
 "s15"      : "Exporting to format XDXF",
 "s16"      : "A XDXF dictionary is made of a XML file\nalways named 'dict.xdxf' and located in\nan own sub-folder for each dictionary.\n\nThe data will be encoded in Utf-8",
 "s17"      : "Folder which will contain the dictionary:",
 "s18"      : "Name of the dictionary (will be the name of the new sub-folder):",
 "s19"      : "Exporting to CSV format (delimited text)",
 "s20"      : "Separator character:",
 "s21"      : "(Tab)",
 "s22"      : "(Comma)",
 "s23"      : "(Semicolon)",
 "s24"      : "Line End:",
 "s25"      : "Exporting to personalized binary format",
 "s26"      : "Separating Byte(s):",
 "s27"      : "Ending Byte(s):",
 "s28"      : "Export...",
 "s29"      : "(dictionary without name)",
 "s30"      : "(dictionary without description)",
 "s31"      : "Binary",
 "s32"      : "Headwords List",
 "s33"      : "Exportation of the headwords list",
 "s34"      : "The headwords list will be exported under text format.",
 "s35"      : "Data separator:",
 "s36"      : "The data of some dictionaries embed format or semantic tags (<.>) which decrease readability in programs not supporting them.",
 "s37"      : "Export without tabs",
 "s38"      : "The contents of double braces is processed by Linguae as a link to the correspondant headword, but these braces decrease the readability in software not recognizing it.",
 "s39"      : "Export witout double braces",
 "s40"      : "Exportating to TEI format",
 "s41"      : "The TEI format is a multipurpose format\nsurpassing by a wide margin the needs of a dictionary.\n\nLinguae can export to this format but can't read it.",
 "s42"      : "Sort the dictionary in strict Ascii order\n(needed for compatibility with Stardict)",
 "s43"      : "Convert '<br>' into real line feed.",
 "s44"      : "Exportating to SQLite-3 format",
 "s45"      : "SQLite is a database format, handled by par SQL\n and managed natively by many languages (PHP, etc.).",
}
# ------------------------------------------------------
# --- Fenêtre d'édition des éléments de dictionnaire ---
# ------------------------------------------------------
wined = {
 "title1"   : u"Edit an item of the dictionary",
 "title2"   : u"Add an item to the dictionary",
 "msg1"     : u"Unlock the item ID",
 "msg2"     : u"CAUTION!\n\nAny secondary modification of the ID of an item breaks the possible links to this item (roots, synonym...)\nas well as the links to the audio and graphical resources associated to it.\n\nContinue?",
 "msg3"     : u"Import an audio file", 
 "msg5"     : u"Importing an audio file is possible only if the word is fitted with an ID.",
 "msg6"     : u"The resource sub-folder can't be created,\ncheck he writing rights for the folder of the dictionary.",
 "msg7"     : u"Import a picture",
 "msg8"     : u"Importing pictures is possible only if the word has an ID.",
 "msg9"     : u"Delete a picture",
 "msg10"    : u"No picture is selected!",
 "msg11"    : u"Can't suppress the image file!",
 "msg12"    : u"See the picture",
 "msg14"    : u"The audio features of Linguae are deactivated.\nCheck the correct installation of the audio library Snack.",
 "msg15"    : u"Recording and playing the pronunciation are possible only if the word has an ID.",
 "msg16"    : u"No pronunciation is yet recorded.\n\nPress 'Rec' to record then 'Stop' to stop recording.",
 "msg17"    : u"Can't read the audio file!",
 "msg18"    : u"Selection of the recording device has failed!\n\n Nb: You must select the device to which your microphone is connected.",
 "msg19"    : u"Can't record the audio file!",
 "msg20"    : u"Modifications can't be applied!",
 "msg21"    : u"is an existing ID in the dictionary.\n\nThe ID is optional but must be unique in the dictionary.\nAn ID is necessary only if you want afterwards be able\nto refer to this item as a root, synonym, etc.\nor to link it some resources (sounds, pictures).",
 "msg22"    : u"Can't access the dictionary file for writing, check you have the needed access rights and that the file is not 'read-only'.",
 "msg23"    : u"Encoding problem of the field",
 "msg24"    : u"Nb : use the on-board characters chart to write characters unable to access with the keyboard",
 "msg25"    : u"Utf-8 encoding problem for the index",
 "msg26"    : u"Encoding problem for the index",
 "msg27"    : u"Warning ! tag not closed",
 "msg28"    : u"Select the piece of text to which the tag will be added!",
 "msg29"      : "Select the field to clean its tags!",
 "s2"       : "Headword (31 characters at most):",
 "s3"       : "Headword:",
 "s4"       : "Short translations/definitions (53 char. max as a whole, 31 char. each and separated by ' , ' )\n(will be used for reversing the dictionary):",
 "s5"       : "Short translations/definitions (separated by ' ; ' )  (will be used for reversing the dictionary) :",
 "s6"       : "Long translations/definitions:",
 "s7"       : "(optional ID, unique in the dictionary)",
 "s8"       : "Unlock the ID",
 "s9"       : "Add an automatic ID",
 "s10"      : "IDs of the Roots (separated by ' ; ' ):",
 "s11"      : "IDs of the Synonyms (separated by ' ; ' ):",
 "s12"      : "IDs of the Antonyms (separated by ' ; ' ):",
 "s13"      : "IDs of the 'See-also' (separated by ' ; ' ):",
 "s14"      : "Attributes: (separated by ' ; ' ):",
 "s15"      : "Phonetic of the headword:",
 "s16"      : "Recorder of the pronunciation",
 "s17"      : "Recording device:",
 "s18"      : "0: ( by default )",
 "s19"      : "Import",
 "s20"      : "Pictures",
 "s21"      : "Delete",
 "s22"      : "Manage...",
 "s23"      : "Clean tags",
 "ib1"      : "Paste the contents of the clipboard",
 "ib2"      : "Add tags: selected text in italic",
 "ib3"      : "Add tags: selected text in bold",
 "ib4"      : "Add tags: selected text underlined",
 "ib5"      : "Add tags: selected text in big",
 "ib6"      : "Add tags: selected text in small",
 "ib7"      : "Add tag of line jump",
 "ib8"      : "Add tags: internal link to a headword",
 "ib9"      : "Delete all tags of the active field",
}
# ---------------------------------------------------
# --- Fenêtre de modif des icônes du dictionnaire ---
# ---------------------------------------------------
winic = {
 "title"    : u"Modifying the icons of the dictionary",
 "msg1"     : u"Including a picture",
 "msg2"     : u"Write at least one valid path to a graphic file!",
 "msg3"     : u"The file can't be found!",
 "s1"       : "Source language picture:",
 "s2"       : "(no picture)",
 "s3"       : "Target language picture:",
 "s4"       : "New picture for the source language (optional) :",
 "s5"       : "New picture for the target language (optional) :",
 "s6"       : "Modify",
}
# --------------------------------------------
# --- Fenêtre de dictionnaire par héritage ---
# --------------------------------------------
winher = {
 "title"    : u"Building a dictionary by inheritance",
 "msg1"     : u"This module allows to derive a dictionary said 'by inheritance' from two source dictionaries, according to the following scheme:\n\n\t[ Dictionary 1 > 2 ] + [ Dictionary 2 > 3 ] => [ Dictionary 1 > 3 ]\n\nThe quality of the inherited dictionary will be very variable according to the compatibility of the writing of the source dictionaries, and will extend from the decent to the nearly unusable. Such an automatic process can't replace a true dictionary human-written, it's only a stopgap for the lacking of an existing dictionary.",
 "msg2"     : u"This file already exists. Do you want to replace it?",
 "msg3"     : u"[ --- Start of the global process --- ]",
 "msg4"     : u" Instantiation of the dictionary",
 "msg5"     : u"Done!",
 "msg6"     : u"The data of this dictionary are protected,\nit can't hence be used as a source dictionary.",
 "msg7"     : u"Building a temporary index...",
 "msg8"     : u"Data analysis...\n(long process, please wait)",
 "msg9"     : u"Building the inherited dictionary...",
 "msg10"    : u"[ --- End of the global process --- ]",
 "msg11"    : u"The dictionary was successfully created.\n\nDo you want to load it?",
 "msg12"    : u"Your dictionnary folder is empty!\n\nYou must copy at first some dictionaries in this folder to use this tool.",
 "msg13"    : u"Loading the parent-dictionary has failed!",
 "s1"       : "Dictionary",
 "s2"       : "Name of the inherited dictionary",
 "s3"       : "Build",
 "s4"       : "(Progress)",
 "s5"       : "Group of character(s) marking the end of the area to take in account during the crossing of the data (by default: space):",
 "s6"       : "Case sensitive",
}
# --------------------------------------
# --- Fenêtre d'aide à la traduction ---
# --------------------------------------
wintrl = {
 "title"    : u"Translation helper",
 "s1"       : "Type or paste the text to translate",
 "s2"       : "Open a text file",
 "s3"       : "To display the matches for a word: Double-click on the word (or select it then Ctrl-P)",
 "s4"       : "Possible matchess:",
 "s5"       : "Double-click on a match to display its data...",
 "msg1"     : u"Open a text file to translate",
}
# ------------------------------------
# --- Fenêtre "A propos de Linguae ---
# ------------------------------------
winabt = {
 "s1"       : "Multiformat dictionary manager",
 "s2"       : "Software under license CeCILL (compatible with GNU-GPL):"
}
# --------------------------------------------
# --- Fenêtre de recherche des liens morts ---
# --------------------------------------------
winlk = {
 "title"    : u"Checking the links of the dictionnary",
}
# ---------------------------------
# --- Fenêtre de téléchargement ---
# ---------------------------------
windwn = {
 "title"    : u"Download and install dictionaries",
 "s1"       : "Author",
 "s2"       : "Date",
 "s3"       : "Version",
 "s4"       : "Format",
 "s5"       : "Download and install",
 "s6"       : "Selected:",
 "s7"       : "Source of the dictionaries:",
 "s8"       : "POLYGLOTTE Project",
 "s9"       : "Connecting to the server...",
 "s10"      : "Notes",
 "s11"      : "File(s)",
 "s12"      : "Downloading, please wait...",
 "s13"      : "Downloading completed",
 "s14"      : "License",
 "s15"      : "Dictionary already installed, check the box to reinstall it.",
 "s16"      : "Dictonary not yet installed, check the box to install it.",
 "s17"      : "(No dictionary matches the filtering option)",
 "s18"      : "Size",
 "s19"      : "Dictionary already installed, check the box to update it.",
 "ib1"      : "Go to the Web site of the Polyglotte Project",
 "msg1"     : u"Connection has failed. Can't download the index",
 "msg2"     : u"Your new dictionaries are installed and ready for using (Menu 'Dictionaries')",
 "msg3"     : u"A problem has occured while downloading, if it persists please contact the webmasters of the site.",
}
# ---------------------------------------
# --- Fenêtre d'interrogation de Swac ---
# ---------------------------------------
winsw = {
 "title"    : u"Ask Swac",
}
