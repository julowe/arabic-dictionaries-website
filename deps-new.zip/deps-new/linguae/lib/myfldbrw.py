#!/usr/bin/env python
# -*- coding:utf-8 -*-

import Tkinter
import tkFileDialog
import os.path


# ////////////////////////////////////////////////////////////////////////
#                                                                         
#   Widget Sélecteur de répertoire                                        
#                                                                         
#   sous licence CeCILL-2 (GNU-GPL compatible) : http://www.cecill.info/  
#                                                                         
#   Auteur   : Billig - 2008-2009                                         
#   Contact  : linguae@stalikez.info                                      
#   Site Web : http://linguae.stalikez.info                               
#                                                                         
# ////////////////////////////////////////////////////////////////////////


class FolderBrowser(Tkinter.Frame):
    
    def __init__(self, parent, width=30, background='white', initialdir="", lang="fr", forcebuttontext="", font=""):
        
        self.lang = lang
        
        Tkinter.Frame.__init__(self, parent, height=100)
        
        
        # Texte du bouton "Parcourir"
        if forcebuttontext == "":
            if self.lang == "fr":
                buttontext = "Parcourir"
            elif lang == "en":
                buttontext = "Browse"
            else:
                buttontext = "..."
        else:
            buttontext = forcebuttontext
        
        # Dimensions internes
        wbutton = len(buttontext)    
        wtxt = width - wbutton
        
        # Case du chemin
        self.txt_path = Tkinter.Entry(self, width=wtxt, background=background)
        if font != "":
            self.txt_path['font'] = font
        self.txt_path.pack(fill="y", side="left")
        
        # Bouton "Parcourir"
        self.bt_brw = Tkinter.Button(self, text=buttontext, width=wbutton, command=self.__browseFolder)
        self.bt_brw .pack(side="left")
        
        # Afficher le répertoire par défaut, s'il est valide
        self.config(initialdir)
        
        return
    
    def config(self, initialdir=None, state=None):
        
        u"""
        | Méthode à invoquer à partir de l'hôte pour configurer le widget       
        | après son initialisation.                                             
        """
        
        if initialdir:
            if initialdir == "":
                self.txt_path.delete(0, "end")
            elif os.path.isdir(initialdir):
                self.txt_path.delete(0, "end")
                self.txt_path.insert("end", initialdir)
        
        if state:
            if state in ("disabled", "normal"):
                self.txt_path['state'] = state
                self.bt_brw['state'] = state
        
        
        return
    
    
    def getpath(self):
        
        u"""
        | Méthode à invoquer à partir de l'hôte pour obtenir le chemin du       
        | répertoire inscrit dans la case de texte du widget                    
        """
        
        return self.txt_path.get()
    
    
    def __browseFolder(self):
        
        u"""
        | Ouvre une boîte de sélection de répertoire                            
        | et affiche le chemin du répertoire choisi dans la case de texte du    
        | widget.                                                               
        """
        
        if self.lang == "fr":
            title = 'Choisissez un répertoire...'
        else:
            title = "Select a folder..."
        
        # Répertoire initial
        initialdir = self.txt_path.get()
        if not os.path.isdir(initialdir):
            initialdir = ""
        
        # Répertoire de retour
        rep = tkFileDialog.askdirectory(parent=self, title=title, initialdir=initialdir)
        
        if not rep: return   # L'utilisateur a cliqué 'Annuler' dans la boîte de dialogue
        
        # Afficher le nouveau répertoire
        self.txt_path.delete(0, "end")
        self.txt_path.insert("end", rep)
        
        return
    
    
#***** MAIN *****
if __name__=='__main__':
    f_root =  Tkinter.Tk()
    FolderBrowser(f_root, initialdir=os.path.expanduser('~'), width=50).pack(padx= 10, pady=10)
    f_root.mainloop()



