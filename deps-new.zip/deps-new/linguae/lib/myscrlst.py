#!/usr/bin/env python
# -*- coding:utf-8 -*-

#///////////////////////////////
#/// Widget ScrolledList ///////
#///////////////////////////////

from Tkinter import*

class ScrolledList(Frame):
  
  
    def __init__(self, root="", height=6, width=18, onclic="", ondblclic="",
                font="", background="white", selectborderwidth=1):
 
        # Invocation du contructeur du Frame représentant le widget
        Frame.__init__(self, root, width=width, borderwidth=0, relief='flat')    
        
        # Liste + scroll
        self.lst=Listbox(self, height=height, width=width, highlightthickness=0, background=background, selectborderwidth=selectborderwidth)
        self.lst.grid(row=2, column=0)
        
        self.lst.bind('<ButtonRelease-1>', self.listclic)
        self.lst.bind('<Double-ButtonRelease-1>', self.listdblclic)
        
        self.scr=Scrollbar(self, command=self.lst.yview)
        self.scr.grid(row=1, rowspan=2,column=1, sticky='NSW')
        self.scr.grid_remove()
        self.lst['yscrollcommand'] = self.scr.set
        
        self.lst.bind('<Up>', self.__lstUpDown)
        self.lst.bind('<Down>', self.__lstUpDown)
        self.lst.bind('<Prior>', self.__lstUpDown)
        self.lst.bind('<Next>', self.__lstUpDown)
        self.lst.bind('<MouseWheel>', self.__scrollWheel)
      
        if font != "": self.lst['font']=font
        self.width=width
        self.onclic=onclic          # Fonction appelée par le clic sur un élément
        self.ondblclic=ondblclic    # Fonction appelée par le double-clic sur un élément
    
    
    def activate(self,i):
        self.lst.activate(i)
    
    
    def add(self, txt, p = END):
        """ 
        | Ajoute 'txt' à la position 'p',                                       
        |  si 'p' n'est pas précisé, 'txt' est ajouté en fin de liste.          
        """
        
        self.lst.insert(p, txt)
        self.update()
        
        # masquer l'ascenceur si inutile
        if self.lst.size() < int(self.lst['height']):
            self.scr.grid_remove()
            self.lst['width'] = self.width
        
        # afficher l'ascenceur
        else:
            self.scr.grid()
            self.lst['width'] = self.width - 2
        
        
        return
  
    def hideScroll(self):
        u"""
        | Force le masquage de l'ascenceur, même si le contenu dépase la
        | zone de visibilité
        """
        
        self.scr.grid_remove()
        self.lst['width'] = self.width
        
        return
  
    def clear(self):
        u"""
        | Vide la liste et masque l'ascenceur                                   
        """
        
        self.lst.delete(0, END)
        
        self.scr.grid_remove()
        self.lst['width'] = self.width
        
        return
  
    def listcount(self):
        return self.lst.size()
  
    def getitem(self,i):
        u""" Retourne le texte de l'élément d'index i """
        return self.lst.get(i)
      
    def getselecteditem(self):
        u""" Retourne le texte de l'élément sélectionné """
        try:
            t = self.lst.get(self.lst.curselection()[0])
        except:
            t = ""
        return t
  
    def getlist(self):
        u""" Retourne le contenu de la Listbox dans une pyListe """
        
        return self.lst.get(0, END)
        
  
    def getselectedindex(self):
        u""" Retourne l'index numérique de l'élément sélectionné """
        try:
            i = self.lst.curselection()[0]
        except:
            i = -1
            
        return i
    
    def delselectedindex(self):
        u""" Supprime l'élément sélectionné """
        
        
        #try:
        self.lst.delete(self.getselectedindex())
        #except:
        pass
        
        return
    
    def setSel(self, i):
        u""" 
        | Sélectionne l'élément i et uniquement celui-ci                        
        """
        self.lst.selection_clear(0, END)
        self.lst.selection_set(i)
        
        return
    
    
    def selClear(self):
        u"""
        | Désélectionne tout                                                    
        """
        self.lst.selection_clear(0, END)
        
        return
    
    def see(self, i): 
        self.lst.see(i)
  
    def __lstUpDown(self, event):
        u""" Action sur les touches haut-bas """
      
        if event.keysym == "Up": v = -1
        elif event.keysym == "Down": v = 1
        elif event.keysym == "Prior": v = -4
        elif event.keysym == "Next": v = 4
        else: return
        
        try:
            i = int(self.lst.curselection()[0])   # index du mot en sélection
        except:
            return
        
        
        self.lst.selection_clear(0, END)
      
        i +=  int(v)
      
        if i < 0: i = 0
        if i >= self.lst.size(): i = self.lst.size()-1
        
        self.lst.selection_set(i)
        self.lst.see(i)
        
        self.listclic(event)       # Affiche la sélection dans la case
        
        return

    def __scrollWheel(self, event):
        u""" Scroll avec la roulette de souris """
      
        if event.delta <0:self.lst.yview_scroll(1, 'units')
        else: self.lst.yview_scroll(-1, 'units')
        
        return

    def listclic(self, event):
        u""" Clic sur un élément de la liste """
        
        #self.lst.focus_set()
        
        if self.onclic != "":
            
            if self.lst.curselection() is None : return
            if len(self.lst.curselection()) == 0 : return
            
            # on passe l'index à la procédure référencée sous "onclic"
            # ainsi que l'ID du widget ScrolledList
            
            self.onclic(self.lst.curselection()[0], id(self)) 
        
        return
  
    def listdblclic(self, event):
        u""" Double-Clic sur un élément de la liste """
        
        #self.lst.focus_set()
        
        if self.ondblclic != "":
            
            if self.lst.curselection() is None : return
            if len(self.lst.curselection()) == 0 : return
            
            # on passe l'index à la procédure référencée sous "ondblclic"
            # ainsi que l'ID du widget ScrolledList
            
            self.ondblclic(self.lst.curselection()[0], id(self)) 
        
        return
  
    def setFont(self, font):
        self.lst['font']=font
        return
  
    def config(self, background='white'):
        self.lst['background']=background
        
        return

#=== MAIN (widget en mode test )
if __name__ == '__main__':
  print '# # # MODE TEST # # #'
  w=ScrolledList()
  for t in range(3): w.add(str(t))
  w.pack()
  w.mainloop()