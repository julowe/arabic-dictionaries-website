#!/usr/bin/env python
# -*- coding:utf-8 -*-


# ////////////////////////////////////////////////////////////////////////
#                                                                         
#   Widget Gestionnaire d'Historique de navigation                        
#                                                                         
#   sous licence CeCILL-2 (GNU-GPL compatible) : http://www.cecill.info/  
#                                                                         
#   Auteur   : Billig - 2008-2009                                         
#   Contact  : linguae@stalikez.info                                      
#   Site Web : http://linguae.stalikez.info                               
#                                                                         
# ////////////////////////////////////////////////////////////////////////



import Tkinter

class HistorNav(Tkinter.Frame):
    
    u"""
    | Classe de widget "navigateur d'historique"                                
    """

    def __init__(self, parent, background="white", histmax=20, gethistory = None):
        
        u"""
        | ARGUMENTS :                                                           
        |   'gethistory' : fonction de l'hôte récupérant l'élément d'historique 
        |                  ((index, libellé) ou None) dans un argument. Cette   
        |                  fonction est invoquée par le widget lors de l'action 
        |                  sur ses touches de navigation.                       
        """     
        
        
        self.hist = []                      # pyListe des (index, libellé) = historique
        self.histMax = histmax              # nombre maximum d'éléments de l'historique
        self.hCursor = 0                    # curseur dans l'historique
        self.gethistory = gethistory        # référence à la fonction de l'hôte
        
        
        # Images d'interface
        self.img_prevact = Tkinter.PhotoImage(data="""R0lGODlhEAAQALMAABNpDVh9UiiqFjbAM1K7ImewYWvCMGnFUIaefpLUb7a+q63ZmMjOvP8A/+P0
        2P7+/SH5BAEAAA0ALAAAAAAQABAAAAR1sMmmzrhlzc1sWslhCIPCDV+SGCwrmNKhhsmztCNDoWJt
        4wJEoyAy+Bw4AkHQGLB8toV0oQQ0DYeHdrtdMp3G7VQqEFgLhKeW6i1bFwIWwQcvlwOSgVJZY9jN
        MAoCSmUjdgBCE4J/bogbEwgAkpIBMI+XmBEAADs=""")
        #self.img_prevdis = Tkinter.PhotoImage(data="""R0lGODlhEAAQALMAAEVFRW1tbXJycoeHh4qKipGRkZeXl5ycnJOTk7W1tbm5ucTExMrKyv8A/+vr
        #6/39/SH5BAEAAA0ALAAAAAAQABAAAAR1sMmmzrhlzc1sWslhCIPCDV+SGCwrmNKhhsmztCNDoWJt
        #4wJEoyAy+Bw4AkHQGLB8toV0oQQ0DYeHdrtdMp3G7VQqEFgLhKeW6i1bFwIWwQcvlwOSgVJZY9jN
        #MAoCSmUjdgBCE4J/bogbEwgAkpIBMI+XmBEAADs=""")
        self.img_nextact = Tkinter.PhotoImage(data="""R0lGODlhEAAQALMAABNpDVh9UiipFjbAM1K7ImewYWzCL2XFVIaefovSaba+q6zVnP8A//7+/QAA
        BhQHqCH5BAEAAAwALAAAAAAQABAAAARvkEmpzrhnzc3OSUtyGMKgcAOYJEZrEMIpfWG7uK1ApazR
        /DgBglEYuRK/RosAYwxwtuSLAHAakMlsA6Z7YrWNhUBQLRCWTKx4XBWj1eNxQDJgMn9rtkwhYAo+
        cWRDE3yBbACDHAgAjIwBMhyRkREAADs=""")
        #self.img_nextdis = Tkinter.PhotoImage(data="""R0lGODlhEAAQALMAAEVFRW1tbXJycoeHh4qKipGRkZiYmJubm5OTk7Gxsbm5ucLCwv8A//39/QAA
        #ABwcHCH5BAEAAAwALAAAAAAQABAAAARwkEmpzrhnzc3OSUtyGMKgcAOYJEZrEMIpfWG7uK1ApazB
        #NA2cAMEojFwJYPAFYwxwNiUT4DQkldgGTPe8ZhsLgYBaILQI6GtYTA2fCWqxOCAZoNHANVumEKAF
        #H3JjRBN9gmwAhBwIAI2NATIckpIRAAA7""")
        self.img_down = Tkinter.PhotoImage(data="""R0lGODlhEAAQAIAAAAAAAP8A/yH5BAEAAAEALAAAAAAQABAAAAIUjI+py+0PYwO00mnBs/HKD4bieBQAOw==""")
        
        
        Tkinter.Frame.__init__(self, parent, relief="raised", background=background)
        
        self.bt_previous = Tkinter.Button(self, image=self.img_prevact, state='disabled', border=0, background=background, command=self.__toprevious)
        self.bt_previous.pack(side="left")
        
        self.bt_next = Tkinter.Button(self, image=self.img_nextact, state='disabled', border=0, background=background, command=self.__tonext)
        self.bt_next.pack(side="left")
        
        self.bt_dropdown = Tkinter.Button(self, image=self.img_down, border=0, background=background, command=self.__downmenu)
        self.bt_dropdown.pack(side="left")
        
        # Menu déroulant de l'historique
        self.mnu_hist = Tkinter.Menu(self,tearoff = 0)
        self.mnu_hist.add_command(label="(vide)" )
        
        return
    
    
    
    def add(self, idx=None, libel=None):
        
        u"""
        | Ajouter un élément d'historique.
        | Cette fonction doit être appelée par l'hôte pour compléter
        | l'historique.
        """
        
        # si l'ajout est identique au curseur, ne rien faire
        if len(self.hist)>0:
            if idx == self.hist[self.hCursor][0]:
                return
        
        
        # si le curseur est remonté, supprimer tous les éléments qui le suivent
        if self.hCursor < len(self.hist)-1:
            del self.hist[self.hCursor+1:]
            self.bt_next['state'] = "disabled" # désactiver le bouton "next"
        
        # ajouter l'élément  
        self.hist.append( (idx, libel) )
        self.hCursor = len(self.hist)-1
        
        # activer le bouton "previous" du widget
        if len(self.hist) > 1:
            self.bt_previous['state'] = 'normal'
        
        
        # Supprimer l'élément le plus ancien si nécessaire
        while len(self.hist) > self.histMax:
            del self.hist[0]
            self.hCursor = len(self.hist)-1
        
        
        return
    
    
    def reinit(self):
        u"""
        | Réinitialisation de l'historique                                      
        """
        
        self.hist = [] 
        self.hCursor = 0
        self.bt_next['state'] = 'disabled'
        self.bt_previous['state']= 'disabled'
        
        return
    
    
    def __toprevious(self):
        
        u"""
        | Retourner l'élément précédent mémorisé dans l'historique                
        |                                                                       
        | RETOUR :                                                              
        |    - L'(index+libellé) précédent s'il existe dans l'historique.                 
        |    - None sinon.                                                      
        """
        
        if self.hCursor <= 0:
            self.bt_previous['state'] = "disabled"  # on désactive le bouton "previous"
            self.hCursor = 0
            return None
        
        # ----------------------------------
        # --- Remonter dans l'historique    
        # ----------------------------------
        
        self.hCursor -= 1
        
        # Remontée maximale
        if self.hCursor == 0:
            self.bt_previous['state'] = "disabled"  # on désactive le bouton "previous"
            self.bt_next['state'] = "normal"        # on active le bouton "next"
        # Remontée standard
        else:
            self.bt_next['state'] = "normal"        # on active le bouton "next"
        
        # Appel de la fonction de l'hôte en lui passant en argument
        # l'index+libellé mémorisé de la structure
        
        self.gethistory(self.hist[self.hCursor])
        
        
        return 


    def __tonext(self):
        
        u"""
        | Retourner l'élément suivant mémorisé dans l'historique                
        |                                                                       
        | RETOUR :                                                              
        |    - L'(index+libellé) suivant s'il existe dans l'historique.                 
        |    - None sinon.                                                      
        """
        
        if self.hCursor >= len(self.hist) - 1:
            self.bt_next['state'] = "disabled"  # on désactive le bouton "next"
            self.hCursor = len(self.hist) - 1
            return None
        
        
        # ----------------------------------
        # --- Descendre dans l'historique   
        # ----------------------------------
        
        self.hCursor += 1
        
        # Descente maximale 
        if self.hCursor == len(self.hist) - 1:
            self.bt_next['state'] = "disabled"      # on désactive le bouton "next"
            self.bt_previous['state'] = "normal"    # on active le bouton "previous"
        # Descente standard 
        else:
            self.bt_previous['state'] = "normal"        # on active le bouton "previous"
        
        
        # Appel de la fonction de l'hote en lui passant en argument
        # l'index+libellé mémorisé de la structure
        
        self.gethistory(self.hist[self.hCursor])
        
        return
    
    
    def __downmenu(self):
        
        u"""
        | Remplir et afficher le menu déroulant des éléments d'historique.      
        """
        
        # Vider le menu
        self.mnu_hist.delete(0, "end")
        
        # Remplir le menu avec l'historique, éléments les plus récents en haut
        for i in range(len(self.hist)):
            
            if i == self.hCursor:
                self.mnu_hist.insert_command(0, label=self.hist[i][1], background="green", command=lambda arg=i: self.__onclicMenu(arg))
            else:
                self.mnu_hist.insert_command(0, label=self.hist[i][1], command=lambda arg=i: self.__onclicMenu(arg))
        
        
        # Afficher le menu
        self.mnu_hist.tk_popup(self.bt_dropdown.winfo_rootx() + self.mnu_hist.winfo_reqwidth()//2,
                self.bt_dropdown.winfo_rooty() + self.bt_dropdown.winfo_reqheight(),
                0)
        
        return
    
    
    def __onclicMenu(self, i):
        
        
        # supprimer tous les éléments qui suivent le clic
        if i < len(self.hist)-1:
            del self.hist[i+1:]
        
        self.hCursor = i
        
        self.bt_next['state'] = "disabled" # désactiver le bouton "next"
        
        
        # Appel de la fonction de l'hote en lui passant en argument
        # l'index+libellé mémorisé de la structure
        
        self.gethistory(self.hist[i])
        
        return
        
        