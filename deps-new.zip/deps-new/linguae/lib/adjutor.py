#!/usr/bin/env python
# -*- coding:utf-8 -*-



# ////////////////////////////////////////////////////////////////////////
#                                                                         
#   ADJUTOR                                                               
#   Système d'Aide ultra-léger, à capacité contextuelle                   
#   pour application Python/Tkinter                                       
#                                                                         
#                                                                         
#   sous licence CeCILL-2 (GNU-GPL compatible) : http://www.cecill.info/  
#                                                                         
#   Auteur   : Billig - 2008-2009                                         
#   Contact  : linguae@stalikez.info                                      
#   Site Web : http://linguae.stalikez.info                               
#                                                                         
# --------------------- MODE D'EMPLOI ------------------------------------
#                                                                         
# 1) initialiser avec le chemin complet du fichier d'aide                 
#    et (facultatif) le chemin d'un fichier d'aide par défaut             
#    qui sera utilisé si le fichier d'aide est introuvable :              
#                                                                         
#       import adjutor                                                    
#       monAide = adjutor.Adjutor(chemin_fichier, chemin_fichier_defaut)  
#                                                                         
# 2) appel de l'aide, par la suite :                                      
#                                                                         
#           monAide.showHelp()                                            
#                                                                         
#       aide contextuelle :                                               
#                                                                         
#           monAide.showHelp(contextID)                                   
#                                                                         
#   (contextID est l'identifiant de chaque notice d'aide,                 
#    tel que défini dans le fichier d'aide)                               
#                                                                         
# ////////////////////////////////////////////////////////////////////////




from Tkinter import*
from ScrolledText import*
import tkMessageBox
import os.path
import webbrowser



class Adjutor():
    u"""
    | Objet système d'Aide de l'application appelante                           
    """
    
    def __init__(self, fichpath, defautfichpath=""):
        
        u"""
        | - Initialiser le système d'aide                                       
        |    en lui fournissant le fichier d'aide au format adj (format texte)  
        |                                                                       
        | - Construction des tables de cartographie du fichier d'aide           
        """
        
        self.title = "Aide" # Titre de la fenêtre (sera remplacé par le titre présent dans le fichier d'aide)
        self.form = None    # objet fenêtre d'aide
        
        
        # ----------------------------------------
        # --- Ouvrir et analyser le fichier adj   
        # ----------------------------------------
        
        if not os.path.isfile(fichpath):
            
            # Fichier absent > utiliser le fichier par défaut
            fichpath = defautfichpath
            
            if not os.path.isfile(fichpath):
                # L'échec est silencieux lors de l'initialisation
                # mais un message s'affichera ensuite
                # à chaque tentative d'appel de l'aide
                self.file = None
                return
        
        
        self.adjpath = fichpath
        self.file = open(fichpath, "rU")
        
        
        # -----------------------------------------------------------------------------------------------
        #  Construire les tables statiques d'accès au données :                                          
        #                                                                                                
        #       - mapmenu  : table des données de menu                                                   
        #       - mapID    : table de conversion ID > index dans mapmenu                                 
        #       - mapimg   : table des images  (désactivée)                                              
        #                                                                                                
        #  structure de 'mapmenu' (pyListe de tuples) :                                                  
        #  [ ( <0. libellé sommaire>,                                                                    
        #      <1. n° ligne fichier adj>,                                                                
        #      <2. niveau hiérarchique> ,                                                                
        #      <3. ID>,                                                                                  
        #      <4. ID du parent>,                                                                        
        #    ) ,                                                                                         
        #      (...) ]                                                                                   
        #                                                                                                
        #  Structure de 'mapID' (pyDictionnaire) :                                                       
        #  { mapID[<ID>] = <index dans mapmenu>, ... }                                                   
        #                                                                                                
        #  Nb : Une table complémentaire dynamique 'mapidxToID' est construite par 'HelpForm.loadMenu()' 
        # -----------------------------------------------------------------------------------------------
        
        self.mapmenu=[]
        self.mapID = {}
        #self.mapimg = {}
        
        
        nl = 0          # numéro de ligne du fichier
        idx = 0         # index des données de sommaire
        level = 1       # profondeur d'identation / niveau hiérarchique
        levelparent=1
        IDparent = ""   # Id du noeud parent
        
        
        for ligne in self.file:
            
            if ligne.startswith('%adj'):            # Première ligne du fichier
                
                self.title = ligne.split("/")[1].strip() # Titre de la fenêtre
            
            
            # /// désactivé ///
            #elif ligne.startswith(';IDimg'):       # début d'un bloc d'image
            #    
            #    ID = chp[1].split('=')[1].strip()  # Libellé de l'ID
            #    # Table IDimg  > n° ligne fichier   
            #    self.mapimg[ID] = nl+1
            
            elif ligne.startswith(';ID'):           # Début d'une notice
                
                chp = ligne.split(';')
                
                # Libellé de l'ID
                ID = chp[1].split('=')[1].strip()   
                
                # Niveau hiérarchique / Profondeur d'identation (x de 'IDx')
                level = int(ligne[3])
                
                # ID du parent
                if level == 1: IDparent = ID
                
                # Libellé du sommaire (on y ajoute l'indentation éventuelle)
                som = " "*(5*(level-1)) + chp[2].strip() 
                
                # Compléter la Table des données de sommaire
                self.mapmenu.append( (som, nl+1, level, ID, IDparent) )
                
                # Compléter la Table ID  > index de sommaire   
                self.mapID[ID] = idx                        
                
                idx += 1
            
            
            nl += 1
        
        
        
        return
        
        
    def showHelp(self, contextID=""):
        
        u"""
        | Afficher la fenêtre d'aide.                                           
        |                                                                       
        | Si 'contextID' est fourni, la fenêtre s'affiche avec la notice        
        | contextuelle, sinon elle s'affiche avec la première notice.           
        |                                                                       
        """    
        
        
        # ---------------------------------------------
        # --- Echec : le fichier est introuvable       
        # ---------------------------------------------
        
        if self.file is None: # pas de fichier d'aide disponible
            tkMessageBox.showwarning(title = "Open the help file",
                    message = "Le fichier d'aide est introuvable !\n\n" + "-"*30 + "\n\nCan't find the help file!")
            return
        
        # ----------------------------------------------
        # --- Afficher la fenêtre d'aide                
        # ----------------------------------------------
        
        try:
            # Tenter d'activer (fenêtre non modale)
            self.form.focus_set()           
        except:
            # Echec de l'activation > instancier la fenêtre d'aide
            self.form = HelpForm(adj=self, contextID=contextID, )
            self.form.after(100,self.form.resize)
        
        self.form.focus_force()
        
        
        # ----------------------------------
        # --- Afficher la notice            
        # ----------------------------------
        try:
            
            if contextID != "":
                i = self.mapID[contextID]    # Index de la ligne du sommaire
            else:
                i = 0
            
            self.form.openNotice(idx=i)
            
        except:
            self.form.txt_hlp['state'] = "normal"
            self.form.txt_hlp.delete("1.0", END)
            self.form.txt_hlp.insert(END, "(Impossible d'afficher la notice d'aide contextuelle)")
            self.form.txt_hlp['state'] = "disabled"
            self.form.lst_som.selection_clear(0, END) 
            return
        
        
        return
    
    
    
    def loadRawAdj(self):
        u"""
        Charge le fichier adj complet en texte brut
        pour l'éditer
        """
        
        self.txt_hlp.delete("1.0", END)
        
        self.txt_hlp.insert(END, self.file.read())
        
        return


    def terminate(self):
        u"""
        Fermer Adjutor et détruire sa fenêtre
        Nb : la destruction de la fenêtre doit être explicite car
        elle dérive de Tk et non de Toplevel
        """
        try:
            self.form.destroy()
        except:
            pass
        
        self = None
        
        return



class HelpForm(Tk):
    
    u"""
    Fenêtre d'aide
    """
    
    # Nb : classe derivée de Tk et non de Toplevel car sinon une fenêtre d'aide appelée         
    # depuis une boîte de dialogue modale serait aréactive                                      
    # Conséquences :                                                                            
    # - l'aide reste ouverte à la fermeture de l'application et il faut donc                    
    #   prévoir sa fermeture dans le code de celle-ci (appel de la méthode Adjutor.terminate() )
    # - des images d'interfaces sont utilisables en mode autonome mais si le module est appelé  
    #   par une application Tk-hôte il y a un bug dans l'indexation des objets images de Tcl... 
    
    
    
    def __init__(self, adj=None, contextID=""):
        u"""
        
        adj : l'objet Adjutor qui a appelé la fenêtre
        """
        
      
        Tk.__init__(self)
        
        self.adj = adj
        self.title(adj.title)
        self.focus_set()
        
        
        self.curidx = -1        # index de la notice courante
        self.historique = []    # pyListe des index des notices parcourues
        self.histcursor = 0     # curseur dans l'historique de navigation
        
        # Images de l'interface
        
        #self.img_flG = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAAX/BQCAAICAAAAAgADcAACAgMDAwICAgAC0AACMAP//AAAA//8A/wD/
        #/////yH5BAEAAA0ALAAAAAAQABAAAAQ6sMnZAL0XWIxB2NzkfaEYnFqqSuPpviRQzHRNa3Z+V0nv
        #/74NAEhMgACCpGpJQQpApcoz2oRSrdRQBAA7""")
        
        #self.img_flD = PhotoImage(data="""R0lGODlhEAAQALMAAAAAAAX/BQCAAICAAAAAgADcAACAgMDAwICAgAC0AACMAP//AAAA//8A/wD/
        #/////yH5BAEAAA0ALAAAAAAQABAAAAQ6sMkpAb0YWMxB2BzlfaJmmkEKjmnrkg1QzHRNW7Ktz1ri
        #/8AfLkhMbE5IgRIUAixDIgETqoFeptZQBAA7""")
        
        self.__makeToolBar() # Barre de menu/outils
        
        # --------------------------------------
        # --- Panneau redimensionnable général  
        # --------------------------------------
        
        self.panM=PanedWindow(self, orient=HORIZONTAL, sashpad=4, sashwidth=6, sashrelief=RAISED, height=500, width=500)
        self.panM.pack(side=LEFT,expand="yes",fill="both")
        
        # ---------------------
        # --- Panneau Gauche   
        # ---------------------
        
        self.fr_G=Frame(self.panM)
        self.panM.add(self.fr_G)
        
        # Liste de menu
        #(Nb : affecter une largeur initale faible puis redimensionner afin de ne pas masquer le scrollbar)
        self.lst_som=Listbox(self.fr_G, width=10, borderwidth=1, activestyle='none',
                                selectforeground='black', selectbackground='white', selectborderwidth=0,
                                highlightthickness=0, highlightcolor='white', highlightbackground='white',
                                exportselection=False, selectmode=SINGLE,
                                foreground='black', background="white", font="Helvetica 8 bold")
        self.lst_som.pack(side=LEFT, expand="yes", fill="both",)
        self.lst_som['cursor'] = "hand2"
        self.lst_som.bind('<ButtonRelease-1>', self.onClicSommaire)
        
        # Scrollbar de la liste de menu
        self.scr_lst = Scrollbar(self.fr_G, command=self.lst_som.yview)
        self.lst_som['yscrollcommand'] = self.scr_lst.set
        self.scr_lst.pack(side=LEFT, fill="both")
        
        # Charger le menu latéral
        self.__loadMenu()
        
        
        
        # ---------------------
        # ---Panneau Droit     
        # ---------------------
        
        self.fr_D=Frame(self.panM)
        self.panM.add(self.fr_D)
        
        # Zone de texte de l'aide 
        # (packée dans un Frame car ScrolledText est incompatible avec PanedWindow)
        self.txt_hlp=ScrolledText(self.fr_D, width=20, wrap=WORD, borderwidth=1, font="Helvetica 9 normal", background="white", state="disabled")
        self.txt_hlp.pack(side=LEFT, expand="yes", fill="both")
        
        # styles d'affichage de l'aide
        self.txt_hlp.tag_config("normal", lmargin1=13, lmargin2=13, spacing1=3, spacing3=2)
        self.txt_hlp.tag_config("pre", font="Courier 9 normal", lmargin1=13, lmargin2=13, spacing1=3, spacing3=2)
        self.txt_hlp.tag_config("h1", font="Helvetica 14 bold", lmargin1=2, lmargin2=2, spacing3=2)
        self.txt_hlp.tag_config("h2", font="Helvetica 12 bold", lmargin1=2, lmargin2=2, spacing1=3, spacing3=2)
        self.txt_hlp.tag_config("h3", font="Helvetica 10 bold", lmargin1=2, lmargin2=2, spacing1=3, spacing3=2)
        self.txt_hlp.tag_config("u", underline=1)
        self.txt_hlp.tag_config("b", font="Helvetica 9 bold")
        self.txt_hlp.tag_config("i", font="Helvetica 9 italic")
        self.txt_hlp.tag_config("bi", font="Helvetica 9 bold italic")
        self.txt_hlp.tag_config("small", font="Helvetica 8 bold")
        self.txt_hlp.tag_config("big", font="Helvetica 11 bold")
        
        self.txt_hlp.tag_config("a", foreground="blue", underline=1, lmargin1=13, lmargin2=13)
        self.txt_hlp.tag_bind("a","<ButtonRelease-1>", self.openLink)
        self.txt_hlp.tag_bind("a","<Enter>", self.enterLink)
        self.txt_hlp.tag_bind("a","<Leave>", self.leaveLink)
        
        
        return


    def __loadMenu(self, idxMapmenu=None):
        
        u"""
        Chargement dynamique du menu
        avec reconstruction de la table 'mapidxToID' (idx de menu > ID dans mapmenu)
        
        Le nouvel index de idxMapmenu dans la listbox est retourné
        """
        
        # structure de mapmenu :
        # [ ( <0. libellé sommaire>, <1.n° ligne fichier adj>, <2. niveau hiérarchique> , <3. ID>, <4. IDparent ) , (...) ]
        
        self.mapidxToID = [] # table index dynamique du sommaire > ID de la ligne correspondante
        

        self.lst_som.delete(0, END) # Vider le sommaire
        self.update()

        
        # ID du noeud parent à développer
        if not idxMapmenu is None:
            IDparent = self.adj.mapmenu[idxMapmenu][4]
        else:
            IDparent = ""
        
        n =0
        newidx = 0
        newindexclic = -1
        for ligne in self.adj.mapmenu:
            
            level = self.adj.mapmenu[n][2] # niveau hiérarchique
            
            if level == 1:
                flagaffiche = True
            elif level > 1 and self.adj.mapmenu[n][4] == IDparent: 
                flagaffiche = True    
            else:
                flagaffiche = False
                
            if flagaffiche:
                self.lst_som.insert(END, " " + self.adj.mapmenu[n][0])    # afficher le libellé dans la liste
                self.mapidxToID.append(self.adj.mapmenu[n][3])      # index sommaire > ID de la ligne
                newidx +=1
            n += 1
            if n == idxMapmenu:
                newindexclic = newidx
        
        return newindexclic


    def __makeToolBar(self):
        u"""
        Constuire la barre d'outils
        """
        x = 3
        y = 1
        ix = 0
        iy = 0
        
        tb = Frame(self)
        
        #self.bt_hDown = Button(tb, image=self.img_flG, borderwidth=1, relief=FLAT, command=self.__historyDown, height=20, width=20)
        self.bt_hDown = Button(tb, text=" << ", borderwidth=1, relief=FLAT, command=self.__historyDown, state="disabled", font='Helvetica 9 normal')
        self.bt_hDown.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        self.bt_hDown.bind("<Enter>", self.enterMenuButton)
        self.bt_hDown.bind("<Leave>", self.leaveMenuButton)
        
        #self.bt_hUp=Button(tb, image=self.img_flD, borderwidth=1, relief=FLAT, command=self.__historyUp, height=20, width=20)
        self.bt_hUp=Button(tb, text=" >> ", borderwidth=1, relief=FLAT, command=self.__historyUp, state="disabled", font='Helvetica 9 normal')
        self.bt_hUp.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        self.bt_hUp.bind("<Enter>", self.enterMenuButton)
        self.bt_hUp.bind("<Leave>", self.leaveMenuButton)
        
        tb.pack(anchor='w')
        
        return


    def __historyDown(self):
        u"""
        Afficher la notice précédente de l'historique
        """
        
        self.histcursor += 1
        
        idx = self.historique[self.histcursor] # Index de la notice à afficher
        
        print self.historique
        print self.histcursor
        print idx
        
        if self.histcursor >= len(self.historique)-1:
            self.bt_hDown['state'] = "disabled"
            self.bt_hDown['font'] = "Helvetica 9 normal"
        
        self.bt_hUp['state'] = "normal"
        self.bt_hUp['font'] = "Helvetica 9 bold"
        
        # Ouvrir la notice
        self.openNotice(idx=idx, noHist=True)
        
        
        return


    def __historyUp(self):
        u"""
        Afficher la notice suivante de l'historique
        """
        
        self.histcursor -= 1
        
        idx = self.historique[self.histcursor] # Index de la notice à afficher
        
        print self.historique
        print self.histcursor
        print idx
        
        if self.histcursor <= 0:
            self.bt_hUp['state'] = "disabled"
            self.bt_hUp['font'] = "Helvetica 9 normal"
        else:
            self.bt_hDown['state'] = "normal"
            self.bt_hDown['font'] = "Helvetica 9 bold"
            
        # Ouvrir la notice
        self.openNotice(idx=idx, noHist=True)
        
        
        return

    def enterMenuButton(self, event):
        u"""
        Entrée de la souris sur un bouton de menu
        > afficher les contours
        """
        
        if event.widget['state'] == "disabled":
            return
        
        event.widget['relief'] = RAISED 
        
        return
    
    def leaveMenuButton(self, event):
        u"""
        Sortie de la souris d'un bouton de menu
        > masquer les contours
        """
        
        event.widget['relief'] = FLAT
        
        return
    

    def resize(self, height=600, width=700, widthMenu=220):
        u"""
        Dimensionnement initial de la fenêtre
        """
        offsets = "+" + self.geometry().split("+",1)[1]
        self.geometry(str(width) + "x" + str(height) + offsets)
        
        self.panM.sash_place(0, widthMenu, 0)
        
        return

    def enterLink(self, event):
        
        self.txt_hlp['cursor'] = "hand2"
    
    def leaveLink(self, event):
        
        self.txt_hlp['cursor'] = ""
    

    def openLink(self, event):
        u"""
        Clic sur un lien
        """
        
        # Récupérer le texte du  lien
        #ins = self.txt_hlp.index(INSERT) + '+1c'
        pos = self.txt_hlp.tag_ranges("a")
        href=""
        
        for i in  range(len(pos)):
            
            if self.txt_hlp.compare(pos[i], ">", INSERT) :
                
                href = self.cibles[(i-1)/2]
                break
        
        # Ouvrir le lien
        
        if href !="":
            
            # Lien externe
            if href.startswith("http"):
                
                try:    webbrowser.open(href)
                except: pass
            # Lien interne
            else:
                
                # Réinitialiser le cursus dans l'historique
                self.histcursor = 0                 
                self.bt_hUp['state'] = "disabled"
                self.bt_hUp['font'] = "Helvetica 9 normal"   
                
                # Ouvrir la notice
                
                i = self.adj.mapID[href]    # index de la ligne de sommaire
                
                self.openNotice(idx=i)
                
                # Sélectionner le titre dans la liste du sommaire
                
                self.lst_som.activate(i)
                self.lst_som.selection_clear(0, END)
                self.lst_som.selection_set(i)
                self.lst_som.see(i)
                
                
                
                
                
        return


    def onClicSommaire(self, event):
        u"""
        Clic sur une ligne de sommaire
        """
        
        #self.lst_som.update()
      
        
        try:
            i = int(self.lst_som.curselection()[0])    # Index de la ligne cliquée dans la liste de sommaire
        except:
            return
        
        # ---------------------------------------------------------
        # --- Traduire cet index de sommaire en index dans mapmenu 
        # ---------------------------------------------------------
        
        ID = self.mapidxToID[i] # traduire l'index de listbox en ID
        i = self.adj.mapID[ID]  # traduire l'ID en index pour mapmenu
        
        
        # Réinitialiser le cursus dans l'historique
        self.histcursor = 0                 
        self.bt_hUp['state'] = "disabled"   
        self.bt_hUp['font'] = "Helvetica 9 normal"
        
        
        # Rafraichir graphiquement le menu (retourne le nouvel index dans la listbox)
        newindex = self.__loadMenu(idxMapmenu=i) 
        
        # Faire concorder la sélection dans le menu
        # avec la ligne cliquée antérieurement à son rafraichissement
        # > cauchemar ! Tk a des bogues...
        # remplacé par un affichage blanc sur blanc de la barre de sélection
        # nb : newindex est faut en fin de liste (à corriger)
        
        
        
        self.update()
        self.lst_som.selection_clear(0, END)
        self.txt_hlp.focus_set()
        self.update()
        
        
        # Ouvrir la notice
        self.openNotice(idx=i)      
        
        
        return
    
    
    def openNotice(self, idx=None, noHist=False):
        u"""
        Ouvrir une notice par son ID ou son index menu 'idx'
        
        si noHist est True, il n'y a pas d'inscription dans l'historique
        """
        
        # ---------------------------------------------
        # --- Réinitialiser l'affichage de la notice   
        # ---------------------------------------------
        
        self.adj.file.seek(0)
        
        self.txt_hlp['state'] = "normal"
        self.txt_hlp.delete("1.0", END)
        
        
        # --------------------------------------------------------------------
        # --- Déduire le n° de ligne à partir de l'index de la notice         
        # --------------------------------------------------------------------
        
        nl = self.adj.mapmenu[idx][1]   # N° de la ligne de début de la notice
        
        
        # ------------------------------
        # --- Lire la notice            
        # ------------------------------
        
        n=0
        for ligne in self.adj.file:
            if n >= nl:
                
                if ligne.startswith(";ID"): # La lecture s'arrête au début de la notice suivante
                    break
                
                elif ligne.startswith("===="):
                    self.txt_hlp.tag_add("h1", INSERT + "-1l", INSERT + "+1l") 
                    
                elif ligne.startswith("----"):
                    self.txt_hlp.tag_add("h2", INSERT + "-1l", INSERT + "+1l") 
                    
                elif ligne.startswith("...."):
                    self.txt_hlp.tag_add("h3", INSERT + "-1l", INSERT + "+1l") 
                    
                elif ligne.startswith("::"):
                    self.txt_hlp.insert(END, ligne[2:], "pre")
                    
                elif ligne.startswith(";"):
                    pass
                
                else:
                    self.txt_hlp.insert(END, ligne, "normal")
                   
            n += 1
        
        
        
        # ----------------------------------------------------
        # --- Vérifier si la notice suivante est indentée,    
        # --- si oui, on inscrit un menu en fin de notice     
        # ----------------------------------------------------
        
        levelbase = self.adj.mapmenu[idx][2]
        
        try:
            level = self.adj.mapmenu[idx+1][2]
            
            i = 1
            while level == levelbase + 1:
                self.txt_hlp.insert(END, "   - <a>"+ self.adj.mapmenu[idx+i][0].strip() + "|" + self.adj.mapmenu[idx+i][3] + "</a>\n", "normal")
                i += 1
                try:
                    level = self.adj.mapmenu[idx+i][2]
                except IndexError:
                    break
        except:
            pass
        
        
        # -----------------------------------------------------------
        # --- Traiter les balises de format (gras, italique, ...)    
        # -----------------------------------------------------------
        
        self.ctags() 
        
        self.txt_hlp['state'] = "disabled"  # Désactiver la saisie 
        
        
        # --- Sélectionner le titre dans la liste du sommaire
        self.lst_som.selection_clear(0, END)
        self.lst_som.activate(idx)
        self.lst_som.selection_set(idx)
        self.lst_som.see(idx)
        
        
        # ---------------------------------------------
        # --- Compléter l'historique                   
        # ---------------------------------------------
        if not noHist:
        
            if len(self.historique):
                if idx != self.historique[0]:
                    self.historique.insert(0, idx)
            else:
                self.historique.insert(0, idx)
                
                
            self.historique = self.historique[:20] # Limiter le contenu de l'historique
            
            if len(self.historique) > 1:
                self.bt_hDown['state'] = "normal"
                self.bt_hDown['font'] = "Helvetica 9 bold"
        
        # ---
        
        self.curdix = idx
        
        return


    def ctags(self):
        u"""
        1)Affecte des tags Tk associés aux balises de format de police
        
        2) Remplace les balises <br> par des sauts de ligne
        
        3) Construit une pyListe de cibles de lien
        
        """
        
        w = self.txt_hlp
        
        self.cibles = []
        
        # ----------------------------------
        # --- Balises de format de police   
        # ----------------------------------
        
        # Nb : la protection des "*" littéraux par "\" est gérée
        
        for name1Tag, name2Tag, nameStyle in (  
                                            ("***","***","bi"),
                                            ("**","**","b"),
                                            ("*","*","i"),
                                            ("<u>","</u>","u"),
                                            ("<big>","</big>","big"),
                                            ("<small>","</small>","small")
                                            ):
            
            idx1 = "1.0"
            idx2 = "1.0"
            
            while idx1 != "":
                idx1 = w.search(name1Tag, idx2, stopindex=END)
                
                if idx1 == "":
                    break
                
                if w.get(str(idx1) + "-1c") == "\\":                        # Présence d'un caractère d'échappement
                    w.delete(str(idx1) + "-1c")                             # Effacer le caractère d'échappement
                    idx2 = str(idx1) + "+1c"
                    continue
                
                w.delete(idx1, str(idx1) + "+" + str(len(name1Tag)) +"c")   # effacer la balise ouvrante
                
                idx2 = w.search(name2Tag, idx1, stopindex=END)
                
                if idx2 == "":                                              # pas de balise fermante
                    idx2 = END
                else:
                    w.delete(idx2, str(idx2) + "+" + str(len(name2Tag)) +"c") # effacer la balise fermante
                
                
                w.tag_add(nameStyle, idx1, idx2)                            # affecter le tag-style
        
        
        # -------------------------
        # --- Balises de liens     
        # -------------------------
        
        idx1 = "1.0"
            
        while idx1 != "":
            idx1 = w.search("<a>", "1.0", stopindex=END)
            
            if idx1 == "":
                break
            
            idx2 = w.search("</a>", idx1, stopindex=END)
            
            # Récupérer le texte du lien et la cible
            txt = w.get(str(idx1) + "+3c", idx2).split("|")
            lien = txt[0]
            cible = ""
            try   : cible=txt[1]
            except: pass
            if cible == "": # Si pas de cible mentionnée > le texte de lien sert de cible
                cible = lien
            
            self.cibles.append(cible)
            
            # effacer les balises et le contenu
            w.delete(idx1, str(idx2) + "+4c")
            
            # Remplacer le contenu
            w.insert(idx1, lien, "a")
            
        
        return



# ===============================================
# === MAIN (mode autonome)                       
# ===============================================
if __name__=='__main__':
    
    print '# # # MODE AUTONOME # # #'
    
    hlp = Adjutor(os.path.join("..", "hlp", "fr.adj"))
    
    hlp.showHelp()
    
    mainloop()