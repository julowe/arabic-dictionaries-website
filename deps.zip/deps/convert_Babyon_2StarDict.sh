#!/bin/bash

for file in *.bgl
do
	./bgl2txt -s utf-8 -t utf-8 "$file"
done

for file in *.babylon
do
	./babylon "$file"
	rm -rfv "$file"
done

exit $?
