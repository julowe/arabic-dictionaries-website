#!/usr/bin/env python
# -*- coding:utf-8 -*-
# ===========================================================================
# ===                                                                        
# ===   MODULE DE LANGUE DE L'INTERFACE                                      
# ===                                                                        
# ===   Les chaînes sont stockées dans des pyDictionnaires                   
# ===   simulant une structure : [section] clef=valeur                       
# ===                                                                        
# === Le nom convivial de la langue est dans le pseudo commentaire #lg_name# 
# ===                                                                        
# ===========================================================================
#lg_name# Français
g = {
 "close"    : "Fermer",
 "hlp"      : "Aide",
 "cncl"     : "Annuler",
 "brw"      : "Parcourir...",
 "cpy"      : "Copier",
 "pst"      : "Coller",
 "opn"      : "Ouvrir",
 "adv"      : "Avancé",
 "basic"    : "Basique",
 "loadfst"  : u"Chargez d'abord un dictionnaire !",
 "enclst"   : u"\tcp1252 (Windows - Europe de l'Ouest)\n\tcp1250 (Windows - Europe centrale)\n\tcp1251 (Windows - cyrillique\n\tcp1253 (Windows - grec)\n\tcp1254 (Windows - turc)\n\tetc...",
 "id1"      : u"est un identifiant qui existe déjà dans le dictionnaire.\n\nChaque identifiant doit être unique dans le dictionnaire.",
 "msg1"     : u"Les fonctions audio de cette application nécessitent que la bibliothèque Snack (licence GNU-GPL) soit installée.",
 "msg2"     : u"Snack pour Windows est joint au paquetage de Linguae et son installation manuelle est très simple.",
 "msg3"     : u"Toutes les fonctions audio de Linguae seront désactivées tant que cette bibliothèque ne sera pas installée.\n\nVoulez-vous afficher l'aide pour plus de détails ?",
 "msg4"     : u"Bibliothèque audio non accessible",
 "msg5"     : u"(1 de 2)",
 "msg6"     : u"(2 de 2)",
 "fmp3"     : "Fichiers MP3",
 "fwav"     : "Fichiers Wave",
 "faudio"   : "Fichiers audio",
 "fgif"     : "Fichiers GIF",
 "fjpeg"    : "Fichiers JPEG",
 "fpng"     : "Fichiers PNG",
 "fbmp"     : "Fichiers BMP",
 "ftiff"    : "Fichiers TIFF",
 "fgraph"   : "Fichiers graphiques",
 "fall"     : "Tous les fichiers",
 "ftxt"     : "Fichiers texte",
 "fling"    : "Fichiers Ling",
 "fwb"      : "Fichiers WB",
 "fdict"    : "Fichiers Stardict",
 "fddz"     : "Fichiers Stardict compressés",
 "flim"     : "Fichiers délimités",
 "fini"     : "Fichiers INI",
 "fxdxf"    : "Fichiers XDXF",
 "ftei"     : "Fichiers TEI",
 "fdictd"   : "Fichiers Freedict",
 "fsup"     : "Fichiers tous formats supportés",
 "fpy"      : "Fichiers Python",
 "fsqlite"  : "Fichiers SQLite-3",
}
# ----------------------------------------
# --- Messages de l'objet dictionnaire ---
# ----------------------------------------
dic = {
 "msg1"     : u"Charger un dictionnaire",
 "msg2"     : u"Impossible de lier la barre de progression",
 "msg3"     : u"Echec du chargement du dictionnaire.",
 "msg4"     : u"Ce fichier est introuvable !",
 "msg5"     : u"Ce fichier n'a pas un format reconnu par Linguae.",
 "msg6"     : u"L'identifiant",
 "msg7"     : u"est doublonné.\n\nUn identifiant doit être unique dans un dictionnaire !\nVeuillez corriger les données (menu Edition) ou signaler cette erreur à l'auteur du dictionnaire.\n\nContinuer le chargement du dictionnaire ?",
 "msg8"     : u"Impossible de charger le fichier *.ifo",
 "msg9"     : u"Ce dictionnaire est de sous-type",
 "msg10"    : u"Ce sous-type du format Dict n'est pas encore pris en charge par Linguae.",
 "msg11"    : u"Impossible d'ouvrir le fichier index *.idx",
 "msg12"    : u"Impossible d'ouvrir le fichier des données *.dict",
 "msg14"    : u"Erreur au chargement d'un dictionnaire DICT compressé : impossible d'ouvrir le fichier temporaire.",
 "msg15"    : u"Ouverture d'un fichier WB",
 "msg16"    : u"Les fichiers WB sont encodés sur 8-bits\net ne contiennent aucune information sur l'encodage des caractères...\n\nPour un affichage correct, il est donc nécessaire de préciser manuellement\nl'encodage de la langue source ET celui de la langue cible.\n\nLes encodages les plus couramment utilisés pour ce format sont :",
 "msg17"    : u"Précisez tout d'abord l'encodage de la LANGUE SOURCE dans ce fichier WB :",
 "msg18"    : u"Précisez ensuite l'encodage de la LANGUE CIBLE dans ce fichier WB :",
 "msg19"    : u"Ce fichier WB a pu être ouvert mais l'encodage choisi pour la langue source est incorrect,\nl'affichage de certains caractères sera probablement erroné.\n\nPour rectifier cela, fermez ce dictionnaire et rouvrez-le en choisissant un autre encodage.\n\nEncodage choisi :",
 "msg20"    : u"Les fichiers délimités ne contiennent aucune information\nsur l'encodage des caractères...\n\nPour un affichage correct, il est donc nécessaire de\n préciser manuellement l'encodage originel de ce fichier.\n\nNb : les encodages 8-bits les plus couramment utilisés pour ce format sont :",
 "msg21"    : u"Impossible de déterminer le séparateur des champs de ce fichier.\n\nChargement impossible !",
 "msg22"    : u"Ce fichier a pu être ouvert mais l'encodage choisi est incorrect,\nl'affichage de certains caractères sera probablement erroné.\n\nPour rectifier cela, fermez ce dictionnaire et rouvrez-le en choisissant un autre encodage.\n\nEncodage choisi :",
 "msg23"    : u"Charger un fichier INI",
 "msg24"    : u"Les fichiers INI ne contiennent aucune information\nsur l'encodage des caractères...\n\nPour un affichage correct, il est donc nécessaire de\n préciser manuellement l'encodage originel de ce fichier.",
 "msg25"    : u"Une erreur de décodage/encodage est survenue\npour l'entrée d'index",
 "msg26"    : u"! Erreur de décodage",
 "msg27"    : u"! Preling > Ling : Ligne sans traduction :",
 "msg28"    : u"L'ajout de la traduction courte a échoué :",
 "msg29"    : u"! Erreur concaténation Preling !",
 "msg30"    : u"Ce dictionnaire est au format DICT compressé, il ne peut être modifié.\n\nPour déplacer une de ses entrées, vous devrez d'abord le convertir au format DICT non compressé\nou tout autre format géré par Linguae (Menu 'Fichier' > 'Exporter').",
 "msg31"    : u"Déplacer une entrée",
 "msg32"    : u"Les entrées de ce type de dictionnaire ne sont pas déplaçables",
 "msg33"    : u"Du fait de sa structure hiérarchique, un dictionnaire au format INI\nne peut être trié",
 "msg34"    : u"Ce dictionnaire est au format DICT compressé, il ne peut être modifié.\n\nPour le trier, vous devrez d'abord le convertir au format DICT non compressé\nou tout autre format géré par Linguae (Menu 'Fichier' > 'Exporter').",
 "msg35"    : u"Ce type de dictionnaire n'est pas triable",
 "msg36"    : u"Ce fichier n'est pas un fichier Ling valide !",
 "msg37"    : u"Le chargement va se poursuivre mais la propriété suivante est incorrecte :",
}
# --------------------------------------------------
# --- Fenêtre principale (sauf menus déroulants) ---
# --------------------------------------------------
win1 = {
 "msg1"     : u"Ecouter la prononciation",
 "msg2"     : u"Les fonctions audio de Linguae sont désactivées.\n\nVérifiez l'installation correcte de la librairie audio 'Snack'.",
 "msg3"     : u"Echec de la lecture du fichier audio !",
 "msg4"     : u"Vérifier la version du dictionnaire",
 "msg6"     : u"Rechercher une nouvelle version du dictionnaire",
 "msg7"     : u"Echec de la connexion Internet pour ce dictionnaire",
 "msg8"     : u"La version utilisée du dictionnaire est la plus récente disponible.",
 "msg9"     : u"Une nouvelle version est disponible en téléchargement\n\nVersion locale :",
 "msg10"    : u"Version téléchargeable :",
 "msg11"    : u"Désirez-vous vous connecter au site Web du dictionnaire ?",
 "msg12"    : u"Echec de la connexion Internet.\n\nLa vérification du numéro de version du programme n'a pu être effectuée.",
 "msg13"    : u"La version utilisée du programme est la plus récente disponible :",
 "msg14"    : u"Rechercher une nouvelle version du programme",
 "msg15"    : u"Désirez-vous vous connecter au site Web de Linguae pour la télécharger ?",
 "msg16"    : u"Télécharger une nouvelle version de Linguae",
 "msg17"    : u"Echec de la connexion au site Web de Linguae.",
 "msg18"    : u"Connexion au site Web de Linguae",
 "msg19"    : u"Dictionnaires sur le Web",
 "msg20"    : u"Linguae va vous connecter au site du Projet POLYGLOTTE.\n\nLe but de celui-ci est, entre autres, de regrouper et centraliser un maximum de liens vers des dictionnaires numériques d'accès libre.\n\nConsultez en particulier la section 'Dictionnaires bilingues' de ce site.\n\n\nContinuer ?",
 "msg21"    : u"Fonctionnalité non disponible sur cette plateforme.\n\nVeuillez contacter l'auteur à",
 "msg22"    : u"à l'aide de votre logiciel de courrier habituel.",
 "msg23"    : u"Supprimer une entrée de dictionnaire",
 "msg24"    : u"Déplacer une entrée de dictionnaire",
 "msg25"    : u"Sélectionnez d'abord une entrée !",
 "msg26"    : u"Index actuel de l'entrée :",
 "msg27"    : u"Indiquez le nouvel index désiré\ndans l'intervalle suivant :",
 "msg28"    : u"Valeur incorrecte !\n\nL'index cible doit être un chiffre entre 0 et",
 "msg29"    : u"Etes-vous sûr de vouloir supprimer l'entrée d'index n°",
 "msg30"    : u"La suppression sera irréversible.\n\nConfirmer ?",
 "msg31"    : u"Ce dictionnaire est au format DICT compressé, il ne peut être modifié.\n\nPour l'éditer, vous devrez d'abord le convertir au format DICT non compressé\nou tout autre format géré par Linguae (Menu 'Fichier' > 'Exporter').",
 "msg32"    : u"Ouvrir le dictionnaire inverse",
 "msg33"    : u"Chargez d'abord un dictionnaire de référence !",
 "msg34"    : u"Echec du chargement du dictionnaire :",
 "msg35"    : u"Echec de l'ouverture automatique d'un dictionnaire.",
 "msg36"    : u"Ouvrir un dictionnaire",
 "msg37"    : u"Echec du chargement d'un greffon",
 "msg38"    : u"Le plugin/greffon",
 "msg39"    : u"n'a pas pu être chargé.",
 "msg40"    : u"Convertir un fichier graphique en chaîne base64",
 "msg41"    : u"Cet outil permet de convertir un fichier graphique quelconque en format texte suivant le codage standard \"base64\". Ce format texte est celui-ci accepté par Linguae pour insérer des icônes de dictionnaire dans un fichier texte d'importation d'un dictionnaire.\n\nContinuer ?",
 "msg42"    : u"Ce fichier n'est pas un fichier GIF standard",
 "msg43"    : u"Ce fichier n'est pas un fichier GIF !",
 "msg44"    : u"Conversion effectuée avec succès.\n\nLe texte base64 de l'image a été copié dans le presse-papiers.",
 "msg46"    : u"Quitter Linguae",
 "msg47"    : u"Merci de signaler tout problème rencontré à :\n\n\tlinguae@stalikez.info",
 "msg48"    : "Au revoir...",
 "msg49"    : u"ATTENTION, certains dictionnaires peuvent être sous licence et sujets à des droits d'auteur.\nLeur diffusion sous une autre forme que le fichier original est peut-être interdite.\n\nToute modification de contenu ou de format ne peut, dans ce cas, être effectuée que dans un cadre strictement privé\net sans aucune diffusion secondaire.\n\nVeuillez, en cas de doute, vous reporter aux licences respectives des dictionnaires qui ne vous sont pas personnels.\n\nContinuer ?",
 "msg50"    : u"Du fait de la structure hiérarchique du format INI\nun dictionnaire inverse ne peut être construit", 
 "msg51"    : u"Type de dictionnaire non spécifié. Extraction impossible !",
 "msg52"    : u"L'extraction des modifications n'est possible que pour un dictionnaire au format Ling.",
 "msg53"    : u"Type de dictionnaire non spécifié. Exportation impossible !",
 "msg54"    : u"L'ajout ou la modification des icônes n'est possible que pour les dictionnaires au format Ling.\n\nVous devez d'abord convertir le dictionnaire à ce format avant d'intégrer des icônes à ce dictionnaire.",
 "msg55"    : u"Cette fonction n'est disponible qu'après avoir défini un dossier des dictionnaires (voir : Options)",
 "msg57"    : u"Le greffon a été installé avec succès.\nIl est disponible dans le menu des greffons.",
 "msg58"    : u"Le dictionnaire inverse est introuvable !\n\nVoulez construire le dictionnaire inverse maintenant ?\n\nNB : si vous répondez 'non', il sera toujours possible de construire le dictionnaire inverse\nen utilisant la commande appropriée du menu 'Fichier'.",
 "msg59"    : u"Voulez-vous recopier ce dictionnaire dans votre dossier de stockage des dictionnaires ?",
 "msg60"    : u"Le numéro de version de ce dictionnaire inverse ne correspond pas à celui du dictionnaire source.\n\nIl serait peut-être préférable de vous procurer une version à jour du dictionnaire inverse.\n\nSi une nouvelle version n'est pas disponible, vous pouvez reconstruire automatiquement le dictionnaire inverse (voir Menu Fichier).",
 "msg61"    : u"Cette fonction n'est disponible que pour un dictionnaire au format Ling.",
 "ib1"      : "Recherche rapide : tapez un début de mot",
 "ib7"      : "Index de l'entrée sélectionnée",
 "ib8"      : "Identifiant de l'entrée sélectionnée",
 "ib9"      : "Encodages de l'entrée sélectionnée",
 "ib10"     : "Dictionnaire non protégé",
 "ib11"     : "Ouvrir un dictionnaire",
 "ib12"     : "Propriétés du dictionnaire",
 "ib13"     : "Exporter le dictionnaire",
 "ib14"     : "Ouvrir le dictionnaire inverse",
 "ib15"     : "Chercher dans les entrées de dictionnaire",
 "ib16"     : "Editer l'entrée de dictionnaire",
 "ib17"     : "Ajouter une nouvelle entrée de dictionnaire",
 "ib18"     : "Supprimer l'entrée de dictionnaire sélectionnée",
 "ib19"     : "Trier le dictionnaire",
 "ib20"     : "Afficher la table des caractères",
 "ib21"     : "Voir l'aide de Linguae",
 "ib22"     : "Dictionnaire protégé",
 "ib23"     : "Langue source :",
 "ib24"     : "Langue cible :",
 "ib25"     : "Historique de navigation",
 "s1"       : "Traduction & Définition",
 "s2"       : "(greffon : aucun)",
 "s3"       : "Ecouter",
 "s5"       : "Racines :",
 "s6"       : "Synonymes :",
 "s7"       : "Antonymes :",
 "s8"       : "Voir aussi :",
 "s9"       : "Aucun greffon n'est actuellement chargé.\n\nPour charger un greffon, utilisez le menu 'Greffons'.\n\nPour ajouter un greffon à Linguae, utilisez le menu 'Greffons'>'Importez un greffon...'.",
 "s10"      : "A propos de votre dictionnaire",
}
# ------------------------
# --- Menus déroulants ---
# ------------------------
menu = {
 "mfich"    : "Fichier",
    "m1"    : "Ouvrir un dictionnaire...",
    "m2"    : "Créer un nouveau dictionnaire...",
    "m3"    : "Propriétés...",
    "m3b"   : "Copier sous...",
    "m4"    : "Importer Preling...",
    "m4b"   : "Importer...",
    "m5"    : "Exporter...",
    "m6"    : "Construire le dictionnaire inverse...",
    "m7"    : "Voir le dictionnaire inverse...",
    "m7b"   : "Télécharger des dictionnaires...",
    "m8"    : "Quitter",
 "mdic"     : "Dictionnaires",
    "m9"    : "(Aucun dictionnaire)",
    "m9b"   : "Ouvrir le dossier des dictionnaires...",
    "m34"   : '(chemin non paramétré : voir "Options")',
 "msearch"  : "Chercher",
 "medit"    : "Edition",
    "m10"   : "Trier le dictionnaire...",
    "m11"   : "Editer l'entrée de dictionnaire...",
    "m12"   : "Supprimer l'entrée...",
    "m13"   : "Déplacer l'entrée...",
    "m14"   : "Ajouter une nouvelle entrée...",
    "m15"   : "Table des caractères...",
    "m16"   : "Modifier les icônes du dictionnaire...",
 "mopt"     : "Options",
    "m17"   : 'Passer à la ligne les " ; "',
    "m17a"  : "Toujours au premier plan",
    "m18"   : "Transparence...",
    "m19"   : "Préférences...",
 "mtools"   : "Outils",
    "m20"   : "Aide à la traduction...",
    "m21"   : "Construire un dictionnaire par héritage...",
    "m21b"  : "Contrôler les liens du dictionnaire...",
    "m22"   : "Extraire les modifications du dictionnaire...",
    "m23"   : "Convertir une image en base64...",
 "mplug"    : "Greffons",
    "m24"   : "Aucun",
    "m24a"  : "Importer un greffon...",
 "mhlp"     : "Aide",
    "m25"   : "A propos de Linguae...",
    "m26"   : "Aide de Linguae...",
    "m27"   : "Site Web de Linguae...",
    "m28"   : "Rechercher une nouvelle version de Linguae...",
    "m29"   : "A propos de ce dictionnaire...",
    "m30"   : "Contacter l'auteur de ce dictionnaire...",
    "m31"   : "Site Web de ce dictionnaire...",
    "m32"   : "Rechercher une nouvelle version de ce dictionnaire...",
    "m33"   : "Chercher des dictionnaires sur le Web..."
}
# -------------------------------
# --- Fenêtre de transparence ---
# -------------------------------
winalpha = {
 "title"     : u"Réglage de la transparence",
 "warning"   : "Nb : la commande de transparence ne fonctionne pas sur toutes les plateformes\n et produit des résultats d'intensité variable suivant les cartes graphiques",
 "fail"      : "Echec de l'activation de la transparence",
}
# -----------------------------------
# --- Fenêtre d'inversion de dico ---
# -----------------------------------
winrev = {
 "title"    : u"Construire le dictionnaire inverse",
 "msg1"     : u"Ce dictionnaire est déjà un dictionnaire issu d'une inversion automatique !",
 "msg2"     : u"Les propriétés de ce dictionnaire ne mentionnent pas que ses données sont destinées à être inversées.",
 "msg3"     : u"Son inversion risque donc d'aboutir à un résultat très médiocre.\n\nContinuer quand même ?",
 "msg4"     : u"Les données de ce dictionnaire sont protégées,\nle format du dictionnaire inverse sera obligatoirement le format Ling\net le dictionnaire inverse sera lui aussi protégé.", 
 "msg5"     : u"Un fichier existe déjà sous ce nom. Désirez-vous le remplacer ?",
 "msg6"     : u"Création d'un nouveau fichier WB",
 "msg7"     : u"Les fichiers WB sont encodés sur 8-bits\net ne contiennent aucune information sur l'encodage des caractères...\n\nPour un affichage correct, il est donc nécessaire de préciser manuellement\nl'encodage de la langue source ET celui de la langue cible.\n\nPrécisez tout d'abord l'encodage désiré pour la LANGUE SOURCE du fichier WB à créer :",
 "msg9"     : u"Précisez ensuite l'encodage désiré pour la LANGUE CIBLE dans ce nouveau fichier WB :",
 "msg10"    : u"Echec de la construction du dictionnaire inverse",
 "msg11"    : u"Impossible d'inscrire le nom du dictionnaire inverse dans le dictionnaire-source\npour la raison suivante :",
 "msg12"    : u"Le dictionnaire a été inversé avec succès",
 "s1"       : "Format du dictionnaire inverse :",
 "s2"       : "CSV (fichier texte tabulé)",
 "s3"       : "Séparateur des traductions individuelles dans le dictionnaire source :",
 "s4"       : "Point-virgule",
 "s5"       : "Virgule",
 "s6"       : "Mode d'inversion :",
 "s7"       : "Inverser en négligeant les infos et traductions longues",
 "s8"       : "Inverser en conservant, sans inversion, les infos et traductions longues",
 "s9"       : "Dossier du dictionnaire inverse :",
 "s11"      : "Créer dans le dossier des dictionnaires",
 "s12"      : "Nom du fichier du dictionnaire inverse :",
 "s13"      : "Construire",
 "s14"      : "! Echec d'encodage !",
 "s15"      : "Nouveau dictionnaire inverse",
 "s16"      : "(Dictionnaire inversé automatique - consultez le dictionnaire original pour les informations de licence)",
 "s17"      : "Ce dictionnaire inverse a été créé par un processus automatique et ne peut prétendre à la précision et à la correction d'un dictionnaire rédigé manuellement.",
 "s18"      : "(Dictionnaire inversé automatique)",
 "s19"      : "! Echec d'encodage utf-8 dans le fichier *.ifo !",
}
# --------------------------------
# --- Fenêtre de table UNICODE ---
# --------------------------------
winuni = {
 "title"    : u"Table de caractères UNICODE",
 "s1"       : "Police de la langue source",
 "s2"       : "Police de la langue cible",
 "s3"       : "Choisissez une sous-table dans la liste",
 "s4"       : "Si cette police ne prend pas en charge les caractères désirés,\nvous devez choisir une autre police d'affichage par défaut (Options)\nou modifier les polices spécifiques du dictionnaire (Propriétés du dictionnaire)",
 "s5"       : "Double-cliquez sur un caractère pour l'ajouter",
}
# --------------------------------------
# --- Fenêtre de tri du dictionnaire ---
# --------------------------------------
winsort = {
 "title"    : u"Trier le dictionnaire",
 "s1"       : "Vous pouvez personnaliser le tri du dictionnaire\nen ajoutant dans la liste de gauche des équivalences\nde caractères pour le tri alphabétique, suivant\nla syntaxe suivante :\n\n <motif de caractères du dico>=<motif de caractères équivalents>\nUne équivalence par ligne.\n\nExemple : ö = oe\n(signifie que le caractère ö sera trié comme s'il s'agissait de 'oe')\n\nSymboles :\n\t'$$' : espace\n\t'%%' : absence de caractère",
 "s2"       : "Si la liste reste vide, les critères de tri alphabétique par défaut\nde votre plateforme seront appliqués au dictionnaire.",
 "s3"       : "Sauvegarder les paramètres de tri",
 "s4"       : "Trier",
 "s5"       : "Restaurer l'ordre de tri antérieur",
 "s6"       : "Trier en ordre Ascii strict (sans utiliser les équivalences de tri)",
 "msg1"     : u"La sauvegarde des équivalences de tri est impossible car le répertoire de ressources ne peut être créé.\n\nVérifiez les droits en écriture sur le répertoire du dictionnaire.",
}
# -------------------------------------------------
# --- Fenêtre de recherche dans le dictionnaire ---
# -------------------------------------------------
winfnd = {
 "title"    : u"Chercher dans le dictionnaire",
 "msg1"     : u"le début du dictionnaire est atteint.",
 "msg2"     : u"la fin du dictionnaire est atteinte.",
 "msg3"     : u"La chaîne",
 "msg4"     : u"est introuvable",
 "msg5"     : u"Enregistrer les résultats de recherche sous...",
 "s1"       : "Précédent",
 "s2"       : "Suivant",
 "s3"       : "Options",
 "s4"       : "Recherche sensible à la casse",
 "s5"       : "Recherche en début des entrées",
 "s6"       : "Recherche sensible aux ligatures (œ, æ, ...)",
 "s7"       : "Domaine de recherche",
 "s8"       : "Entrées",
 "s9"       : "Notices",
 "s10"      : "Identifiants (wordIDs)",
 "s11"      : "Recherche par expression rationnelle",
 "s12"      : "Chercher tout",
 "s13"      : "Type de recherche",
 "s14"      : "Recherche itérative",
 "s15"      : "Afficher les résultats comme une liste d'entrées",
 "s16"      : "Mot entier uniquement",
 "s17"      : "Attributs",
}
# ------------------------------------------------
# --- Fenêtre de gestion des images ressources ---
# ------------------------------------------------
winimg = {
 "title"    : u"Gérer les illustrations",
 "s1"       : "Liste des images :",
 "msg1"     : u"Supprimer l'image sélectionnée ?",
}
# -------------------------------------
# --- Fenêtre d'importation Preling ---
# -------------------------------------
winimp = {
 "title"    : "Importer un pré-dictionnaire formaté",
 "msg1"     : u"Vous devez choisir un fichier à importer !",
 "msg2"     : u"Ce fichier cible existe déjà.\n\nVoulez-vous le remplacer ?",
 "msg3"     : u"Entrez le chemin d'un fichier source à importer !\n\nPressez le bouton 'Parcourir' pour rechercher sur le disque.\n\nTout fichier texte tabulé, CSV ou au format Preling est valide.",
 "msg4"     : u"Document source introuvable !",
 "msg5"     : u"La conversion en Ling à échouée, pour la raison suivante :",
 "msg6"     : u"Echec de l'enregistrement du fichier,\nvérifiez la validité du nom de fichier.",
 "msg7"     : u"L'importation avec conversion au format Ling a été effectuée avec succès.\n\nVoulez-vous ouvrir le nouveau dictionnaire ?",
 "s1"       : "(voir l'aide pour les spécifications du format d'importation CSV ou Preling)",
 "s2"       : "Fichier source",
 "s3"       : "Chemin du fichier texte formaté à importer :",
 "s4"       : "Nb : cet encodage et ce séparateur ne seront pris en compte que si le document\nne contient aucune directive explicite à leur sujet.",
 "s5"       : "Fichier cible",
 "s6"       : "Nom du fichier cible :",
 "s7"       : "Créer le fichier *.ling dans le dossier du fichier à importer",
 "s8"       : "Créer le fichier *.ling dans le dossier des dictionnaires",
 "s9"       : "[NON ENCORE DEFINI]",
 "s10"      : "Importer",
 "s11"      : "Importer le contenu du presse-papiers",
 "s12"      : "Encodage du texte à importer :",
 "s13"      : "Séparateur des données :",
}
# ---------------------------------------------
# --- Fenêtre d'importation format non géré ---
# ---------------------------------------------
winimpx = {
 "title"    : "Importer un dictionnaire",
 "s1"       : "IMPORTANT : ce module sert à ouvrir des dictionnaires en format importable par Linguae\nmais NON géré nativement par ce dernier.\nPour ouvrir un dictionnaire en format géré, utilisez le menu 'Fichier > Ouvrir'.\nPour importer un pré-dictionnaire, utilisez le menu 'Fichier > Importer Preling'.",
}
# -----------------------------------------
# --- Fenêtre des infos du dictionnaire ---
# -----------------------------------------
wininf = {
 "title"    : u"A propos de ce dictionnaire...",
 "s1"       : "Version",
 "s2"       : "Informations :",
 "s3"       : "Statut et Licence :",
 "s4"       : "Auteur(s) :",
 "s5"       : "Autres auteur(s) :",
 "s6"       : "Contact :",
 "s7"       : "Références bibliographiques :",
 "s8"       : "Plus d'infos...",
}
# -----------------------------------------------------
# --- Fenêtre de création d'un nouveau dictionnaire ---
# -----------------------------------------------------
winnew = {
 "title"    : "Créer un nouveau dictionnaire",
 "s1"       : "Format du nouveau dictionnaire :",
 "s2"       : "(fichier texte tabulé)",
 "s3"       : "Dossier du nouveau dictionnaire :",
 "s4"       : "Créer dans le dossier des dictionnaires",
 "s5"       : "Nom du fichier du nouveau dictionnaire :",
 "s6"       : "Créer",
 "msg1"     : u"Impossible de créer le nouveau dictionnaire.\nUn fichier existe déjà sous ce nom !",
 "msg2"     : u"Echec de la création du nouveau dictionnaire :\nErreurs d'encodage utf-8 dans le fichier *.ifo",
}
# ---------------------------
# --- Fenêtre des options ---
# ---------------------------
winopt = {
 "title"    : u"Préférences",
 "s1"       : "Polices",
 "s2"       : "Chemins",
 "s2b"      : "Couleurs",
 "s3"       : "Divers",
 "s4"       : "Police actuelle des dictionnaires :",
 "s5"       : "Nouvelle Police des dictionnaires :",
 "s6"       : "Taille :",
 "s7"       : "Police actuelle des traductions :",
 "s8"       : "Nouvelle Police des traductions :",
 "s8b"      : "Polices par défaut",
 "s9"       : "Chemin par défaut de recherche des dictionnaires :",
 "s10"      : "Chemin du dossier lié au menu \"Dictionnaires\"\n(Tous les dictionnaires contenus dans ce dossier et ses sous-dossiers seront affichés dans le menu) :",
 "s11"      : "Actions au démarrage :",
 "s12"      : "Vérifier la disponibilité d'une nouvelle version.",
 "s13"      : "Rouvrir le dernier dictionnaire ouvert.",
 "s14"      : "Rouvrir le dernier greffon ouvert.",
 "s15"      : "Cliquez sur une case de couleur pour modifier l'élément :",
 "s16"      : "Mot de liste",
 "s17"      : "Mot d'entrée",
 "s18"      : "Phonétique",
 "s19"      : "Traductions courtes",
 "s20"      : "Traductions longues",
 "s21"      : "Fond de notice",
 "s22"      : "Couleurs par défaut",
 "s24"      : "Afficher les noms conviviaux des dictionnaires dans le menu",
 "s25"      : "Afficher les noms des fichiers des dictionnaires dans le menu",
}
# ----------------------------------------------
# --- Fenêtre des propriétés du dictionnaire ---
# ----------------------------------------------
winprop = {
 "title"    : u"Propriétés du dictionnaire",
 "s1"       : "Chemin du fichier :",
 "s2"       : "Taille du fichier :",
 "s3"       : "Modifié le :",
 "s4"       : "Nombre d'entrées :",
 "s5"       : "Format du dictionnaire :",
 "s6"       : "Contenu de l'en-tête du fichier :",
 "s7"       : "Contenu du fichier ifo :",
 "s8"       : "fichier texte délimité",
 "s9"       : "fichier INI",
 "s10"      : "Valider",
 "s11"      : "Editer",
 "msg1"     : u"Editer les propriétés du dictionnaire",
 "msg2"     : u"L'édition des propriétés est destinée aux utilisateurs avancés\nconnaissant bien les spécifications du format concerné (voir Aide).\n\nDes propriétés incorrectes ou incorrectement formatées peuvent rendre le dictionnaire illisible.\n\nPour cette raison, une copie de sauvegarde du dictionnaire sera automatiquement enregistrée.\n\nContinuez ?",
}
# ----------------------------------------------
# --- Fenêtre d'extraction des modifications ---
# ----------------------------------------------
winext = {
 "title"    : u"Extraction des modifications",
 "msg1"     : u"L'extraction vers un nouveau document Ling à échouée, pour la raison suivante :",
 "msg2"     : u"Echec de l'enregistrement du fichier des modifications.",
 "msg3"     : u"L'extraction a été effectuée avec succès.",
 "s1"       : "Les modifications apportées à ce dictionnaire (entrées éditées et entrées ajoutées) vont être enregistrées dans un nouveau fichier au format Ling. Vous pourrez ensuite éventuellement transmettre ce fichier à l'auteur du dictionnaire original.",
 "s2"       : "Extraire les entrées ajoutées et les entrées éditées",
 "s3"       : "Extraire uniquement les entrées ajoutées",
 "s4"       : "Extraire",
}
# -----------------------------------------
# --- Fenêtre d'encodage des caractères ---
# -----------------------------------------
winenc = {
 "title"    : "Choix des encodages de caractères",
    "s1"    : "Encodage langue",
}
# ---------------------------------------------
# --- Fenêtre d'exportation du dictionnaire ---
# ---------------------------------------------
winexp = {
 "title"    : u"Exportation du dictionnaire",
 "msg1"     : u"Les données de ce dictionnaire sont protégées,\nl'exportation vers un autre format est donc impossible.",
 "msg2"     : u"Exporter à partir d'un dictionnaire Ling",
 "msg3"     : u"Le format Ling différencie un champ de traductions dites \"courtes\" et un champ de traductions dites \"longues\" (incluant infos, exemples, etc.).\n\nVoulez-vous fusionner ces deux champs dans le nouveau dictionnaire ?\nSi vous choisissez \"Non\", seules les traductions courtes seront intégrées au nouveau dictionnaire.",
 "msg4"     : u"Exporter vers XDXF",
 "msg5"     : u"Vous devez définir un dossier ET un nom.",
 "msg6"     : u"Echec de la création du dossier du dictionnaire XDXF",
 "msg7"     : u"Exporter un dictionnaire sous...",
 "msg8"     : u"L'exportation a rencontré le problème suivant :",
 "msg9"     : u"Le dictionnaire a été exporté avec succès",
 "msg10"    : u"en format binaire personnalisé.",
 "msg11"    : u"en format texte Preling.",
 "msg12"    : u"Voulez-vous ouvrir ce nouveau dictionnaire ?",
 "msg13"    : u"Echec de l'enregistrement du fichier",
 "msg14"    : u"est un encodage qui ne permet pas la conversion de ce dictionnaire\n\nChoisissez un autre encodage et réessayez...\n\nSi Unicode est supporté par le(s) programme(s) destiné(s) à lire ces données,\npréférez 'utf-8' comme encodage.",
 "msg15"    : u"Encodage impossible de la langue source avec l'encodage choisi :",
 "msg16"    : u"Encodage impossible de la langue cible avec l'encodage choisi :",
 "msg17"    : u"Choisissez d'autres encodages et réessayez...",
 "msg18"    : u"Echec de l'exportation au format WB",
 "msg19"    : u"Le dictionnaire a été exporté au format WB,\nmais certaines données ont été tronquées.",
 "msg20"    : u"La liste des entrées a été exportée avec succès.",
 "msg21"    : u"en format TEI.",
 "msg22"    : u"en base de données SQLite.",
 "s1"       : "Choisissez un format d'exportation dans la liste de gauche",
 "s2"       : "Exportation au format Ling",
 "s3"       : "L'encodage des données textuelles se fera en Utf-8,\n quel que soit l'encodage du dictionnaire source.",
 "s4"       : "Protéger les entrées",
 "s5"       : "Protéger les traductions/définitions",
 "s6"       : "Exportation au format Preling",
 "s7"       : "Le format Preling est un format texte passerelle avec le format binaire Ling\nil permet l'édition du dictionnaire dans un simple éditeur de texte\net l'accès à toutes les possibilités du format Ling.",
 "s8"       : "Saut de ligne :",
 "s9"       : "Exportation au format WB",
 "s10"      : "WB est un format 8-bits (Ascii étendu), l'encodage doit donc\nêtre compatible. Ex. : 'latin-1', 'cp1242' pour l'Europe de l'W.",
 "s11"      : "ATTENTION, les champs du format WB sont limités\nà 30/31 caractères pour la langue source\n et à 50/53 caractères pour la langue cible.\nLes données dépassant ces longueurs seront tronquées...",
 "s12"      : "Exportation au format DICT",
 "s13"      : "Le dictionnaire Dict sera composé de trois fichiers, encodés en Utf-8 :\tNomDuDico.ifo\tNomDuDico.idx\tNomDuDico.dict\nL'extension que vous choisirez pour le nom du fichier d'exportation est sans importance, ces trois fichiers seront créés dans le répertoire avec le même nom de base.",
 "s14"      : "Transférer les contenus entre crochets du champ des\nentrées en tête du champ traduction (facilite l'usage\nde la lecture d'écran par les logiciels le permettant)",
 "s15"      : "Exportation au format XDXF",
 "s16"      : "Un dictionnaire XDXF est composé d'un fichier XML\nnommé obligatoirement 'dict.xdxf' et placé dans\nun sous-dossier propre à chaque dictionnaire.\n\nLes données seront encodées en Utf-8",
 "s17"      : "Dossier qui contiendra le dictionnaire :",
 "s18"      : "Nom du dictionnaire (sera le nom du nouveau sous-dossier) :",
 "s19"      : "Exportation au format CSV (texte délimité)",
 "s20"      : "Caractère séparateur :",
 "s21"      : "(tabulation)",
 "s22"      : "(virgule)",
 "s23"      : "(point-virgule)",
 "s24"      : "Saut de ligne :",
 "s25"      : "Exportation en format binaire personnalisé",
 "s26"      : "Octet(s) de séparation :",
 "s27"      : "Octet(s) de terminaison :",
 "s28"      : "Exporter...",
 "s29"      : "(dictionnaire sans nom)",
 "s30"      : "(dictionnaire sans description)",
 "s31"      : "Binaire",
 "s32"      : "Liste des entrées",
 "s33"      : "Exportation de la liste des entrées",
 "s34"      : "La liste des entrées sera exporté en format texte.",
 "s35"      : "Séparateur des données :",
 "s36"      : "Les données de certains dictionnaires incorporent des balises (<.>) sémantiques ou de mise en forme qui gènent la lisibilité dans les logiciels qui ne les prennent pas en charge.",
 "s37"      : "Exporter en nettoyant les balises",
 "s38"      : "Le contenu des doubles accolades est interprété par Linguae comme un lien vers l'entrée correspondante, mais ces accolades réduisent la lisibilité dans les logiciels ne les reconnaissant pas.",
 "s39"      : "Exporter en nettoyant les doubles accolades",
 "s40"      : "Exportation au format TEI",
 "s41"      : "Le format TEI est un format polyvalent\ndépassant largement le cadre d'un dictionnaire.\n\nLinguae peut exporter vers ce format mais ne peut le lire.",
 "s42"      : "Trier le dictionnaire suivant l'ordre Ascii strict\n(nécessaire pour la compatibilité avec Stardict)",
 "s43"      : "Convertir les '<br>' en saut de ligne réel.",
 "s44"      : "Exportation au format SQLite-3",
 "s45"      : "SQLite est un format de base de données, manipulable par SQL\n et géré nativement par de nombreux langages (PHP, etc.).",
}
# ------------------------------------------------------
# --- Fenêtre d'édition des éléments de dictionnaire ---
# ------------------------------------------------------
wined = {
 "title1"   : u"Editer un élément de dictionnaire",
 "title2"   : u"Ajouter un élément de dictionnaire",
 "msg1"     : u"Déverrouiller l'Identifiant de l'entrée",
 "msg2"     : u"ATTENTION !\n\nToute modification secondaire de l'identifiant d'une entrée brise les pointages éventuels vers cette entrée (racines, synonymes...)\nainsi que ses liens vers les ressources sonores et graphiques associées.\n\nContinuer ?",
 "msg3"     : u"Importer un fichier audio", 
 "msg5"     : u"L'importation d'un fichier audio n'est possible que si le mot est muni d'un identifiant.",
 "msg6"     : u"Le sous-répertoire de ressource ne peut être créé,\nvérifiez les droits en écriture sur le répertoire du dictionnaire.",
 "msg7"     : u"Importer une image",
 "msg8"     : u"L'importation d'images n'est possible que si le mot est muni d'un identifiant.",
 "msg9"     : u"Supprimer une image",
 "msg10"    : u"Aucune image n'est sélectionnée !",
 "msg11"    : u"Impossible de supprimer le fichier de l'image !",
 "msg12"    : u"Voir l'image",
 "msg14"    : u"Les fonctions audio de Linguae sont désactivées.\nVérifiez l'installation correcte de la librairie audio Snack.",
 "msg15"    : u"L'enregistrement et l'écoute de la prononciation\nne sont possibles que si le mot est muni d'un identifiant.",
 "msg16"    : u"Aucune prononciation n'est encore enregistrée.\n\nPressez 'Rec' pour l'enregistrer puis 'Stop' pour arrêter l'enregistrement.",
 "msg17"    : u"Echec de la lecture du fichier audio !",
 "msg18"    : u"Echec de la sélection du périphérique d'enregistrement !\n\n Nb : Vous devez sélectionner le périphérique sur lequel est connecté votre microphone.",
 "msg19"    : u"Echec de l'enregistrement du fichier audio !",
 "msg20"    : u"Modifications non applicables !",
 "msg21"    : u"est un identifiant qui existe déjà dans le dictionnaire.\n\nL'identifiant est facultatif mais doit être unique dans le dictionnaire.\nUn identifiant est nécessaire seulement si vous voulez ensuite pouvoir\nvous référer à cette entrée comme racine, synonyme, etc.\nou pour lui adjoindre des ressources (sons, images).",
 "msg22"    : u"Impossible d'accéder au fichier dictionnaire en écriture, vérifiez que vous avez les droits d'accès nécessaires et que le fichier n'est pas en lecture seule.",
 "msg23"    : u"Problème d'encodage du champ",
 "msg24"    : u"Nb : utilisez la table de caractères intégrée pour inscrire des caractères non accessibles par le clavier",
 "msg25"    : u"Problème d'encodage UTF-8 pour l'index",
 "msg26"    : u"Problème d'encodage pour l'index",
 "msg27"    : u"Attention ! balise non fermée",
 "msg28"    : u"Sélectionnez la portion de texte à baliser !",
 "msg29"      : "Sélectionnez le champ à nettoyer de ses balises !",
 "s2"       : "Entrée de dictionnaire (31 caractères maximum) :",
 "s3"       : "Entrée de dictionnaire :",
 "s4"       : "Traductions/définitions courtes (53 car. maxi au total, 31 car. chacune et séparées par ' , ' )\n(seront utilisées pour inverser le dictionnaire) :",
 "s5"       : "Traductions/définitions courtes (séparées par ' ; ' )  (seront utilisées pour inverser le dictionnaire) :",
 "s6"       : "Infos ou traductions/définitions longues :",
 "s7"       : "(identifiant facultatif, unique dans le dictionnaire)",
 "s8"       : "Déverrouiller l'ID",
 "s9"       : "Ajouter un ID automatique",
 "s10"      : "IDs des Racines (séparés par ' ; ' ) :",
 "s11"      : "IDs des Synonymes (séparés par ' ; ' ) :",
 "s12"      : "IDs des Antonymes (séparés par ' ; ' ) :",
 "s13"      : "IDs des \" Voir-aussi \" (séparés par ' ; ' ) :",
 "s14"      : "Attributs : (séparés par ' ; ' ) :",
 "s15"      : "Phonétique de l'entrée :",
 "s16"      : "Enregistreur de la prononciation",
 "s17"      : "Périphérique d'enregistrement :",
 "s18"      : "0: ( par défaut )",
 "s19"      : "Importer",
 "s20"      : "Illustrations",
 "s21"      : "Supprimer",
 "s22"      : "Gérer...",
 "s23"      : "Nettoyer les balises",
 "ib1"      : "Coller le contenu du presse-papiers",
 "ib2"      : "Baliser : texte séléctionné en italique",
 "ib3"      : "Baliser : texte séléctionné en gras",
 "ib4"      : "Baliser : texte séléctionné en souligné",
 "ib5"      : "Baliser : texte séléctionné plus grand",
 "ib6"      : "Baliser : texte séléctionné plus petit",
 "ib7"      : "Poser une balise de saut de ligne",
 "ib8"      : "Baliser : lien interne vers une entrée",
 "ib9"      : "Supprimer toutes les balises du champs actif",
}
# ---------------------------------------------------
# --- Fenêtre de modif des icônes du dictionnaire ---
# ---------------------------------------------------
winic = {
 "title"    : u"Modifier les icônes du dictionnaire",
 "msg1"     : u"Inclure une image",
 "msg2"     : u"Inscrivez au moins un chemin valide vers un fichier graphique !",
 "msg3"     : u"Fichier  introuvable !",
 "s1"       : "Image Langue source :",
 "s2"       : "(pas d'image)",
 "s3"       : "Image Langue cible :",
 "s4"       : "Nouvelle image pour la langue source (facultatif) :",
 "s5"       : "Nouvelle image pour la langue cible (facultatif) :",
 "s6"       : "Modifier",
}
# --------------------------------------------
# --- Fenêtre de dictionnaire par héritage ---
# --------------------------------------------
winher = {
 "title"    : u"Construire un dictionnaire par héritage",
 "msg1"     : u"Ce module permet de dériver un dictionnaire dit \"par héritage\" à partir de deux dictionnaires sources, suivant le schéma suivant :\n\n\t[ Dictionnaire 1 > 2 ] + [ Dictionnaire 2 > 3 ] => [ Dictionnaire 1 > 3 ]\n\nLa qualité du dictionnaire hérité sera très variable en fonction de la compatibilité de la rédaction des dictionnaires de départ, et ira de l'acceptable au quasi-inutilisable. Un tel processus automatique ne remplace pas un véritable dictionnaire rédigé humainement, ce n'est qu'un pis-aller palliant l'absence d'un dictionnaire existant.",
 "msg2"     : u"Ce fichier existe déjà. Voulez-vous le remplacer ?",
 "msg3"     : u"[ --- Démarrage du traitement global --- ]",
 "msg4"     : u"Instanciation du dictionnaire",
 "msg5"     : u"Terminé !",
 "msg6"     : u"Les données de ce dictionnaire sont protégées,\nil ne peut donc pas être utilisé comme dictionnaire source.",
 "msg7"     : u"Construire un index temporaire...",
 "msg8"     : u"Analyse des données...\n(processus long, veuillez patienter)",
 "msg9"     : u"Construction du dictionnaire hérité...",
 "msg10"    : u"[ --- Fin du traitement global --- ]",
 "msg11"    : u"Le dictionnaire a été créé avec succès.\n\nVoulez-vous le charger ?",
 "msg12"    : u"Votre dossier des dictionnaires est vide !\n\nVous devez d'abord copier des dictionnaires dans ce dossier pour pouvoir utiliser cette fonction.",
 "msg13"    : u"Le chargement du dictionnaire-parent a échoué !",
 "s1"       : "Dictionnaire",
 "s2"       : "Nom du dictionnaire hérité",
 "s3"       : "Construire",
 "s4"       : "(Avancement)",
 "s5"       : "Groupe de caractère(s) marquant la fin de la zone à prendre en compte lors du croisement des données (par défaut : espace) :",
 "s6"       : "Sensible à la casse",
}
# --------------------------------------
# --- Fenêtre d'aide à la traduction ---
# --------------------------------------
wintrl = {
 "title"    : u"Aide à la traduction",
 "s1"       : "Tapez ou collez le texte à traduire",
 "s2"       : "Ouvrir un fichier texte",
 "s3"       : "Pour afficher les correspondances d'un mot : Double-clic sur le mot (ou mise en sélection et Ctrl+P)",
 "s4"       : "Correspondances possibles :",
 "s5"       : "Double-cliquez sur une correspondance pour afficher sa notice...",
 "msg1"     : u"Ouvrir un fichier texte à traduire",
}
# ------------------------------------
# --- Fenêtre "A propos de Linguae ---
# ------------------------------------
winabt = {
 "s1"       : "Gestionnaire de dictionnaires multiformat",
 "s2"       : "Logiciel sous licence CeCILL (compatible GNU-GPL) :"
}
# --------------------------------------------
# --- Fenêtre de recherche des liens morts ---
# --------------------------------------------
winlk = {
 "title"    : u"Contrôle des liens du dictionnaires",
}
# ---------------------------------
# --- Fenêtre de téléchargement ---
# ---------------------------------
windwn = {
 "title"    : u"Télécharger et installer des dictionnaires",
 "s1"       : "Auteur",
 "s2"       : "Date",
 "s3"       : "Version",
 "s4"       : "Format",
 "s5"       : "Télécharger et installer",
 "s6"       : "Sélectionné(s) :",
 "s7"       : "Source des dictionnaires :",
 "s8"       : "Projet POLYGLOTTE",
 "s9"       : "Connexion au serveur en cours...",
 "s10"      : "Commentaires",
 "s11"      : "Fichier(s)",
 "s12"      : "Téléchargement en cours, patientez...",
 "s13"      : "Téléchargement terminé",
 "s14"      : "Licence",
 "s15"      : "Dictionnaire déjà installé, cochez la case pour le réinstaller.",
 "s16"      : "Dictionnaire non encore installé, cochez la case pour l'installer.",
 "s17"      : "(Aucun dictionnaire ne correspond au critère de filtrage)",
 "s18"      : "Taille",
 "s19"      : "Dictionnaire installé, cochez la case pour le mettre à jour.",
 "ib1"      : "Aller sur le site Web du projet Polyglotte",
 "msg1"     : u"Echec de la connexion, impossible de télécharger l'index",
 "msg2"     : u"Vos nouveaux dictionnaires sont installés et prêts à l'emploi (Menu 'Dictionnaires')",
 "msg3"     : u"Un problème est survenu lors du téléchargement, s'il persiste merci de contacter les responsables du site.",
}
# ---------------------------------------
# --- Fenêtre d'interrogation de Swac ---
# ---------------------------------------
winsw = {
 "title"    : u"Interroger Swac",
}

if __name__ == '__main__':
    
    # Rechercher les chaînes orphelines ou non normalisées dans les fichiers
    # utilisant ces chaînes de langues
    import sys
    k = ""
    section = ""
    
    # Domaine de la recherche : concaténer les fichiers concernés
    root = sys.argv[0].split("lang")[0]
    txt = open(root + "corpus.py", "r").read()
    txt += open(root + "lib\mydic.py", "r").read()
    
    # Nb toutes les variables doivent avoir été initialisées avant l'itération dans locals()
    
    for section in locals():
        
        # ne tester que les variables dictionnaires
        if isinstance(eval(section), dict):
            
            for k in eval(section):
                if txt.find(section +'", "' + k) == -1 :
                    print "orpheline : ", section, k
                
                if txt.find(section +'","' + k) > -1 :
                    print "format espace : ", section, k
                
                if txt.find(section +"', '" + k) > -1 :
                    print "format guillemets : ", section, k
                
                if txt.find(section +"','" + k) > -1 :
                    print "format espace et guillemets : ", section, k
        
    print "...... ok"
        