#!/usr/bin/env python
# -*- coding:utf-8 -*-

# ////////////////////////////////////////////////////////////////////////
#                                                                         
#   LINGUAE                                                               
#   Gestionnaire de dictionnaire multiformat multiplateforme              
#                                                                         
#   sous licence CeCILL-2 (GNU-GPL compatible) : http://www.cecill.info/  
#                                                                         
#   Auteur   : Billig - 2008-2011                                         
#   Contact  : linguae@stalikez.info                                      
#   Site Web : http://linguae.stalikez.info                               
#                                                                         
# ////////////////////////////////////////////////////////////////////////


u"""
| Module corpus.py                                                              
|                                                                               
| Corps du programme en mode graphique.                                         
|                                                                               
| Contenu :                                                                     
|   classes de toutes les fenêtres de l'application.                            
"""

versionProgr = "0.15 Beta"


from Tkinter import*
import ScrolledText
import tkFileDialog
import tkSimpleDialog
import tkMessageBox
import tkColorChooser
import tkFont

import os.path
import time
import datetime
import base64
import shutil
import glob
import webbrowser
import re                       # Expressions rationnelles
import urllib
import StringIO                 # accéder à une chaîne comme avec un fichier

from lib.mytools import *       # bibliothèque de fonctions perso
import lib.mydic                # classe d'objet Dictionnaire
import lib.myencsel             # Widget perso : sélection d'encodage
import lib.myprogbr             # Widget perso : barre de progression
import lib.myscrlst             # Widget perso : liste à barre de progression
import lib.myimg                # Ensemble des Gifs de l'interface
import lib.adjutor              # Gestionnaire d'aide        
import lib.mylang               # Gestionnaire du multilinguisme d'interface
import lib.myappdat             # Gestionnaire du rep. des données d'application
import lib.mynavig              # Widget perso : gestionnaire d'historique
import lib.myfldbrw             # Widget perso : sélecteur de répertoire

import lib.infobulle            # classe d'infobulle (code récupéré)



class Inifile():
    
    u"""
    | Classe de gestion d'un fichier de configuration *.ini simplifié           
    |                                                                           
    | *.ini simplifié : de type clef=valeur SANS titre de sections,             
    | chaque clef doit donc être unique dans le fichier                         
    |                                                                           
    """

    
    def __init__(self, path):
        
        u"""
        | Initialise l'objet d'accès au fichier ini                             
        | Le fichier est créé s'il n'existe pas                                 
        | Nom et extension du fichier sont indifférents (extension '.ini' non   
        | obligatoire)                                                          
        """
        
        self.path = ""              # Chemin complet de l'ini
        
        if os.path.isfile(path):
            self.path = path
        else:
            ff = open(path,'w')     # Créer le fichier si inexistant...
            self.path = path
            ff.close()
            
        return
    
    
    
    def get(self, k, default):
        u"""
        | Retourne la valeur de la clef 'k' du fichier ini                      
        | Retourne la valeur 'default' si la clé est inexistante                
        """
        
        try:
            fichini = open(self.path,'rU')      # Essayer d'ouvrir l'ini en lecture
        except:
            return default                      # Retourner la valeur par défaut si échec
        
        
        # --- Ouverture ok en lecture 
        
        k = k + "="
        lignes = fichini.readlines()            # Copier le fichier dans une liste de lignes
        fichini.close()                         # On peut refermer le fichier
        
        for ligne in lignes:
            if ligne.startswith(k):             # La ligne de la clé est trouvée !
                ligne = ligne.replace("\n", "").replace("\r", "")    # On supprime le caractère de fin de ligne
                ligne = ligne[len(k):]          # On retourne la ligne sans sa clef
                ligne = ligne.decode('utf-8')   # On décode car l'ini est encodé en utf-8
                if ligne == "": ligne = default # Ligne vide > retour de la valeur par défaut
                return ligne
        
        return default                          # Ligne non trouvée > retour de la valeur par défaut



    def write(self, k, v):        
        u"""
        | Inscrit la valeur 'v' de la clef 'k' dans le fichier de configuration 
        | de type ini simplifié                                                 
        """
        
        flagUpdate = False                      # Flag mis à vrai si mise à jour d'une ligne existante
                                                # ... reste faux si la ligne est ajoutée à l'ini
        
        
        # ---------------------------------------------
        # --- Copier l'ini dans une pyListe de lignes  
        # ---------------------------------------------
        
        try:
            fichini = open(self.path,'rU')      # Essayer d'ouvrir le fichier ini en lecture
        except:
            fichini = open(self.path,'w')       # Créer le fichier si inexistant...
            fichini.close()
            fichini = open(self.path,'rU')      # ... puis le réouvrir en lecture
        
        lignes = fichini.readlines()            # Copier le fichier dans une liste de lignes
        fichini.close()                         # On peut refermer le fichier
        
       
        
        # ---------------------------------------------
        # --- Confectionner la nouvelle ligne          
        # ---------------------------------------------
        
        
        # --- Clef
        
        k = k + "="
        
        try:
            k = k.decode('cp1242')
        except:
            try:
                k = k.decode('Latin-1')
            except:
                pass
        
        k = k.encode('utf-8')
        
        # --- Valeur
        
        try:
            v = v.decode('cp1242')
        except:
            try:
                v = v.decode('Latin-1')
            except:
                pass
        
        v = v.encode('utf-8')
        
        # --- Libellé de la ligne à inscrire dans l'ini
        
        newligne = k + v + "\n"                  
        
        
        # -------------------------------------------------
        # --- Vérifier si la clé est déjà présente ou non  
        # -------------------------------------------------
        
        for i in range(len(lignes)):
            if lignes[i].startswith(k):         # La ligne de la clé est trouvée !
                lignes[i] = newligne            # On modifie la ligne avec la nouvelle valeur
                flagUpdate = True               # On marque que la ligne a été mise à jour
                break                           # On peut quitter l'itération
        
        if flagUpdate == False:                 # Aucune ligne n'a été mise à jour...
            lignes.append(newligne)             # ...donc la clef est absente > on l'ajoute
        
        
        # --------------------------------------------------
        # --- Réécrire la liste de lignes dans le fichier   
        # --------------------------------------------------
        
        fichini = open(self.path,'w')
        fichini.write("".join(lignes))
        fichini.close()
        
        return
    


class WindowInfo(Toplevel):
    
    u"""
    | Fenêtre d'affichage des infos et du statut du dictionnaire courant.       
    |                                                                           
    | Cette fenêtre est affichée en splash au chargement d'un dico,             
    | elle n'apparaît que si elle contient quelque chose                        
    |                                                                           
    | Cette fenêtre est appelable par le menu Aide (commande dégrisée uniquement
    | si la fenêtre contient quelque chose).                                    
    |                                                                           
    """
    
    
    def __init__(self):
        
        u"""
        | Mise en place de l'interface de la fenêtre d'affichage                
        | des infos et statut du dictionnaire.                                  
        |                                                                       
        | Remplissage des cases avec les données du dictionnaire.               
        """
        
        flagContent = False
        
        Toplevel.__init__(self, padx=5, pady=3)
        
        # masquer la fenêtre (évite un bref pop-up si la fenêtre doit être aussitôt fermée
        # pour cause de contenu nul)
        self.withdraw()
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+40)
        top = str(int(app.geometry().split('+')[2])+60)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("wininf", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        
        self.focus_set()
        
        wtxt=72
        
        # --------------------------------------
        # --- Nom convivial du dictionnaire     
        # --------------------------------------
        
        if app.dic.dicName != "":
            fr_ttr=Frame(self)
            fr_ttr.grid()
            
            # Icône de langue 1, à gauche
            if app.ic1:
                Label(fr_ttr, image=app.ic1).grid(row=0, column=0)
            
            # Nom du dico, au centre
            Label(fr_ttr, text=app.dic.dicName, font=("Helvetica", 12, "bold"), background='black', foreground='white').grid(row=0, column=1, padx=10, ipadx=8)
            
            # Icône de lange 2, à droite
            if app.ic2:
                Label(fr_ttr, image=app.ic2).grid(row=0, column=2)
            
            flagContent = True
        
        
        # ---------------------------------------
        # --- Date et version du Dictionnaire    
        # ---------------------------------------
        
        t = ""
        if app.dic.dicVersionNumber !="":
            pass
            t = app.lg.get("wininf", "s1") + " " + app.dic.dicVersionNumber  + "  "
        if app.dic.versionDate != "":
            t = t + app.dic.versionDate
        if t != "":
            Label(self, text=t, font=("Helvetica", 8, "normal")).grid() 
            flagContent = True
        
        # --------------------------------------------
        # --- Case des Informations du dictionnaire   
        # --------------------------------------------
        
        if app.dic.showDicInfo and app.dic.dicInfo != "":
            
            Label(self, text=app.lg.get("wininf", "s2"), font=("Helvetica", 9, "bold")).grid(sticky="W")
            
            txt_info = ScrolledText.ScrolledText(self, width=wtxt, height=7, background='white', font=("Helvetica", 8, "normal"))
            
            # Définir les styles d'affichage
            txt_info.tag_config("normal", font=("Helvetica", 8, "normal"), wrap=WORD, lmargin1=5, lmargin2=5, spacing1=5)
            txt_info.tag_config("b", font=("Helvetica", 8, "bold"))
            txt_info.tag_config("i", font=("Helvetica", 8, "italic"))
            txt_info.tag_config("small", font=("Helvetica", 7))
            txt_info.tag_config("big", font=("Helvetica", 9))
            txt_info.tag_config("url", foreground="blue", underline=1)
            txt_info.tag_config("mail", foreground="blue", underline=1)
            txt_info.tag_bind("url", "<ButtonRelease-1>", lambda event : onclickUrl(txt_info))
            txt_info.tag_bind("mail", "<ButtonRelease-1>", lambda event : onclickMail(txt_info))
            txt_info.tag_bind("url", "<Enter>", lambda event : onEnterLink(txt_info))
            txt_info.tag_bind("mail", "<Enter>", lambda event : onEnterLink(txt_info))
            txt_info.tag_bind("url", "<Leave>", lambda event : onLeaveLink(txt_info))
            txt_info.tag_bind("mail", "<Leave>", lambda event : onLeaveLink(txt_info))
            
            
            # Ecrire dans la TextBox en convertissant les éventuelles entités
            txt_info.insert(END, entToChar(app.dic.dicInfo), "normal")
            
            # Convertir les balises du texte
            tagsConv(txt_info, btag="b", itag="i", utag="u", bigtag="big", smalltag="small")
            
            # Reconnaissance automatique des urls > pose du tag "url"
            addTagToUrl(txt_info, "url")
            
            # Reconnaissance automatique des adresses mail > pose du tag "mail"
            addTagToMail(txt_info, "mail")
            
            
            
            txt_info['state']= 'disabled'
            txt_info.grid()
            flagContent = True
        
        
        # ---------------------------------
        # --- Case de Statut et Licence    
        # ---------------------------------
        
        if app.dic.showDicStatus and app.dic.dicStatus != "":
            
            Label(self, text=app.lg.get("wininf", "s3"), font=("Helvetica", 9, "bold")).grid(sticky="W")
            txt_status = ScrolledText.ScrolledText(self, width=wtxt, height=7, background='white', font=("Helvetica", 8, "normal"))
            
            # Définir les styles d'affichage
            txt_status.tag_config("normal", font=("Helvetica", 8, "normal"), wrap=WORD, lmargin1=5, lmargin2=5, spacing1=5)
            txt_status.tag_config("b", font=("Helvetica", 8, "bold"))
            txt_status.tag_config("i", font=("Helvetica", 8, "italic"))
            txt_status.tag_config("small", font=("Helvetica", 7))
            txt_status.tag_config("big", font=("Helvetica", 9))
            txt_status.tag_config("url", foreground="blue", underline=1)
            txt_status.tag_config("mail", foreground="blue", underline=1)
            txt_status.tag_bind("url", "<ButtonRelease-1>", lambda event : onclickUrl(txt_status) )
            txt_status.tag_bind("mail", "<ButtonRelease-1>", lambda event : onclickMail(txt_status))
            txt_status.tag_bind("url", "<Enter>", lambda event : onEnterLink(txt_status))
            txt_status.tag_bind("mail", "<Enter>", lambda event : onEnterLink(txt_status))
            txt_status.tag_bind("url", "<Leave>", lambda event : onLeaveLink(txt_status))
            txt_status.tag_bind("mail", "<Leave>", lambda event : onLeaveLink(txt_status))
            
            # Ecrire dans la TextBox en convertissant les éventuelles entités
            txt_status.insert(END, entToChar(app.dic.dicStatus), "normal")
            
            # Convertir les balises du texte
            tagsConv(txt_status, btag="b", itag="i", utag="u", bigtag="big", smalltag="small")
            
            # Reconnaissance automatique des urls > pose du tag "url"
            addTagToUrl(txt_status, "url")
            
            # Reconnaissance automatique des adresses mail > pose du tag "mail"
            addTagToMail(txt_status, "mail")
            
            txt_status['state']= 'disabled'
            txt_status.grid()
            
            flagContent = True
        
        
        # ----------------------
        # --- Auteur(s)         
        # ----------------------
        
        t = "\n".join(app.dic.mainAuthors)
        if t != "":
            Label(self, text=app.lg.get("wininf", "s4"), font=("Helvetica", 9, "bold")).grid(sticky="W")
            Message(self, text=t, font=("Helvetica", 9, "normal"), width=500).grid(sticky="W")
            flagContent = True
        
        t = "\n".join(app.dic.altAuthors)
        if t != "":
            Label(self, text=app.lg.get("wininf", "s5"), font=("Helvetica", 8, "bold")).grid(sticky="W")
            Label(self, text=t).grid(sticky="W")
            flagContent = True
        
        if app.dic.contactAuthor != "":
            t = app.lg.get("wininf", "s6") + " " + app.dic.contactAuthor
            txt_contact=Text(self, font=("Helvetica", 8, "normal"), relief=FLAT, height=1, width=len(t), background =self['background'])
            txt_contact.insert(END, t)
            txt_contact.tag_config("url", foreground="blue", underline=1)
            txt_contact.tag_config("mail", foreground="blue", underline=1)
            txt_contact.tag_bind("url", "<ButtonRelease-1>", lambda event : onclickUrl(txt_contact) )
            txt_contact.tag_bind("mail", "<ButtonRelease-1>", lambda event : onclickMail(txt_contact))
            txt_contact.tag_bind("url", "<Enter>", lambda event : onEnterLink(txt_contact))
            txt_contact.tag_bind("mail", "<Enter>", lambda event : onEnterLink(txt_contact))
            txt_contact.tag_bind("url", "<Leave>", lambda event : onLeaveLink(txt_contact))
            txt_contact.tag_bind("mail", "<Leave>", lambda event : onLeaveLink(txt_contact))
            
            # Reconnaissance automatique des urls > pose du tag "url"
            addTagToUrl(txt_contact, "url")
            
            # Reconnaissance automatique des adresses mail > pose du tag "mail"
            addTagToMail(txt_contact, "mail")
            
            txt_contact['state'] = 'disabled'
            txt_contact.grid()
            flagContent = True
        
        
        # --------------------------
        # --- Case de la Biblio     
        # --------------------------
        
        if app.dic.showBiblio and len(app.dic.biblio) > 0:
            
            Label(self, text=app.lg.get("wininf", "s7"), font=("Helvetica", 9, "bold")).grid(sticky="W")
            txt_biblio = ScrolledText.ScrolledText(self, width=wtxt, height=6, background='white', font=("Helvetica", 8, "normal"))
            
            # Définir les styles d'affichage
            txt_biblio.tag_config("normal", font=("Helvetica", 8, "normal"), wrap=WORD, lmargin1=5, lmargin2=5, spacing1=5)
            txt_biblio.tag_config("b", font=("Helvetica", 8, "bold"))
            txt_biblio.tag_config("i", font=("Helvetica", 8, "italic"))
            txt_biblio.tag_config("small", font=("Helvetica", 7))
            txt_biblio.tag_config("big", font=("Helvetica", 9))
            txt_biblio.tag_config("url", foreground="blue", underline=1)
            txt_biblio.tag_bind("url", "<ButtonRelease-1>", lambda event : onclickUrl(txt_biblio) )
            txt_biblio.tag_bind("url", "<Enter>", lambda event : onEnterLink(txt_biblio))
            txt_biblio.tag_bind("url", "<Leave>", lambda event : onLeaveLink(txt_biblio))
            
            # Remplir la case
            for r in  app.dic.biblio:
                txt_biblio.insert(END, r + "\n", "normal")
            
            # Convertir les balises du texte
            tagsConv(txt_biblio, btag="b", itag="i", utag="u", bigtag="big", smalltag="small")
            
            # Reconnaissance automatique des urls > pose du tag "url"
            addTagToUrl(txt_biblio, "url")
            
            txt_biblio['state']= 'disabled'
            txt_biblio.grid()
            
            flagContent = True
        
        
        # ------------------------------
        # --- Frame des Boutons         
        # ------------------------------
        
        fr_but = Frame(self)
        fr_but.grid(pady=5)
        
        Button(fr_but, text="Ok", width=25, command=self.destroy).grid(row=0, column=0, padx=10)
        
        # Tester la présence d'un fichier d'info dans les ressources
        # si oui, afficher le bouton pour l'ouvrir
        fich_info = os.path.join(app.dic.path + "_res", "_dic_info.*")
        if len(glob.glob(fich_info)) > 0:
            Button(fr_but, text=app.lg.get("wininf", "s8"), width=25, command=self.__seeFichInfo).grid(row=0, column=1, padx=10)
        
        
        
        # -----------------------------
        # --- Ligne de Copyright       
        # -----------------------------
        
        if app.dic.copyright != "":
            t = "© " + app.dic.copyright
            Label(self, text=t, font=("Helvetica", 8, "normal")).grid(sticky="W")
            flagContent = True
        
        
        # ---------------------------------------
        
        # Quitter immédiatement si rien à afficher
        if not flagContent :
            app.m_hlp.entryconfigure(5, state='disabled') # Désactiver le menu "à propos de ce dictionnaire"
            self.destroy()
        else:
            # afficher la fenêtre
            self.deiconify()
            
            # Activer la commande du menu permettant de réafficher ultérieurement la fenêtre d'info
            app.m_hlp.entryconfigure(5, state='normal')
        
        
        return
    
    
    def __seeFichInfo(self):
        """
        | Afficher le fichier d'info à partir du répertoire de ressources
        """
        
        fich = glob.glob(os.path.join(app.dic.path + "_res", "_dic_info.*"))[0]
        
        r = shellopen(fich)
        
        if r != 0:
            tkMessageBox.showwarning(parent=self,
            title = "Linguae",
            message = "Can't open...\n\n'" + fich + "'")
        
        
        return



class WindowOptions(Toplevel):
    
    u"""
    | Fenêtre d'options et paramètres généraux du programme
    """



    def __init__(self, seefirst=0):
        
        u"""
        | Mise en place de l'interface de la fenêtre des options.               
        | 
        | ARGUMENTS :                                                           
        |   'seefirst" : index du panneau à afficher au démarrage               
        """
        
        Toplevel.__init__(self, padx=10, pady=10)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
            
        self.title(app.lg.get("winopt", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        
        wOngl = 130
        hOngl = 20
        hPan = 20 # nb caractères
        wPan = 100 # nb caractères
        
        
        # ------------------------------------
        # --- Frame des Boutons/faux-onglets  
        # ------------------------------------
        
        r=0
        fr_ongl = Frame(self)
        fr_ongl.grid(row=r, sticky="WENS")
        
        # Polices
        ongl_0 = Button(fr_ongl, text=" " + app.lg.get("winopt", "s1"), image=app.imglst.puceS, compound=LEFT, height=hOngl, width=wOngl, borderwidth=0, foreground='black', background='white')
        ongl_0.pack(side=LEFT, anchor=W, padx=4)
        
        # Chemins
        ongl_1 = Button(fr_ongl, text=" " + app.lg.get("winopt", "s2"), image=app.imglst.puceX, compound=LEFT, height=hOngl, width=wOngl, borderwidth=0, foreground='white', background='#B4B4B4')
        ongl_1.pack(side=LEFT, padx=4)
        
        # Couleurs
        ongl_2 = Button(fr_ongl, text=" " + app.lg.get("winopt", "s2b"), image=app.imglst.puceX, compound=LEFT, height=hOngl, width=wOngl, borderwidth=0, foreground='white', background='#B4B4B4')
        ongl_2.pack(side=LEFT, padx=4)
        
        # Divers
        ongl_3 = Button(fr_ongl, text=" " + app.lg.get("winopt", "s3"), image=app.imglst.puceX, compound=LEFT, height=hOngl, width=wOngl, borderwidth=0, foreground='white', background='#B4B4B4')
        ongl_3.pack(side=LEFT, padx=4)
        
        # Dimensionneur de l'espace des frames
        
        Label(self, text="", width=wPan, height=hPan).grid(row=1)
        
        
        # ========================================
        # === Frame des polices (onglet 0)        
        # ========================================
        
        r=1
        fr_font = Frame(self, borderwidth=3, relief='ridge')
        fr_font.grid(row=r, ipadx=20, ipady=20, sticky="WENS")
        
        
        # --------------------------------------
        # --- Police de la liste de dico        
        # --------------------------------------
        
        r=0
        # Etiquette de la police actuelle
        Label(fr_font, text=app.lg.get("winopt", "s4")).grid(row=r, column=0, sticky=E)
        Label(fr_font, text=app.lst_dico['font']).grid(row=r, column=1, sticky=W)
        
        # Case de la nouvelle police
        Label(fr_font, text=app.lg.get("winopt", "s5")).grid(row=r+1, column=0, sticky=E)
        self.txt_dicofontName=Entry(fr_font, width=30, background='white')
        self.txt_dicofontName.grid(row=r+1, column=1)
        
        # Taille de la nouvelle police
        Label(fr_font, text=app.lg.get("winopt", "s6")).grid(row=r+1, column=3)
        self.txt_dicofontSize=Entry(fr_font, width=3, background='white')
        self.txt_dicofontSize.grid(row=r+1, column=4, padx=6)
        
        # Etiquette de démonstration de la police (case-exemple)
        self.lab_exdicofont=Label(fr_font, text="0123456789\nABCDEFabcdef", borderwidth=1, background='white', relief='solid', padx=10, pady=5)
        self.lab_exdicofont.grid(row=r+2, column=0)
        
        # Liste des polices
        r=2
        self.lst_font1=Listbox(fr_font,height=5, width=30)
        self.lst_font1.grid(row=r, column=1)
        scr1=Scrollbar(fr_font, command=self.lst_font1.yview)
        scr1.grid(row=r, column=2, sticky=NS)
        self.lst_font1['yscrollcommand'] = scr1.set
        self.lst_font1['font'] = self.txt_dicofontName['font']
        self.lst_font1.bind('<ButtonRelease-1>', lambda event : self.fontSel(1))
        
        r=3
        Label(fr_font, text="", height=1).grid(row=r, columnspan=10) # espaceur
        
        
        # ----------------------------------------------
        # --- Police de la case de la notice            
        # ----------------------------------------------
        
        r=4
        # Etiquette de la police actuelle
        Label(fr_font, text=app.lg.get("winopt", "s7")).grid(row=r, column=0, sticky=E)
        Label(fr_font, text=app.txt_notice['font']).grid(row=r, column=1, sticky=W)
        
        # Case de la nouvelle police
        Label(fr_font, text=app.lg.get("winopt", "s8")).grid(row=r+1, column=0, sticky=E)
        self.txt_traducfontName=Entry(fr_font, width=30, background='white')
        self.txt_traducfontName.grid(row=r+1, column=1)
        
        # Taille de la nouvelle police
        Label(fr_font, text=app.lg.get("winopt", "s6")).grid(row=r+1, column=3)
        self.txt_traducfontSize=Entry(fr_font, width=3, background='white')
        self.txt_traducfontSize.grid(row=r+1, column=4, padx=6)
        
        # Etiquette de démonstration de la police (case-exemple)
        self.lab_extraducfont=Label(fr_font, text="0123456789\nABCDEFabcdef", borderwidth=1, background='white', relief='solid', padx=10, pady=5)
        self.lab_extraducfont.grid(row=r+2, column=0)
        
        # Liste des polices
        r=6
        self.lst_font2=Listbox(fr_font,height=5, width=30)
        self.lst_font2.grid(row=r, column=1)
        scr2=Scrollbar(fr_font, command=self.lst_font2.yview)
        scr2.grid(row=r, column=2, sticky=NS)
        self.lst_font2['yscrollcommand'] = scr2.set
        self.lst_font2.bind('<ButtonRelease-1>', lambda event : self.fontSel(2))
        self.lst_font2['font'] = self.lst_font1['font']
        
        # Bouton "Appliquer les polices par défaut"
        Button(fr_font, text=app.lg.get("winopt", "s8b"), command=self.setDefFonts).grid(row=7, ipadx=3)
        
        
        fr_font.grid_remove()
        
        
        # ---------------------------------
        # --- Frame des chemins (onglet 1) 
        # ---------------------------------
        
        r = 1
        fr_dir = Frame(self, borderwidth=3, relief='ridge', padx=5)
        fr_dir.grid(row=r, ipadx=20, ipady=20, sticky="WENS")
        
        r = 0
        Label(fr_dir, text=" ").grid(row=r, column=0)   # passer une ligne
        Label(fr_dir, text=" ").grid(row=r+1, column=0) # passer une ligne
        
        # Chemin par défaut de recherche des dictionnaires
        r = 2
        Label(fr_dir, text=app.lg.get("winopt", "s9")).grid(row=r, column=0, sticky='W')
        self.fb_pathSearch = lib.myfldbrw.FolderBrowser(fr_dir, width=90)
        self.fb_pathSearch.grid(row=r+1, column=0, sticky='W')
        
        Label(fr_dir, text=" ").grid(row=r+2, column=0) # passer une ligne
        Label(fr_dir, text=" ").grid(row=r+3, column=0) # passer une ligne
        
        # Chemin du dossier de stockage (lié au menu) des dictionnaires
        r += 4
        Label(fr_dir, text=app.lg.get("winopt", "s10"), justify=LEFT).grid(row=r, column=0, sticky='W')
        self.fb_pathStor = lib.myfldbrw.FolderBrowser(fr_dir, width=90)
        self.fb_pathStor.grid(row=r+1, column=0, sticky='W')
        
        # Options d'affichage du menu des dictionnaires (noms de fichiers ou noms conviviaux)
        r +=2
        self.vOptMenudic = StringVar()
        Radiobutton(fr_dir, text=app.lg.get("winopt", "s24"), variable=self.vOptMenudic, value="nmdic").grid(row=r, column=0, sticky='W')
        Radiobutton(fr_dir, text=app.lg.get("winopt", "s25"), variable=self.vOptMenudic, value="nmfich").grid(row=r+1, column=0, sticky='W')
        
        
        fr_dir.grid_remove()
        
        
        # ----------------------------------
        # --- Frame des couleurs (onglet 2) 
        # ----------------------------------
        font1 = "Helvetica 10 normal"
        
        fr_coul = Frame(self, borderwidth=3, relief='ridge', padx=6, pady=5)
        fr_coul.grid(row=1, sticky="WENS")
        
        Label(fr_coul, text=app.lg.get("winopt", "s15")).grid(row=0, column=0, columnspan=10, sticky="e")
        
        fr_ex = Frame(fr_coul, border=1, relief=SOLID, padx=8, pady=8)
        fr_ex.grid(row=1, column=0, rowspan=10, padx=5, pady=5)
        
        # Case d'exemple de liste
        self.txt_exliste = Text(fr_ex, width=16, height=12, font=font1)
        self.txt_exliste.tag_config('liste', lmargin1=3, lmargin2=3 )
        for n in range(int(self.txt_exliste['height'])):
            self.txt_exliste.insert(END, app.lg.get("winopt", "s16") + " " + str(n+1) + "\n", 'liste')
        self.txt_exliste.grid(row=0, column=0, padx=4, pady=4)
        
        # Case d'exemple de notice
        self.txt_excoul = Text(fr_ex, width=20, height=12)
        self.txt_excoul.tag_config('miroir', lmargin1=5, lmargin2=5, spacing1=5, spacing3=5, borderwidth=2, relief=SOLID, font="Helvetica 10 bold")
        self.txt_excoul.tag_config('phon', lmargin1=5, lmargin2=5, spacing1=5, font=font1)
        self.txt_excoul.tag_config('short', lmargin1=5, lmargin2=5, spacing1=5, spacing3=2, font=font1)
        self.txt_excoul.tag_config('long', lmargin1=5, lmargin2=5, spacing1=5, font=font1)
        self.txt_excoul.tag_config('ety', lmargin1=5, lmargin2=5, spacing1=5, font=font1)
        self.txt_excoul.tag_config('syn', lmargin1=5, lmargin2=5, spacing1=5, font=font1)
        self.txt_excoul.tag_config('anto', lmargin1=5, lmargin2=5, spacing1=5, font=font1)
        
        self.txt_excoul.insert(END, app.lg.get("winopt", "s17") + "\n", 'miroir')
        self.txt_excoul.insert(END, app.lg.get("winopt", "s18") + "\n", 'phon')
        self.txt_excoul.insert(END, app.lg.get("winopt", "s19") + "\n", 'short')
        self.txt_excoul.insert(END, "---------\n")
        self.txt_excoul.insert(END, app.lg.get("winopt", "s20") + "\n ...\n", 'long')
        self.txt_excoul.insert(END, "<etym>.....</etym>" + "\n", 'ety')
        self.txt_excoul.insert(END, "<synonym>..</synonym>" + "\n", 'syn')
        self.txt_excoul.insert(END, "<antonym>..</antonym>" + "\n", 'anto')
        
        
        self.txt_excoul.grid(row=0, column=1, padx=4, pady=4)
        
        
        # --- Cases de couleurs
        
        r = 0
        
        # Mot d'entrée
        r += 1
        Label(fr_coul, text=app.lg.get("winopt", "s17") + " :").grid(row=r, column=1)
        
        self.lab_c1f = Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c1f.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c1f.grid(row=r, column=2, padx=1)
        
        self.lab_c1b = Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c1b.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c1b.grid(row=r, column=3, padx=1)
        
        # Phonétique
        r += 1
        Label(fr_coul, text=app.lg.get("winopt", "s18") + " :").grid(row=r, column=1)
        
        self.lab_c2f = Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c2f.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c2f.grid(row=r, column=2, padx=1)
        
        self.lab_c2b = Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c2b.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c2b.grid(row=r, column=3, padx=1)
        
        # Traductions courtes
        r += 1
        Label(fr_coul, text=app.lg.get("winopt", "s19") + " :").grid(row=r, column=1)
        
        self.lab_c3f = Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c3f.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c3f.grid(row=r, column=2, padx=1)
        
        self.lab_c3b = Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c3b.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c3b.grid(row=r, column=3, padx=1)
        
        # Traductions longues
        r += 1
        Label(fr_coul, text=app.lg.get("winopt", "s20") + " :").grid(row=r, column=1)
        
        self.lab_c4f =Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c4f.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c4f.grid(row=r, column=2, padx=1)
        
        self.lab_c4b = Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c4b.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c4b.grid(row=r, column=3, padx=1)
        
        # Etymologie
        r += 1
        Label(fr_coul, text="Etymologie" + " :").grid(row=r, column=1)
        
        self.lab_c7f =Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c7f.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c7f.grid(row=r, column=2, padx=1)
        
        self.lab_c7b = Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c7b.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c7b.grid(row=r, column=3, padx=1)
        
        # Synonymie
        r += 1
        Label(fr_coul, text="Synonymie" + " :").grid(row=r, column=1)
        
        self.lab_c8f =Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c8f.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c8f.grid(row=r, column=2, padx=1)
        
        self.lab_c8b = Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c8b.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c8b.grid(row=r, column=3, padx=1)
        
        # Antonymie
        r += 1
        Label(fr_coul, text="Antonymie" + " :").grid(row=r, column=1)
        
        self.lab_c9f =Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c9f.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c9f.grid(row=r, column=2, padx=1)
        
        self.lab_c9b = Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c9b.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c9b.grid(row=r, column=3, padx=1)
        
        # Mot de liste
        r += 1
        Label(fr_coul, text=app.lg.get("winopt", "s16") + " :").grid(row=r, column=1)
        
        self.lab_c5f =Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c5f.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c5f.grid(row=r, column=2, padx=1)
        
        self.lab_c5b = Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c5b.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c5b.grid(row=r, column=3, padx=1)
        
        # Fond de notice
        r += 1
        Label(fr_coul, text=app.lg.get("winopt", "s21") + " :").grid(row=r, column=1)
        
        self.lab_c6b = Label(fr_coul, text="          ", border=1, relief="solid", cursor="hand2")
        self.lab_c6b.bind("<Button-1>", lambda event : self.onClickCoul(event))
        self.lab_c6b.grid(row=r, column=3, padx=1)
        
        # Bouton 'Couleurs par défaut'
        r += 1
        Button(fr_coul, text=" " + app.lg.get("winopt", "s22") + " ", command= lambda : self.applyColorDef()).grid(row=r, column=1)
        
        fr_coul.grid_remove()
        
        
        # --------------------------------
        # --- Frame des divers (onglet 3) 
        # --------------------------------
        
        fr_div = Frame(self, borderwidth=3, relief='ridge', padx=10)
        fr_div.grid(row=1, ipadx=20, ipady=20, sticky="WENS")
        
        # --- Actions au démarrage
        
        Label(fr_div, text=app.lg.get("winopt", "s11"), font="Helvetica 10 bold", height=2, justify=LEFT).pack(anchor='w')
        
        # Vérifier la disponibilité d'une nouvelle version
        self.vChkNewver = IntVar()
        Checkbutton(fr_div, text=app.lg.get("winopt", "s12"), variable=self.vChkNewver).pack(anchor='w')
        
        # Rouvrir le dernier fichier ouvert
        self.vOpenLastFile = IntVar()
        Checkbutton(fr_div, text=app.lg.get("winopt", "s13"), variable=self.vOpenLastFile).pack(anchor='w')
        
        # Rouvrir le dernier greffon ouvert
        self.vOpenLastPlugin = IntVar()
        Checkbutton(fr_div, text=app.lg.get("winopt", "s14"), variable=self.vOpenLastPlugin).pack(anchor='w')
        
        
        # --- Choix du langage d'interface
        
        Label(fr_div, text="Interface language :", font="Helvetica 10 bold", height=2, justify=LEFT).pack(anchor='w')
        self.lst_lg = lib.myscrlst.ScrolledList(fr_div, width=30, onclic=self.onclicLstlg)
        self.lst_lg.pack(anchor='w')
        
        
        # ---
        
        fr_div.grid_remove()
        
        
        # ------------------------------------------
        # --- Frame des Boutons de pied de page     
        # ------------------------------------------
        r = 2
        fr_butOpt=Frame(self)
        fr_butOpt.grid(row=r, column=0, columnspan=4, pady=8, sticky="WENS")
        
        Label(fr_butOpt, text="", width=wPan).grid(row=0, columnspan=3) # dimensionneur
        Button(fr_butOpt, image=app.imglst.ok, compound=LEFT, text="  Ok", width=100, padx= 10, command=self.__validerOptions).grid(row=0, column=0, pady=8, padx=10)
        Button(fr_butOpt, image=app.imglst.exit, compound=LEFT, text="  " + app.lg.get("g", "close"), width=100, padx= 10, command=self.destroy).grid(row=0, column=1, pady=8, padx=10)
        Button(fr_butOpt, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=100, padx= 10,command=lambda: app.showHelp("pref")).grid(row=0, column=2, pady=8, padx=10)
        
        
        # --------------------------
        # --- Gestion des onglets   
        # --------------------------
        listOngl = [ (ongl_0, fr_font), (ongl_1, fr_dir), (ongl_2, fr_coul ), (ongl_3, fr_div )]
        ongl_0['command'] = lambda: onglClick(0, listOngl, app.imglst, self, 'g')
        ongl_1['command'] = lambda: onglClick(1, listOngl, app.imglst, self, 'g')
        ongl_2['command'] = lambda: onglClick(2, listOngl, app.imglst, self, 'g')
        ongl_3['command'] = lambda: onglClick(3, listOngl, app.imglst, self, 'g')
        
        
        # préremplissage des données
        self.__prefill()
        
        
        # Afficher le panneau
        onglClick(seefirst, listOngl, app.imglst, self, 'g')
        
        
        return


    def __prefill(self):
        
        u"""
        | Préremplissage de la fenêtre avec les valeurs                         
        | courantes des options et paramètres.                                  
        """
        
        # ---------------------------
        # --- Police des entrées     
        # ---------------------------
        
        # --- Extraire le nom/taille de la police courante
        
        f = app.lst_dico['font'].split("}")
        
        if len(f) >1:
            sz = f[1].split()[0]
            f = f[0].strip("{}")
        else:
            f = f[0].split()
            sz = f[1]
            f = f[0]
        
        # --- Afficher dans l'interface
        self.txt_dicofontName.insert(END, f)
        self.txt_dicofontSize.insert(END, sz)
        
        # Appliquer la police courante à la case-exemple
        self.lab_exdicofont['font'] = app.lst_dico['font']
        
        
        
        # ----------------------------
        # --- Police de la notice     
        # ----------------------------
        
        # --- Extraire le nom/taille de la police courante
        
        f = app.txt_notice['font'].split("}")
        
        if len(f) >1:
            sz = f[1].split()[0]
            f = f[0].strip("{}")
        else:
            f = f[0].split()
            sz = f[1]
            f = f[0]
        
        # --- Afficher dans l'interface
        
        self.txt_traducfontName.insert(END, f)
        self.txt_traducfontSize.insert(END, sz)
        
        # Appliquer la police courante à la case-exemple
        self.lab_extraducfont['font'] = app.txt_notice['font']
        
        
        # -------------------------------------
        # --- Remplir les listes de polices    
        # -------------------------------------
        
        fntlst=list(tkFont.families())
        fntlst.sort()
        for t in fntlst:
            self.lst_font1.insert(END, t)
            self.lst_font2.insert(END, t)
        
        
        # --------------------
        # --- Chemins         
        # --------------------
        
        # --- Chemin de recherche des dictionnaires
        
        dp = app.ini.get('DicSearchPath','')
        
        try   : dp = dp.decode('utf-8').encode('latin-1')     # L'ini retourne le chemin en utf-8
        except: pass
        
        if os.path.isdir(dp):
            self.fb_pathSearch.config(initialdir=dp)
        
        
        # --- Répertoire de stockage des dictionnaires
        
        dp = app.ini.get('DicStorageFolder','')
        
        try   : dp = dp.decode('utf-8').encode('latin-1')     # L'INI retourne le chemin en utf-8
        except: pass
        
        if os.path.isdir(dp):
            self.fb_pathStor.config(initialdir=dp)
        
        # Afficher les noms de fichiers/conviviaux dans le menu
        if app.ini.get("DicNamesInMenu", "1") == "1":
            self.vOptMenudic.set("nmdic")
        else:
            self.vOptMenudic.set("nmfich")
        
        
        
        # ------------------------------
        # --- Couleurs                  
        # ------------------------------
        
        self.__prefillColor()
        
        
        # ------------------------------
        # --- Actions au démarrage      
        # ------------------------------
        
        # Vérifier la disponibilité d'une nouvelle version
        self.vChkNewver.set(int(app.ini.get("CheckNewVersion", "1")))
        
        # Rouvrir le dernier fichier ouvert
        self.vOpenLastFile.set(int(app.ini.get("OpenLastFile", "1")))
        
        # Rouvrir le dernier greffon ouvert
        self.vOpenLastPlugin.set(int(app.ini.get("OpenLastPlugin", "1")))
        
        
        
        # -------------------------------
        # --- Langue de l'interface      
        # -------------------------------
        
        
        # Remplir la liste avec le contenu du répertoire des langues
        
        lgpath = os.path.join(os.path.dirname(os.path.realpath(sys.argv[0])),'lang')
        lstfich = os.listdir(lgpath)
        
        for f in lstfich:
            
            if f == "verto.py":
                continue
            
            if f.endswith(".py") and not f.startswith("_"):
                for ligne in open(os.path.join(lgpath, f)):
                    if ligne.startswith('#lg_name#'):
                        self.lst_lg.add(ligne[9:].strip() + " - (" + f[0:-3] + ")")
                        break
        
        # Sélectionner la langue en cours
        
        ptrn = "(" + app.lg.getlgcode() + ")" 
        
        for i in range(self.lst_lg.listcount()):
            if ptrn in self.lst_lg.getitem(i):
                self.lst_lg.setSel(i)
                break
        
        
        return


    def __prefillColor(self):
        u"""
        | Recopie les couleurs de l'interface dans les cases d'édition          
        | des couleurs                                                          
        """
        
        
        self.txt_exliste['background'] = app.lst_dico['background']
        self.txt_exliste['foreground'] = app.lst_dico['foreground']
        
        self.txt_excoul['background'] = app.txt_notice['background']
        self.txt_excoul['foreground'] = app.txt_notice['foreground']
        
        self.txt_excoul.tag_config("miroir", foreground = app.txt_notice.tag_cget("miroir", "foreground"),
                                             background = app.txt_notice.tag_cget("miroir", "background"))
        
        
        self.txt_excoul.tag_config("phon", foreground = app.txt_notice.tag_cget("phon", "foreground"),
                                           background = app.txt_notice.tag_cget("phon", "background"))
        
        self.txt_excoul.tag_config("short", foreground = app.txt_notice.tag_cget("short", "foreground"),
                                            background = app.txt_notice.tag_cget("short", "background"))
        
        self.txt_excoul.tag_config("long", foreground = app.txt_notice.tag_cget("long", "foreground"),
                                           background = app.txt_notice.tag_cget("long", "background"))
        
        self.txt_excoul.tag_config("ety", foreground = app.txt_notice.tag_cget("ety", "foreground"),
                                           background = app.txt_notice.tag_cget("ety", "background"))
        
        self.txt_excoul.tag_config("syn", foreground = app.txt_notice.tag_cget("syn", "foreground"),
                                           background = app.txt_notice.tag_cget("syn", "background"))
        
        self.txt_excoul.tag_config("anto", foreground = app.txt_notice.tag_cget("anto", "foreground"),
                                           background = app.txt_notice.tag_cget("anto", "background"))
        
        self.lab_c1f['background'] = app.txt_notice.tag_cget("miroir", "foreground")
        self.lab_c1b['background'] = app.txt_notice.tag_cget("miroir", "background")
        
        self.lab_c2f['background'] = app.txt_notice.tag_cget("phon", "foreground")
        self.lab_c2b['background'] = app.txt_notice.tag_cget("phon", "background")
        
        self.lab_c3f['background'] = app.txt_notice.tag_cget("short", "foreground")
        self.lab_c3b['background'] = app.txt_notice.tag_cget("short", "background")
        
        self.lab_c4f['background'] = app.txt_notice.tag_cget("long", "foreground")
        self.lab_c4b['background'] = app.txt_notice.tag_cget("long", "background")
        
        self.lab_c5f['background'] = app.lst_dico['foreground']
        self.lab_c5b['background'] = app.lst_dico['background']
        
        self.lab_c6b['background'] = app.txt_notice['background']
        
        self.lab_c7f['background'] = app.txt_notice.tag_cget("ety", "foreground")
        self.lab_c7b['background'] = app.txt_notice.tag_cget("ety", "background")
        
        self.lab_c8f['background'] = app.txt_notice.tag_cget("syn", "foreground")
        self.lab_c8b['background'] = app.txt_notice.tag_cget("syn", "background")
        
        self.lab_c9f['background'] = app.txt_notice.tag_cget("anto", "foreground")
        self.lab_c9b['background'] = app.txt_notice.tag_cget("anto", "background")
        
        return
    
    
    def applyColorDef(self):
        u"""
        Restaurer les couleurs par défaut de l'interface
        """
        
        app.applyColor(flagdef=True)
        app.update()
        self.__prefillColor()
    
    

    def onClickCoul(self, event):
        u"""
        | Clic sur une case de couleur                                          
        | > afficher la boîte de sélection des couleurs                         
        """
        
        w = event.widget
        
        # Afficher la boîte de choix de couleur
        # Nb : l'argument title n'est pris en compte que sous Linux,
        #      sous Windows le titre reste par défaut : "Couleurs"... :-(
        c = tkColorChooser.askcolor(parent=self, title= "Modifier une couleur", color = w['background'])
        
        if c[1] is None: return # l'utilisateur a cliquer sur annuler
        
        # Modifier le background du widget Label
        w['background'] = c[1]
        
        # Modifier le tag de la case d'exemple
        if id(w) == id(self.lab_c1f):
            self.txt_excoul.tag_configure("miroir", foreground = c[1])
        elif id(w) == id(self.lab_c1b):
            self.txt_excoul.tag_configure("miroir", background = c[1])
        
        elif id(w) == id(self.lab_c2f):
            self.txt_excoul.tag_configure("phon", foreground = c[1])
        elif id(w) == id(self.lab_c2b):
            self.txt_excoul.tag_configure("phon", background = c[1])
        
        elif id(w) == id(self.lab_c3f):
            self.txt_excoul.tag_configure("short", foreground = c[1])
        elif id(w) == id(self.lab_c3b):
            self.txt_excoul.tag_configure("short", background = c[1])
        
        elif id(w) == id(self.lab_c4f):
            self.txt_excoul.tag_configure("long", foreground = c[1])
        elif id(w) == id(self.lab_c4b):
            self.txt_excoul.tag_configure("long", background = c[1])
        
        elif id(w) == id(self.lab_c7f):
            self.txt_excoul.tag_configure("ety", foreground = c[1])
        elif id(w) == id(self.lab_c7b):
            self.txt_excoul.tag_configure("ety", background = c[1])
        
        elif id(w) == id(self.lab_c8f):
            self.txt_excoul.tag_configure("syn", foreground = c[1])
        elif id(w) == id(self.lab_c8b):
            self.txt_excoul.tag_configure("syn", background = c[1])
        
        elif id(w) == id(self.lab_c9f):
            self.txt_excoul.tag_configure("anto", foreground = c[1])
        elif id(w) == id(self.lab_c9b):
            self.txt_excoul.tag_configure("anto", background = c[1])
        
        elif id(w) == id(self.lab_c5f):
            self.txt_exliste['foreground'] = c[1]
        elif id(w) == id(self.lab_c5b):
            self.txt_exliste['background'] = c[1]
        
        elif id(w) == id(self.lab_c6b):
            self.txt_excoul['background'] = c[1]
        return
    

    def onclicLstlg(self, idx=None, id=None):
        
        u"""
        | Clic sur une nouvelle langue d'interface                              
        | > avertir de la nécessité de redémarrer le programme                  
        """
        
        tkMessageBox.showinfo(parent=self,
            title = app.lg.get("winopt", "title"),
            message = self.lst_lg.getselecteditem() + "\n\nThis new interface language will be used at next starting Linguae")
        
        
        return
    
    
    def setDefFonts(self):
        
        u"""
        | [ appelé par le Bouton "Appliquer les polices par défaut" ]           
        |                                                                       
        | Affecte les polices par défaut dans les cases                         
        """
        
        self.txt_dicofontName.delete(0,END)
        self.txt_dicofontName.insert(END, "<defaut>")
        self.txt_dicofontSize.delete(0,END)
        self.txt_dicofontSize.insert(END, "9")
        
        # Appliquer la police à la case-exemple
        self.lab_exdicofont['font'] = (self.txt_dicofontName.get(), int(self.txt_dicofontSize.get()))
        
        # ---
        
        self.txt_traducfontName.delete(0,END)
        self.txt_traducfontName.insert(END, "<defaut>")
        self.txt_traducfontSize.delete(0,END)
        self.txt_traducfontSize.insert(END, "9")
        
        # Appliquer la police à la case-exemple
        self.lab_extraducfont['font'] = (self.txt_traducfontName.get(), int(self.txt_traducfontSize.get()))
        
        
        return


    def fontSel(self, n):
        
        u"""
        | [ appelé par le Clic sur un nom de police dans la liste ]             
        |                                                                       
        | Affiche le nom de police et met à jour la case-exemple                
        """
        
        if n == 1:
            self.txt_dicofontName.delete(0,END)
            self.txt_dicofontName.insert(END,self.lst_font1.get(self.lst_font1.curselection()[0]))
            
            # Appliquer la police à la case-exemple
            self.lab_exdicofont['font'] = (self.txt_dicofontName.get(), int(self.txt_dicofontSize.get()))
        
        else:
            self.txt_traducfontName.delete(0,END)
            self.txt_traducfontName.insert(END,self.lst_font2.get(self.lst_font2.curselection()[0]))
            
            # Appliquer la police à la case-exemple
            self.lab_extraducfont['font'] = (self.txt_traducfontName.get(), int(self.txt_traducfontSize.get()))
        
        return


    def __validerOptions(self):
        
        u"""
        | Valider les options puis fermer la fenêtre d'options                  
        """
        
        app['cursor'] = "watch"
        self['cursor'] = "watch"
        
        # ===================
        # === Polices        
        # ===================
        
        # Récupérer les noms de police en cours
        nmDico = self.txt_dicofontName.get()
        nmTraduc = self.txt_traducfontName.get()
        if nmDico == ""  : nmDico='<defaut>'
        if nmTraduc == "": nmTraduc='<defaut>'
        
        # Récupérer les tailles de police en cours
        try   : szDico=int(self.txt_dicofontSize.get())
        except: szDico=9
        try   : szTraduc=int(self.txt_traducfontSize.get())
        except: szTraduc=9
        
        # Regrouper le tout dans des chaînes uniques "splittables"
        strFontDico = nmDico + "?" + str(szDico) + "?normal"
        strFontTraduc = nmTraduc + "?" + str(szTraduc) + "?normal"
        
        app.appliquerFont(strFontDico, strFontTraduc)
        
        
        # ======================
        # === Chemins           
        # ======================
        
        app.ini.write('DicSearchPath', self.fb_pathSearch.getpath())    # Chemin de recherche par défaut
        app.ini.write('DicStorageFolder', self.fb_pathStor.getpath())   # Dossier de stockage
        
        if self.vOptMenudic.get() == "nmdic":
            app.ini.write('DicNamesInMenu', "1")
        else:
            app.ini.write('DicNamesInMenu', "0")
        
        app.updateMenuDic()
        
        
        # =======================
        # === Divers             
        # =======================
        
        if self.vChkNewver.get():
            app.ini.write('CheckNewVersion', '1')
        else:
            app.ini.write('CheckNewVersion', '0')
        
        if self.vOpenLastFile.get():
            app.ini.write('OpenLastFile', '1')
        else:
            app.ini.write('OpenLastFile', '0')
        
        if self.vOpenLastPlugin.get():
            app.ini.write('OpenLastPlugin', '1')
        else:
            app.ini.write('OpenLastPlugin', '0')
        
        
        # langue d'interface
        try:
            t = self.lst_lg.getselecteditem().split("(")[1].strip(")")
            app.ini.write("language", t)
        except:
            pass
        
        # =======================
        # === Couleurs           
        # =======================
        
        # Notice : mot d'entrée
        app.ini.write('HeadwordFgColor', self.lab_c1f['background'])
        app.ini.write('HeadwordBgColor', self.lab_c1b['background'])
        
        # Notice : phonétique
        app.ini.write('PhonFgColor', self.lab_c2f['background'])
        app.ini.write('PhonBgColor', self.lab_c2b['background'])
        
        # Notice : traductions courtes
        app.ini.write('ShortFgColor', self.lab_c3f['background'])
        app.ini.write('ShortBgColor', self.lab_c3b['background'])
        
        # Notice : traductions longues
        app.ini.write('LongFgColor', self.lab_c4f['background'])
        app.ini.write('LongBgColor', self.lab_c4b['background'])
        
        # Liste des entrées
        app.ini.write('ListFgColor', self.lab_c5f['background'])
        app.ini.write('ListBgColor', self.lab_c5b['background'])
        
        # Fond de notice
        app.ini.write('NoticeBgColor', self.lab_c6b['background'])
        
        # Etymologie
        app.ini.write('EtymFgColor', self.lab_c7f['background'])
        app.ini.write('EtymBgColor', self.lab_c7b['background'])
        
        # Synonymes
        app.ini.write('SynFgColor', self.lab_c8f['background'])
        app.ini.write('SynBgColor', self.lab_c8b['background'])
        
        # Antonymes
        app.ini.write('AntoFgColor', self.lab_c9f['background'])
        app.ini.write('AntoBgColor', self.lab_c9b['background'])
        
        # Raffraichir les couleurs de l'interface
        app.applyColor()
        
        # ===
        
        app['cursor'] = ""
        self['cursor'] = ""
        
        self.destroy()
        
        return


class WindowSplash(Toplevel):
    
    
    def __init__(self, version=None):
        
        Toplevel.__init__(self, relief="solid", borderwidth=2, background="white", padx=20, pady=20)
        
        # masquer la fenêtre (minimise le bref pop-up avant centrage de la fenêtre)
        self.withdraw()
        
        self.resizable(width=NO, height=NO)
        self.grab_set()               # fenêtre modale
        self.overrideredirect(1)
        
        self.logo = PhotoImage(data="""R0lGODlhUABQALMAAAAAABgYGDU1NU5OTmtra39/f5iYmK2trbW1tcHBwc7Oztra2ufn5+/v7/f39////ywAAAAAUABQAAAE/vDJSau91s2maXsdJo5kiYWS032mw5pwPKGXKr1yrreMtkwJR4+W2hmPNhzowjk6RUpM47P42K7PrHGBSBQMBEOh2mD8iI/fTCvqaN4jx+JAGBAQjMKAy1g+omwkGmUgNDgOCHQDAgYHCg95AgQHYAllbmhogUUbbwwKAwUABg4EDQoOBwwJCAUMBwACCQcpIT0zNpu1hRldBZKJ
        CgxNLggaCgUJBgoGEwcqDH27g5tuFBqsBosBBAK0fy9WQhyzBAUNBwgPB2eQvNJIfhgKAAUBAQ/1ifITyzUFX4a5cAHp0S4dKjTBSUUAAIADDZqtsVCg0C13CAQEMKAkxIoc/nCuvfBxIACAOzcgqeG05MqgPggGqJNni1+LIh5rDUPQ0EAQTTdQ5CqSqIDBQkMzCJo4xULEAaEgCa3g4CgJPUan/QF64g1BeB0EIgigJiRQIRb6KOs2YN0hqTZJcHAxN+26AAL6EHGxoEeDvgIVZLQjIFadWCYlosIVNw44XLn6
        GBg1MemBdAS6aTSpMRSBIBPq0Io2ESEVDsQm9AFFytkUAvcAmHTocAC3ZqCJIOAJookEeDJCPBroZ4EBAwLszKYdS0ByA2bqVLTyR1pCDSWt/tmaMLi1C4VjNx8AUTskOwUwHaT5Z8GjYU06shT52w31B4tGJfjBYmEZDs+N/vRdB6zQwsF7WOQSUgbW5OSMAMJwMIwECHDRyH6fCLCOAixMMhWFlkxhHQjR+MYVLyp1N4UGdyiwwBv/BfSDi9FM1kwfCwQwAACMuZAMDk1BQksSE57wQZH9/QYKAX65wMCObSlA
        wBx8AdBWHwdA1dZ3B/ySgBkSLLDSdvOhIM0tMK7wl5deqSCKUQqw8wgXYbyxAEAEVNAHA91AchEqOXlVA4lF9KWgAcYtk5SLCngx2n4DSFTGJy92l0oAX8AV1Hyc1kJQb0JosAokDU3pB2p++uWWAeokkQJ8KiRwzwAioqnDB6hUAQ0ZIeyIKZovmCEsCLK66CRdgkpwz5dm/mBxwUUM+nFMqBMgIBten9hpojDRyJrAdir8ZVETDgFx3RAlYNJmddA2wJOOBwQhTjRV/dWXRqwq4OJ/fmBZTxnulbhif3Wh6JEP
        OonKwRwOdbNYiFWkseID9lAR8YpuMHCPT/GqeIYVUwQ5X1PEfGoQLQZwVmGoZaBiiXsLaKQKoCm59YBJBAxEr4gcRpyLb5xAo2KoaG11yj2qCOtiAvoSVMckr26gzCsaVWTLQAQ1Bcdb48y1Z2/yTNHoSUaJiSNdw9gTwCw+aQ32jnmGs69ATZ54XUKoJQtJGchBWCECxBxp7R4foNrSAYV9M9e64F7SmIKWpjGIqNG4qNGU/vq29EYBmQGqVwhqu9KfED/0gC4vQIkTLpGQ3eKcjiWG8EE3TMrRhCV/vK4pUpqD
        7aDmMEoLDjV8lZHAYWOg+p4CAlSUwPMteSFb8kWEzELBvzPmO9ZyqClVVbZxY9zXEkhJyikPfAuCtQAgIAyZ69DL+yWZfzhD3SuImsI3gsEGgGDUQdST2FG43zBADABwgOhqUYXPUSFog+pEybhTQJA9QBtWClUPhLEA8mSudH0ojIYcoL5LSMgvBdMeVfp1neEN40wJwYMoICSMQehLAO6hwyRW0bdIwWdIKugLIaQxl5GQAIhFS4MSQ/KlBtiGR88TkxcawRbnCOYBMgPc/pGGQjQO+cZdcUDB4igXsQm9hBmF
        MUoApAQb8d0pTtABAw6fsZUKbQUe3xpHmICjlJ+Fi2fu8Iq7SKix2uzIIZyhTXI28xBLHGsQhftOYzp1tyAhQlzcE4gCGQmVwvjKIZI4CTemtLgl/OdFj2FPcPL2GEy4BxI8yUj7hNENBIjBDrBJjgfVtRoOWcos6VLKf1jWm8J96Qs7Og6rBnA8wjQCZ6iY0J5YYCwbZGtBIFFNU4ZjBX3FaRV1QA/b8DIlB0zPQ0JAYUL2M0SBJMkxHhCUikD1lwhx4XWvoETznkiWhkHnjnpRCXyQwkV4eup7xEFRA4XQBT7t
        85a0Od4C/k6iL8cBbXF6GQIg4Dk5UO2lePpqo0y0wTSoOOA4+Minn3Ch0Urd4i18hOBU5LBCQqxPDLDJyD28MQdmQuUkGOOQTpqVUZcEM0GomucLUOkOVOjhdQVAnHNEcRI8sMARusIGf64DtJvcDUVowlpAy9AlViwgl8cBSD4e8oq/dM+a38LeJNtQBIEc1B0TOIMQkDMb8lgCIlFFjjlUITkyFOI9KLKJ3aiyEFQEa28piRRylqHMHdlDIkp0z19CtjeMtQRoJyqNUPpQQKRUzgE41APtCECPzIQhCoX7xEv3
        Eg/NVapMYsoSI35qB1/hSxzRkmSnYjBTxgZxAo/oRkrZ1GeUSBVioyfQBS+CdbUDIueTbVmEDzswk+F6IBCyS0r1poCV2HzhF4bZyC0kIl7pVgBkNE1BfFIipr904yS1SU7HyPEq+7lXtHDBaJYoVixj1HIAIwKMk0rz35qGwFDx6hLz0tGWz5jiC+2A31cb3JVr9AZLeb3qjdqrSg4bFDB3GoBBmsGIcyRRuCZOV4n255wwdKkPd4hrBGNMXOqQNjOtoAQd5srjHYTreRJWMRYNReQi72AIrP0B4JpIYifvuEzX
        AIuVt8zlLnv5y2AOs5itHAEAADs=""")
        
        
        # Interface graphique
        lab_logo=Label(self,image=self.logo, background="white")
        lab_logo.grid(row=0, column=0)
        Label(self, text="Linguae    ", background="white", foreground="red", font="Times 30 bold").grid(row=0, column=1)
        if version:
            Label(self, text="Version " + version, font="Helvetica 10 bold", background="white").grid(row=1, column=1)
        
        # Centrer la fenêtre
        self.update()
        self.deiconify()
        self.focus_set()
        lib.mytools.centerWin(self)
        
        # Toujours au premier plan par :
        # si "perte de focus" -> "redonner le focus"
        # car Topmost ne marche que sous Windows
        
        self.bind("<FocusOut>", lambda event: self.focus_set())
        
        return
    
    

class WindowAskLanguage(Tk):
    
    u"""
    | Fenêtre (Tk) de choix par l'utilisateur du langage à utiliser pour        
    | l'interface.                                                              
    |                                                                           
    | Fenêtre s'affichant au lancement du programme si aucun langage d'interface
    | n'est mémorisé dans l'ini.                                                
    |                                                                           
    | Cette fenêtre est Tk() et non Toplevel() car elle est instanciée, si      
    | besoin, par WindowMain__init__() avant Tk.init()                           
    """
    
    def __init__(self, iniobj=None):
        
        u"""
        | Mise en place del'interface graphique                                 
        |                                                                       
        |   ARGUMENTS :                                                         
        |       'iniobj' : objet d'accés au fichier ini                         
        """
        
        Tk.__init__(self)
        self.title("Linguae")
        self.resizable(width=NO, height=NO)
        self.grab_set()               # fenêtre modale
        self.focus_set()
        
        # Objet fichier ini 
        self.ini = iniobj
        
        
        # Procédure qui sera appelée à la tentative de fermeture de la fenêtre
        self.protocol('WM_DELETE_WINDOW', self.queryUnload)
        
        
        # ---------------------------
        # --- Interface graphique ---
        # ---------------------------
        
        Label(self, text="Select a language for the interface:").pack()
        self.lst_lg = lib.myscrlst.ScrolledList(self, width=30, onclic=self.oncliclst, ondblclic=self.selectlang)
        self.lst_lg.pack()
        self.bt_ok = Button(self, text="OK", width=10, state='disabled', command=self.selectlang)
        self.bt_ok.pack(fill=X)
        
        self.__prefill()
        
        self.update()
        
        # Centrer la fenêtre
        lib.mytools.centerWin(self)
        
        self.mainloop()
        
        
        return
    
    
    
    def __prefill(self):
        
        u"""
        | Remplir la liste avec le contenu du répertoire des langues            
        """
        
        lgpath = os.path.join(os.path.dirname(os.path.realpath(sys.argv[0])),'lang')
        lstfich = os.listdir(lgpath)
        
        for f in lstfich:
            if f.endswith(".py") and not f.startswith("_"):
                for ligne in open(os.path.join(lgpath, f)):
                    if ligne.startswith('#lg_name#'):
                        self.lst_lg.add(ligne[9:].strip() + " - (" + f[0:-3] + ")")
                        break
        
        return
    
    
    def queryUnload(self):
        u"""
        | Fermer la fenêtre sans définir de langage > Quitter le programme      
        """
        sys.exit()
        return
    
    def oncliclst(self, idx=None, id=None):
        u"""
        | Clic sur une langue > activer le bouton ok                            
        """
        
        self.bt_ok['state']="normal"
        
        return

    def selectlang(self, idx=None, id=None):
        u""""
        | Sélection de la langue par le bouton ou un double clic sur la liste   
        """
        
        t = self.lst_lg.getselecteditem().split("(")[1].strip(")")
        
        self.ini.write("language", t)
        
        self.quit()



class WindowNewDic(Toplevel):
    
    u"""
    | Fenêtre de création et d'ouverture d'un nouveau dictionnaire vide         
    """

    def __init__(self):
        
        u"""
        | Mise en place de l'interface graphique                                
        """
        
        Toplevel.__init__(self)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winnew", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        
        ww = 80
        
        # ---------------------------------
        # --- Frame du format de fichier   
        # ---------------------------------
        
        fr_type=LabelFrame(self, text=app.lg.get("winnew", "s1"))
        fr_type.grid(row=0, column=0, columnspan=10)
        
        Label(fr_type,width=ww).grid(row=0, column=0) #dimensionneur
        
        self.vFileType = StringVar()
        Radiobutton(fr_type, text="Ling", variable=self.vFileType, value="ling").grid(row=0,column=0, padx=5, sticky='W')
        Radiobutton(fr_type, text="Dict", variable=self.vFileType, value="dict").grid(row=1,column=0, padx=5, sticky='W')
        Radiobutton(fr_type, text="XDXF", variable=self.vFileType, value="xdxf").grid(row=2,column=0, padx=5, sticky='W')
        Radiobutton(fr_type, text="WB", variable=self.vFileType, value="wb").grid(row=3,column=0, padx=5, sticky='W')
        Radiobutton(fr_type, text="INI", variable=self.vFileType, value="ini").grid(row=4,column=0, padx=5, sticky='W')
        Radiobutton(fr_type, text="CSV " + app.lg.get("winnew", "s2"), variable=self.vFileType, value="csv").grid(row=5,column=0, padx=5, sticky='W')
        self.vFileType.set('ling')
        
        
        # ----------------------------------------------------
        # --- Frame du répertoire du nouveau dictionnaire     
        # ----------------------------------------------------
        
        fr_rep=LabelFrame(self, text=app.lg.get("winnew", "s3"))
        fr_rep.grid(row=1, column=0, columnspan=10, padx=4, pady=2)
        
        Label(fr_rep, width=ww, height=2).grid(row=0, column=0, columnspan=10) #dimensionneur
        
        self.fb_folder=lib.myfldbrw.FolderBrowser(fr_rep, width=80)
        self.fb_folder.grid(row=0, column=0, padx=5, sticky='WN', pady=5)
        
        # Case à cocher 'Créer dans le dossier des dictionnaires'
        self.vChkDicFolder = IntVar()
        ChkDicFolder=Checkbutton(fr_rep, text=app.lg.get("winnew", "s4"), variable=self.vChkDicFolder, command=self.onclicChkDicFolder)
        ChkDicFolder.grid(row=1, column=0, sticky='WN')
        
        
        # Présélectionner le répertoire de stockage des dicos
        dp = app.ini.get('DicStorageFolder','')
        if dp != "":
            ChkDicFolder.select()
            self.fb_folder.config(initialdir=dp, state='disabled')
        else:
            ChkDicFolder['state']='disabled'
        
        
        # ------------------------------
        # --- Frame du nom de fichier   
        # ------------------------------
        
        fr_name=LabelFrame(self, text=app.lg.get("winnew", "s5"))
        fr_name.grid(row=2, column=0, columnspan=10, padx=4, pady=2)
        
        Label(fr_name,width=ww, height=4).grid(row=0, column=0) #dimensionneur
        
        self.txt_name=Entry(fr_name, width=30, background="white")
        self.txt_name.grid(row=0, column=0)
        self.txt_name.insert(END, "newdic")
        
        
        # -------------------------
        # --- Frame des Boutons    
        # -------------------------
        fr_but=Frame(self)
        fr_but.grid(row=3, column=0, columnspan=10, padx=4, pady=2)
        
        Button(fr_but, image=app.imglst.ok, compound=LEFT, text="  " + app.lg.get("winnew", "s6"), width=100, padx= 10, command=self.makeNewDic).grid(row=0, column=0, pady=8, padx=10)
        Button(fr_but, image=app.imglst.exit, compound=LEFT, text="  " + app.lg.get("g", "close"), width=100, padx= 10, command=self.destroy).grid(row=0, column=1, pady=8, padx=10)
        Button(fr_but, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=100, padx= 10,command=lambda: app.showHelp("newdic")).grid(row=0, column=2, pady=8, padx=10)
        
        return


    def onclicChkDicFolder(self):
        
        u"""
        | Clic sur la case 'utiliser le dossier de stockage des dictionnaires'  
        """
        
        if self.vChkDicFolder.get() == 1:
            self.fb_folder.config(initialdir = app.ini.get('DicStorageFolder',''),
                                  state = 'disabled')
        else:
            self.fb_folder.config(state = 'normal')
        
        
        return


    def makeNewDic(self):
        
        u"""
        | Créer un nouveau dictionnaire vide                                    
        """
        
        newDicType = self.vFileType.get()
        
        # -----------------------------------------------------------------
        # --- Confectionner le chemin du fichier du nouveau dictionnaire   
        # -----------------------------------------------------------------
        
        if newDicType == 'xdxf':
            
            repxdxf = os.path.join(self.fb_folder.getpath(),self.txt_name.get())
            fichpath = os.path.join( repxdxf, "dict.xdxf")
            
        else :
            
            fichpath = os.path.join(self.fb_folder.getpath(),self.txt_name.get()) + "." + newDicType
        
        # Vérifier qu'aucun fichier n'existe sous ce nom
        if os.path.isfile(fichpath):
            tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("winnew", "title"),
                    message = app.lg.get("winnew", "msg1") )
            return
        
        # ------------------------------------------------------
        # --- Initialiser le nouveau dictionnaire               
        # ------------------------------------------------------
        
        cp1 = ""
        cp2 = ""
        if newDicType == 'ling': # -----------------------------
            
            strFich = lib.mydic.DicObject.strPrelingToStrLing(strPreling="%preling")
            
            # Echec > avertir et quitter
            if strFich.startswith("!"):
                tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("winnew", "title") + " Ling",
                    message = strLing)
                return
            
        elif newDicType == 'dict': # -----------------------------
            
            radicfich = os.path.splitext(fichpath)[0]
            
            # le *.dict est enregistré dans la section commune plus bas
            strFich=""
            
            # Enregistrer le *.idx
            ff = open(radicfich + ".idx", 'wb')
            ff.write("")
            ff.close()
            
            # Enregistrer le *.ifo
            t ="StarDict's dict ifo file\nversion=2.4.2\nbookname=" + os.path.basename(radicfich) +\
            "\nwordcount=0" +\
            "\nidxfilesize=" + str(os.path.getsize(radicfich + ".idx")) +\
            "\nsynwordcount=\nsametypesequence=m\nidxoffsetbits=32\nauthor=\nemail=\nwebsite=\ndescription=\ndate=\n"
            
            try:
                t = t.encode('utf-8')
            except:
                tkMessageBox.showwarning(parent=self,
                title = app.lg.get("winnew", "title") + " Dict",
                message = app.lg.get("winnew", "msg2") )
                return
            
            ff = open(radicfich + ".ifo", 'wb')
            ff.write(t)
            ff.close()
            
        elif newDicType == 'xdxf': # -----------------------------
            
            if not os.path.isdir(repxdxf):
                os.mkdir(repxdxf) # Créer le répertoire du dico
            
            strFich = '<?xml version="1.0" encoding="UTF-8" ?>\n<xdxf lang_from="" lang_to="" format="visual">\n<ar><head><k>Mot1</k></head>\n<def>Traduction1</def></ar>\n</xdxf>\n'
            
        elif newDicType == 'wb': # -----------------------------
            
            strFich=""
            
        elif newDicType == 'csv': # -----------------------------
            
            strFich="Mot1\tTraduction1\nMot2\tTraduction2\n"
            
        elif newDicType == 'ini': # -----------------------------
            
            strFich="[Section1]\nClef1=Valeur1\nClef2=Valeur2\n[Section2]\nClef1=Valeur1\nClef2=Valeur2\n"
            cp1 = "latin-1"
            cp2 = "latin-1"
            
        else:
            print "Format non reconnu : " + newDicType
            
        
        # ---------------------------------------
        # --- Enregistre le nouveau fichier      
        # ---------------------------------------
        
        try   : app.dic.file.close()
        except: pass
        ff = open(fichpath, 'wb')
        ff.write(strFich)
        ff.close()
        
        # -------------------------------------------------------
        # -- Recharge le dictionnaire avec le nouveau fichier    
        # -------------------------------------------------------
        
        app.loadDico(fichpath, cp1=cp1, cp2=cp2, showSplash=False)
        
        app.updateMenuDic()
        
        self.destroy()
        
        return
    
    

class WindowChkLinks(Toplevel):
    
    u"""
    | Fenêtre de recherche des liens (relations) morts                          
    |                                                                           
    """
    
    
    def __init__(self):
        
        u"""                                                                    
        | Mise en place de l'interface graphique                                
        """        
        
        self.lstidx = []    # pyListe des index-dictionnaire des entrées listées 
        
        Toplevel.__init__(self, padx=3)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
                
        self.title(app.lg.get("winlk", "title"))
        self.resizable(width=NO, height=NO)
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        
        # ---
        
        Label(self, text="Les liens des relations (synonymes etc.) vont être contrôlés : recherche des liens morts.").grid(row=0, pady=3)
        
        self.lst_result = lib.myscrlst.ScrolledList(self, width=60, height=10, onclic=self.__onClickRes, selectborderwidth=2)
        self.lst_result.grid(row=1)
        
        
        # -------------------------
        # --- Frame des Boutons    
        # -------------------------
        r = 2
        fr_bt=Frame(self)
        fr_bt.grid(row=r, column=0, columnspan=10, pady=8, sticky="WENS")
        
        self.bt_Do=Button(fr_bt, image=app.imglst.ok, compound=LEFT, text="  OK ", width=90, padx= 7, command=self.doCheck)
        self.bt_Do.grid(row=0, column=0, pady=8, padx=10)
        
        Button(fr_bt, image=app.imglst.exit, compound=LEFT, text="  " + app.lg.get("g", "close"), width=90, command=self.destroy, padx= 7).grid(row=0, column=1, pady=8, padx=10)
        Button(fr_bt, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=90, padx= 7, command=lambda: app.showHelp("chklnk")).grid(row=0, column=2, pady=8, padx=10)
        
        # Barre de progression
        self.progr = lib.myprogbr.ProgressBar(self, width=380)
        self.progr.grid(row=r+1, column=0, columnspan=4, pady=5)
        self.progr.grid_remove()
        
        
        return


    def __onClickRes(self, idxlst, idw):
        
        u"""
        | Clic sur un mot de la liste des résultats de recherche                
        | Affighage de l'élément cliqué dans la fenêtre principale              
        |                                                                       
        | ARGUMENTS :                                                           
        |     'idxlst' : index du mot cliqué dans la liste.                     
        |                                                                       
        |     'idw' : ID du widget (inutile ici mais nécessaire à la            
        |             procédure 'onclic' de la liste).                          
        """
        
        # Extraire l'index du libellé
        i = self.lstidx[int(idxlst)]
        
        # Afficher le mot du dictionnaire dans la fenêtre principale
        app.dic.lstbox.activate(i)
        app.dic.lstbox.selection_set(i)
        app.dic.lstbox.see(i)
        app.selDisplayData(None)
        
        
        
        return


    def doCheck(self):
        
        u"""
        | Contrôler les liens
        """
        
        self.progr.setMax(app.dic.wordcount)
        self.progr.grid()
        
        getdata = app.dic.getdata           # accélérateurs locaux
        isdickey = app.dic.wordIDs.has_key
        
        self.lst_result.clear()
        self.lstidx = []
        
        for i in range(app.dic.wordcount):
            
            self.progr.setValue(i)
            
            data = getdata(i)
            
            wIDs = []
            
            if data['rac'] != "" and not data['rac'].startswith("|!|"):
                wIDs += data['rac'].split(";")
            if data['syn'] != "" and not data['syn'].startswith("|!|"):
                wIDs += data['syn'].split(";")
            if data['ant'] != "" and not data['ant'].startswith("|!|"):
                wIDs += data['ant'].split(";")
            if data['see'] != "" and not data['ant'].startswith("|!|"):
                wIDs += data['see'].split(";")
                
            if len(wIDs) == 0:
                continue
            
            for wID in wIDs:
                if not isdickey(wID.strip()):
                    self.lst_result.add(data['mot'] + "    >    " + wID)
                    self.lstidx.append(i)
            
        # Si aucun lien mort n'est trouvé :
        if self.lst_result.listcount() == 0:
            self.lst_result.add("...OK...")
            
            
        self.progr.grid_remove()
        
        
        return



class WindowDicDownload(Toplevel):
    
    u"""
    | Fenêtre de téléchargement de dictionnaires                                
    """
    
    
    def __init__(self, indexurl):
        
        u"""                                                                    
        | Mise en place de l'interface graphique                                
        | On instancie avec l'url du document d'indexation des dictionnaires    
        """
        
        
        # initialisation de la pyListe de l'index distant (liste des dicos
        # disponibles en téléchargement)
        # chaque élement de la pyListe est un pydictionnaire
        # des données du dico : url, statut de m.à.j, statut du coche, etc.
        
        self.remoteindex = []
        
        Toplevel.__init__(self)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('700x600+' + left + '+' + top)
        
        self.title(app.lg.get("windwn", "title"))
        self.grab_set()      # fenêtre modale
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        # Frame de tête
        fr_hd = Frame(self, pady=3, padx =3)
        fr_hd.pack(fill=X, anchor=CENTER)
        
        # Lien vers Polyglotte
        Label(fr_hd, text=app.lg.get("windwn", "s7")).grid(row=0, column=0)
        lab_polyg = Label(fr_hd, text=app.lg.get("windwn", "s8"), foreground="blue", cursor="hand2")
        lab_polyg.bind("<ButtonRelease-1>", app.toWebPolyglotte)
        lib.infobulle.InfoBulle(parent=lab_polyg, text=app.lg.get("windwn", "ib1"))
        lab_polyg.grid(row=0, column=1, sticky=W)
        
        
        # Bouton d'options de filtrage
        Label(fr_hd, text=" "*20 + "Filtre : ").grid(row=0, column=2, sticky=E)
        self.vFilter = StringVar()
        OptionMenu(fr_hd, self.vFilter,
            "[--]  " + "Tous les dictionnaires",
            "[A1]  " + "Dictionnaires installés mais non à jour",
            "[A2]  " + "Dictionnaires non installés",
            "-------------------",
            "[B1]  " + "Dictionnaires unilingues français",
            "[B2]  " + "Dictionnaires français > autre langue",
            "[B3]  " + "Dictionnaires autre langue > français",
            "-------------------",
            "[C1]  " + "Dictionnaires du domaine public",
            "[C2]  " + "Dictionnaires sous licence Creative Commons",
            "[C3]  " + "Dictionnaires sous licence GNU-GPL",
            "[C4]  " + "Dictionnaires sous copyright",
            "-------------------",
            "[D1]  " + "Dictionnaires au format Ling",
            "[D2]  " + "Dictionnaires au format XDXF",
            "[D3]  " + "Dictionnaires au format (Star)Dict",
            "-------------------",
            "[E1]  " + "Fr <> Lanques indo-européennes italiques",
            "[E2]  " + "Fr <> Lanques indo-européennes germaniques",
            "[E3]  " + "Fr <> Lanques indo-européennes celtiques",
            "[E4]  " + "Fr <> Lanques indo-européennes slaves",
            "[E5]  " + "Fr <> Langues indo-européennes (autres)",
            "[E6]  " + "Fr <> Langues non-indo-européennes",
            "[E7]  " + "Fr <> Langues anciennes ou scientifiques",
            "[E8]  " + "Fr <> Langues et parlers régionaux",
            
            command = self.__onclicFilter,
            ).grid(row=0, column=3, sticky=E)
        
        self.vFilter.set("[--]  Tous les dictionnaires")  # par défaut
        self.memovFilter = self.vFilter.get()       # mémoriser (permet le rétablissement après clic sur un séparateur)
        
        
        # ----------------------------------------------------------------------
        # --- Liste (textBox)                                                   
        # ----------------------------------------------------------------------
        
        self.txt_index = ScrolledText.ScrolledText(self, font="Courier 10 normal", height=6, background="white", wrap="word")
        self.txt_index.pack(expand=True, fill=BOTH)
        
        decal = 60
        
        # Styles d'affichage
        self.txt_index.tag_config("sep", wrap=NONE)
        self.txt_index.tag_config("nom", font="Helvetica 10 bold", lmargin1=5, spacing1=100)
        self.txt_index.tag_config("present_ajour", foreground="grey")
        self.txt_index.tag_config("present_nonajour", foreground="orange")
        self.txt_index.tag_config("absent", foreground="black")
        
        
        # ----------------------------------------------------------------------
        # --- Frame des Boutons                                                 
        # ----------------------------------------------------------------------
        
        r = 2
        fr_but=Frame(self, pady=5)
        fr_but.pack(fill=X)
        
        # Etiquette du nbre de dicos sélectionnés
        Label(fr_but, text=" " + app.lg.get("windwn", "s6")).grid(row=0, column=0)
        self.lab_nbdic=Label(fr_but, text="0")
        self.lab_nbdic.grid(row=0, column=1)
        
        # Etiquette du nombre total de dicos
        self.lab_nbtot=Label(fr_but, text="/ 0")
        self.lab_nbtot.grid(row=0, column=2)
        
        # Boutons
        self.bt_do=Button(fr_but, state="disabled", image=app.imglst.dwnld, compound=LEFT, text="  " + app.lg.get("windwn", "s5") + " ", padx= 10, command=self.doInstall)
        self.bt_do.grid(row=0, column=3, padx=10)
        self.bt_esc=Button(fr_but, image=app.imglst.exit, compound=LEFT, text="  " + app.lg.get("g", "cncl"), width=100, padx= 10, command=self.destroy)
        self.bt_esc.grid(row=0, column=4, padx=10)
        Button(fr_but, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=100, padx= 10,command=lambda: app.showHelp("dwnld")).grid(row=0, column=5, padx=10)
        
        
        # ----------------------------------------------------------------------
        # --- Frame de la Barre de progression                                  
        # ----------------------------------------------------------------------
        
        self.fr_progr = Frame(self)
        self.fr_progr.pack(fill=X)
        
        self.lab_url = Label(self.fr_progr, text="...")
        self.lab_url.pack(anchor="w")
        
        self.progr = lib.myprogbr.ProgressBar(self.fr_progr)
        self.progr.pack(expand=TRUE, fill=X, side=LEFT)
        
        Label(self.fr_progr, image=app.imglst.poign).pack(side=LEFT)        
        
        
        # -------------------------------------
        # --- Télécharger l'index en ligne     
        # -------------------------------------
        
        self['cursor'] = 'watch'
        app['cursor'] = 'watch'
        
        flagfailconnect = False
        
        # Afficher le message "Connexion en cours"
        self.txt_index.insert(END, "\n  " + app.lg.get("windwn", "s9")) 
        self.update()
        
        try:
            lignes = urllib.urlopen(indexurl).readlines()
        except:
            flagfailconnect = True
        
        
        # Lire la racine de téléchargement
        try:
            root = lignes[0].split("\t")[0]
            self.dwnroot = root.split("=")[1].strip('"')
        except:
            flagfailconnect = True
        
        
        if flagfailconnect :
            # Message d'échec du téléchargement de l'index
            self.txt_index.delete("1.0", END)
            self.txt_index.insert(END, "\n  " + app.lg.get("windwn", "msg1"))
            self['cursor'] = ''
            app['cursor'] = ''
            return
        
        
        del lignes[0]
        
        
        # ------------------------------------------------------
        # --- Construire en mémoire l'index des dicos distants  
        # ------------------------------------------------------
        
        lignes.sort()
        
        for ligne in lignes:
            
            elem = {} # pyDictonnaire de la ligne/dico (complété plus bas)
            
            
            # Supprimer les caractères de saut de ligne (conservés par readlines() )
            ligne = ligne.strip("\r\n")
            
            # Scinder la ligne en champs
            chp = ligne.split("\t")
            
            # Nettoyer les guillemets entourant les champs
            for i in range(len(chp)):
                chp[i] = chp[i].strip('"')
            
            # Sauter les lignes vides et les lignes de commentaires
            if chp[0] == "" or chp[0][0] == "#":
                continue
            
            # FORMAT D'UNE LIGNE D'INDEX :        
            #   chp[0]  : nom convivial du dico   
            #   chp[1]  : version                 
            #   chp[2]  : date                    
            #   chp[3]  : auteur                  
            #   chp[4]  : format                  
            #   chp[5]  : url du zip              
            #   chp[6]  : nom(s) fichier(s) inclus
            #   chp[7]  : familles de langues     
            #   chp[8]  : sens de traduction      
            #   chp[9]  : licence                 
            #   chp[10] : poids                   
            #   ...                               
            #   chp[x]  : (non pris en compte)    
            #   ...                               
            #   chp[len(chp)-1] : commentaires    
            
            
            # Exclure les lignes mal formatées
            if len(chp)< 8:
                print "!!! LIGNE MALFORMATEE DANS L'INDEX !!! :"
                try:
                    print ligne
                except:
                    print ligne.encode('utf-8')
                
                continue
            
            # Compléter le pyDictionnaire de la ligne/dico
            elem['coche']   = False
            elem['visible'] = True
            elem['maj']     = "absent"
            elem['nom']     = chp[0].strip()
            elem['version'] = chp[1].strip()
            elem['date']    = chp[2].strip()
            elem['auteur']  = chp[3].strip()
            elem['format']  = chp[4].strip().lower()
            
            fichurl = chp[5].strip()
            if not fichurl.startswith("http"):
                    fichurl= self.dwnroot + fichurl
            elem['url']     = fichurl
            
            elem['files']   = chp[6].strip()
            elem['lgfam']   = chp[7].strip().lower()
            elem['senstr']  = chp[8].strip().lower()
            elem['lic']     = chp[9].strip().lower()
            elem['size']    = chp[10].strip().replace(";", " (zip) [") + "]"
            elem['com']     = chp[len(chp)-1].strip()
            
            # Compléter la pyListe d'index avec l'élément
            self.remoteindex.append(elem)
        
        
        # Afficher la liste des dicos disponibles
        
        self.__writeList()
        
        self.txt_index.focus_set()
        
        return
    
    
    def __onclicFilter(self, event=None):
        u"""
        | Clic sur un élément de la liste                                       
        """
        
        # Ne rien faire si clic sur un pseudo-séparateur
        if self.vFilter.get().startswith("---"):
            # Rétablir le filtre antérieur
            self.vFilter.set(self.memovFilter)
            return
        
        # Mémoriser le nouveau filtre
        self.memovFilter = self.vFilter.get()
        
        self.__writeList()
        
        return
    
    
    
    def __toggleInfo(self, idx):
        u"""
        | Masque ou affiche le panneau d'info du dico
        | (appelé par le clic sur l'icône d'expansion)
        """
        
        exec("down=self.down" + str(idx) )
        
        if down['text']== "+":
            exec("self.box" + str(idx) +"['height']=13")
            down.config( text = "-", image = app.imglst.moins)
        else:
            exec("self.box" + str(idx) +"['height']=1")
            down.config( text = "+", image = app.imglst.plus)
        
        
        
        return
    
    def __writeDico(self, n):
        
        u"""
        | Ecrire les données du dico d'index 'n' dans la liste de la fenêtre    
        """
        
        elem = self.remoteindex[n]
        
        # variables chaînes des titres de ligne
        hAuteur = "\t" + app.lg.get("windwn", "s1").ljust(15) + ": "
        hVersion = "\t" + app.lg.get("windwn", "s3").ljust(15) + ": "
        hDate = "\t" + app.lg.get("windwn", "s2").ljust(15) + ": "
        hLicence = "\t" + app.lg.get("windwn", "s14").ljust(15) + ": "
        hFormat = "\t" + app.lg.get("windwn", "s4").ljust(15) + ": "
        hNomfich = "\t" + app.lg.get("windwn", "s11").ljust(15) + ": "
        hSize = "\t" + app.lg.get("windwn", "s18").ljust(15) + ": "
        hCom = "\t" + app.lg.get("windwn", "s10").ljust(15) + ": "
        hinstok = "\t" + app.lg.get("windwn", "s16") + "\n"
        hinstno = "\t" + app.lg.get("windwn", "s15") + "\n"
        hinstup = "\t" + app.lg.get("windwn", "s19") + "\n"
        
        
        # indicateur de mise à jour (contient le nom du style d'affichage correspondant)
        maj = "absent"  
        
        
        
        # --- Création et affichage de la case à cocher
        
        exec("self.vChk" + str(n) + "=StringVar()") in locals(), globals()
        exec("self.chk_dic" + str(n) + "=Checkbutton(self.txt_index)") in locals(), globals()
        
        exec("chk = self.chk_dic" + str(n)) in locals(), globals()
        exec("vChk = self.vChk" + str(n)) in locals(), globals()
        
        chk.config( background = self.txt_index['background'],
                    cursor = "arrow",
                    activebackground = self.txt_index['background'],
                    highlightthickness = 0,
                    variable = vChk,
                    onvalue = "x" + str(n),
                    offvalue = "z" + str(n),)
        
        if self.remoteindex[n]['coche']:
            vChk.set("x" + str(n))
        else:           
            vChk.set("z" + str(n))
            
        chk.bind("<ButtonRelease-1>", self.__selectDic)
        self.txt_index.window_create(END, window=chk)
        
        
        # --- Icône du format de dico
        
        fmt = elem['format'] # format du dico
        lab = Label(self.txt_index, background=self.txt_index['background'])
        if fmt == "ling":
            lab['image'] = app.imglst.dicling
        elif fmt == "dict" :
            lab['image'] = app.imglst.dicdict
        elif fmt == "wb" :
            lab['image'] = app.imglst.dicwb
        elif fmt == "xdxf" :
            lab['image'] = app.imglst.dicxdxf
        elif fmt == "ini" :
            lab['image'] = app.imglst.dicini
        else:
            lab['image'] = app.imglst.diccsv
        
        self.txt_index.window_create(END, window=lab)
        
        
        # -----------------------------------------------------------------
        # --- Contrôler si le dico est déjà stocké localement et à jour    
        #     > modifier l'indicateur 'maj' en rapport                     
        # -----------------------------------------------------------------
        
        # Scinder le champ des fichiers inclus dans le zip
        nds = elem['files'].split("/")
        
        # --- Déterminer le nom du fichier distant dont la présence est à rechercher localement
         
        if len(nds) > 1: # un répertoire est inclus dans le zip
            
            if fmt =="xdxf":
                remotefichname = nds[0].strip()
            else:
                nds = nds[1].split("|")
                remotefichname = nds[0].strip()
            
        else: # nom de fichier unique dans le zip
            
            remotefichname = elem['files']
        
        
        # --- Contrôler la présence locale du dico
        
        maj = "absent"
        for localfich in app.diclocaldatabase:
            
            # Le fichier est-il présent ?
            
            if remotefichname == localfich[0]: # présence du dico local
                
                #print "\nLOCAL  : ", localfich
                #print "INDEX  : ", (elem['date'], elem['version'])
                
                maj = "present_ajour"
                
                if localfich[1] != "": # date du dico local présente
                    
                    # Les dates concordent-elles .
                    if elem['date'] != localfich[1]:
                        maj = "present_nonajour"
                
                if localfich[2] != "": # version du dico local présente
                    
                    # Les numéros de version concordent-ils ?
                    if elem['version'].split()[0] != localfich[2].split()[0]:
                        maj = "present_nonajour"
                    
                elif localfich[1] == "" and localfich[2] == "": # ni date ni version en local
                    
                    if elem['date'] != "" or elem['version'] != "": # date ou version distante
                    
                        # dans ce cas le dico local est considéré arbitrairement non à jour
                        # ce qui charge la version distante avec ces indications
                        # on se limite aux formats embarquant date et version
                        if os.path.splitext(localfich[0])[1].lower() in (".ling", ".dict", ".dz", ".xdxf", ""):
                            maj = "present_nonajour"
                
                break   
        
        
        elem['maj'] = maj
        
        
        # --- Nom convivial du dico
        
        t = " " + elem['nom']
        self.txt_index.insert(END, t, ("nom", maj))
        
        
        # --- Créer la boîte individuelle des infos du dico
        
        exec("self.box" + str(n) + "=Text(self.txt_index)") in locals(), globals()
        exec("box=self.box" + str(n)) in locals(), globals()
        box.config( background = "white",
                    relief="flat",
                    wrap = "word",
                    borderwidth=0,
                    highlightthickness=0,
                    font = "Courier 10 normal",
                    height = 1)
        box.tag_config("info", lmargin2=200)
        box.tag_config("present_ajour", foreground="grey")
        box.tag_config("present_nonajour", foreground="orange")
        box.tag_config("absent", foreground="black")
        box.tag_config("infogreen", foreground="#00AA00", spacing1=7)
        box.tag_config("infored", foreground="red", spacing1=7)
        self.txt_index.window_create(END, window=box, padx=4)
        
        
        # --- Créer l'icône d'expansion (interne à la boîte)
        
        exec("self.down" + str(n) + "=Label(box, text='+', image=app.imglst.plus)") in locals(), globals()
        exec("down=self.down" + str(n)) in locals(), globals()
        down.config( background = self.txt_index['background'],
                    cursor="hand2",
                    )
        down.bind("<ButtonRelease-1>", lambda event, idx=n : self.__toggleInfo(idx))
        box.window_create(END, window=down)
        self.txt_index.insert(END, "\n")
        
        
        # --- Auteur
        
        t = hAuteur + elem['auteur'] + "\n"
        box.insert(END, t, ("info", maj))
        
        
        # --- Version
        
        t = hVersion + elem['version']+ "\n"
        box.insert(END, t, ("info", maj))
        
        
        # --- Date
        
        dt = elem['date']
        if dt != "":
            dtfr = dt[0:4]                          # année
            try:
                dtfr = dt[4:6] + "-" + dtfr         # mois
                try:
                    dtfr = dt[6:] + "-" + dtfr      # jour
                except:
                    pass    
            except:
                pass
            
            t = hDate + dtfr + "\n"
            box.insert(END, t, ("info", maj))
        
        
        # --- Licence
        
        lic = elem['lic']
        if lic == "dp"    : lic = "Document du domaine public"
        elif lic == "gnu" : lic = "GNU-GPL"
        elif lic == "cpr" : lic = "(c) copyright - avec autorisation"
        elif lic == "ccbs": lic = "Creative Commons CC-by-sa"
        elif lic == "ccbn": lic = "Creative Commons CC-by-nc-nd"   
        elif lic == "xxx" : lic = "type de licence inconnu"	
        
        if lic != "":
            t = hLicence + lic + "\n"
            box.insert(END, t, ("info", maj))
        
        
        # --- Format du dico
        
        t = hFormat + fmt + "\n"
        box.insert(END, t, ("info", maj))
        
        
        # --- Nom du ou des fichiers inclus
        
        t = elem['files'].replace("/", "/ ").replace("|", " | ")
        t = hNomfich + t + "\n"
        box.insert(END, t, ("info", maj))
        
        
        # --- Poids du fichier
        
        t = hSize + elem['size'] + "\n"
        box.insert(END, t, ("info", maj))
        
        
        # --- Commentaires
        
        t = ""
        try:
            t = elem['com'].strip()
        except:
            pass
        
        if t != "": 
            t = hCom + t + "\n"
            box.insert(END, t, ("info", maj))
        
        
        # --- Info d'installation
        
        if maj == "absent":
            box.insert(END, hinstok, "infored")
        elif maj == "present_nonajour":
            box.insert(END, hinstup, "infored")
        else:
            box.insert(END, hinstno, "infogreen")
        
        
        # --- Séparateur (ligne entre les dicos)
        
        self.txt_index.insert(END, "_"*120 + "\n\n", "sep")
        
        
        
        return
    
    
    
    def __writeList(self, event=None):
        
        u"""
        | Afficher la liste des dicos disponibles en téléchargement             
        | en tenant compte du filtrage choisi par l'utilisateur                 
        """
        
        
        # Réinitialiser (effacer) la liste affichée
        self.txt_index.delete("1.0", END)
        self.txt_index.insert("end", "\n")
        
        
        # -------------------------------
        # --- Filtrage  d'affichage      
        # -------------------------------
        
        fltr = self.vFilter.get().lower()
        
        n = 0
        nbselect = 0
        
        for n in range (len(self.remoteindex)):
            
            flagadd = False
            
            elem = self.remoteindex[n]
            
            if "tous" in fltr:
                flagadd = True
                
            # --- Filtrage en fonction du statut d'installation
                
            elif "[a1]" in fltr:    # dico installé non à jour
                if elem['maj'] == "present_nonajour":
                    flagadd = True
                
            elif "[a2]" in fltr:    # dico non installé
                if elem['maj'] == "absent":
                    flagadd = True
                
                
            # --- Filtrage en fonction de la langue
                
            elif "[b1]" in fltr:    # dico français unilingue
                if "frafra" in elem['senstr']:  
                    flagadd = True
                
            elif "[b2]" in fltr:    # dico fr > autre langue
                if elem['senstr'] != "frafra" and elem['senstr'].startswith("fra"):
                    flagadd = True
                
            elif "[b3]" in fltr:    # dico autre langue > français
                if elem['senstr'] != "frafra" and elem['senstr'].endswith("fra"):
                    flagadd = True
                
                
            # --- Filtrage en fonction du format de dico
                
            elif "[d1]" in fltr:
                if "ling" in elem['format']:
                    flagadd = True
                
            elif "[d2]" in fltr:
                if "xdxf" in elem['format']:
                    flagadd = True
                
            elif "[d3]" in fltr:
                if "dict" in elem['format']:
                    flagadd = True
                
                
            # --- Filtrage en fonction de la licence
                
            elif "[c1]" in fltr:  # domaine public
                if "dp" in elem['lic']:
                    flagadd = True
                
            elif "[c2]" in fltr: # creative commons
                if "cc" in elem['lic']:
                    flagadd = True
                
            elif "[c3]" in fltr:     # Gnu-Gpl
                if "gnu" in elem['lic']:
                    flagadd = True
                
            elif "[c4]" in fltr:   # copyright
                if "cpr" in elem['lic']:
                    flagadd = True
                
                
            # --- Filtrage en fonction de la famille de langue-cible
                
            elif not "frafra" in elem['senstr']:
                
                if "[e1]" in fltr: # indo-européennes italiques
                    if "ine:itc" in elem['lgfam']:
                        flagadd = True
                    
                elif "[e2]" in fltr: # indo-européennes germaniques
                    if "ine:gem" in elem['lgfam']:
                        flagadd = True
                    
                elif "[e3]" in fltr: # indo-européennes celtiques
                    if "ine:cel" in elem['lgfam']:
                        flagadd = True
                    
                elif "[e4]" in fltr: # indo-européennes slaves
                    if "ine:sla" in elem['lgfam']:
                        flagadd = True
                    
                elif "[e5]" in fltr: # indo-européennes (autres)
                    if "ine" in elem['lgfam'] and not elem['lgfam'] in ("ine:itc", "ine:gem", "ine:cel", "ine:sla"):
                        flagadd = True
                    
                elif "[e6]" in fltr:  # non indo-européennes
                    if not ("ine" in elem['lgfam']):
                        flagadd = True
                    
                elif "[e7]" in fltr: # anciennes ou scientifiques
                    if elem['senstr'].startswith("anc") or elem['senstr'].endswith("anc") :
                        flagadd = True
                    
                elif "[e8]" in fltr: # régionales
                    if elem['senstr'].startswith("reg") or elem['senstr'].endswith("reg") :
                        flagadd = True
            
            
            # Ajouter le dico à la liste
            if flagadd:
                nbselect += 1
                self.__writeDico(n)
        
        
        # ------------------------------------
        
        # Ecrire le nombre de dicos 
        self.lab_nbtot['text'] = "/ " + str(nbselect) + " / " + str(n+1)
        
        
        # Avertir en cas de recherche infructueuse
        if nbselect == 0:
            self.txt_index.insert("end", app.lg.get("windwn", "s17"))
        
        
        self['cursor'] = ''
        app['cursor'] = ''
        
        return
    
    
    
    def __selectDic(self, event):
        
        u"""
        | Clic sur une case à cocher pour sélectionner un dico                  
        | > Activation/désactivation du bouton de téléchargement                
        """
        
        # valeur de la variable associée au widget cliqué
        v = event.widget.getvar(name = event.widget.cget("variable") )
        
        # index du dico
        idx = int(v[1:])
        #print idx
        # Nb : sous Windows le changement de valeur de la variable Tkinter
        # se produit après le ButtonRelease
        # on teste donc son état antérieur !
        if app.pf in ("win", "osx"):
            testvalue = "z"
        else:
            testvalue = "x"
        #print v[0]
        
        if v[0] == testvalue:
            # état du coche
            self.remoteindex[idx]['coche'] = True
        else:
            self.remoteindex[idx]['coche'] = False
        
        # Compter les dicos cochés
        nbdic = 0
        for dic in self.remoteindex:
            if dic['coche']:
                nbdic += 1

        self.lab_nbdic['text'] = str(nbdic)
        
        if nbdic > 0:
            self.bt_do['state'] = "normal"
        else:
            self.bt_do['state'] = "disabled"
            
        return
    
    
    def doInstall(self):
        
        u"""
        | Télécharger et installer les dictionnaires sélectionnés dans la liste 
        """
        
        self.lab_url['text'] = app.lg.get("windwn", "s12")
        
        import zipfile
        
        self.bt_do['state'] = 'disabled'
        
        # Adapter la barre de progression à la largeur de la fenêtre
        self.progr.setWidth(self.winfo_width()-20)
        
        # Supprimer une éventuelle mise en cache antérieure
        urllib.urlcleanup()
        
        
        # ****************************************************************
        # *** Boucle de téléchargement et d'installation, dico par dico   
        # ****************************************************************
        
        repStordic = app.ini.get('DicStorageFolder','')
        
        flagplouf = False
        
        for dic in self.remoteindex:
            
            if dic['coche']: # case coché = Le dico est à télécharger
                
                
                # ---------------------------------------------------------------
                # --- Télécharger le fichier (un zip généralement) dans le cache 
                # ---------------------------------------------------------------
                
                # reconstruire l'url absolue du fichier à télécharger
                fichurl = dic['url']
                if not fichurl.startswith("http"):
                    fichurl= self.dwnroot + fichurl
                
                # afficher l'url du fichier en cours de téléchargement
                self.lab_url['text'] = fichurl 
                
                # chemin du fichier local à créer dans le cache
                fichcache = os.path.join(app.appdata.cache, os.path.basename(dic['url']))
                
                # télécharger
                urllib.urlretrieve(fichurl, fichcache, self.__getdicdwnlog)
                
                
                # ----------------------------------------------------------------------
                # --- Dézipper (si nécessaire) et recopier dans le dossier dictionnaire 
                # ----------------------------------------------------------------------
                
                flagreloaddico = False # permet de recharger le dico si m.à.j.d'un dico ouvert
                
                # C'est un zip : on le dézippe dans le dossier "Dictionnaires"
                if fichcache.lower().endswith(".zip"):
                    
                    # Instancier l'objet fichier Zip en mode "read"
                    try:
                        ozip = zipfile.ZipFile(fichcache, 'r')              
                    except:
                        print os.path.basename(fichcache) + " n'est pas un fichier zip valide !!!"
                        flagplouf = True
                        continue
                    
                    # installer le contenu du zip, fichier par fichier
                    for f in  ozip.namelist():
                        
                        # Contrôle du contenu
                        if f.startswith("/") or f.startswith(".."):
                            print "FICHIER INVALIDE !!!"
                            flagplouf = True
                            continue
                        
                        # Vérifier que ce fichier n'est pas le dico en cours d'utilisation
                        # si oui, on valide un flag pour le recharger après la mise à jour
                        ciblepath = os.path.join(repStordic, f)
                        try:
                            if ciblepath.replace("\\", "/").lower() == app.dic.path.replace("\\", "/").lower():
                                flagreloaddico = True
                                app.dic.file.close()
                        except:
                            pass
                        
                        
                        # installer le fichier dans le dossier des dicos
                        try:
                            ozip.extract(f, repStordic)
                        
                        except: # si python < 2.6 (.extract() non supporté)
                            
                            elem = os.path.join(repStordic, f)  # chemin complet du fichier à installer
                            
                            repcible = os.path.dirname(elem)    # répertoire cible du fichier à installer
                            if not os.path.isdir(repcible):     # on crée le répertoire s'il n'existe pas
                                os.makedirs(repcible)
                            
                            try:
                                fichcible = open(os.path.join(repStordic, f),"wb")
                                fichcible.write(ozip.read(f))
                                fichcible.close()
                            except:
                                pass
                        
                    ozip.close()
                    
                    
                # Ce n'est pas un zip : on recopie le fichier
                else:
                    
                    # Vérifier que le fichier n'est pas le dico en cours d'utilisation
                    ciblepath = os.path.join(repStordic, os.path.basename(fichcache))
                    try:
                        if ciblepath.replace("\\", "/").lower() == app.dic.path.replace("\\", "/").lower():
                            flagreloaddico = True
                            app.dic.file.close()
                    except:
                        pass
                    
                    
                    shutil.copy2(fichcache, ciblepath)
        
        
        # -----------------------------------
        # --- Fin de l'installation          
        # -----------------------------------
        
        app.updateMenuDic() # Mise à jour du menu dictionnaire

        
        self.bt_do['state'] = 'normal'
        
        self.lab_url['text'] = app.lg.get("windwn", "s13")
        
        if flagplouf:
            # Message : un problème est survenu
            tkMessageBox.showinfo(parent=self,
                        title = app.lg.get("windwn", "title"),
                        message = app.lg.get("windwn", "msg3"))
        else:
            # Message : informer du succès
            tkMessageBox.showinfo(parent=self,
                        title = app.lg.get("windwn", "title"),
                        message = app.lg.get("windwn", "msg2"))
       
        self.destroy()
        
        # --- Recharger le dico courant si besoin
        if flagreloaddico:
            app.dic.file.close()
            app.loadDico(app.dic.path, showSplash=False) # Recharger avec le fichier mis à jour
        
        
        return
    
    
    def __getdicdwnlog(self, nbdone, blocsize, filesize):
        
        u"""
        | Obtenir le rapport du téléchargement en cours.                        
        | (appelé automatiquement par urllib.urlretrieve)                       
        |                                                                       
        | ARGUMENTS :                                                           
        |   'nbdone' : nombre de blocs transférés.                              
        |   'blocsize' : taille unitaire des blocs (en octets).                 
        |   'filesize' : taille du fichier (en octets).                          
        """
        
        max = filesize/blocsize
        if max < 1:
            max = 1
        
        self.progr.setMax(max)
        self.progr.setValue(nbdone)
        
        
        return
    
    
    

class WindowEdit(Toplevel):
    
    u"""
    | Fenêtre d'édition d'un élément de dictionnaire : entrée et notice         
    |                                                                           
    | Edition dans le dictionnaire et adjonction éventuelle de ressources liées 
    | (sons, images)                                                            
    """


    def __init__(self, i):
        
        u"""                                                                    
        | Mise en place de l'interface graphique                                
        """                                                                     
        
        # --- Tests préalables :
            
        # Un Dict compressé est non éditable > avertir et quitter
        if app.dic.type in ("dictdz", "dictgz"):
            app.hideProgr()
            tkMessageBox.showinfo(parent=app,
                    title = app.lg.get("wined", "title1"),
                    message = app.lg.get("win1", "msg31"))
            return
        
        # ---
        
        
        self.mysound = None # son Snack
        
        wTxt=110
        
        Toplevel.__init__(self, padx=3)
        
        # --- Titre de la fenêtre
        
        if i == -1 :
            t = app.lg.get("wined", "title2") + " " + app.dic.type.upper() # Ajouter
        else:
            t = app.lg.get("wined", "title1") + " " + app.dic.type.upper() # Editer
        
        if app.dic.type.startswith("dict") :
            t = t + "/" + app.dic.subtype.lower()
        
        self.title(t)
        
        # ---
        
        self.resizable(width=NO, height=NO)
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        
        # ---------------------------------------------
        # --- Frame de tête (avec barre d'outils)      
        # ---------------------------------------------
        
        fr_head=Frame(self)
        fr_head.grid(row=0, column=0, columnspan=3, sticky='W')
        
        # Etiquette de la case de saisie de l'entrée
        lab_chp1 = Label(fr_head) # Nb : le texte de l'étiquette est complété plus bas
        lab_chp1.grid(row=0, column=0, sticky='W')
        
        # Etiquette d'affichage de l'index
        self.lab_idx=Label(fr_head, text=" "*20 + "Index : " + str(i)+ " "*20, borderwidth=2) 
        self.lab_idx.grid(row=0, column=1)
        
        # Bouton 'Coller'
        B1 = Button(fr_head, compound=LEFT, text=" " + app.lg.get("g", "pst"), image=app.imglst.paste, command=self.__pasteToEdit)
        B1.grid(row=0, column=2, ipadx=3)
        lib.infobulle.InfoBulle(parent=B1, text=app.lg.get("wined", "ib1"))
        
        # Bouton <i>
        B2 = Button(fr_head, text="<i>", command=lambda : self.__addTag("i"))
        B2.grid(row=0, column=3)
        lib.infobulle.InfoBulle(parent=B2, text=app.lg.get("wined", "ib2"))
        
        # Bouton <b>
        B3 = Button(fr_head, text="<b>", command=lambda : self.__addTag("b"))
        B3.grid(row=0, column=4)
        lib.infobulle.InfoBulle(parent=B3, text=app.lg.get("wined", "ib3"))
        
        # Bouton <u>
        B4 = Button(fr_head, text="<u>", command=lambda : self.__addTag("u"))
        B4.grid(row=0, column=5)
        lib.infobulle.InfoBulle(parent=B4, text=app.lg.get("wined", "ib4"))
        
        # Bouton <big>
        B5 = Button(fr_head, text="<big>", command=lambda : self.__addTag("big"))
        B5.grid(row=0, column=6)
        lib.infobulle.InfoBulle(parent=B5, text=app.lg.get("wined", "ib5"))
        
        # Bouton <small>
        B6 = Button(fr_head, text="<small>", command=lambda : self.__addTag("small"))
        B6.grid(row=0, column=7)
        lib.infobulle.InfoBulle(parent=B6, text=app.lg.get("wined", "ib6"))
        
        # Bouton <br>
        B7 = Button(fr_head, text="<br>", command=lambda : self.__addTag("br"))
        B7.grid(row=0, column=8)
        lib.infobulle.InfoBulle(parent=B7, text=app.lg.get("wined", "ib7"))
        
        # Bouton de lien interne (doubles accolades)
        B8 = Button(fr_head, text="{{..}}", command=lambda : self.__addTag("lk"))
        B8.grid(row=0, column=9)
        lib.infobulle.InfoBulle(parent=B8, text=app.lg.get("wined", "ib8"))
        
        # Bouton de nettoyage des balises
        B9 = Button(fr_head, text=app.lg.get("wined", "s23"), command=self.__cleanTags)
        B9.grid(row=0, column=10)
        lib.infobulle.InfoBulle(parent=B9, text=app.lg.get("wined", "ib9"))
        
        
        
        # -----------------------------------
        # --- Case de saisie de l'entrée     
        # -----------------------------------
        
        self.txt_chp1=Entry(self, background='white')
        self.txt_chp1.grid(row=1, column=0, columnspan=3, sticky='W')
        self.txt_chp1['font']=app.lst_dico['font']
        
        # Texte de l'étiquette de la case (variable suivant de type de dictionnaire)
        if app.dic.type.startswith('wb'):
          lab_chp1['text']=app.lg.get("wined", "s2")
          self.txt_chp1['width'] = 31
        else:
          lab_chp1['text']=app.lg.get("wined", "s3")
          self.txt_chp1['width'] = wTxt
        
        
        # -------------------------------------
        # --- Case des traductions courtes     
        # -------------------------------------
        
        lab_editShort=Label(self, justify=LEFT)
        lab_editShort.grid(row=2, column=0, columnspan=10, sticky='W')
        
        self.txt_editShort = ScrolledText.ScrolledText(self, height=1, background='white', wrap="word")
        self.txt_editShort.grid(row=3, column=0, columnspan=10, sticky='W')
        self.txt_editShort['font']=app.txt_notice['font']
        
        # Texte de l'étiquette de la case (variable suivant de type de dictionnaire)
        if app.dic.type.startswith('wb'):
            lab_editShort['text'] = app.lg.get("wined", "s4")
            self.txt_editShort['width'] = 53
        else:
            lab_editShort['text'] = app.lg.get("wined", "s5")
            self.txt_editShort['width'] = wTxt-3
            
            if app.dic.type[:4] in ("dict", "xdxf"):
                self.txt_editShort['height'] = 10
        
        if app.dic.type[:4] in ("ling", "xdxf"):
            
            # --------------------------------
            # --- Case multiligne des infos   
            # --------------------------------
            
            Label(self, text=app.lg.get("wined", "s6")).grid(column=0, sticky='W')
            self.txt_editLong = ScrolledText.ScrolledText(self, width=wTxt-3, height=5, background='white', wrap="word")
            self.txt_editLong.grid(column=0, columnspan=10, sticky='W')
            self.txt_editLong['font']=app.txt_notice['font']
        
        if app.dic.type[:4] in ("ling"):
            
            # -----------------------------------
            # --- Frame du wordID (identifiant)  
            # -----------------------------------
            
            fr_ID = Frame (self, pady=2)
            fr_ID.grid(column=0, columnspan=10, sticky="W")
            
            Label(fr_ID, text="ID :").grid(row=0, column=0)
            self.txt_ID=Entry(fr_ID, width=10, background='white')
            self.txt_ID.grid(row=0, column=1)
            Label(fr_ID, text=app.lg.get("wined", "s7")).grid(row=0, column=2)
            
            # Bouton de déverrouillage du wordID
            self.bt_unlockID=Button(fr_ID, text=app.lg.get("wined", "s8"), width=30, command=self.__unlockID)
            self.bt_unlockID.grid(row=0, column=3, padx=10)
            
            # Bouton de confection d'un wordID automatique
            self.bt_makeID=Button(fr_ID, text=app.lg.get("wined", "s9"),width=30, command=self.__makeID)
            self.bt_makeID.grid(row=0, column=3, padx=10)
            
            # ------------------------
            # --- Case des racines    
            # ------------------------
            
            Label(self, text=app.lg.get("wined", "s10")).grid(column=0, sticky='W')
            self.txt_rac=Entry(self, width=wTxt, background='white', font="courier 9")
            self.txt_rac.grid(column=0, columnspan=10, sticky='W')
            
            # -------------------------
            # --- Case des synonymes   
            # -------------------------
            
            Label(self, text=app.lg.get("wined", "s11")).grid(column=0, sticky='W')
            self.txt_syn=Entry(self, width=wTxt, background='white', font="courier 9")
            self.txt_syn.grid(column=0, columnspan=10, sticky='W')
            
            # --------------------------
            # --- Case des antonymes    
            # --------------------------
            
            Label(self, text=app.lg.get("wined", "s12")).grid(column=0, sticky='W')
            self.txt_ant=Entry(self, width=wTxt, background='white', font="courier 9")
            self.txt_ant.grid(column=0, columnspan=10, sticky='W')
            
            # ----------------------------
            # --- Case des "voir aussi"   
            # ----------------------------
            
            Label(self, text=app.lg.get("wined", "s13")).grid(column=0, sticky='W')
            self.txt_see=Entry(self, width=wTxt, background='white', font="courier 9")
            self.txt_see.grid(column=0, columnspan=10, sticky='W')
            
            # ----------------------
            # --- Case des tokens   
            # ----------------------
            
            Label(self, text=app.lg.get("wined", "s14")).grid(column=0, sticky='W')
            self.txt_tok=Entry(self, width=wTxt, background='white', font="courier 9")
            self.txt_tok.grid(column=0, columnspan=10, sticky='W')
        
        if app.dic.type[:4] in ("ling", "xdxf"):
            
            # ----------------------------
            # --- Case de la phonétique   
            # ----------------------------
            
            Label(self, text=app.lg.get("wined", "s15")).grid(column=0, sticky='W')
            self.txt_phon=Entry(self, width=wTxt-15, background='white')
            self.txt_phon.grid(column=0, columnspan=10, sticky='W')
            self.txt_phon['font']=app.txt_notice['font']
        
        if app.dic.type[:4] in ("ling"):
            
            # -------------------------------
            # --- Frame de l'enregistreur    
            # -------------------------------
            
            fr_rec = Frame (self, padx=5, pady=3, borderwidth=3, relief=SUNKEN, background='black')
            fr_rec.grid(row=100,column=0, sticky='W', padx=3, pady=3)
            
            Label(fr_rec, text=app.lg.get("wined", "s16") + " ", font="Helvetica 8 bold", foreground='white', background='black').grid(row=0, column=0)
            
            # --- frame des "boutons de magnétophone"
            fr_record = Frame(fr_rec, background='black')
            fr_record.grid(row=0, column=1, columnspan=10)
            
            # Boutton 'Rec'
            self.bt_rec=Button(fr_record, image=app.imglst.rec, compound=LEFT, text=" Rec ", command=self.__recWord)
            self.bt_rec.pack(side="left")
            
            # Boutton 'Stop'
            Button(fr_record, image=app.imglst.stop, compound=LEFT, text=" Stop ", command=self.__soundStop).pack(side="left")
            
            # Boutton 'Play'
            self.bt_play=Button(fr_record, image=app.imglst.audio, compound=LEFT,text=" Play ", command=self.__playWord)
            self.bt_play.pack(side="left")
            
            # Boutton voyant 'On'
            self.lab_recon=Label(fr_record, text=" ", width=1, background='black')
            self.lab_recon.pack(side="left", padx=10)
            
            # Etiquette d'affichage du temps
            self.lab_time=Label(fr_record,text="0.00", foreground='white', background='black', font='courier 9')
            self.lab_time.pack(side="left")
            
            
            # --- Bouton déroulant de choix du périphérique d'enregistrement
            Label(fr_rec, text=app.lg.get("wined", "s17"), foreground='white', background='black').grid(row=1, column=0, sticky='W')
            self.vAudioinput = StringVar(self)
            
            # Construire la liste des périphériques d'enregistrement
            opt=[]
            opt.append(app.lg.get("wined", "s18")) # ("0: ( par défaut )")
            
            if app.snackisactive:
                n = 0
                for d in tkSnack.audio.inputDevices():
                    n += 1 ; opt.append(str(n) +": "+d)
            
            opt = tuple(opt)
            self.opt_audioinput=apply(OptionMenu, (fr_rec, self.vAudioinput) + opt)
            t = app.ini.get("audioInputDevice", "")
            if t == "":
                self.vAudioinput.set(opt[0])
            else:
                self.vAudioinput.set(t)
            
            if not app.snackisactive:
                self.opt_audioinput['state'] = "disabled"
            
            self.opt_audioinput.grid(row=1,column=1, columnspan=10, pady=5, sticky='W')
            
            # --- Frame de format
            Label(fr_rec, text = "Format d'enregistrement :", foreground='white', background='black').grid(row=2, column=0, sticky='W')
            
            fr_fmt = Frame(fr_rec, background='black')
            fr_fmt.grid(row=2, column=1, columnspan=10, sticky="W")
            
            # Boutons-radio de choix du format
            self.vFmtAudio = StringVar()
            Radiobutton(fr_fmt, text="WAVE", width=8,variable=self.vFmtAudio, value="wav").pack(side="left")
            Radiobutton(fr_fmt, text="MP3", width=8, variable=self.vFmtAudio, value="mp3").pack(side="left")
            self.vFmtAudio.set("wav")
            
            # Bouton d'importation d'un fichier audio externe
            Button(fr_fmt, text = " " + app.lg.get("wined", "s19") + " ", command=self.__importAudio).pack(side="left", padx=4)
            
            
            # ------------------------
            # --- Frame des images    
            # ------------------------
            
            fr_img = LabelFrame (self, text=app.lg.get("wined", "s20"), padx=5, pady=3, borderwidth=2, relief=GROOVE)
            fr_img.grid(row=100,column=1, columnspan=10, padx=3, pady=3, sticky='W')
            
            # liste des images
            self.lst_img=lib.myscrlst.ScrolledList(fr_img, height=4, ondblclic=self.__showGestImg)
            self.lst_img.grid(row=0, rowspan=10,column=0, padx=3, pady=3)
            
            # Boutons de gestion des images
            Button(fr_img, text=app.lg.get("wined", "s22"), width=11, command=self.__showGestImg).grid(row=2, column=1)      # Voir
        
        
        
        # ------------------------
        # --- Frame des boutons   
        # ------------------------
        
        fr_but=Frame(self, pady=10)
        fr_but.grid(column=0, columnspan=10)
        Button(fr_but, image=app.imglst.ok, compound=LEFT, text='  Ok', width=100, command=self.doEdit).grid(row=0, column=0, padx=25)
        Button(fr_but, image=app.imglst.exit, compound=LEFT, text="  " + app.lg.get("g", "cncl"), width=100, command=self.cancelEdit).grid(row=0, column=1, padx=25)
        Button(fr_but, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=100, padx= 10,command=lambda: app.showHelp("editnotice")).grid(row=0, column=2, pady=8, padx=10)
        
        
        # ------------------------------------------------------------------------
        # --- Remplir les cases d'édition avec les données de l'entrée à éditer   
        # ------------------------------------------------------------------------
        
        if i == -1:     # Ajout d'une nouvelle entrée
            txt=u"( ... )"
            txt = txt.encode(app.dic.encoding1)
            self.txt_chp1.insert(END, txt)
            
            txt=u"( ... )"
            txt = txt.encode(app.dic.encoding2)
            self.txt_editShort.insert(END, txt)
            
            try   : self.txt_tok.insert(END, "e;n") # flags d'édition et de nouvelle entrée
            except: pass
        
        else :
            
            # --- Récupérer toutes les données (>pyDictionnaire)
            data = app.dic.getdata(i)
            
            # --- Entrée du dictionnaire
            t = data['mot']
            if app.dic.type.startswith("xdxf") or (app.dic.type.startswith("dict") and app.dic.subtype == "x"):
                t = t.replace(">", "&gt;")
                
            self.txt_chp1.insert(END, t) 
            
            # --- Traductions courtes
            t = data['short']                                 
            self.txt_editShort.insert(END, t)
            
            if t.startswith("|!|"):
                self.txt_editShort["background"] = self["background"]
                self.txt_editShort["state"] = "disabled"
            
            # --- Traduction longue
            try   : self.txt_editLong.insert(END, data['long'])   
            except: pass
            
            # --- ID
            id = data['ID']
            if id != "":
                self.txt_ID.insert(END, id)
                
                # verrouiller l'ID              
                self.txt_ID['state'] = 'disabled'
                self.txt_ID['background'] = self['background']
                self.bt_makeID.grid_remove()
            
            # --- Racines
            try   : self.txt_rac.insert(END, data['rac'])        
            except: pass
            
            # --- Synonymes
            try   : self.txt_syn.insert(END, data['syn'])        
            except: pass
            
            # --- Antonymes
            try   : self.txt_ant.insert(END, data['ant'])        
            except: pass
            
            # --- Voir-aussi
            try   : self.txt_see.insert(END, data['see'])        
            except: pass
            
            # --- Tokens
            
            if "e" not in data['tok'].split(";"): # flag d'édition
                data['tok'] += ";e"
                data['tok'].strip(";")
                
            try   : self.txt_tok.insert(END, data['tok'])        
            except: pass
            
            
            
            # --- Phonétique
            try   : self.txt_phon.insert(END, data['phon'])       
            except: pass
            
            # --- Charger la liste des images
            try   : self.__loadImgLst(wID=id)
            except: pass
        
        
        return

    
    def __loadImgLst(self, wID):
        
        # Vider la liste
        self.lst_img.clear()
        
        # Remplir la liste
        lf = glob.glob(os.path.join(app.dic.path + "_res", "img", wID + "_*.*"))
        for f in lf:
            self.lst_img.add(os.path.basename(f))
        
        return
    
    
    
    def __addTag(self, tagname):
        u"""
        | Ajoute une balise de mise en forme à la zone de texte selectionné     
        | d'une textBox.                                                        
        """
        
        # widget ayant le focus
        try : w = self.focus_displayof() 
        except: pass
        
        
        # Vérifier que c'est un ScrolledText sinon avertir et quitter
        if not w.__class__ is self.txt_editShort.__class__:
            tkMessageBox.showwarning(parent=self,
                title = app.lg.get("wined", "title1"),
                message = app.lg.get("wined", "msg28"))
            return
        
        # Appliquer la balise
        if tagname == "br":
            
            try   : w.insert(INSERT, "<br>")
            except: return
            
        else:
            
            try   : t = w.get(SEL_FIRST, SEL_LAST) # copier le texte en sélection
            except: t= "" 
            
            try   : w.delete(SEL_FIRST, SEL_LAST) # effacer le texte
            except: pass
            
            if tagname == "lk":
                try   : w.insert(INSERT, "{{" + t + "}}")
                except: return
            else:
                try   : w.insert(INSERT, "<" + tagname + ">" + t + "</" + tagname + ">")
                except: return
        
        
        return
    
    
    def __cleanTags(self):
        
        u"""
        | Nettoie les balises d'une textBox.                                    
        """
        
        # widget ayant le focus
        try : w = self.focus_displayof() 
        except: pass
        
        
        # Vérifier que c'est un ScrolledText sinon avertir et quitter
        if not w.__class__ is self.txt_editShort.__class__:
            tkMessageBox.showwarning(parent=self,
                title = app.lg.get("wined", "title1"),
                message = app.lg.get("wined", "msg29"))
            return
        
        
        try   : t = w.get("1.0", END) # copier le texte du widget
        except: return 
        
        if t == "" :
            return
        
        
        # nettoyer les balises
        cleanTag = re.compile(r"<[^>]+?>", re.MULTILINE)
        t = re.sub(cleanTag, "", t)
        
        # remplacer le texte par le texte nettoyé
        w.delete("1.0", END)
        w.insert(END, t)
        
        return
    
    def __unlockID(self):
        
        u"""
        | Déverrouiller l'ID pour permettre sa modification                     
        """
        
        # Avertir des conséquences ( > bris des liens)
        r = tkMessageBox.askyesno(parent=self,
            title = app.lg.get("wined", "msg1"),
            message = app.lg.get("wined", "msg2"))
        if r == False : return
        
        # Déverrouiller
        self.txt_ID['state']='normal'
        self.txt_ID['background']='white'
        self.bt_unlockID['state']='disabled'
        
        
        return


    def __importAudio(self):
        
        u"""
        | Importer un fichier audio pour en faire une ressource associée à un   
        | élément de dictionnaire                                               
        """
        
        id = self.txt_ID.get().strip()              # wordID de l'entrée éditée
        i = int(self.lab_idx['text'].split(":")[1]) # Index de l'entrée éditée
        
        # ----------------------------------
        # --- Contrôles préalables          
        # ----------------------------------
        
        # Contrôle de l'unicité du wordID éventuel
        # pour éviter l'écrasement de fichiers audios
        if app.dic.wordIDs.has_key(id):
            if app.dic.wordIDs[id][0] != i:
                tkMessageBox.showinfo(parent=self,
                    title = app.lg.get("wined", "msg3"),
                    message = "'" + id + "' " + app.lg.get("g", "id1") )
                return
        
        # Contrôle de l'existence d'un wordID
        if id == "":
            tkMessageBox.showinfo(parent=self,
                title = app.lg.get("wined", "msg3"),
                message = app.lg.get("wined", "msg5"))
            self.txt_ID.focus_set()
            return
        
        
        
        # ------------------------------------------------------
        # --- Choix du fichier ressource source audio           
        # ------------------------------------------------------
        
        fichsourcepath = tkFileDialog.askopenfilename(parent=self,
                            title = app.lg.get("wined", "msg3"),
                            filetypes = (
                                (app.lg.get("g", "faudio"),'*.mp3 *.wav *.wave'),
                                (app.lg.get("g", "fmp3"),'*.mp3'),
                                (app.lg.get("g", "fwav"),'*.wav *.wave'),
                                (app.lg.get("g", "fall"),'*.*')
                                        )
                            )
        
        if not fichsourcepath: return   # L'utilisateur a cliqué 'Annuler' dans la boîte de dialogue
        
        # Format audio du fichier source
        fmt = os.path.splitext(fichsourcepath)[1][1:].lower()
        
        
        # -----------------------------------------------------------
        # --- Créer le répertoire de ressource s'il n'existe pas     
        # -----------------------------------------------------------
        
        repRes = os.path.join(app.dic.path + "_res", "audio")
        
        if not os.path.isdir(repRes):
            try:
                os.makedirs(repRes)
            except:
                tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("wined", "msg3"),
                    message = app.lg.get("wined", "msg6") ) # ("le sous-rep ne peut être créé")
                return
          
        
        # -------------------------------------------------------------
        # --- Effacer l'éventuel fichier audio antérieur (tout format) 
        # -------------------------------------------------------------
        
        for f in glob.glob(os.path.join(repRes, id + ".*")):      # Chemin du fichier audio
            
            try   : os.chmod(f, 0777)       # Ouvrir tous les droits sur le fichier
            except: pass
            
            try   : os.remove(f)            # Effacer
            except: pass
        
        
        # ------------------------------------------------------
        # --- Enregistrer le fichier ressource                  
        # ------------------------------------------------------
        
        shutil.copy(fichsourcepath, os.path.join(repRes, id + "." + fmt))
        
        
        return


    
    def __showGestImg(self, idximg=None, widget=None):
        
        u"""
        | [ appelé par le Bouton 'Gérer les images' et le double-click sur la   
        |   liste ]                                                             
        |                                                                       
        | Affiche la fenêtre de visualisation des images avec l'image           
        | sélectionnée.                                                         
        |                                                                       
        | ARGUMENTS :                                                           
        |   'idximg' : contient None si appel par le bouton et l'index de       
        |              l'image si appel par le double-click                     
        |                                                                       
        |   'widget' : non utilisé mais imposé par le callback du               
        |              widget ScrolledList                                      
        |                                                                       
        """
        
        # ----------------------------------
        # --- Contrôles préalables          
        # ----------------------------------
        
        wID = self.txt_ID.get().strip()
        
        # Contrôle de l'existence d'un wordID
        if wID == "":
            tkMessageBox.showinfo(parent=self,
                title = app.lg.get("wined", "msg7"),
                message = app.lg.get("wined", "msg8") )
            self.txt_ID.focus_set()
            return
        
        
        # S'assurer de l'unicité du wordID éventuel
        # pour éviter l'écrasement de fichiers images
        i = int(self.lab_idx['text'].split(":")[1]) # Index de l'entrée éditée
        if app.dic.wordIDs.has_key(wID):
            if app.dic.wordIDs[wID][0] != i:
                tkMessageBox.showinfo(parent=self,
                    title = app.lg.get("wined", "msg7"),
                    message = "'" + wID + "' " + app.lg.get("g", "id1") )
                return
        
        
        
#        if idximg == -1:
#            if self.lst_img.listcount()>0:
#                idximg = 0
#            else:
#                tkMessageBox.showwarning(parent=self,
#                        title = app.lg.get("wined", "msg12"),
#                        message = app.lg.get("wined", "msg10") ) # ("Aucune image n'est sélectionnée !")
#                return
        
        # ------------------------------------------------------------------
        # --- Afficher la fenêtre de gestion des images (modale bloquante)  
        # ------------------------------------------------------------------
        
        if idximg is None:
            if self.lst_img.listcount()>0:
                idximg = 0
            else:
                idximg = -1
        
        # Instancier la fenêtre
        
        WindowImage(wID=wID, idximg=idximg)
        
        
        # --- Mise à jour de la liste après fermeture de la fenêtre de gestion des images
        
        self.__loadImgLst(wID=wID)
        
        return
        

    def __playWord(self):
        
        u"""
        | Ecouter la prononciation du mot en édition                            
        """
        
        # ----------------------------
        # --- Contrôles préalables    
        # ----------------------------
        
        # Librairie audio Snack absente > avertir et quitter
        if not app.snackisactive:
            tkMessageBox.showwarning(parent=self,
                    title = u"Linguae audio",
                    message = app.lg.get("wined", "msg14") )
            return
        # ---
        
        id = self.txt_ID.get().strip()
        
        # Avertir de la nécessité d'un identifiant et quitter
        if id == "":
            tkMessageBox.showinfo(parent=self,
                title = u"Linguae audio",
                message = app.lg.get("wined", "msg15") )
            self.txt_ID.focus_set()
            return
        
        
        # ------------------------------------------
        # --- Chemin du fichier audio à écouter     
        # ------------------------------------------
        
        lstfich = glob.glob(os.path.join(app.dic.path + "_res", "audio", id + ".*"))
        
        if len(lstfich) == 0:
            # Pas de fichier audio > indiquer le mode d'emploi
            tkMessageBox.showinfo(parent=self,
                title = u"Linguae audio",
                message = app.lg.get("wined", "msg16") )
            return
        
        fich = lstfich[0]
        
        
        # -------------------
        # --- Ecouter        
        # -------------------
        
        try:
            self.mysound = tkSnack.Sound()
            self.mysound.read(fich) 
            self.mysound.play()
        
        except: # Echec de la lecture du fichier audio
            tkMessageBox.showwarning(parent=self,
                title = u"Linguae audio",
                message = app.lg.get("wined", "msg17") )
            self.mysound.stop()
            self.mysound = None
            return
        
        self.bt_play['state']='disabled'
        self.bt_rec['state']='disabled'
        self.lab_recon['background']='green'
        
        
        # -------------------------------------
        # --- Afficher le temps qui s'écoule   
        # -------------------------------------
        
        lensound= float(self.mysound.length(unit="SECONDS"))
        while 1:
            playtime = tkSnack.audio.elapsedTime()
            try:
                self.lab_time['text']= str(playtime)[:4]
                self.lab_time.update()
            except:
                pass
            
            if playtime >= lensound: break
        
        self.bt_play['state']='normal'
        self.bt_rec['state']='normal'
        self.lab_recon['background']='black'
        self.update()
        
        return


    def __recWord(self):
        
        u"""
        | [ appelé par le clic sur le Bouton "Rec" ]                            
        |                                                                       
        | Enregistrer la prononciation du mot en édition dans un fichier de     
        | ressource audio (*.mp3 ou *.wav).                                      
        """
        
        
        # ----------------------------------
        # --- Contrôles préalables          
        # ----------------------------------
        
        
        # Librairie audio Snack absente > avertir et quitter
        if not app.snackisactive:
            tkMessageBox.showwarning(parent=self,
                    title = u"Linguae audio",
                    message = app.lg.get("wined", "msg14") )
            return
        # ---
        
        id = self.txt_ID.get().strip()
        i = int(self.lab_idx['text'].split(":")[1]) # Index de l'entrée éditée
        
         # Avertir de la nécessité d'un identifiant et quitter
        if id == "":
            tkMessageBox.showinfo(parent=self,
                title = u"Linguae audio",
                message = app.lg.get("wined", "msg15") )
            self.txt_ID.focus_set()
            return
        
        # Contrôle de l'unicité du wordID éventuel
        # pour éviter l'écrasement de fichiers sons
        if app.dic.wordIDs.has_key(id):
            if app.dic.wordIDs[id][0] != i:
                tkMessageBox.showinfo(parent=self,
                    title = u"Linguae audio",
                    message = "'" + id + "' " + app.lg.get("g", "id1") )
                return
        
       
        
        # --------------------------------------------
        # --- Chemin du fichier à enregistrer         
        # --------------------------------------------
        
        
        # Créer le répertoire de ressource s'il n'existe pas
        
        repRes = os.path.join(app.dic.path + "_res", "audio")
        
        if not os.path.isdir(repRes):
            try:
                os.makedirs(repRes)
            
            except: # Echec de la création > avertir et quitter
                tkMessageBox.showwarning(parent=self,
                    title = u"Linguae audio",
                    message = app.lg.get("wined", "msg6") )
                return
        
        
        
        # -------------------------------------------------------------
        # --- Effacer l'éventuel fichier audio antérieur (tout format) 
        # -------------------------------------------------------------
        
        for f in glob.glob(os.path.join(repRes, id + ".*")):      # Chemin du fichier audio
            
            try   : os.chmod(f, 0777)       # Ouvrir tous les droits sur le fichier
            except: pass
            
            try   : os.remove(f)            # Effacer
            except: pass
        
        
        # -----------------------------------------------------------------
        # --- Sélectionner le périphérique d'entrée pour l'enregistrement  
        # -----------------------------------------------------------------
        
        n = int(self.vAudioinput.get()[0])-1 # index du périphérique dans la liste retournée par inputDevices()
        if n > -1:
            try:
                tkSnack.audio.selectInput(tkSnack.audio.inputDevices()[n])
            except:
                tkMessageBox.showwarning(parent=self,
                    title = u"Linguae audio",
                    message = app.lg.get("wined", "msg18") )
                return
        
        
        # -------------------
        # --- Enregistrer    
        # -------------------
        
        # Chemin du fichier
        fichpath = os.path.join(repRes,id + "." + self.vFmtAudio.get())  
        
        try:
            self.mysound = tkSnack.Sound(fileformat=self.vFmtAudio.get().upper(), file=fichpath)
            self.mysound.record() 
        except:
            tkMessageBox.showwarning(parent=self,
                    title = u"Linguae audio",
                    message = app.lg.get("wined", "msg19") ) # ("Echec enregistrement fichier audio")
            self.mysound.stop()
            self.mysound = None
            return
        
        self.bt_play['state']='disabled'
        self.bt_rec['state']='disabled'
        self.lab_recon['background']='red'
        
        
        # -------------------------
        # --- Afficher le temps    
        # -------------------------
        
        while self.mysound:     # mis à None par le bouton 'Stop'
            
            # Nb: ces 'try' suppriment un message d'erreur en console (erreur dans tcl) en quittant la fenêtre d'édition
            # ne pas les jumeler en un, car risqe de gel  avec impossibilité de quitter Linguae...
            try:
                self.lab_time['text'] = str(tkSnack.audio.elapsedTime())[:4]
            except:
                pass
            try:
                self.lab_time.update()
            except:
                pass
            
        self.bt_play['state']='normal'
        self.bt_rec['state']='normal'
        self.lab_recon['background']='black'
        self.update() # Permet l'affichage du temps et l'action du bouton Stop
        
        return


    def __soundStop(self):
        
        u"""
        | Stoppe la lecture ou l'enregistrement audio                           
        """
        
        try:    self.mysound.stop() 
        except: pass
        
        try:    self.mysound.destroy()
        except: pass
        
        self.mysound = None
        
        
        
        # (NB: les objets suivants ne sont pas instanciés dans tous les formats, d'où les Try)
        try   : self.bt_play['state']='normal'
        except: pass
        
        try   : self.bt_rec['state']='normal'
        except: pass
        
        try   : self.lab_recon['background']='black'
        except: pass
        
        return


    def __pasteToEdit(self):
        
        u"""
        | Copie le contenu du presse-papiers dans la case posédant le focus     
        """
        
        try:
            w = self.focus_displayof() # widget ayant le focus
        except:
            return
        
        try:    w.delete(SEL_FIRST, SEL_LAST)
        except: pass
        
        try:
            w.insert(INSERT, self.clipboard_get())
        except:
            return
        
        return


    def cancelEdit(self):
        u"""
        | Annuler l'édition : ferme la fenêtre sans valider les modifications   
        |                                                                       
        | Nb : les modifications des ressources (images, sons) ne sont pas      
        |      annulées.                                                        
        """
        
        self.__soundStop()  # stoppe un éventuel enregistrement/écoute en cours
        
        self.destroy()


    def doEdit(self):
        
        u"""
        | Valide les modifications d'un élément de dictionnaire                 
        |                                                                       
        | > aiguillage vers les modules d'édition propres à chaque format et    
        |   affichage, si besoin, de leur message de retour : une chaîne vide   
        |   si succès, un message d'erreur si échec.                            
        """
        
        
        app['cursor'] = "watch"
        self['cursor'] = "watch"
        self.update()
        
        self.__soundStop()  # stoppe un éventuel enregistrement/écoute en cours
        
        
        # ------------------------------------------
        # --- Contrôles avant aiguillage            
        # ------------------------------------------
        
        if app.dic.type.startswith("ling"):
            lsteditbox = (self.txt_editShort, self.txt_editLong)
        else:
            lsteditbox = (self.txt_editShort,)
        
        flagtag = ""
        for w in lsteditbox:
            
            txt = w.get("0.0",END)
            
            # comparer le nombre de balises ouvrantes et fermantes
            if txt.count("<b>") != txt.count("</b>"):
                flagtag = "<b>"
                break
            if txt.count("<i>") != txt.count("</i>"):
                flagtag = "<i>"
                break
            if txt.count("<c c") != txt.count("</c>"):
                flagtag = "<c>"
                break
            if txt.count("<small>") != txt.count("</small>"):
                flagtag = "<small>"
                break
            if txt.count("<big>") != txt.count("</big>"):
                flagtag = "<big>"
                break
            if txt.count("<etym>") != txt.count("</etym>"):
                flagtag = "<etym>"
                break
            if txt.count("<synonym>") != txt.count("</synonym>"):
                flagtag = "<synonym>"
                break
            if txt.count("<antonym>") != txt.count("</antonym>"):
                flagtag = "<antonym>"
                break
            if txt.count("<kref>") != txt.count("</kref>"):
                flagtag = "<kref>"
                break
            
        if flagtag != "": # on avertit et on quitte en laissant la fenêtre d'édition ouverte
            w['background'] = "#FFDDDD"
            w.focus_set()
            app['cursor'] = ""
            self['cursor'] = ""
            tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("wined", "title1"),
                    message = app.lg.get("wined", "msg27") + " : " + flagtag)
            return
            
        
        # ------------------------------------------------
        # --- Aiguillage                                  
        # ------------------------------------------------
        
        memoLocalEditDate = app.dic.localEditDate 
        app.dic.localEditDate = str(datetime.date.today())
        
        ret = ""
        
        if app.dic.type.startswith("ling"):
            ret = self.__doEditLing()
        
        elif app.dic.type.startswith("wb"):
            ret = self.__doEditWB()
        
        elif app.dic.type.startswith("dict"):
            ret = self.__doEditDict()
            
        elif app.dic.type.startswith("xdxf"):
            ret = self.__doEditXDXF()
        
        elif app.dic.type.startswith("csv"):
            ret = self.__doEditCSVorINI()
        
        elif app.dic.type.startswith("ini"):
            ret = self.__doEditCSVorINI()
        
        
        # -------------------------------------------------
        
        app['cursor'] = ""
        self['cursor'] = ""
        
        # -------------------------------------------------------------------------------------------------
        # --- Echec : afficher le message d'échec et quitter la procédure sans fermer la fenêtre d'édition 
        # -------------------------------------------------------------------------------------------------
        
        if ret != "":
            tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("wined", "title1"),
                    message = app.lg.get("wined", "msg20") + "\n\n" + ret)
            app.dic.localEditDate = memoLocalEditDate
            return
        
        # -----------------------
        # --- Succès             
        # -----------------------
        
        
        # Mémoriser le périphérique d'enregistrement ('try' car non utilisé par tous les formats)
        try   : app.ini.write("audioInputDevice", self.vAudioinput.get())
        except: pass
        
        self.destroy() # Ferme la fenêtre d'édition si édition ok
        
        return


    def __doEditLing(self):
        
        u"""
        | Valide les modifications d'un élément de dictionnaire Ling            
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide en cas de succès                                  
        |   - Une chaîne contenant un message d'erreur en cas d'échec           
        """
        
        i = int(self.lab_idx['text'].split(":")[1]) # Index de l'entrée éditée
        
        
        
        # ------------------------------------------------------------------------
        # --- Formatage des éventuels sauts de lignes dans short et infos >> <br> 
        # ------------------------------------------------------------------------
        
        tShort = self.txt_editShort.get("0.0",END).strip()
        tShort = tShort.replace("\r\n", "<br>")
        tShort = tShort.replace("\r", "<br>")
        tShort = tShort.replace("\n", "<br>")
        
        tLong = self.txt_editLong.get("0.0",END).strip()
        tLong = tLong.replace("\r\n", "<br>")
        tLong = tLong.replace("\r", "<br>")
        tLong = tLong.replace("\n", "<br>")
        
        
        # ------------------------------------------------------------------
        # --- Confectionner la chaîne de l'entrée (compatible Preling)      
        #     avec le contenu des cases d'édition de la feuille d'édition   
        # ------------------------------------------------------------------
        
        newStr = ""
        
        # --- [0] Entrée du dictionnaire
        newStr += self.txt_chp1.get().strip().encode('utf-8') + "\t"
        
        # --- [1] traductions courtes
        newStr += tShort.encode('utf-8') + "\t"
        
        # --- [2] traductions longues
        newStr += tLong.encode('utf-8') + "\t" 
        
        # --- [3] wordID de l'entrée
        wID = self.txt_ID.get().strip("; ").lower()[:8]                         
        wID = wID.replace(" ","")
        wID = wID.replace("_","")
        
        # contrôle de validité du wordID
        ret = lib.mydic.DicObject.validateLingWordID(wID)
        if ret != "":
            self.txt_ID.focus_set()
            return ret
        
        # Contrôle de l'unicité (doublonnage de wordID ?)
        if app.dic.wordIDs.has_key(wID):
            if app.dic.wordIDs[wID][0] != i:
                return u"'" + wID+"' " + app.lg.get("wined", "msg21")
        
        newStr += wID + "\t"
        
        # [4] liste des racines
        newStr += self.txt_rac.get().strip("; ") + "\t"
        
        # [5] liste des synonymes
        newStr += self.txt_syn.get().strip("; ") + "\t"
        
        # [6] liste des voir-aussi
        newStr += self.txt_see.get().strip("; ") + "\t"
        
        # [7] liste des tokens
        newStr += self.txt_tok.get().strip("; ") + "\t"
        
        # [8] phonétique
        newStr += self.txt_phon.get().strip().encode('utf-8') + "\t" 
        
        # [9] liste des antonymes
        newStr += self.txt_ant.get().strip("; ")
        
        
        # ---------------------------------------------------------------
        # --- Confectionner la nouvelle chaîne Preling du dictionnaire   
        #     en incorporant la nouvelle chaîne de l'entrée éditée       
        # ---------------------------------------------------------------
        
        strPreling = app.dic.toStrPreling(progr=None, iEdit=i, contentEdit=newStr)
        
        
        # ----------------------------------------------
        # --- Confectionner la nouvelle chaîne Ling     
        # ----------------------------------------------
        
        strLing = lib.mydic.DicObject.strPrelingToStrLing(strPreling=strPreling)
        
        if strLing.startswith("!"):
            return strLing  # retourner le message d'erreur
        
        
        # -------------------------------------
        # --- Enregistrer le nouveau fichier   
        # -------------------------------------
        
        fichpath = app.dic.path
        app.dic.file.close()
        
        
        try:
            ff = open(fichpath, 'wb')
        except IOError, msg:        # Impossible d'ouvrir le fichier du dico en écriture (droits d'accés ou lecture seule)
            app.dic.file = open(fichpath, 'rb')# le rouvrir en lecture et quitter
            return app.lg.get("wined", "msg22") + "\n\n" + str(msg)
        
        ff.write(strLing)
        ff.close()
        
        
        # --------------------------------------------------------
        # --- Recharger le dictionnaire avec le nouveau fichier   
        # --------------------------------------------------------
        
        app.loadDico(fichpath, showSplash=False)
        
        # Rafraîchir l'affichage des données
        
        if i == -1:
            i = app.lst_dico.size()-1    # Dernier index de la liste si édition d'une nouvelle entrée
        
        
        app.dic.lstbox.activate(i)
        app.dic.lstbox.selection_set(i)
        app.dic.lstbox.see(i)
        app.selDisplayData(None)
        
        return ""
    

    def __doEditWB(self):
        
        u"""
        | Valide les modifications d'un élément de dictionnaire WB              
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide en cas de succès                                  
        |   - Une chaîne contenant un message d'erreur en cas d'échec           
        """
        
        i = int(self.lab_idx['text'].split(":")[1]) # lire l'index du mot édité (-1 si mot ajouté)
        
        
        # ---------------------------------------------------
        # --- Confectionner le bloc WB à modifier ou ajouter 
        # ---------------------------------------------------
        
        chp1 = self.txt_chp1.get().strip()
        chp1 = chp1.replace(",", ";")
        
        try:
            chp1 = chp1.encode (app.dic.encoding1)   # Appliquer l'encodage originel du fichier
        except:
            return u"index " + str(i) + "\n\n" + app.lg.get("wined", "msg23") + "1\n\n" + + app.lg.get("wined", "msg24")
        
        chp2 = self.txt_editShort.get("0.0",END).strip()
        
        try:
            chp2 = chp2.encode (app.dic.encoding2)   # Appliquer l'encodage originel du fichier
        except:
            return u"index " + str(i) + "\n\n" + app.lg.get("wined", "msg23") + "2\n\n" + + app.lg.get("wined", "msg24")
        
        
        newBloc = chp1[:30].ljust(31,'\0') + chp2[:50].ljust(53,'\0')
        
        
        # ----------------------------------------------------------
        # --- Mise à jour de la liste des entrées dans l'interface  
        # ----------------------------------------------------------
        
        if i == -1:     # Ajouter une entrée
            app.lst_dico.insert(END, self.txt_chp1.get())
        else:           # Remplacer une entrée
            app.lst_dico.delete(i)
            app.lst_dico.insert(i, self.txt_chp1.get())
        
        
        # ----------------------------------------------------
        # --- Confectionner la nouvelle chaîne du fichier WB  
        # ----------------------------------------------------
        
        fichpath = app.dic.path
        
        if i == -1:     # Ajouter une entrée
            pass
        else:           # Remplacer une entrée
            app.dic.file.seek(0)
            part1 = app.dic.file.read(84*i)
            app.dic.file.seek(84*(i+1))
            part2 = app.dic.file.read(os.path.getsize(fichpath))
            
            strfile = part1 + newBloc + part2
        
        
        # ----------------------------------------
        # --- Enregistrer le nouveau fichier WB   
        # ----------------------------------------
        
        app.dic.file.close()
        
        if i == -1:     # Ajouter une entrée
            
            try:
                app.dic.file = open(fichpath, 'ab') # ouvrir en "append"
            except IOError, msg:        # Impossible d'ouvrir le fichier du dico en écriture (droits d'accés ou lecture seule)
                app.dic.file = open(fichpath, 'rb')# le rouvrir en lecture et quitter
                return app.lg.get("wined", "msg22") + "\n\n" + str(msg)
            
            app.dic.file.write(newBloc)
            app.dic.file.close()
            app.dic.file = open(fichpath, 'rb')
            
            app.dic.wordcount += 1
        
        
        else:           # Remplacer une entrée
            
            try:
                app.dic.file = open(fichpath, 'wb')
            except IOError, msg:        # Impossible d'ouvrir le fichier du dico en écriture (droits d'accés ou lecture seule)
                app.dic.file = open(fichpath, 'rb')# le rouvrir en lecture et quitter
                return app.lg.get("wined", "msg22") + "\n\n" + str(msg)
            
            app.dic.file.write(strfile)
            app.dic.file.close()
            app.dic.file = open(fichpath, 'rb')
        
        
        # ------------------------------------------
        # --- Rafraîchit l'affichage des données    
        # ------------------------------------------
        
        
        if i == -1:
            i = app.lst_dico.size()-1    # Dernier index de la liste si édition d'une nouvelle entrée
        
        app.dic.lstbox.activate(i)
        app.dic.lstbox.selection_set(i)
        app.dic.lstbox.see(i)
        app.selDisplayData(None)
        
        
        return ""
    
    
    def __doEditXDXF(self):
        
        u"""
        | Valide les modifications d'un élément de dictionnaire XDXF            
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide en cas de succès                                  
        |   - Une chaîne contenant un message d'erreur en cas d'échec           
        """
        
        i = int(self.lab_idx['text'].split(":")[1]) # index du mot édité
        
        # -----------------------------------------------------
        # --- Confectionner les blocs du fichier, à conserver  
        # -----------------------------------------------------
        
        fichpath = app.dic.path
        
        if i == -1:     # nouvelle entrée
            
            app.dic.file.seek(0)
            part1 = app.dic.file.read()
            part1 = part1[:part1.rfind("</xdxf>")]
            part1 = part1.rstrip("\n")
            part2 = "\n</xdxf>\n"
        
        else:
            ii = i-1
            if ii<0: ii=0
            
            app.dic.file.seek(0)
            part1 = app.dic.file.read(app.dic.datamap[ii][0] + app.dic.datamap[ii][1])
                        
            app.dic.file.seek(app.dic.datamap[i][0] + app.dic.datamap[i][1])
            part2 = app.dic.file.read(os.path.getsize(fichpath)) # lit jusqu'au bout du fichier
        
        
        # --------------------------------------------------
        # --- Confectionner le bloc de l'entrée à modifier  
        # --------------------------------------------------
        
        tchp1 = self.txt_chp1.get().strip()
        tshort = self.txt_editShort.get("0.0",END).strip()
        tlong = self.txt_editLong.get("0.0",END).strip()
        tphon = self.txt_phon.get().strip()
        
        
        # --- concaténer le nouveau bloc xdxf
        
        newBloc = "\n<ar><head><k>" + tchp1 + "</k></head><def>" + tshort 
        
        if tphon != "":
            newBloc += "<trn>" + tphon + "</trn>\n"
        
        if tlong != "":
            newBloc += "<co>" + tlong + "</co>\n"
        
        newBloc += "</def></ar>"    
        
        # --- Appliquer l'encodage originel du fichier
        
        try:
            newBloc = newBloc.encode('utf-8')
        except:
            return app.lg.get("wined", "msg25") + " " + str(i)
        
        
        # -------------------------------------------------
        # --- Mise à jour du fichier                       
        # -------------------------------------------------
        
        # Confectionner la nouvelle chaîne du fichier
        strfile = part1 + newBloc + part2
        
        # Enregistrer le fichier
        app.dic.file.close()
        
        try:
            app.dic.file = open(fichpath, 'wb')
        except IOError, msg:        # Impossible d'ouvrir le fichier du dico en écriture (droits d'accés ou lecture seule)
            app.dic.file = open(fichpath, 'rb')# le rouvrir en lecture et quitter
            return app.lg.get("wined", "msg22") + "\n\n" + str(msg)
        
        app.dic.file.write(strfile)
        app.dic.file.close()
        app.dic.file = open(fichpath, 'rb')
        
        
        # Recharge le dictionnaire avec le nouveau fichier
        app.loadDico(fichpath, showSplash=False)
        
        # Rafraîchit l'affichage des données
        
        if i == -1:
            i = app.lst_dico.size()-1    # Dernier index de la liste si édition d'une nouvelle entrée
        
        app.dic.lstbox.activate(i)
        app.dic.lstbox.selection_set(i)
        app.dic.lstbox.see(i)
        app.selDisplayData(None)
        
        
        return ""
        

    def __doEditCSVorINI(self):
        
        u"""
        | Valide les modifications d'un élément de dictionnaire CSV ou INI      
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide en cas de succès                                  
        |   - Une chaîne contenant un message d'erreur en cas d'échec           
        """
        
        i = int(self.lab_idx['text'].split(":")[1]) # index du mot édité
        
        
        # -----------------------------------------------------
        # --- Confectionner les blocs du fichier, à conserver  
        # -----------------------------------------------------
        
        fichpath = app.dic.path
        
        if i == -1:     # nouvelle entrée
            
            app.dic.file.seek(0)
            part1 = app.dic.file.read() + app.dic.br
            part2 = ""
        
        else:
            ii = i-1
            if ii<0: ii=0
            
            app.dic.file.seek(0)
            part1 = app.dic.file.read(app.dic.datamap[ii][0]+app.dic.datamap[ii][1])
            if part1 != "" : part1 = part1 + app.dic.br
            
            app.dic.file.seek(app.dic.datamap[i][0]+app.dic.datamap[i][1])
            part2 = app.dic.file.read(os.path.getsize(fichpath)) # lit jusqu'au bout du fichier
        
        
        # --------------------------------------------------
        # --- Confectionner le bloc de l'entrée à modifier  
        # --------------------------------------------------
        chp1 = self.txt_chp1.get().strip()
        chp2 = self.txt_editShort.get("0.0",END).strip()
        
        if app.dic.type.startswith("ini") and chp1.startswith("["): # section d'ini
            newBloc = chp1
        else:
            newBloc = chp1 + app.dic.sep + chp2
        
        # --- Appliquer l'encodage originel du fichier
        
        try:
            newBloc = newBloc.encode (app.dic.encoding1)
        except:
            return app.lg.get("wined", "msg26") + " " + str(i) + "\n\n" + app.lg.get("wined", "msg24")
        
        
        # -------------------------------------------------
        # --- Mise à jour du fichier                       
        # -------------------------------------------------
        
        # Confectionner la nouvelle chaîne du fichier
        strfile = part1 + newBloc + part2
        
        # Enregistrer le fichier
        app.dic.file.close()
    
        try:
            ff = open(fichpath, 'wb')
        except IOError, msg:        # Impossible d'ouvrir le fichier du dico en écriture (droits d'accés ou lecture seule)
            app.dic.file = open(fichpath, 'rb')# le rouvrir en lecture et quitter
            return app.lg.get("wined", "msg22") + "\n\n" + str(msg)
        
        ff.write(strfile)
        ff.close()
        
        # Recharger le dictionnaire avec le nouveau fichier
        cp = app.dic.encoding1
        app.loadDico(fichpath, cp1=cp, showSplash=False)
        
        # Rafraîchit l'affichage des données
        
        if i == -1:
            i = app.lst_dico.size()-1    # Dernier index de la liste si édition d'une nouvelle entrée
        
        app.dic.lstbox.activate(i)
        app.dic.lstbox.selection_set(i)
        app.dic.lstbox.see(i)
        app.selDisplayData(None)
        
        return ""


    def __doEditDict(self):
        
        u"""
        | Valide les modifications d'un élément de dictionnaire Dict            
        |                                                                       
        | RETOUR :                                                              
        |   - Une chaîne vide en cas de succès                                  
        |   - Une chaîne contenant un message d'erreur en cas d'échec           
        """
        
        i = int(self.lab_idx['text'].split(":")[1]) # Index de l'entrée éditée
        
        # Confectionner la chaîne de l'entrée éditée
        # avec le contenu des cases d'édition de la feuille d'édition
        
        try:
            newStr = self.txt_chp1.get().strip().encode('utf-8') + "\0"         # [0] Entrée du dictionnaire
            newStr += self.txt_editShort.get("0.0",END).strip().encode('utf-8') # [1] traduc courte
        except:
            return app.lg.get("wined", "msg25") + " " + str(i)
        
        # Obtenir un tuple des chaines Dict : (stridx, strdict, strwordcount)
        strs = app.dic.toStrsDict(iEdit=i, contentEdit=newStr)
        
        # si strs est une chaîne et non un tupple => problème !
        if type(strs) is type("xxx"):
            return strs
        
        
        # -------------------------------------------------------
        # --- Enregistrer les nouveaux fichiers *.idx et *.dict  
        # -------------------------------------------------------
        
        radicfich = os.path.splitext(app.dic.path)[0]     # Radical des différents fichiers Dict
        
        
        # --- Enregistrer le *idx
        try:
            ff = open(radicfich + '.idx', 'wb')
        except IOError, msg:        # Impossible d'ouvrir le fichier du dico en écriture (droits d'accés ou lecture seule)
            return app.lg.get("wined", "msg22") + "\n\n" + str(msg)        
        
        ff.write(strs[0])
        ff.close()
        
        
        # --- Enregistrer le *dict
        app.dic.file.close()
        try:
            ff = open(radicfich + '.dict', 'wb')
        except IOError, msg:        # Impossible d'ouvrir le fichier du dico en écriture (droits d'accés ou lecture seule)
            app.dic.file = open(radicfich + '.dict', 'rb')
            return app.lg.get("wined", "msg22") + "\n\n" + str(msg)        
        
        ff.write(strs[1])
        ff.close()
        
        
        # ------------------------------------------------
        # --- Reconstruire le fichier *.ifo               
        # ------------------------------------------------
        lg = ""
        strifo = ""
        ff = open(radicfich + '.ifo', 'rU')
        
        for ligne in ff:
            
            if ligne.startswith("wordcount="):
                lg = "wordcount=" + strs[2] + "\n"
            elif ligne.startswith("idxfilesize="):
                lg = "idxfilesize=" + str(os.path.getsize(radicfich + ".idx")) + "\n"
            else:
                lg = ligne
                
            strifo += lg 
        
        ff.close()
        ff = open(radicfich + '.ifo', 'wb')   # Enregistrer le *ifo
        ff.write(strifo)
        ff.close()
        
        
        # --------------------------------------------------------------
        # --- Recharger le dictionnaire avec le nouveau fichier Dict    
        # --------------------------------------------------------------
        
        app.loadDico(radicfich + '.dict', showSplash=False)
        
        # --- Rafraîchit l'affichage des données
        
        if i == -1:
            i = app.lst_dico.size()-1    # Dernier index de la liste si édition d'une nouvelle entrée
        
        
        app.dic.lstbox.activate(i)
        app.dic.lstbox.selection_set(i)
        app.dic.lstbox.see(i)
        app.selDisplayData(None)
        
        
        return ""


    def __makeID(self):
        
        u"""
        | Confectionne un wordID automatique pour l'entrée en édition           
        | et l'affiche dans la case ad hoc                                      
        """
        
        self.txt_ID.delete(0,END)
        self.txt_ID.insert(END, app.dic.makeWordID(self.txt_chp1.get()))
        
        return


class WindowSwac(Toplevel):
    
    u"""
    | Fenêtre de recherche de fichiers sons sur le site Swac
    """
    
    
    def __init__(self, mot="", lg=""):
        
        u"""
        Mise en place de l'interface graphique de la fenêtre
        """
        
        Toplevel.__init__(self)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+300)
        top = str(int(app.geometry().split('+')[2])+90)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winsw", "title"))
        self.resizable(width=NO, height=NO)
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        # Procédure qui sera appelée à la tentative de fermeture de la fenêtre
        self.protocol('WM_DELETE_WINDOW', self.queryUnload)
        
        # Case du mot
        self.txt_mot = Entry(self, width=30, font=app.lst_dico['font'])
        self.txt_mot.grid(row=0, column=0)
        self.txt_mot.insert(END, mot)
        
        # Case de la langue
        self.txt_lg = Entry(self, width=4)
        self.txt_lg.grid(row=0, column=1)
        self.txt_lg.insert(END, lg)
        
        # Bouton d'interrogation
        Button(self, text=" > ", command=self.__askfromlocal).grid(row=0, column=2)
        
        
        # Lien vers le site Swac
        lab_sw = Label(self, image=app.imglst.info, compound="left", text="   SWAC Web site", cursor="hand2", foreground="blue")
        lab_sw.bind("<ButtonRelease-1>", self.toWebSwac)
        lab_sw.grid(row=2, column=0, columnspan=3, padx=2)
        
        
        # --- Interroger
        if mot != "":
            self.__askforword(mot, lg)
        
        return
    
    def queryUnload(self):
        
        app.f_swac = None
        self.destroy()
        
        
    
    def askfromsel(self, mot, lg=""):
        
        if mot == "" :
            return
        
        self.txt_mot.delete(0, END)
        self.txt_mot.insert(END, mot)
        
        # Code de langue
        if lg == "":
            lg = self.txt_lg.get()
        
        if lg == "":
            return
        
        self.txt_lg.delete(0, END)
        self.txt_lg.insert(END, lg)
        
        # ---
        
        self.__askforword(mot=mot, lg=lg)
        
        return
    

    def __askforword(self, mot, lg):
        
        u"""
        | Interroger la banque Swac                                             
        |                                                                       
        | ARGUMENTS :                                                           
        |   'mot' : le mot dont on recherche la pronciation                     
        |                                                                       
        |   'lg'  : la langue du mot (code ISO 639)                             
        |                                                                       
        """
        
        self['cursor'] = 'watch'
        app['cursor'] = 'watch'
        
        self.update()
        
        # Réinitialiser le Frame de retour des données
        try:
            self.fr_lnk.destroy()
        except:
            pass
        
        self.fr_lnk = Frame(self)
        self.fr_lnk.grid(row=1, column=0, columnspan=3)
        self.lab_msg = Label(self.fr_lnk, text="")
        self.lab_msg.grid(row=0, column=0, padx=3, pady=7)
        
        
        # ---------------------------------------------------
        # --- Formatter le mot pour le passer dans une url   
        # ---------------------------------------------------
        
        mot = mot.split("{")[0]
        mot = mot.split("[")[0]
        mot = mot.split("(")[0].strip()
        
        try:
            mot = mot.encode('utf-8')
        except:
            pass
        
        
        mot = map(ord,mot)
        moturl = ""
        
        for c in mot:
            if c > 128:
                # codage url = % + hexa de l'ordinal
                code = "%" + hex(c)[2:].upper()
            else:
                code = chr(c)
            moturl += code
        
        moturl = urllib.quote_plus(moturl, "%")
        
        
        # ---------------------------------------------------------
        # --- Charger la première page Swac >                      
        #     y récupérer les liens vers les pages d'info des sons 
        # ---------------------------------------------------------
        
        url = "http://swac-collections.org/index.php?page=snds&alphaidx=" + moturl + "&lang=" +  lg
        
        # Message d'attente
        self.lab_msg.config(text = "Connection à SWAC en cours...", foreground='black')
        self.update()
        
        try:
            swac1 = urllib.urlopen(url).readlines()
        except:
            self['cursor'] = ''
            app['cursor'] = ''
            tkMessageBox.showwarning(parent = self,
                title = app.lg.get("win1", "msg16"),
                message = app.lg.get("win1", "msg17") ) # ("échec de la connexion")
            self.destroy()
            return
        
        # Message d'attente
        self.lab_msg['text'] = "Recherche des enregistrements..."
        self.update()
        
        # Analyser la page
        
        pages = []  # liens vers les pages d'info de sons
        libels = [] # libellé des textes enregistrés
        
        for ligne in swac1:
            if "href='" in ligne:
                idx = ligne.split("href='")[1]
                idx = idx.split("'")[0]
                pages.append("http://swac-collections.org/" + idx)
                libel=""
                libel = ligne.split("png'>")[1]
                libel = libel.split("</a>")[0].strip()
                libels.append(libel)
        
        
        # Rien de trouvé > avertir et quitter
        if len(pages) == 0:
            self['cursor'] = ''
            app['cursor'] = ''
            self.lab_msg.config(text= "(aucun enregistrement SWAC pour ce mot)", foreground='red')
            return
        
        
        # ----------------------------------------------------------
        # --- Ouvrir les pages Swac d'info des sons >               
        #     y récupérer les liens vers les mp3 (un lien par page) 
        # ----------------------------------------------------------
        
        self.lab_msg['text'] = "Enregistrement(s) trouvé(s) :"
        self.update()
        
        n = 0
        for page in pages:
            
            swac2 = urllib.urlopen(page).readlines()
            
            for ligne in swac2:
                if "'> MP3" in ligne:
                    mp3 = ligne.split("'> MP3")[0]
                    mp3 = mp3.split("'")[-1]
                    
                    # on crée dynamiquement les étiquettes et les boutons
                    Label(self.fr_lnk, image=app.imglst.web, compound="left", text=" " + libels[n], font=app.lst_dico['font']).grid(row=n+1, column=0, padx=3, sticky="W")
                    Button(self.fr_lnk, image=app.imglst.audio, command=lambda arg=mp3: self.playSwacFile(arg)).grid(row=n+1, column=1, pady=2)
                    if app.dic.type.startswith("ling"):
                        if app.dic.curWordID != "":
                            Button(self.fr_lnk, image=app.imglst.save, command=lambda arg=mp3: self.saveSwacFile(arg)).grid(row=n+1, column=2, padx=4, pady=2)
                    break
            n += 1
        
        self['cursor'] = ''
        app['cursor'] = ''
        
        return


    def __askfromlocal(self):
        
        u"""
        | Interroger SWAC à partir du bouton local.       
        """
        
        mot = self.txt_mot.get()
        lg = self.txt_lg.get()
        
        # --- Interroger
        if mot != "" and lg != "":
            self.__askforword(mot, lg)
        
        
        return
    

    def toWebSwac(self, event=None):
        
        u"""
        | Ouvrir la page web de Swac dans le navigateur par défaut.       
        """
        
        try:
            webbrowser.open('http://swac-collections.org')
        except:
            pass
        
        return



    def playSwacFile(self, url):
        
        u"""
        | [ Appelé par le clic sur le bouton "Ecouter"]                         
        |                                                                       
        | Ecouter la prononciation du mp3 en sélection.                         
        """
        
        self['cursor'] = 'watch'
        app['cursor'] = 'watch'
        self.update()
        
        # --------------------------
        # --- Télécharger le mp3    
        # --------------------------
        
        # chemin du fichier local à créer/récupérer dans le cache
        mp3 = os.path.join(app.appdata.cache, os.path.basename(url))
        
        # Si le mp3 est absent du cache > on le télécharge
        if not os.path.isfile(mp3):
            
            try:
                urllib.urlretrieve(url, mp3)
            except:
                self['cursor'] = ''
                app['cursor'] = ''    
                return
        
        
        # -------------------
        # --- Ecouter        
        # -------------------
        
        try:
            self.mysound = tkSnack.Sound()
            self.mysound.read(mp3) 
            self.mysound.play()
        except:
            tkMessageBox.showwarning(parent = self,
                title = app.lg.get("win1", "msg1"),
                message = app.lg.get("win1", "msg3")) # ("échec lecture fichier audio")
            try:
                self.mysound.stop()
            except:
                pass
            
            self['cursor'] = ''
            app['cursor'] = ''
            return
        
        
        
        self['cursor'] = ''
        app['cursor'] = ''
        
        return
    
    
    
    def saveSwacFile(self, url):
        
        u"""
        | [ Appelé par le clic sur le bouton "Enregistrer"]                     
        |                                                                       
        | Enregistre le mp3 en tant que fichier local de la prononciation.      
        """
        
        self['cursor'] = 'watch'
        app['cursor'] = 'watch'
        self.update()
        
        # --------------------------
        # --- Télécharger le mp3    
        # --------------------------
        
        # chemin du fichier local à créer/récupérer dans le cache
        mp3 = os.path.join(app.appdata.cache, os.path.basename(url))
        
        # Si le mp3 est absent du cache > on le télécharge
        if not os.path.isfile(mp3):
            
            try:
                urllib.urlretrieve(url, mp3)
            except:
                self['cursor'] = ''
                app['cursor'] = ''    
                return
        
        
        # --------------------------------------------
        # --- Chemin du fichier à enregistrer         
        # --------------------------------------------
        
        
        # Créer le répertoire de ressource s'il n'existe pas
        
        repRes = os.path.join(app.dic.path + "_res", "audio")
        
        if not os.path.isdir(repRes):
            try:
                os.makedirs(repRes)
            
            except: # Echec de la création > avertir et quitter
                tkMessageBox.showwarning(parent=self,
                    title = u"Linguae audio",
                    message = app.lg.get("wined", "msg6") )
                self['cursor'] = ''
                app['cursor'] = ''   
                return
        
        
        # -------------------------------------------------------------
        # --- Effacer l'éventuel fichier audio antérieur (tout format) 
        # -------------------------------------------------------------
        
        wID = app.dic.curWordID
        
        for f in glob.glob(os.path.join(repRes, wID + ".*")): # Chemin du fichier audio
            
            try   : os.chmod(f, 0777)       # Ouvrir tous les droits sur le fichier
            except: pass
            
            try   : os.remove(f)            # Effacer
            except: pass
        
        
        # -----------------------------------------------------------------
        # --- Enregistrer = copier dans le répertoire de ressource audio   
        # -----------------------------------------------------------------
        
        # Chemin du fichier cible
        fichcible = os.path.join(repRes, wID + ".mp3")  
        
        try:
            shutil.copy(mp3, fichcible)
        except:
            print "Echec de la copie du fichier dans le repertoire audio !"
            self['cursor'] = ''
            app['cursor'] = ''
            return
        
        
        # Message de succès
        self['cursor'] = ''
        app['cursor'] = ''
        
        tkMessageBox.showwarning(parent = self,
                title = "Linguae audio",
                message = "Ce fichier audio sera maintenant disponible hors connexion à partir de la notice")
        
        return



class WindowTranslate(Toplevel):
    
    u"""
    | Fenêtre d'aide à la traduction commune à toutes les langues.              
    |                                                                           
    | Le principe est de feuilleter le dictionnaire et d'afficher les mots de   
    | plus proche concordance et non forcément le mot exact si ce dernier est   
    | absent du dictionnaire.                                                   
    """
    
    
    def __init__(self):
        
        u"""
        Mise en place de l'interface graphique de la fenêtre
        """
        
        Toplevel.__init__(self)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+80)
        top = str(int(app.geometry().split('+')[2])+140)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("wintrl", "title"))
        self.resizable(width=NO, height=NO)
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        
        
        # Frame des boutons
        fr_tool=Frame(self)
        fr_tool.grid(row=0, column=0, columnspan=10, sticky="W")
        Label(fr_tool, text=app.lg.get("wintrl", "s1")).grid(row=0, column=0, sticky='W')
        self.bt_copy=Button(fr_tool, text=" " + app.lg.get("g", "pst") + " ", compound=LEFT, image=app.imglst.paste, command=self.copyToTransl)
        self.bt_copy.grid(row=0, column=1, pady=2, padx=5)
        self.bt_open=Button(fr_tool, text=" " + app.lg.get("wintrl", "s2") + " ", compound=LEFT, image=app.imglst.open, command=self.openToTransl)
        self.bt_open.grid(row=0, column=2, pady=2, padx=5)
        Button(fr_tool, image=app.imglst.hlp, compound=LEFT, text=" " + app.lg.get("g", "hlp") + " ", padx= 10,command=lambda: app.showHelp("trad")).grid(row=0, column=3, pady=2, padx=5)
        
        Label(self, text=app.lg.get("wintrl", "s3")).grid(row=1, column=0, columnspan=10, sticky='W')
        
        # zone du texte à traduire
        self.txt_source = ScrolledText.ScrolledText(self,width=80,height=10, background='white')
        self.txt_source['font']=app.lst_dico['font']
        self.txt_source.grid(row=2, column=0, columnspan=10, sticky='W')
        self.txt_source.bind("<Double-ButtonRelease-1>", self.dbClicOnWord)
        self.txt_source.bind("<Control-p>", self.dbClicOnWord)
        
        Label(self, text=app.lg.get("wintrl", "s4")).grid(row=3, column=0, sticky='W')
        
        # répétiteurs du mot et de la meilleure correspondance
        self.repwd=Text(self, width=20, height=1, borderwidth=0, background=self['background'])
        self.repwd.insert(END, "...")
        self.repwd.tag_config("vert", foreground="#008000")
        self.repwd.tag_config("rouge", foreground="red")
        self.repwd.grid(row=3, column=1, sticky='W')
        
        self.repbestwd=Text(self, width=20, height=1, borderwidth=0, background=self['background'])
        self.repbestwd.insert(END, "...")
        self.repbestwd.tag_config("vert", foreground="#008000")
        self.repbestwd.tag_config("rouge", foreground="red")
        self.repbestwd.grid(row=3, column=2, sticky='W')
        
        self.repwd['font'] = app.txt_notice['font']
        self.repbestwd['font'] = app.lst_dico['font']
        
        # liste des correspondances
        self.lst_match=lib.myscrlst.ScrolledList(self, width=82, height=10, font=app.dic.lstbox['font'], ondblclic=self.dblClicOnMatch, background='#ffffee')
        self.lst_match.grid(row=4, column=0, columnspan=10, sticky='W')
        
        Label(self, text=app.lg.get("wintrl", "s5")).grid(row=5, column=0, columnspan=10, sticky='W')
        
        self.txt_source.focus_set()
        
        return
    
    
    def openToTransl(self):
        
        u"""
        | Ouvrir un fichier texte à traduire et copier son contenu dans la case 
        | du texte à traduire.                                                  
        |                                                                       
        | Le texte du fichier remplace le contenu de la case.                   
        """
        
        fichpath = tkFileDialog.askopenfilename(parent=self,
                                title = app.lg.get("wintrl", "msg1"),
                                filetypes = (
                                (app.lg.get("g", "ftxt"),'*.txt'),
                                (app.lg.get("g", "fall"),'*.*'))
                                )
            
        if not fichpath: return   # L'utilisateur a cliqué 'Annuler' dans la boîte de dialogue
        
        ff = open(fichpath,"rU")
        t = ff.read()
        ff.close()
        
        try:
            t = t.decode('cp1252')
        except:
            pass
        
        self.txt_source.delete("1.0", END)
        self.txt_source.insert(END, t)
        
        
        return


    def copyToTransl(self):
        
        u"""
        | Copie le contenu du presse-papiers dans la case du texte à traduire.  
        |                                                                       
        | Le texte est inséré à l'emplacement du curseur ou remplace la         
        | sélection éventuelle.                                                 
        """
        
        try:    self.txt_source.delete(SEL_FIRST, SEL_LAST)
        except: pass
        self.txt_source.insert(INSERT, self.clipboard_get())
            
        return

    

    def dbClicOnWord(self, event):
        
        u"""
        | [ appelé par le Double-Clic ou Ctrl-P sur un mot à traduire ]         
        |                                                                       
        | Affiche les correspondances approchantes du mot cliqué.               
        """
        
        
        self.update()
        
        try:
            wordsel = self.txt_source.get(SEL_FIRST, SEL_LAST)  # mot à traduire
        except: # rien n'est sélectionné
            return
        
        self['cursor'] = "watch"
        app['cursor'] = "watch"
        
        try:
            wordsel = wordsel.encode('utf-8')
        except:
            pass
        
        # nettoyage des ponctuations
        # Nb : ne pas nettoyer les apostrophes internes (l') sinon problème avec (c'h)
        # l'usage du Ctrl+p à la place du double-clic contourne le problème
        wordsel = wordsel.lower().strip(" ,;:!?.()[]{}'\"") 
        
        wordstart = wordsel.lower()[:3]
        
        # accélérateurs locaux
        idxfind = app.dic.idxfind
        get = app.dic.lstbox.get
        getdata = app.dic.getdata
        
        
        # ------------------------------------------
        # --- Chercher la correspondance optimale   
        # ------------------------------------------
        
        motif = wordsel
        
        while len(motif)>0:
            ibest = idxfind(motif, dom='idx', decal=0, debut=True, ignorecase=True)
            if ibest is None:
                motif = motif[:-1]
            else:
                break
        
        # Nettoyage des données antérieures
        self.lst_match.clear()
        self.repwd.delete("1.0", END)
        self.repbestwd.delete("1.0", END)
        
        if ibest is None:
            app['cursor']=""
            self['cursor']=""
            return
        
        bestword = get(ibest).encode('utf-8').split()[0]
        
        
        # --------------------------------------------
        # --- Compléter la liste des correspondances  
        # --------------------------------------------
        
        oRegex = re.compile(r"<[^>]+?>")    # Expression régulière pour suppression des balises
        
        # --- Ajouter les correspondances approchantes (3 caractères mini) précédentes
        i = ibest
        while 1:
            i -= 1
            word = get(i).encode('utf-8')
            if word[:3].lower() == wordstart:
                
                t = word + "  >>>  " + getdata(i)['short'].replace("\n", "//").replace("\t", " ") + "  [" + str(i) + "]"
                t = t.replace("<br>"," ")
                # épurer le texte de ses éventuelles balises
                t = re.sub(oRegex, "", t)
                
                self.lst_match.add(t, p=0)
                
            else:
                break
        
        # --- Correspondance optimale
        
        t = get(ibest).encode('utf-8') + "  >>>  " + getdata(ibest)['short'].replace("\n", "//").replace("\t", " ") + "  [" + str(ibest) + "]"
        t = t.replace("<br>"," ")
        # épurer le texte de ses éventuelles balises
        t = re.sub(oRegex, "", t)
        
        self.lst_match.add(t)
        memidx = self.lst_match.listcount()-1
        
        # --- Ajouter les correspondances approchantes (3 caractères mini) suivantes
        
        i = ibest
        while 1:
            i += 1
            word = get(i).encode('utf-8')
            if word[:3].lower() == wordstart:
                
                t = word + "  >>>  " + getdata(i)['short'].replace("\n", "//").replace("\t", " ") + "  [" + str(i) + "]"
                t = t.replace("<br>"," ")
                # épurer le texte de ses éventuelles balises
                t = re.sub(oRegex, "", t)
                
                self.lst_match.add(t)
                
            else:
                break
        
        # Sélectionner la correspondance optimale
        self.lst_match.setSel(memidx)
        self.lst_match.see(memidx)
        self.lst_match.activate(memidx)
        self.lst_match.focus_set()
        
        
        # -----------------------------------------------------------------------
        # --- Afficher les répétiteurs : mot cliqué et meilleure correspondance  
        # -----------------------------------------------------------------------
        
        if len(bestword) > len(wordsel):
            nmax = len(bestword)
            nmin = len(wordsel)
        else:
            nmax = len(wordsel)
            nmin = len(bestword)
        
        for l in range(nmin):
            if wordsel[l] == bestword[l] :
                self.repwd.insert(END, wordsel[l], "vert")
                self.repbestwd.insert(END, bestword[l], "vert")
            else:
                self.repwd.insert(END, wordsel[l], "rouge")
                self.repbestwd.insert(END, bestword[l], "rouge")
        
        for l in range(nmin, nmax):
            try:
                self.repwd.insert(END, wordsel[l], "rouge")
            except :
                pass
            try:
                self.repbestwd.insert(END, bestword[l], "rouge")
            except:
                pass
            
        # ---
        
        app['cursor']=""
        self['cursor']=""
        
        return



    def dblClicOnMatch(self, i, id):
        
        u"""
        | [ appelé par le Double-Clic sur une correspondance]                    
        |                                                                       
        | Afficher l'élément correspondant dans la fenêtre principale.          
        """
        
        imatch = self.lst_match.getselectedindex()
        
        # Extraire l'index originel de la correspondance
        t = self.lst_match.getitem(i).split()[-1]
        i = int(t[1:len(t)-1])
        
        # Afficher la notice correspondante
        app.dic.lstbox.activate(i)
        app.dic.lstbox.selection_set(i)
        app.dic.lstbox.see(i)
        app.selDisplayData(None)
        
        self.lst_match.activate(imatch)
        self.lst_match.setSel(imatch)
        
        return


class WindowExport(Toplevel):
    
    u"""
    | Fenêtre d'exportation du dictionnaire courant vers divers formats.        
    """


    def __init__(self):
        
        u"""
        | Mise en place de l'interface graphique de la fenêtre.                 
        |                                                                       
        | Fenêtre à onglets (un onglet par format cible) pilotés par la liste   
        | des formats d'exportation à sa gauche.                                
        """
        
        # Si le fichier est protégé > avertir et quitter
        # (message dépendant de app car avant instanciation de Toplevel)
        if app.dic.protected1 !="" or app.dic.protected2 !="":
            tkMessageBox.showinfo(parent=app,
                    title = app.lg.get("winexp", "title"),
                    message = app.lg.get("winexp", "msg1") )
            return
        
        # ---
        
        Toplevel.__init__(self)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winexp", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()      # fenêtre modale
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        
        hPan = 20 # nb caractères
        wPan = 50 # nb caractères
        padxPan = 5
        fontttr = "Helvetiva 9 bold"
        
        # ----------------------------------------------------------------------
        # --- ListBox des formats cible de conversion                           
        # ----------------------------------------------------------------------
        
        self.lst_fmt=Listbox(self, height=hPan-7, width=14, background='white', selectborderwidth=3)
        self.lst_fmt.grid(row=0, column=0, padx=5, pady=5)
        self.lst_fmt.bind('<ButtonRelease-1>', self.lst_fmt_select)
        
        self.lst_fmt.insert(END, '<options>')
        self.lst_fmt.insert(END, 'LING')
        self.lst_fmt.insert(END, 'Preling')
        self.lst_fmt.insert(END, 'SQLite')
        self.lst_fmt.insert(END, 'DICT')
        self.lst_fmt.insert(END, 'XDXF')
        self.lst_fmt.insert(END, 'TEI')
        self.lst_fmt.insert(END, 'WB')
        self.lst_fmt.insert(END, 'CSV')
        self.lst_fmt.insert(END, 'INI')
        self.lst_fmt.insert(END, app.lg.get("winexp", "s31")) # Binaire
        self.lst_fmt.insert(END, app.lg.get("winexp", "s32")) # Liste des entrées
        
        
        # ----------------------------------------------------------------------
        # Welcome / Dimensionneur de l'espace des panneaux / Options générales  
        # ----------------------------------------------------------------------
        
        fr_welc=Frame(self)
        fr_welc.grid(row=0, column=1)
        Label(fr_welc, text="", width=wPan, height=hPan).grid(row=0, rowspan=10, column=0, padx=padxPan)
        Label(fr_welc, text="\n" + app.lg.get("winexp", "s1") + "\n\n" + "* "*20, width=wPan).grid(row=0, column=0, padx=padxPan)
        
        # Epurer les balises
        Message(fr_welc, width=300, text=app.lg.get("winexp", "s36"), justify="left").grid(row=2, column=0, padx=padxPan, sticky="w")
        self.vCleanTags = IntVar()
        Checkbutton(fr_welc, text=app.lg.get("winexp", "s37"), variable=self.vCleanTags).grid(row=3, column=0, padx=padxPan, sticky="w")
        
        # Epurer les doubles accolades de liens automatiques
        Message(fr_welc, width=300, text="\n" + app.lg.get("winexp", "s38"), justify="left").grid(row=4, column=0, padx=padxPan, sticky="w")
        self.vCleanAccol = IntVar()
        Checkbutton(fr_welc, text=app.lg.get("winexp", "s39"), variable=self.vCleanAccol).grid(row=5, column=0, padx=padxPan, sticky="w")
        
        
        # ----------------------------------------------------------------------
        # --- Panneau Ling                                                      
        # ----------------------------------------------------------------------
        
        self.fr_ling=Frame(self, borderwidth=2, relief='ridge')
        self.fr_ling.grid(row=0,column=1,padx=padxPan)
        
        Label(self.fr_ling, text=" ", width=wPan, height=hPan).grid(row=0, column=0, rowspan=10, columnspan=10) #dimensionneur)
        
        Label(self.fr_ling, text=app.lg.get("winexp", "s2"), borderwidth=4, foreground="white", background="black", font=fontttr).grid(row=0, column=0, columnspan=10, ipady=2, ipadx=5)
        
        Label(self.fr_ling, text=app.lg.get("winexp", "s3"), justify=LEFT). grid(row=1, column=0)
        
        self.vProtec1 = IntVar()
        chk_lingprotected1 = Checkbutton(self.fr_ling, text=app.lg.get("winexp", "s4"), variable=self.vProtec1)
        chk_lingprotected1.grid(row=2, padx=10, column=0, sticky='W')
        self.vProtec2 = IntVar()
        chk_lingprotected2 = Checkbutton(self.fr_ling, text=app.lg.get("winexp", "s5"), variable=self.vProtec2)
        chk_lingprotected2.grid(row=3, padx=10, column=0, sticky='W')
        
        
        # -------------------------
        # --- Panneau PreLing      
        # -------------------------
        
        self.fr_preling=Frame(self, borderwidth=2, relief='ridge')
        self.fr_preling.grid(row=0,column=1,padx=padxPan)
        
        Label(self.fr_preling, text=" ", width=wPan, height=hPan).grid(row=0, column=0, rowspan=10, columnspan=10) #dimensionneur)
        
        Label(self.fr_preling, text=app.lg.get("winexp", "s6"), borderwidth=4, foreground="white", background="black", font=fontttr).grid(row=0, column=0, columnspan=10, ipady=2, ipadx=5)
        
        Label(self.fr_preling, text=app.lg.get("winexp", "s7"), justify=LEFT).grid(row=1, column=0, columnspan=10)
        
        Label(self.fr_preling, text=app.lg.get("winexp", "s3"), justify=LEFT). grid(row=2, column=0, columnspan=10)
        
        # Choix du saut de ligne à utiliser
        r=3
        self.vCrlf2 = StringVar()
        Label(self.fr_preling, text=app.lg.get("winexp", "s8")).grid(row=r, sticky='W')
        Radiobutton(self.fr_preling, text="CRLF : \\r\\n (Windows)", variable=self.vCrlf2, value='\r\n').grid(row=r+1, column=0, sticky='W', padx=10)
        Radiobutton(self.fr_preling, text="LF : \\n (Unix)", variable=self.vCrlf2, value='\n').grid(row=r+2, column=0, sticky='W', padx=10)
        Radiobutton(self.fr_preling, text="CR : \\r (Mac os)", variable=self.vCrlf2, value='\r').grid(row=r+3, column=0, sticky='W', padx=10)
        self.vCrlf2.set("\r\n")
        
        # Choix du séparateur
        Label(self.fr_preling, text=app.lg.get("winexp", "s35")).grid(row=r, column=1)
        self.txt_sepPreling = Entry(self.fr_preling, width=6) 
        self.txt_sepPreling.insert(END, "{tab}")
        self.txt_sepPreling.grid(row=r, column=2)
        
        
        # -------------------------
        # --- Panneau SQLite       
        # -------------------------
        
        self.fr_sqlite=Frame(self, borderwidth=2, relief='ridge', padx=2)
        self.fr_sqlite.grid(row=0,column=1,padx=padxPan)
        
        Label(self.fr_sqlite, text=" ", width=wPan, height=hPan).grid(row=0, column=0, rowspan=10, columnspan=10) #dimensionneur)
        
        Label(self.fr_sqlite, text=app.lg.get("winexp", "s44"), borderwidth=4, foreground="white", background="black", font=fontttr).grid(row=0, column=0, columnspan=10, ipady=2, ipadx=5)
        
        Label(self.fr_sqlite, text=app.lg.get("winexp", "s45"), justify=LEFT).grid(row=1, column=0, padx=5)
        
        
        
        # -------------------------
        # --- Panneau Wb           
        # -------------------------
        
        self.fr_wb=Frame(self, borderwidth=2, relief='ridge')
        self.fr_wb.grid(row=0,column=1,padx=padxPan)
        
        Label(self.fr_wb, text=" ", width=wPan, height=hPan).grid(row=0, column=0, rowspan=10, columnspan=10) #dimensionneur)
        
        Label(self.fr_wb, text=app.lg.get("winexp", "s9"), borderwidth=4, foreground="white", background="black", font=fontttr).grid(row=0, column=0, columnspan=10, ipady=2, ipadx=5)
        
        r=1
        self.w_wbcp1=lib.myencsel.EncodingSelector(self.fr_wb, text='latin1', title='Encodage langue source :', height=5)
        self.w_wbcp1.grid(row=r, column=0, padx=3)
        self.w_wbcp2=lib.myencsel.EncodingSelector(self.fr_wb, text='latin1', title='Encodage Langue cible :', height=5)
        self.w_wbcp2.grid(row=r, column=1, padx=3)
        
        Label(self.fr_wb, text=app.lg.get("winexp", "s10"), justify=LEFT, anchor='w').grid(row=r+3, column=0, columnspan=10, ipady=2, ipadx=7, sticky='W')
        
        Label(self.fr_wb, text=app.lg.get("winexp", "s11"), justify=LEFT, anchor='w').grid(row=r+4, column=0, columnspan=10, ipady=2, ipadx=7, sticky='W')
        
        # Option WB strict / WB étendu
        self.vWBtype = StringVar()
        Radiobutton(self.fr_wb, text="WB 30/50", value="30/50", variable=self.vWBtype).grid(row=r+5, column=0)
        Radiobutton(self.fr_wb, text="WB 31/53", value="31/53", variable=self.vWBtype).grid(row=r+5, column=1)
        self.vWBtype.set("31/53")
        
        
        # -------------------------
        # --- Panneau Dict         
        # -------------------------
        
        self.fr_dict=Frame(self, borderwidth=2, relief='ridge')
        self.fr_dict.grid(row=0, column=1, padx=padxPan)
        
        Label(self.fr_dict, width=wPan, height=hPan).grid(row=0, column=0, rowspan=10) #dimensionneur)
        
        # Titre
        Label(self.fr_dict, text=app.lg.get("winexp", "s12"), borderwidth=4, foreground="white", background="black", font=fontttr).grid(row=0, column=0, ipady=2, ipadx=5)
        
        # Blabla
        Message(self.fr_dict, text=app.lg.get("winexp", "s13"), width=330, justify=LEFT).grid(row=1, column=0, sticky="W")
        
        Label(self.fr_dict, text='______________').grid(row=2, column=0)
        
        # Case à cocher : transfert de la grammaire entre crochets
        self.vTransGram = IntVar()
        Checkbutton(self.fr_dict, text=app.lg.get("winexp", "s14"), justify=LEFT, variable=self.vTransGram).grid(row=3, column=0, pady=2, sticky="W")
        
        Label(self.fr_dict, text='______________').grid(row=2, column=0)
        
        # Case à cocher : tri ascii strict
        self.vSortascii = IntVar()
        Checkbutton(self.fr_dict, text=app.lg.get("winexp", "s42"), justify=LEFT, variable=self.vSortascii).grid(row=4, column=0, pady=2, sticky="W")
        self.vSortascii.set(1)
        
        # Case à cocher : convertir les <br> en sauts de lignes
        self.vCleanBr = IntVar()
        Checkbutton(self.fr_dict, text=app.lg.get("winexp", "s43"), variable=self.vCleanBr).grid(row=5, column=0, pady=2 , sticky="w")
        
        
        # Bouton déroulant des sous-types Dict
        optionLst = (
            "sametypesequence = m",
            "sametypesequence = x",
            "sametypesequence = h",
            )
            
        self.vSubDict = StringVar()
        self.vSubDict.set(optionLst[0]) # par défaut
        opt_subDict = OptionMenu(self.fr_dict, self.vSubDict, *optionLst)
        opt_subDict.grid(row=6, column=0, pady=2)
        
        
        # -------------------------
        # --- Panneau XDXF         
        # -------------------------
        
        self.fr_xdxf=Frame(self, borderwidth=2, relief='ridge', padx=2)
        self.fr_xdxf.grid(row=0,column=1,padx=padxPan)
        
        Label(self.fr_xdxf, text=" ", width=wPan, height=hPan).grid(row=0, column=0, rowspan=10, columnspan=10) #dimensionneur)
        
        Label(self.fr_xdxf, text=app.lg.get("winexp", "s15"), borderwidth=4, foreground="white", background="black", font=fontttr).grid(row=0, column=0, columnspan=10, ipady=2, ipadx=5)
        
        Label(self.fr_xdxf, text=app.lg.get("winexp", "s16"), justify=LEFT).grid(row=1, column=0, padx=5)
        
        # Sélecteur de répertoire
        Label(self.fr_xdxf, text=app.lg.get("winexp", "s17")).grid(row=2, column=0, sticky='W')
        self.fb_repxdxf = lib.myfldbrw.FolderBrowser(self.fr_xdxf, width=50)
        self.fb_repxdxf.grid(row=3, column=0, sticky='W')
        
        # Case de choix du nom du sous-répertoire
        Label(self.fr_xdxf, text=app.lg.get("winexp", "s18")).grid(row=4, column=0, columnspan=10, padx=3, sticky='W')
        self.txt_namexdxf = Entry(self.fr_xdxf, width=20, background='white')
        self.txt_namexdxf.grid(row=5, column=0, sticky='W')
        
        
        # -------------------------
        # --- Panneau TEI          
        # -------------------------
        
        self.fr_tei=Frame(self, borderwidth=2, relief='ridge', padx=2)
        self.fr_tei.grid(row=0,column=1,padx=padxPan)
        
        Label(self.fr_tei, text=" ", width=wPan, height=hPan).grid(row=0, column=0, rowspan=10, columnspan=10) #dimensionneur)
        
        Label(self.fr_tei, text=app.lg.get("winexp", "s40"), borderwidth=4, foreground="white", background="black", font=fontttr).grid(row=0, column=0, columnspan=10, ipady=2, ipadx=5)
        
        Label(self.fr_tei, text=app.lg.get("winexp", "s41"), justify=LEFT).grid(row=1, column=0, padx=5)
        
        
        
        # -------------------------
        # --- Panneau CSV          
        # -------------------------
        
        self.fr_csv=Frame(self, borderwidth=2, relief='ridge')
        self.fr_csv.grid(row=0,column=1,padx=padxPan)
        
        Label(self.fr_csv, text=" ", width=wPan, height=hPan).grid(row=0, column=0, rowspan=10, columnspan=10) #dimensionneur
        
        Label(self.fr_csv, text=app.lg.get("winexp", "s19"), borderwidth=4, foreground="white", background="black", font=fontttr).grid(row=0, column=0, columnspan=10, ipady=2, ipadx=5)
        
        # Choix du caractère séparateur
        r=1
        self.vSp = StringVar()
        Label(self.fr_csv, text=app.lg.get("winexp", "s20")).grid(row=r, sticky='W')
        Radiobutton(self.fr_csv, text=app.lg.get("winexp", "s21"), variable=self.vSp, value='\t').grid(row=r+1, sticky='W', padx=10)
        Radiobutton(self.fr_csv, text=app.lg.get("winexp", "s22"), variable=self.vSp, value=',').grid(row=r+2, sticky='W', padx=10)
        Radiobutton(self.fr_csv, text=app.lg.get("winexp", "s23"), variable=self.vSp, value=';').grid(row=r+3, sticky='W', padx=10)
        self.vSp.set("\t")
        
        # Choix de l'encodage"
        r=1
        self.w_csvenc=lib.myencsel.EncodingSelector(self.fr_csv, text='latin1', height=12)
        self.w_csvenc.grid(row=r, column=1, rowspan=10, sticky='W')
        
        # Choix du saut de ligne
        r=6
        self.vCrlf = StringVar()
        Label(self.fr_csv, text=app.lg.get("winexp", "s24")).grid(row=r, sticky='W')
        Radiobutton(self.fr_csv, text="CRLF : \\r\\n (Windows)", variable=self.vCrlf, value='\r\n').grid(row=r+1, sticky='W', padx=10)
        Radiobutton(self.fr_csv, text="LF : \\n (Unix)", variable=self.vCrlf, value='\n').grid(row=r+2, sticky='W', padx=10)
        Radiobutton(self.fr_csv, text="CR : \\r (Mac os)", variable=self.vCrlf, value='\r').grid(row=r+3, sticky='W', padx=10)
        
        # Préselectionner le saut de ligne en fonction de la plateforme                        
        if app.pf in('osx', 'linux'):       # Unix (MacosX, Linux, )
            self.vCrlf.set("\r")
        else:                               # Windows par défaut
            self.vCrlf.set("\r\n")
        
        
        
        # -------------------------
        # --- Panneau INI          
        # -------------------------
        
        self.fr_ini=Frame(self, borderwidth=2, relief='ridge')
        self.fr_ini.grid(row=0,column=1,padx=padxPan)
        
        Label(self.fr_ini, text=" ", width=wPan, height=hPan).grid(row=0, column=0, rowspan=10, columnspan=10) #dimensionneur
        
        Label(self.fr_ini, text='Exportation au format INI', borderwidth=4, foreground="white", background="black", font=fontttr).grid(row=0, column=0, columnspan=10, ipady=2, ipadx=5)
        
        # Choix du saut de ligne
        r=1
        self.vBrIni = StringVar()
        Label(self.fr_ini, text=app.lg.get("winexp", "s24")).grid(row=r, sticky='W')
        Radiobutton(self.fr_ini, text="CRLF : \\r\\n (Windows)", variable=self.vBrIni, value='\r\n').grid(row=r+1, sticky='W', padx=10)
        Radiobutton(self.fr_ini, text="LF : \\n (Unix)", variable=self.vBrIni, value='\n').grid(row=r+2, sticky='W', padx=10)
        Radiobutton(self.fr_ini, text="CR : \\r (Mac os)", variable=self.vBrIni, value='\r').grid(row=r+3, sticky='W', padx=10)
        self.vBrIni.set("\r\n")
        
        
        self.w_inienc=lib.myencsel.EncodingSelector(self.fr_ini, text='cp1252', title="Encodage :", height=12)
        self.w_inienc.grid(row=1, column=1, rowspan=10, sticky='W')
        
        
        # -------------------------
        # --- Panneau Binaire      
        # -------------------------
        
        self.fr_bin=Frame(self, borderwidth=2, relief='ridge')
        self.fr_bin.grid(row=0,column=1,padx=padxPan)
        
        Label(self.fr_bin, text=" ", width=wPan, height=hPan).grid(row=0, column=0, rowspan=10, columnspan=10) #dimensionneur)
        
        Label(self.fr_bin, text=app.lg.get("winexp", "s25"), borderwidth=4, foreground="white", background="black", font=fontttr).grid(row=0, column=0, columnspan=10, ipady=2, ipadx=5)
        
        # Choix des octets de séparation
        r=1
        Label(self.fr_bin, text=app.lg.get("winexp", "s26"), padx=3).grid(row=r, column=0, sticky='W')
        txt_spbin=Entry(self.fr_bin, width=8, background="white")
        txt_spbin.grid(row=r, column=1, sticky='W', padx=5)
        txt_spbin.insert(END, "00")
        
        # Choix des octets de terminaison
        r=2
        Label(self.fr_bin, text=app.lg.get("winexp", "s27"), padx=3).grid(row=r, column=0, sticky='W')
        txt_crlfbin=Entry(self.fr_bin, width=8, background="white")
        txt_crlfbin.grid(row=r, column=1, sticky='W', padx=5)
        txt_crlfbin.insert(END, "00 00")
        
        r=3
        w_binenc=lib.myencsel.EncodingSelector(self.fr_bin, text='utf-8', height=6)
        w_binenc.grid(row=r, column=0, columnspan=2, rowspan=10)
        
        
        # ---------------------------------
        # --- Panneau Liste des entrées    
        # ---------------------------------
        
        self.fr_hword=Frame(self, borderwidth=2, relief='ridge')
        self.fr_hword.grid(row=0,column=1,padx=padxPan)
        
        Label(self.fr_hword, text=" ", width=wPan, height=hPan).grid(row=0, column=0, rowspan=10, columnspan=10) #dimensionneur)
        
        Label(self.fr_hword, text=app.lg.get("winexp", "s33"), borderwidth=4, foreground="white", background="black", font=fontttr).grid(row=0, column=0, columnspan=10, ipady=2, ipadx=5)
        
        Label(self.fr_hword, text=app.lg.get("winexp", "s34"), justify=LEFT).grid(row=1, column=0, columnspan=10, padx=5)
        
        # Choix de l'encodage"
        r=2
        self.w_hwordenc=lib.myencsel.EncodingSelector(self.fr_hword, text='latin1', height=12)
        self.w_hwordenc.grid(row=r, column=1, rowspan=10, sticky='W')
        
        # Choix du saut de ligne
        r=2
        self.vBrlst = StringVar()
        Label(self.fr_hword, text=app.lg.get("winexp", "s24")).grid(row=r, sticky='W')
        Radiobutton(self.fr_hword, text="CRLF : \\r\\n (Windows)", variable=self.vBrlst, value='\r\n').grid(row=r+1, sticky='W', padx=10)
        Radiobutton(self.fr_hword, text="LF : \\n (Unix)", variable=self.vBrlst, value='\n').grid(row=r+2, sticky='W', padx=10)
        Radiobutton(self.fr_hword, text="CR : \\r (Mac os)", variable=self.vBrlst, value='\r').grid(row=r+3, sticky='W', padx=10)
        
        # Préselectionner le saut de ligne en fonction de la plateforme
        if app.pf in ('osx', 'linux'):      # Unix (MacosX, Linux, )
            self.vBrlst.set("\r")
        else:                               # Windows par défaut
            self.vBrlst.set("\r\n")
        
        
        
        # -------------------------
        # --- Frame des Boutons    
        # -------------------------
        r = 1
        fr_butOpt=Frame(self)
        fr_butOpt.grid(row=r, column=0, columnspan=4, pady=8, sticky="WENS")
        
        Label(fr_butOpt, text="", width=wPan+int(self.lst_fmt['width'])).grid(row=0, columnspan=3) # dimensionneur
        self.bt_Do=Button(fr_butOpt, image=app.imglst.export, compound=LEFT, text="  " + app.lg.get("winexp", "s28"), width=90, padx= 7, command=self.doExport, state='disabled')
        self.bt_Do.grid(row=0, column=0, pady=8, padx=10)
        Button(fr_butOpt, image=app.imglst.exit, compound=LEFT, text="  " + app.lg.get("g", "close"), width=90, command=self.destroy, padx= 7).grid(row=0, column=1, pady=8, padx=10)
        Button(fr_butOpt, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=90, padx= 7, command=lambda: app.showHelp("export")).grid(row=0, column=2, pady=8, padx=10)
        
        # Barre de progression
        self.progr = lib.myprogbr.ProgressBar(self, width=380)
        self.progr.grid(row=r+1, column=0, columnspan=4, pady=5)
        self.progr.grid_remove()
        
        
        # --- Masquer tous les panneaux au démarrage
        self.fr_ling.grid_remove()
        self.fr_preling.grid_remove()
        self.fr_sqlite.grid_remove()
        self.fr_wb.grid_remove()
        self.fr_dict.grid_remove()
        self.fr_csv.grid_remove()
        self.fr_ini.grid_remove()
        self.fr_bin.grid_remove()
        self.fr_xdxf.grid_remove()
        self.fr_tei.grid_remove()
        self.fr_hword.grid_remove()
        
        return



    def lst_fmt_select(self, event):
        
        u"""
        | Sélection d'un format (ou du panneau d'options) dans la liste des formats.                      
        | Affichage du panneau correspondant                                    
        """
        
        self.lst_fmt.update()
        fmt = self.lst_fmt.get(int(self.lst_fmt.curselection()[0])) # texte de la ligne en sélection
        
        # masquer les panneaux
        self.fr_ling.grid_remove()
        self.fr_preling.grid_remove()
        self.fr_sqlite.grid_remove()
        self.fr_wb.grid_remove()
        self.fr_dict.grid_remove()
        self.fr_csv.grid_remove()
        self.fr_ini.grid_remove()
        self.fr_bin.grid_remove()
        self.fr_xdxf.grid_remove()
        self.fr_tei.grid_remove()
        self.fr_hword.grid_remove()
        
        self.bt_Do['state'] = 'disabled'
        
        
        # Sélectionner (afficher) le panneau de format
        if fmt == "LING":
            self.fr_ling.grid()
            self.bt_Do['state'] = 'active'
        elif fmt == "Preling":
            self.fr_preling.grid()
            self.bt_Do['state'] = 'active'
        elif fmt == "SQLite":
            self.fr_sqlite.grid()
            self.bt_Do['state'] = 'active'
        elif fmt == "WB":
            self.fr_wb.grid()
            self.bt_Do['state'] = 'active'
        elif fmt == "DICT":
            self.fr_dict.grid()
            self.bt_Do['state'] = 'active'
        elif fmt == "CSV":
            self.fr_csv.grid()
            self.bt_Do['state'] = 'active'
        elif fmt == "INI":
            self.fr_ini.grid()
            self.bt_Do['state'] = 'active'
        elif fmt.startswith("Bin"):
            self.fr_bin.grid()
            self.bt_Do['state'] = 'active'
        elif fmt == "XDXF":
            self.fr_xdxf.grid()
            self.bt_Do['state'] = 'active'
        elif fmt == "TEI":
            self.fr_tei.grid()
            self.bt_Do['state'] = 'active'
        elif fmt.startswith(app.lg.get("winexp", "s32")[:2]):
            self.fr_hword.grid() # Liste entrées
            self.bt_Do['state'] = 'active'
        
        
        return


    def doExport(self):
        
        u"""
        | [ appelé par le Bouton 'Exporter' ]                                   
        |                                                                       
        | Exporte le dictionnaire courant dans un fichier d'un autre format.    
        |                                                                       
        | Aiguillage vers des procédures propres à chaque format.               
        |                                                                       
        | Affichage, si nécessaire, du message de retour de ces procédures : une
        | chaîne vide si succès, une chaîne contenant un message d'erreur si    
        |  échec.                                                               
        """
        
        fmt = self.lst_fmt.get(ACTIVE) # format : texte de la ligne en sélection dans la liste des formats
        
        if fmt.startswith(app.lg.get("winexp", "s32")[:2]): fmt = "LST"
        
        dirSearch = app.ini.get("DicSearchPath",os.path.expanduser('~')) # Chemin de recherche des dicos
        
        
        # =========================================================================
        # === Interroger                                                           
        # === (si format source = Ling et cible != Ling, Preling, xdxf, WB, SQLite)
        # =========================================================================
        
        # Demander si fusion des traductions longues et traductions courtes ?
        flagfusion = False
        if app.dic.type.startswith("ling") and not fmt in ('LING','Preling','WB', 'XDXF', 'TEI', 'LST', 'SQLite'):
            flagfusion = tkMessageBox.askyesno(parent=self,
                    title = app.lg.get("winexp", "msg2"),
                    message = app.lg.get("winexp", "msg3") )
        
        
        # ======================================================================
        if fmt == "XDXF": # === Création des répertoires (XDXF uniquement)      
        # ======================================================================
            
            repxdxf = self.fb_repxdxf.getpath().strip()
            namexdxf = self.txt_namexdxf.get().strip()
            
            # Avertir > "Vous devez définir un dossier ET un nom"
            if repxdxf == "" or namexdxf == "":
                tkMessageBox.showwarning(parent=self,
                        title = app.lg.get("winexp", "msg4"),
                        message = app.lg.get("winexp", "msg5") )
                return
            
            
            fullrep = os.path.join(repxdxf, namexdxf)
            
            # Créer le répertoire du dico si besoin
            if not os.path.isdir(fullrep):
                try:
                    os.makedirs(fullrep)
                except:
                    return app.lg.get("winexp", "msg6")
            
            # Enregistrer
            fich = os.path.join(fullrep, "dict.xdxf")
        
        
        
        # ======================================================================
        else: # === Affichage du sélecteur de fichier (tous formats sauf XDXF)  
        # ======================================================================
        
        # Nom par défaut du fichier d'exportation
        
            if fmt == "LST":
                fich = os.path.splitext(app.dic.path)[0] + "_lst.txt"
            else:
                fich = os.path.splitext(app.dic.path)[0] + "." + fmt.lower()
            
            ft=""
            if fmt=="LING"               : ft =((app.lg.get("g", "fling"),'*.ling'),(app.lg.get("g", "fall"),'*.*'))
            elif fmt == "Preling"        : ft =((app.lg.get("g", "ftxt") + " Preling",'*.preling *.txt'),(app.lg.get("g", "fall"),'*.*'))
            elif fmt == "SQLite"         : ft =((app.lg.get("g", "fsqlite"),'*.sqlite3 *.sqling *.sqlite',),(app.lg.get("g", "fall"),'*.*'))
            elif fmt == "LST"            : ft =((app.lg.get("g", "ftxt"),'*.txt'),(app.lg.get("g", "fall"),'*.*'))
            elif fmt == "WB"             : ft =((app.lg.get("g", "fwb"),'*.wb'),(app.lg.get("g", "fall"),'*.*'))
            elif fmt == "DICT"           : ft =((app.lg.get("g", "fdict"),'*.ifo *.dict'),(app.lg.get("g", "fall"),'*.*'))
            elif fmt == "TEI"            : ft =((app.lg.get("g", "ftei"),'*.tei'),(app.lg.get("g", "ftei"),'*.*'))
            elif fmt == "CSV"            : ft =((app.lg.get("g", "flim"),'*.csv *.tab *.txt'),(app.lg.get("g", "fall"),'*.*'))
            elif fmt == "INI"            : ft =((app.lg.get("g", "fini"),'*.ini'),(app.lg.get("g", "fall"),'*.*'))
            elif fmt.startswith("Bin")   : ft =((app.lg.get("g", "fall"),'*.*'),)
            else                         : ft =((app.lg.get("g", "fall"),'*.*'),)
            
            fich = tkFileDialog.asksaveasfilename(parent=self,
                        title = app.lg.get("winexp", "msg7"),
                        filetypes = ft,
                        initialdir = dirSearch,
                        initialfile = fich
                        )
            
            if not fich: return
            
            app['cursor'] = "watch"
            self['cursor'] = "watch"
            
            # S'assurer de la conformité de l'extension avec le format d'exportation
            # l'ajouter le cas échéant
            if fmt != "LST":
                if not fich.endswith('.'+ fmt.lower()):
                    fich += '.'+ fmt.lower()
        
        
        # ----------------------------------------------------------------------
        # --- Afficher et paramétrer la progressbar de la fenêtre d'export      
        # ----------------------------------------------------------------------
        
        self.progr.grid()
        self.progr.setMax(app.dic.lstbox.size())
        self.update()
        
        
        # ----------------------------------------------------------------------
        # --- Paramètres d'exportation                                          
        # --- (seuls certains sont utilisés, suivant les formats)               
        # ----------------------------------------------------------------------
        
        # Protéger le dico 
        if self.vProtec1.get() == 1:
            protected1 = "Linguae"
        else:
            protected1 = ""
            
        if self.vProtec2.get() == 1:
            protected2 = "Linguae"
        else:
            protected2 = ""
        
        # Epurer les balises
        if self.vCleanTags.get() == 1:
            flagcleantags = True
        else:
            flagcleantags = False
        
        # Epurer les accolades
        if self.vCleanAccol.get() == 1:
            flagcleanaccol = True
        else:
            flagcleanaccol = False
        
        
        if fmt == "DICT":
            # Sous-format Dict
            subdict = self.vSubDict.get()[-1]
            # Conversion des <br> en saut de ligne
            if self.vCleanBr.get() == 1:
                flagcleanbr = True
            else:
                flagcleanbr = False
        
        # Déplacer la grammaire entre crochets
        if self.vTransGram.get() == 1:
            flagtransgram = True
        else:
            flagtransgram = False
        
        # Saut de ligne, séparateur et encodage
        if fmt == "Preling":
            br = self.vCrlf2.get()
            
        elif fmt == "CSV":
            sp = self.vSp.get()
            br = self.vCrlf.get()
            cp = self.w_csvenc.get().strip()
            if cp == "": cp ='latin-1'
            
        elif fmt == "INI":
            sp = '='
            br = self.vBrIni.get()
            cp = self.w_inienc.get().strip()
            
        elif fmt == "LST":              # Liste des entrées
            sp = ""
            br = self.vBrlst.get()
            cp = self.w_hwordenc.get().strip()
            
        elif fmt.startswith("Bin"):     # binaire
            
            for c in txt_spbin.get().split():
                sp += chr(int(c))
            
            for c in txt_crlfbin.get().split():
                br += chr(int(c))
            
            cp = w_binenc.get().strip()
            if cp == "": cp ='utf-8'
            
        elif fmt == "WB": 
            cp1 = self.w_wbcp1.get().strip()        # Encodage langue 1
            if cp1 == "": cp1 ='cp1242'             # (par défaut)
            
            cp2 = self.w_wbcp2.get().strip()        # Encodage langue 1
            if cp2 == "": cp2 ='cp1242'             # (par défaut)
        
        
        # ======================================================================
        # === Aiguillage en fonction du format                                  
        # ======================================================================
        
        
        # --- Conversion vers Ling  --------------------------------------------
        
        if fmt == "LING":                           
            
            ret = app.dic.doExportToLing(fich,
                                         protected1 = protected1,
                                         protected2 = protected2,
                                         flagcleantags = flagcleantags,
                                         flagcleanaccol = flagcleanaccol,
                                         prgbar=self.progr)
            
            
        # --- Conversion vers Preling ------------------------------------------
            
        elif fmt == "Preling": 
            
            ret = app.dic.doExportToPreling(fich,
                                            protected1 = protected1,
                                            protected2 = protected2,
                                            flagcleantags = flagcleantags,
                                            flagcleanaccol = flagcleanaccol,
                                            prgbar = self.progr,
                                            br=br)
            
            
        # --- Conversion vers SQLite -------------------------------------------
            
        elif fmt == "SQLite":
            
            ret = app.dic.doExportToSQLite(fich,
                                           flagcleantags = flagcleantags,
                                           flagcleanaccol = flagcleanaccol,
                                           prgbar = self.progr)
            
            
        # --- Conversion vers XDXF ---------------------------------------------
            
        elif fmt == "XDXF":
            
            ret = app.dic.doExportToXDXF(fich,
                                         flagcleantags = flagcleantags,
                                         flagcleanaccol = flagcleanaccol,
                                         prgbar = self.progr)
            
            
        # --- Conversion vers TEI ----------------------------------------------
            
        elif fmt == "TEI":
            
            ret = app.dic.doExportToTEI(fich,
                                        flagcleantags = flagcleantags,
                                        flagcleanaccol = flagcleanaccol,
                                        prgbar = self.progr)
            
            
        # --- Conversion vers CSV, INI, binaire ou liste d'entrées -------------
            
        elif fmt in("CSV", "INI", "LST") or fmt.startswith("Bin"):
            
            ret = app.dic.doExportToBinIniCsv(fich,
                                              fmt = fmt,
                                              flagfusion = flagfusion,
                                              flagcleantags = flagcleantags,
                                              flagcleanaccol = flagcleanaccol,
                                              br = br,
                                              sp = sp,
                                              cp = cp,
                                              prgbar = self.progr)
            
            
        # --- Conversion vers Dict ---------------------------------------------
            
        elif fmt == "DICT":
            
            ret = app.dic.doExportToDict(fich,
                                         flagfusion = flagfusion,
                                         flagcleanbr = flagcleanbr,
                                         flagcleantags = flagcleantags,
                                         flagcleanaccol = flagcleanaccol,
                                         flagtransgram = flagtransgram,
                                         subdict = subdict,
                                         sortascii = self.vSortascii.get(),
                                         prgbar = self.progr)
            
            
        # --- Conversion vers WB -----------------------------------------------
            
        elif fmt == "WB":
            
            ret = app.dic.doExportToWB(fich,
                                       flagcleantags = flagcleantags,
                                       flagcleanaccol = flagcleanaccol,
                                       wbsize = self.vWBtype.get(),
                                       cp1 = cp1,
                                       cp2 = cp2,
                                       prgbar = self.progr)
        
        
        
        # ======================================================================
        # === Gestion du message de retour de la conversion/exportation         
        # === (le retour est une chaîne vide si tout est OK)                    
        # ======================================================================
        
        app['cursor'] = ""
        self['cursor'] = ""
        self.progr.grid_remove()
        
        # --- Un problème est survenu : avertir et quitter sans fermer la fenêtre 
        
        if ret != "":       
            tkMessageBox.showwarning(parent=self,
                    title = "Linguae",
                    message = app.lg.get("winexp", "msg8") + "\n\n" + ret)
            return
        
        
        # ----------------------------------------------------------------------
        # --- Conversion Ok : avertir et quitter en fermant la fenêtre          
        # ----------------------------------------------------------------------
        
        app.updateMenuDic() # Mise à jour du menu des dicos
        
        
        # On propose d'ouvrir le dictionnaire pour tous les formats
        # sauf Preling, TEI, binaire, liste des entrées, SQLite
        
        if fmt.startswith("Bin"):
            tkMessageBox.showinfo(parent=self,
                title = u"Linguae",
                message = app.lg.get("winexp", "msg9") + "\n" + app.lg.get("winexp", "msg10"))
            self.destroy()
            return
        elif fmt == "Preling":
            tkMessageBox.showinfo(parent=self,
                title = u"Linguae",
                message = app.lg.get("winexp", "msg9") + "\n" + app.lg.get("winexp", "msg11"))
            self.destroy()
            return
        elif fmt == "TEI":
            tkMessageBox.showinfo(parent=self,
                title = u"Linguae",
                message = app.lg.get("winexp", "msg9") + "\n" + app.lg.get("winexp", "msg21"))
            self.destroy()
            return
        elif fmt == "LST":
            tkMessageBox.showinfo(parent=self,
                title = u"Linguae",
                message = app.lg.get("winexp", "msg20"))
            self.destroy()
            return
        elif fmt == "SQLite":
            tkMessageBox.showinfo(parent=self,
                title = u"Linguae",
                message = app.lg.get("winexp", "msg9") + "\n" + app.lg.get("winexp", "msg22"))
            self.destroy()
            return
        
        r = tkMessageBox.askyesno(parent=self,
                title = u"Linguae",
                message = app.lg.get("winexp", "msg9") + ".\n\n" + app.lg.get("winexp", "msg12"))
        
        if r == False:
            self.destroy()
            return
        
        
        # ----------------------------------------------------------------------
        # --- Charger le nouveau dico issu de l'exportation                     
        # ----------------------------------------------------------------------
        
        app.loadDico(fich, showSplash=True)
        
        self.destroy()
        
        return




class WindowExtract(Toplevel):
    
    u"""
    |  Fenêtre d'extraction des éléments modifiés (éléments édités et           
    |  nouvelles entrées) et enregistrement de ceux-ci dans un nouveau          
    |  fichier Ling.                                                            
    """
    
    def __init__(self):
        
        u"""
        | Mise enplace de l'interface graphique
        """
        
        Toplevel.__init__(self, padx=10, pady=10)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winext", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        self.focus_set()
        
        try   : self.iconbitmap(app.icone)           
        except: pass
        
        
        
        # ---
        
        Message(self,text=app.lg.get("winext", "s1") + " \n", width=400).grid(row=0, column=0)
        self.vIncl = StringVar()
        Radiobutton(self,text=app.lg.get("winext", "s2"), variable=self.vIncl, value="en").grid(sticky=W)
        Radiobutton(self,text=app.lg.get("winext", "s3"), variable=self.vIncl, value="n").grid(sticky=W)
        self.vIncl.set("en")
        
        # -------------------------
        # --- Frame des Boutons    
        # -------------------------
        r = 4
        fr_butOpt=Frame(self)
        fr_butOpt.grid(row=r, column=0, columnspan=4, pady=8, sticky="WENS")
        
        self.bt_sort=Button(fr_butOpt, image=app.imglst.export, compound=LEFT, text="  " + app.lg.get("winext", "s4"), width=100, padx= 10, command=self.doExtract)
        self.bt_sort.grid(row=0, column=0, pady=8, padx=10)
        self.bt_esc=Button(fr_butOpt, image=app.imglst.exit, compound=LEFT, text="  " + app.lg.get("g", "cncl"), width=100, padx= 10, command=self.destroy)
        self.bt_esc.grid(row=0, column=1, pady=8, padx=10)
        Button(fr_butOpt, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=100, padx= 10,command=lambda: app.showHelp("extract")).grid(row=0, column=2, pady=8, padx=10)
        
        # Barre de progression
        self.progr = lib.myprogbr.ProgressBar(self, width=400)
        self.progr.grid(row=r+1, column=0, columnspan=4, pady=5)
        self.progr.grid_remove()
        
        return
    
    
    def doExtract(self):
        
        u"""
        | Extraire les éléments modifiés et les enregistrer dans                
        | un nouveau fichier Ling.                                              
        """
        
        # --------------------------------------------
        # --- Sélecteur du fichier cible              
        # --------------------------------------------
        
        fich = os.path.splitext(app.dic.path)[0] + "_modifications.ling" # nom par défaut
            
        fich = tkFileDialog.asksaveasfilename(parent=self,
                    title = app.lg.get("winext", "title"),
                    filetypes = ((app.lg.get("g", "fling"),'*.ling'),),
                    initialfile = fich
                    )
            
        if not fich: return
            
        app['cursor'] = "watch"
        self['cursor'] = "watch"
        
        
        
        # --------------------------------------------------------
        # --- Construire la chaîne Preling contenant les modifs   
        # --------------------------------------------------------
        
        self.progr.grid()
        
        strPreling = app.dic.toStrPreling(extract=self.vIncl.get(), progr=self.progr)
        
        
        # ----------------------------------
        # --- Convertir en chaîne Ling      
        # ----------------------------------
        
        strLing = lib.mydic.DicObject.strPrelingToStrLing(strPreling=strPreling)
        
        app['cursor'] = ""
        self['cursor'] = ""
        
        if strLing.startswith("!"): # Echec de la conversion : la chaîne Ling est remplacée par un message
            tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("winext", "title"),
                    message = app.lg.get("winext", "msg1") + "\n\n" + strLing)
            self.destroy()
            return
        
        
        # -----------------------------------
        # --- Enregistrer le fichier ling    
        # -----------------------------------
        
        try:
            ff = open(fich,'wb')
            ff.write(strLing)
            ff.close()
        except:
            tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("winext", "title"),
                    message = app.lg.get("winext", "msg2") )
            return
        
        # Avertir du succès
        tkMessageBox.showinfo(parent=self,
                title = app.lg.get("winext", "title"),
                message = app.lg.get("winext", "msg3") )
        
        self.destroy()
        
        return
    

class WindowImage(Toplevel):
    
    u"""
    | Fenêtre de gestion des images-ressources.                                 
    |                                                                           
    | ARGUMENTS de __init__() :                                                 
    |                                                                           
    |   'wID' : wordID de l'entrée dont les images sont à visualiser            
    |                                                                           
    |   'idximg' : index d'une image dans la liste des images, image à charger  
    |              à l'ouverture.                                               
    |                                                                           
    """
    
    def __init__(self, wID="", idximg=-1):
        
        u"""
        | Mise en place de l'interface graphique
        """
        
        self.wID = wID
        
        Toplevel.__init__(self, padx=3, pady=3)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winimg", "title") + " [" + wID + "]")
        self.grab_set()      # fenêtre modale
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        
        
        # --- Maxi-étiquette d'affichage de l'illustration
        self.lab_see = Label(self, image=app.imglst.photo, width=400, height=250, borderwidth=2, relief=GROOVE, background=app.txt_notice['background'], padx=5, pady=5)
        #self.lab_see.grid(row=0, rowspan=10, column=0, padx=3, pady=3, ipadx=3, ipady=3)
        self.lab_see.pack(expand=True, fill=BOTH, side="left")
        
        # --- Frame droit
        fr_d = Frame(self)
        fr_d.pack(side="left", anchor="n")
        
        # Liste des images
        Label(fr_d,text=app.lg.get("winimg", "s1")).grid(row=0, column=1, ipadx=3, ipady=3)
        self.lst_img = lib.myscrlst.ScrolledList(fr_d, height=8, onclic=self.seeImage)
        self.lst_img.grid(row=1, column=1, padx=2, pady=2)
        
        # Bouttons
        Button(fr_d, width=92, image=app.imglst.imprt, compound=LEFT, text=" " + app.lg.get("wined", "s19"), command=self.__loadImg).grid(row=2, column=1, pady=2)
        self.bt_del = Button(fr_d, width=92, image=app.imglst.suppr, compound=LEFT,text=" " + app.lg.get("wined", "s21"), command=self.__delImg, state='disabled')
        self.bt_del.grid(row=3, column=1, pady=2)
        Label(fr_d).grid(row=4) # Séparateur
        Button(fr_d, width=92, image=app.imglst.exit, compound=LEFT, text=" " + app.lg.get("g", "close"), command=self.__doClose).grid(row=5, column=1, pady=2)
        
        
        # Charger la liste des images
        self.__updateImgLst()
        
        
        
        # Afficher éventuellement une image à l'ouverture
        if idximg > -1:
            self.lst_img.selClear()
            self.lst_img.setSel(idximg)
            self.seeImage(idximg)
        
        
        self.mainloop() # fenêtre modale bloquante
        
        return
    
    
    def __doClose(self):
        
        self.quit()     # sortie du mainloop de la fenêtre bloquante
        
        self.destroy()
    
    
    def __updateImgLst(self):
        
        u"""
        | Mettre à jour la liste des images de l'entrée.                        
        """
        
        # Vider la liste
        self.lst_img.clear()
        
        # Remplir la liste
        lf = glob.glob(os.path.join(app.dic.path + "_res", "img", self.wID + "_*.*"))
        for f in lf:
            self.lst_img.add(os.path.basename(f))
        
        # Bascule de l'état du bouton "supprimer"
        if self.lst_img.listcount() > 0:
            self.bt_del['state'] = 'normal'
        else:
            self.bt_del['state'] = 'disabled'
    
    
    def __loadImg(self):
        
        u"""
        | Importer une image pour en faire une ressource associée à une         
        | entrée de dictionnaire                                                
        """
        
        
        # ------------------------------------------------------
        # --- Choix du fichier ressource source                 
        # ------------------------------------------------------
        
        # Boîte de choix de fichier
        fichsourcepath = tkFileDialog.askopenfilename(parent=self,
                            title = app.lg.get("wined", "msg7"),
                            filetypes=(
                            (app.lg.get("g", "fgraph"), '*.gif *.jpeg *.jpg *.png *.bmp *.tiff *.tif'),
                            (app.lg.get("g", "fgif"),   '*.gif'),
                            (app.lg.get("g", "fjpeg"),  '*.jpeg *.jpg'),
                            (app.lg.get("g", "fpng"),   '*.png'),
                            (app.lg.get("g", "fbmp"),   '*.bmp'),
                            (app.lg.get("g", "ftiff"),  '*.tiff *.tif'),
                            (app.lg.get("g", "fall"),   '*.*') )
                            )
        
        if not fichsourcepath: return   # L'utilisateur a cliqué 'Annuler' dans la boîte de dialogue
        
        
        
        # -----------------------------------------------------------
        # --- Créer le répertoire de ressource s'il n'existe pas     
        # -----------------------------------------------------------
        
        repRes = os.path.join(app.dic.path + "_res", "img")
        
        if not os.path.isdir(repRes):
            try:
                os.makedirs(repRes)
            except:  # ("Impossible de créer le répertoire de ressources")
                tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("wined", "msg7"),
                    message = app.lg.get("wined", "msg6") )
                return
        
        
        # ------------------------------------------------------
        # --- Chemin du fichier ressource à enregistrer (cible) 
        # ------------------------------------------------------
        
        ext = os.path.splitext(fichsourcepath)[1].lower()
        
        imgname = self.wID + "_1" + ext
        imgpath = os.path.join(repRes, imgname) 
        
        n = 1
        while 1:
            if os.path.isfile(imgpath): # le fichier existe déjà
                n += 1
                imgname = self.wID + "_" + str(n) + ext
                imgpath = os.path.join(repRes, imgname)
            else:
                break    
        
        # ------------------------------------------------------
        # --- Enregistrer le fichier image dans le répertoire   
        #     des ressources du dictionnaire                    
        # ------------------------------------------------------
        
        shutil.copy(fichsourcepath, imgpath)
        
        # -----------------------------------------------
        # --- Compléter la liste des images de l'entrée  
        # -----------------------------------------------
        
        self.lst_img.add(imgname)
        
        self.bt_del['state'] = 'normal'
        
        # mettre en sélection la nouvelle image
        self.seeImage(self.lst_img.listcount()-1)
        
        return
    
    
    
    def __delImg(self):
        
        u"""
        | Supprimer le fichier ressource image en sélection dans la liste       
        """
        
        # Fichier en sélection
        fichname = self.lst_img.getselecteditem()
        
        # Aucune image sélectionnée > avertir et quitter
        if fichname == "":
            tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("winimg", "title"),
                    message = app.lg.get("wined", "msg10") )
            return
        
        # Confirmer la suppression
        else:
            r = tkMessageBox.askyesno(parent=self,
                    title = app.lg.get("winimg", "title"),
                    message = app.lg.get("winimg", "msg1") )
            if r == False : return
        
        
        # Construire le chemin complet du fichier à supprimer
        fichpath = os.path.join(app.dic.path + "_res", "img", fichname)
        
        # Ouvrir tous les droits sur le fichier
        try   : os.chmod(fichpath, 0777)      
        except: pass
        
        # Supprimer le fichier ressource
        try:
            os.remove(fichpath)                    
        except:
            tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("wined", "msg9"),
                    message = app.lg.get("wined", "msg11") )
            return
        
        # Mise à jour de la ScrolledList des images
        self.__updateImgLst()
        
        
        # Afficher l'image par défaut
        self.lab_see['image'] = app.imglst.photo
        
        
        return
    
    
    
    def seeImage(self, i, widget=None):
        
        u"""
        | [ appelé par le clic sur une ligne de la liste d'images ]             
        |                                                                       
        | Affichage de l'image d'index i.                        
        """
        
        # Chemin du fichier de l'image
        f =  os.path.join(app.dic.path + "_res", "img", self.lst_img.getitem(i))
        
        # Convertir en objet PhotoImage en utilisant PIL
        try:
            self.curimage = ImageTk.PhotoImage(Image.open(f))
        except:
            self.curimage = app.imglst.photo # image par défaut
        
        # Met en sélection dans la liste
        self.lst_img.setSel(i)
        
        # Affiche l'image dans le Label
        self.lab_see['image'] = self.curimage   
        
        return
        


class WindowProprLingEdit(Toplevel):
    
    u"""
    | Fenêtre d'édition des propriétés d'un dictionnaire ling.                  
    """
    
    
    def __init__(self):
        
        Toplevel.__init__(self)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+30)
        top = str(int(app.geometry().split('+')[2])+50)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winprop", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        ### A FAIRE
        
        return
    

class WindowProperties(Toplevel):
    
    u"""
    | Fenêtre d'affichage et d'édition des propriétés du dictionnaire courant.  
    |                                                                           
    | La présentation et le contenu de la fenêtre sont variables suivant le     
    | format du dictionnaire courant.                                           
    """


    def __init__(self):
        
        Toplevel.__init__(self)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winprop", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        
        
        self['padx']=5
        
        fich = app.dic.path
        
        # Chemin du fichier
        Label(self, text=app.lg.get("winprop", "s1") + " " + fich).grid(row=0, sticky=W, pady=4)
        
        # Taille du fichier
        sz = os.path.getsize(fich)
        if sz >=1024:
            sz=sz/1024
            sz=str(sz)+" Ko"
        else:
            sz=str(sz)+" oct."
        Label(self, text=app.lg.get("winprop", "s2") + " "+ sz).grid(row=1, sticky=W, pady=4)
        
        # Date de modification
        t = time.localtime(os.path.getmtime(fich))
        t= str(t[2]).zfill(2) + "/" + str(t[1]).zfill(2) + "/" + str(t[0]) + "  " + str(t[3]).zfill(2) + ":" + str(t[4]).zfill(2)
        Label(self, text=app.lg.get("winprop", "s3") + " " + t).grid(row=2, sticky=W, pady=4)
        
        # Nombre d'entrées du dictionnaire
        Label(self, text=app.lg.get("winprop", "s4") + " " + str(app.dic.wordcount)).grid(row=3, sticky=W, pady=4)
        
        
        flagAllowEdit = False
        
        r=4
        # =====================================================================================
        if app.dic.type.startswith("ling"):       # === FORMAT LING                            
        # =====================================================================================
            
            # Etiquette du format
            Label(self, text=app.lg.get("winprop", "s5") + " LING").grid(row=r, sticky=W, pady=4)
            
            # Case des propriétés
            Label(self, text=" ").grid(row=r+1, sticky=W, pady=4)
            Label(self, text=app.lg.get("winprop", "s6")).grid(row=r+2, sticky=W)
            
            self.txt_hdr = ScrolledText.ScrolledText(self, height=18)
            self.txt_hdr['font']=('Courier',10,'normal')
            self.txt_hdr.tag_config("normal", wrap=WORD, lmargin1=5, lmargin2=5, spacing1=5)
            self.txt_hdr['background']=self['background']
            
            self.txt_hdr.grid(row=r+3)
            
            # Charger les propriétés dans la case
            app.dic.file.seek(app.dic.hdroffset)
            self.txt_hdr.insert(END, app.dic.file.read(app.dic.hdrsize).replace("\0", "\n"), "normal")
            
            self.txt_hdr['state'] = 'disabled'
            
            flagAllowEdit = True
            
        
        # =====================================================================================
        elif app.dic.type.startswith("dict"):       # === FORMAT DICT                          
        # =====================================================================================
            
            # Etiquette du format
            Label(self, text=app.lg.get("winprop", "s5") + " DICT").grid(row=r, sticky=W, pady=4)
            
            # Case de l'ifo
            Label(self, text=" ").grid(row=r+1, sticky=W, pady=4)
            Label(self, text=app.lg.get("winprop", "s7")).grid(row=r+2, sticky=W)
            
            self.txt_hdr = ScrolledText.ScrolledText(self, height=12)
            self.txt_hdr['font']=('Courier',10,'normal')
            self.txt_hdr.tag_config("normal", wrap=WORD, lmargin1=5, lmargin2=5, spacing1=5)
            self.txt_hdr['background'] = self['background']
            self.txt_hdr.grid(row=r+3, pady=4, padx=4)
            
            # Charger l'ifo
            fich = fich.replace(".dict.gz", ".ifo")
            fich = fich.replace(".dict.dz", ".ifo")
            fich = fich.replace(".dict", ".ifo")
            ff = open(fich, 'r')
            self.txt_hdr.insert(END,ff.read(), "normal")
            ff.close()
            self.txt_hdr['state'] = 'disabled'
            
            flagAllowEdit = True
        
        
        # =======================================================================
        elif app.dic.type.startswith("wb"):       # === FORMAT WB                
        # =======================================================================
            
            # Etiquette du format
            Label(self, text=app.lg.get("winprop", "s5") + " WB").grid(row=r, sticky=W, pady=4)
            
            flagAllowEdit = False
        
        # =======================================================================
        elif app.dic.type.startswith("csv"):      # === FORMAT délimité          
        # =======================================================================
            
            # Etiquette du format
            Label(self, text=app.lg.get("winprop", "s5") + " " + app.lg.get("winprop", "s8")).grid(row=r, sticky=W, pady=4)
            
            flagAllowEdit = False
        
        # =======================================================================
        elif app.dic.type.startswith("ini"):      # === FORMAT ini               
        # =======================================================================
            
            # Etiquette du format
            Label(self, text=app.lg.get("winprop", "s5") + " " + app.lg.get("winprop", "s9")).grid(row=r, sticky=W, pady=4)
            
            flagAllowEdit = False
        
        
        else:
            
            pass
        
        
        # === Frame des boutons
        fr_but=Frame(self)
        fr_but.grid()
        
        if flagAllowEdit:
            # Boutton 'Valider'
            Button(fr_but, image=app.imglst.ok, compound=LEFT, text="  " + app.lg.get("winprop", "s10"), width=100, command=self.doValidClic).grid(row=0, column=0, pady=5, padx=20)
            # Boutton 'Editer'
            self.bt_edit=Button(fr_but, image=app.imglst.edit, compound=LEFT, text="  " + app.lg.get("winprop", "s11"), width=100, command=self.editClic)
            self.bt_edit.grid(row=0, column=0, pady=5, padx=20)
        
        self.bt_cancel=Button(fr_but, image=app.imglst.exit, compound=LEFT, text="  " + app.lg.get("g", "close"), width=100, command=self.destroy)
        self.bt_cancel.grid(row=0, column=1, pady=5, padx=20)
        
        Button(fr_but, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=100, padx= 10,command=lambda: app.showHelp("propr")).grid(row=0, column=2, pady=8, padx=10)
        
        return


    def editClic(self):
        u"""
        | [ appelé par le Clic sur le bouton 'Editer les propriétés' ]          
        |                                                                       
        | Editer les propriétés                                                 
        """
        
        # Avertir à propos des risques de l'édition des propriétés
        r = tkMessageBox.askyesno(parent=self,
                    title = app.lg.get("winprop", "msg1"),
                    message = app.lg.get("winprop", "msg2") )
        if r == False : return
        
        # ---
        
        self.txt_hdr['background'] = 'white' 
        self.txt_hdr['state'] = 'normal'
        self.bt_cancel['text'] = "  " + app.lg.get("g", "cncl")
        self.bt_edit.grid_remove() # Masquer le bouton > démasque le bouton 'Valider' au-dessous
        
        return
    
    
    def doValidClic(self):
        u"""
        | Valider les modifs des propriétés                                     
        |                                                                       
        | Aiguillage vers des procédures propres à chaque format                
        """
        
        self.bt_edit['state'] = "disabled"
        self.update()
        
        # ----------------------------------------------
        # --- Aiguillage suivant format                 
        # ----------------------------------------------
        
        if app.dic.type.startswith("ling"):
            
            self.__doValidLing()
        
        elif app.dic.type.startswith("dict"): 
            
            self.__doValidDict()
            
        else:
            
            pass # Pas de propriétés éditables pour les autres formats
        
        
        # -------------------------------------------------------
        # --- Recharger le dictionnaire avec le nouveau fichier  
        # -------------------------------------------------------
        
        memi = app.dic.curIdx
        app.dic.file.close()
        
        ret = app.loadDico(app.dic.path, showSplash=False)
        
        
        # ------------------------------------------------------
        # --- Un problème est survenu > restaurer le fichier    
        # ------------------------------------------------------
        
        if ret > 0:
            
            fichpath = app.dic.path
            shutil.copy(fichpath + ".back", fichpath)
            
            return
        
        
        
        # ---------------------------------------------------
        # --- Réafficher le mot antérieurement sélectionné   
        # ---------------------------------------------------
        
        app.dic.lstbox.activate(memi)
        app.dic.lstbox.selection_set(memi)
        app.dic.lstbox.see(memi)
        app.selDisplayData(None)    
        
        # --- Fermer la fenêtre des propriétés
        
        self.destroy()
        
        return
    
    
    def __doValidDict(self):
        
        u"""
        | [ appelé par 'doValidClic()' ]                                        
        |                                                                       
        | Valider les modifications des propriétés d'un dictionnaire Dict       
        """
        
        # Chemin de l'ifo
        fichpath = app.dic.path
        fichifo = fichpath.replace(".dict.gz", ".ifo")
        fichifo = fichpath.replace(".dict.dz", ".ifo")
        fichifo = fichifo.replace(".dict", ".ifo")
        
        # Enregistrer la copie de sauvegarde du fichier ifo
        # au cas ou l'édition des propriétés soit invalide
        shutil.copy(fichifo, fichifo + ".back")
        
        # Chaîne de l'ifo
        strfile = self.txt_hdr.get("0.0", END)
        strfile = strfile.encode('utf-8')
        if not strfile.endswith("\n"):
            strfile += "\n"
        
        # Enregistrer l'ifo
        ff = open(fichifo, 'wb')
        ff.write(strfile)
        ff.close()
        
        
        return
    
    
    def __doValidLing(self):
        
        u"""
        | [ appelé par 'doValidClic()' ]                                        
        |                                                                       
        | Valider les modifications des propriétés d'un dictionnaire Ling       
        """
        
        
        # Enregistrer la copie de sauvegarde du fichier dictionnaire
        # au cas ou l'édition des propriétés soit invalide
        fichpath = app.dic.path
        shutil.copy(fichpath, fichpath + ".back")
        
        
        # ----------------------------------------
        # --- Construire le nouveau bloc header   
        # ----------------------------------------
        
        strHdr = self.txt_hdr.get("0.0", END).strip()
        lignes = strHdr.splitlines()
        strHdr = []
        
        for ligne in lignes:
            ligne = ligne.strip()
            
            # sauter les propriétés sans valeur explicite
            if ligne.endswith("="): 
                continue
            
            # sauter les lignes vides
            elif ligne == "":       
                continue
            
            # sauter les lignes sans "="
            elif ligne.find("=") <0:
                continue
            
            # facilite les nettoyages qui suivent
            ligne = ligne.replace("= ", "=")
            ligne = ligne.replace(" =", "=")
        
            # =true > =True 
            ligne = ligne.replace("=true", "=True")
            ligne = ligne.replace("=vrai", "=True")
            ligne = ligne.replace("=Vrai", "=True")
            
            # =false > =False
            ligne = ligne.replace("=false", "=False")
            ligne = ligne.replace("=faux", "=False")
            ligne = ligne.replace("=Faux", "=False")
            
            # Gestion des guillemets (guillemets internes ou restés ouverts)
             
            if ligne.find('="') > 1 :   # Propriété entre guillemets doubles
                
                # (ne pas modifier les propriétés en liste)
                if (ligne.find('","') < 0) and (ligne.find('", "') < 0):
                    
                    # Encodage des guillemets internes :
                    # On supprime le guillemet de queue
                    ligne = ligne.rstrip('"')
                    # On remplace tous les guillemets par l'entité
                    ligne = ligne.replace('"', "&quot;")
                    # On rétablit les guillemets d'entourage
                    ligne = ligne.replace("=&quot;", '="', 1)
                    ligne = ligne + '"'
                    
                # Correction pour les propriétés vides
                if ligne.endswith('="') or not ligne.endswith('"'):
                    ligne = ligne + '"'                   
                
            elif ligne.find("='") > 1 and not ligne.endswith("'"):
                ligne = ligne + "'"
            
            
            ligne = ligne.encode('utf-8')
            strHdr.append(ligne)
        
        strHdr = "\0".join(strHdr)
        
        
        
        # ------------------------------------------
        # --- Reconstruire le bloc de cartographie  
        # ------------------------------------------
        
        strMap = []
        
        strMap.append("%ling/01.01.00")
        strMap.append(numToStr32(70))               # offset du bloc en-tête
        strMap.append(numToStr32(len(strHdr)))      # taille du bloc en-tête
        
        dlt = len(strHdr) - app.dic.hdrsize         # delta des offsets suivant
        
        strMap.append(numToStr32(app.dic.wordlistoffset + dlt)) # offset du bloc des entrées
        strMap.append(numToStr32(app.dic.wordlistsize))         # taille du bloc des entrées
        strMap.append(numToStr32(app.dic.idlistoffset + dlt))   # etc...
        strMap.append(numToStr32(app.dic.idlistsize))
        strMap.append(numToStr32(app.dic.datamapoffset + dlt))
        strMap.append(numToStr32(app.dic.datamapsize))
        strMap.append(numToStr32(app.dic.dataoffset + dlt))
        strMap.append(numToStr32(app.dic.datasize))
        if app.dic.img1offset != 0:
            strMap.append(numToStr32(app.dic.img1offset + dlt))
            strMap.append(numToStr32(app.dic.img1size))
        else:
            strMap.append(numToStr32(0))
            strMap.append(numToStr32(0))
        if app.dic.img2offset != 0:
            strMap.append(numToStr32(app.dic.img2offset + dlt))
            strMap.append(numToStr32(app.dic.img2size))
        else:
            strMap.append(numToStr32(0))
            strMap.append(numToStr32(0))
        
        strMap = "".join(strMap)
        
        
        # -------------------------------------------------
        # --- Reconstruire le fichier ling bloc par bloc   
        # -------------------------------------------------
        
        strfich = []
        
        strfich.append(strMap)
        strfich.append(strHdr)
        
        app.dic.file.seek(app.dic.wordlistoffset)
        bloc = app.dic.file.read(app.dic.wordlistsize)
        strfich.append(bloc)
        
        app.dic.file.seek(app.dic.idlistoffset)
        bloc = app.dic.file.read(app.dic.idlistsize)
        strfich.append(bloc)
        
        app.dic.file.seek(app.dic.datamapoffset)
        bloc = app.dic.file.read(app.dic.datamapsize)
        strfich.append(bloc)
        
        app.dic.file.seek(app.dic.dataoffset)
        bloc = app.dic.file.read(app.dic.datasize)
        strfich.append(bloc)
        
        app.dic.file.seek(app.dic.img1offset)
        bloc = app.dic.file.read(app.dic.img1size)
        strfich.append(bloc)
        
        app.dic.file.seek(app.dic.img2offset)
        bloc = app.dic.file.read(app.dic.img2size)
        strfich.append(bloc)
        
        strfich = "".join(strfich)
        
        
        # ------------------------------------------
        # --- Enregistrer le nouveau fichier Ling   
        # ------------------------------------------
        
        app.dic.file.close()
        ff = open(app.dic.path, 'wb')
        ff.write(strfich)
        ff.close()
        
        
        return
    


class WindowEncodeOpen(Toplevel):
    
    u"""
    | Boîte de dialogue de choix des encodages de caractères, à l'ouverture     
    | d'un dictionnaire.                                                        
    |                                                                           
    | Puis :                                                                    
    |   - Lance l'ouverture du dictionnaire                                     
    |   - Demande si les encodages doivent être mémorisés                       
    |                                                                           
    | ARGUMENTS de __init__() :                                                 
    |                                                                           
    |   'cp1' & 'cp2' : (facultatifs) encodages de la langue 1 et de langue 2.  
    |                   Ces encodages servent à préremplir la fenêtre.          
    """
    
    
    def __init__(self, cp1="", cp2=""):
        
        u"""
        | Mise en place de l'interface de la fenêtre                            
        """
        
        Toplevel.__init__(self)
        
        self.title(app.lg.get("winenc", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
        
        
        # Données de sortie de la fenêtre
        
        self.cp1 = ""           # encodage langue 1
        self.cp2 = ""           # encodage langue 2
        self.annuler = False    # flag d'annulation du chargment du dico
        
        
        # --- Sélecteurs des encodages
        
        if cp1 == "": cp1 = "cp1252"
        if cp2 == "": cp2 = "cp1252"
        
        self.txt_cp1=lib.myencsel.EncodingSelector(self, text=cp1, title=app.lg.get("winenc", "s1") + " 1 :")
        self.txt_cp1.grid(row=0, column=0, padx=5)
        
        self.txt_cp2=lib.myencsel.EncodingSelector(self, text=cp2, title=app.lg.get("winenc", "s1") + " 2 :")
        self.txt_cp2.grid(row=0, column=1, padx=5)
        
        
        # -------------------------
        # --- Frame des Boutons    
        # -------------------------
        fr_but=Frame(self)
        fr_but.grid(row=1, column=0, columnspan=4, pady=8, sticky="WENS")
        
        bt_Do=Button(fr_but, image=app.imglst.open, compound=LEFT, text=" " + app.lg.get("g", "opn"), width=70, padx= 10, command=self.doOpen)
        bt_Do.grid(row=0, column=0, pady=8, padx=10)
        Button(fr_but, image=app.imglst.exit, compound=LEFT, text=" " + app.lg.get("g", "cncl"), width=70, command=self.doCancel, padx= 10).grid(row=0, column=1, pady=8, padx=10)
        Button(fr_but, image=app.imglst.hlp, compound=LEFT, text=" " + app.lg.get("g", "hlp"), width=70, padx= 10,command=lambda: app.showHelp("opendic")).grid(row=0, column=2, pady=8, padx=10)
        
        self.mainloop() # fenêtre bloquante
        
        return
    
    
    def doOpen(self):
        
        u"""
        | Fermer la boîte de dialogue,                                          
        | pour pouvoir ouvrir le fichier dictionnaire avec les encodages        
        | sélectionnés.                                                         
        """
        
        self.cp1 = self.txt_cp1.get()
        self.cp2 = self.txt_cp2.get()
        
        self.quit()     # sortie du mainloop de la fenêtre bloquante
        
        # Nb : la fenêtre sera détruite par la procédure appelante
        # après récupération de ses données
        
        return


    def doCancel(self):
        
        u"""
        | Fermer la boîte de dialogue sans ouvrir le dictionnaire               
        """
        
        self.annuler = True
        
        self.quit()     # sortie du mainloop de la fenêtre bloquante
        
        # Nb : la fenêtre sera détruite par la procédure appelante
        # après récupération de ses données
        
        return


class WindowImportVarious(Toplevel):
    
    u"""
    | Fenêtre d'importation de dicos en formats non gérés nativement.           
    | Le dictionnaire importé est converti en dico Ling puis chargé.
    """
    
    def __init__(self, fichpath=""):
        
        u"""
        | Mise en place de l'interface graphique de la fenêtre                  
        """
        
        Toplevel.__init__(self, padx=10)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+10)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winimpx", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        # --- Etiquette d'info
        Label(self, text=app.lg.get("winimpx", "s1"), justify="left").grid(row=0, column=0, columnspan=4, padx=5, pady=10)
        
        
        # ---------------------------------------
        # --- Frame du chemin du fichier-source  
        # ---------------------------------------
        
        fr_path=LabelFrame(self, text=app.lg.get("winimp", "s2"), padx=10, pady=10 )
        fr_path.grid(row=2, column=0, columnspan=4, pady=10, sticky="WENS")
        
        r = 0
        
        # Chemin du fichier à importer
        self.txt_path=Entry(fr_path,width=60, background="white")
        self.txt_path.grid(row=r+2, column=0)
        self.bt_browse=Button(fr_path, text=" " + app.lg.get("g", "brw"), command=self.__selFile)
        self.bt_browse.grid(row=r+2, column=1, sticky="W")
        
        
        # ----------------------------------------------
        # --- Frame du chemin du fichier-cible          
        # ----------------------------------------------
        
        fr_cible=LabelFrame(self, text=app.lg.get("winimp", "s5"), pady=10)
        fr_cible.grid(row=4, column=0, columnspan=4, pady=8, sticky="WENS")
        
        # Nom de la cible
        Label(fr_cible, text=app.lg.get("winimp", "s6") + " ").grid(row=2, column=0)
        self.txt_namecible=Entry(fr_cible, width=25, background="white")
        self.txt_namecible.grid(row=2, column=1)
        
        
        # Options de la cible
        self.vOptCibleLing = StringVar()
        self.opt_repnatif=Radiobutton(fr_cible, text=app.lg.get("winimp", "s7"), variable=self.vOptCibleLing, value="repsrc")
        self.opt_repnatif.grid(row=3, column=0, columnspan=4, padx=5, sticky=W)
        self.optRepdic=Radiobutton(fr_cible, text=app.lg.get("winimp", "s8"), variable=self.vOptCibleLing, value="repdic")
        self.optRepdic.grid(row=4, column=0, columnspan=4, padx=5, sticky=W)
        self.vOptCibleLing.set("repsrc")
        
        # Désactiver l'option si le répertoire de stockage des dicos n'est pas encore défini
        repdic = app.ini.get('DicStorageFolder','')
        
        if repdic == "" or not os.path.isdir(repdic):
            self.optRepdic['state'] = 'disabled'
            self.optRepdic['text'] = self.optRepdic['text'] + " " + app.lg.get("winimp", "s9")
        else:
            self.vOptCibleLing.set("repdic")
        
        
        
        # -----------------------------------
        # --- Frame inférieur des Boutons    
        # -----------------------------------
        r = 5
        fr_butImp=Frame(self)
        fr_butImp.grid(row=r, column=0, columnspan=4, pady=8, sticky="WENS")
        
        bt_Do=Button(fr_butImp, image=app.imglst.imprt, compound=LEFT, text="  " + app.lg.get("winimp", "s10"), width=100, padx= 10, command=self.__doImport)
        bt_Do.grid(row=0, column=0, pady=8, padx=10)
        Button(fr_butImp, image=app.imglst.exit, compound=LEFT, text="  " + app.lg.get("g", "close"), width=100, command=self.destroy, padx= 10).grid(row=0, column=1, pady=8, padx=10)
        Button(fr_butImp, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=100, padx= 10,command=lambda: app.showHelp("importx")).grid(row=0, column=2, pady=8, padx=10)
        
        # Barre de progression
        self.progr = lib.myprogbr.ProgressBar(self, width=380)
        self.progr.grid(row=r+1, column=0, columnspan=4, pady=5)
        self.progr.grid_remove()
        
        return
    
    
    def __selFile(self):
        
        u"""
        | Clic sur le bouton de sélection du fichier à importer         
        """
        
        # Utiliser le chemin de recherche par défaut des dicos
        dirSearch = app.ini.get("DicSearchPath",os.path.expanduser('~'))
        
        fichpath = tkFileDialog.askopenfilename(parent=self,
                            title = app.lg.get("winimpx", "title"),
                            filetypes=(
                            (app.lg.get("g", "fdictd"),'*.index'),
                            (app.lg.get("g", "fall"),'*.*')),
                            initialdir=dirSearch
                            )
        
        if not fichpath: return   # L'utilisateur a cliqué 'Annuler' dans la boîte de dialogue
        
        self.txt_path.delete(0,END)
        self.txt_path.insert(END, fichpath)
        
        
        # --------------------------------------
        # --- Nom du fichier cible Ling         
        # --------------------------------------
        
        nameling = "import.ling" # par défaut
        
        if os.path.isfile(fichpath):
            nameling = os.path.splitext(os.path.basename(fichpath))[0] + ".ling"
        
        self.txt_namecible.delete(0,END)
        self.txt_namecible.insert(END, nameling)
        
        
        
        return


    def __doImport(self):
        
        u"""
        | [ appelé par le clic sur le bouton 'Importer' ]                       
        |                                                                       
        | Importe un fichier en format non géré en appelant la méthode statique
        | d'importation de l'objet Dictionnaire.                                 
        """
        
        # Nom du fichier source
        fichscrpath = self.txt_path.get()
            
        if fichscrpath.strip() == "":
            tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("winimpx", "title"),
                    message = app.lg.get("winimp", "msg1"))
            return
        
        
        # --------------------------------------------------------
        # --- Construire et vérifier le chemin du fichier cible   
        # --------------------------------------------------------
        
        if self.txt_namecible.get().strip() == "":
            self.txt_namecible.insert(END, "import.ling")
            
        
        # Chemin : enregistrer dans le répertoire de stockage des dictionnaires
        if self.vOptCibleLing.get() == "repdic":
            fichciblepath = os.path.join(app.ini.get('DicStorageFolder',''), self.txt_namecible.get())
        
        # Chemin : enregistrer dans le même répertoire que le fichier source
        else:
            fichciblepath = os.path.join(os.path.dirname(fichscrpath), self.txt_namecible.get())
        
        # Forcer l'extension ling
        if not fichciblepath.endswith(".ling"):
            fichciblepath += ".ling" 
        
        # Vérifier si le fichier existe déjà et si oui avertir
        if os.path.isfile(fichciblepath):
            r = tkMessageBox.askyesno(parent=self,
                    title = app.lg.get("winimpx", "title"),
                    message = u"'" + fichciblepath + "'\n\n" + app.lg.get("winimp", "msg2") )
            if r: # Un fichier préexistant va être remplacé
                os.chmod(fichciblepath, 0777)
            else:
                return
            
        
        # ---------------------------------------------
        # --- Convertir le fichier et l'enregistrer    
        # ---------------------------------------------
        
        self['cursor'] = "watch"
        app['cursor'] = "watch"
        self.update()
        app.update()
        
        ret = lib.mydic.DicObject.importDictd(fichscrpath, fichciblepath)
        
        if ret != "": # echec
            tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("winimpx", "title"),
                    message = app.lg.get("winimp", "msg5") + "\n\n" + ret)
            self['cursor'] = ""
            app['cursor'] = ""
            self.destroy()
            return
        
        
        # ----------------------------------------------------------------------
        # --- Message "conversion ok" et demander si ouverture du nouveau dico  
        # ----------------------------------------------------------------------
        
        r = tkMessageBox.askyesno(parent=self,
                title = app.lg.get("winimpx", "title"),
                message = app.lg.get("winimp", "msg7") )
        
        if r == False:
            self['cursor'] = ""
            app['cursor'] = ""
            self.destroy()
            return
        
        # --- Charger le nouveau dico
        
        app.loadDico(fichciblepath, showSplash=True)
        
        self.destroy()
        
        return




class WindowImportPreling(Toplevel):
    
    u"""
    | Fenêtre d'importation d'un prédictionnaire : fichier au format dit        
    | "Preling" (ou CSV à deux champs) et conversion en fichier "Ling".         
    |                                                                           
    | ARGUMENTS de __init__() :                                                 
    |                                                                           
    |   'fichpath' : (facultatif) chemin d'un fichier Preling à importer        
    """


    def __init__(self, fichpath=""):
        
        u"""
        | Mise en place de l'interface graphique de la fenêtre                  
        """
        
        Toplevel.__init__(self, padx=10)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+10)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winimp", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
       
        
        # --- Etiquette d'info
        Label(self, text=app.lg.get("winimp", "s1")).grid(row=0, column=0, columnspan=4, padx=5, pady=10)
        
        
        # ---------------------------------------------------
        # --- Frame du chemin du fichier-source + encodage   
        # ---------------------------------------------------
        
        fr_path=LabelFrame(self, text=app.lg.get("winimp", "s2"), padx=10, pady=10 )
        fr_path.grid(row=2, column=0, columnspan=4, pady=10, sticky="WENS")
        
        r = 0
        # Case à cocher "Utiliser le contenu du presse-papier"
        self.vOptClip = StringVar()
        opt_clip=Radiobutton(fr_path, text=app.lg.get("winimp", "s11"), variable=self.vOptClip, value="clip", command=self.__onclicOptClip)
        opt_clip.grid(row=r, column=0, sticky="W")
        
        # Chemin du fichier CSV/Preling
        Radiobutton(fr_path, text=app.lg.get("winimp", "s3"), variable=self.vOptClip, value="file", command=self.__onclicOptClip).grid(row=r+1, column=0, sticky="W")
        self.txt_path=Entry(fr_path,width=60, background="white")
        self.txt_path.grid(row=r+2, column=0)
        self.bt_browse=Button(fr_path, text=" " + app.lg.get("g", "brw"), command=self.selFile)
        self.bt_browse.grid(row=r+2, column=1, sticky="W")
        self.vOptClip.set("file")
        
        # sous-frame :
        fr_data=Frame(fr_path)
        fr_data.grid(row=r+4, column=0, columnspan=10)
        
        # Encodage du fichier CSV/Preling
        self.txt_cp=lib.myencsel.EncodingSelector(fr_data, title=app.lg.get("winimp", "s12"))
        self.txt_cp.grid(row=r+3, column=0)
        Label(fr_data, text=app.lg.get("winimp", "s4"), justify="left").grid(row=r+4, column=0, columnspan=10) # info sur la prise en compte de l'encodage
        
        # Séparateur des données du CSV/Preling
        Label(fr_data, text=app.lg.get("winimp", "s13") + " ").grid(row=r+3, column=1)
        self.txt_sep=Entry(fr_data,width=5, background="white")
        self.txt_sep.grid(row=r+3, column=2)
        
        
        # ----------------------------------------------
        # --- Frame du chemin du fichier-cible          
        # ----------------------------------------------
        
        fr_cible=LabelFrame(self, text=app.lg.get("winimp", "s5"), pady=10)
        fr_cible.grid(row=4, column=0, columnspan=4, pady=8, sticky="WENS")
        
        # Nom de la cible
        Label(fr_cible, text=app.lg.get("winimp", "s6") + " ").grid(row=2, column=0)
        self.txt_namecible=Entry(fr_cible, width=25, background="white")
        self.txt_namecible.grid(row=2, column=1)
        
        
        # Options de la cible
        self.vOptCibleLing = StringVar()
        self.opt_repnatif=Radiobutton(fr_cible, text=app.lg.get("winimp", "s7"), variable=self.vOptCibleLing, value="repsrc")
        self.opt_repnatif.grid(row=3, column=0, columnspan=4, padx=5, sticky=W)
        self.optRepdic=Radiobutton(fr_cible, text=app.lg.get("winimp", "s8"), variable=self.vOptCibleLing, value="repdic")
        self.optRepdic.grid(row=4, column=0, columnspan=4, padx=5, sticky=W)
        self.vOptCibleLing.set("repsrc")
        
        # Désactiver l'option si le répertoire de stockage des dicos n'est pas encore défini
        repdic = app.ini.get('DicStorageFolder','')
        
        if repdic == "" or not os.path.isdir(repdic):
            self.optRepdic['state'] = 'disabled'
            self.optRepdic['text'] = self.optRepdic['text'] + " " + app.lg.get("winimp", "s9")
            opt_clip['state'] = 'disabled'
        else:
            self.vOptCibleLing.set("repdic")
        
        
        # -----------------------------------
        # --- Frame inférieur des Boutons    
        # -----------------------------------
        r = 5
        fr_butImp=Frame(self)
        fr_butImp.grid(row=r, column=0, columnspan=4, pady=8, sticky="WENS")
        
        bt_Do=Button(fr_butImp, image=app.imglst.imprt, compound=LEFT, text="  " + app.lg.get("winimp", "s10"), width=100, padx= 10, command=self.__doImport)
        bt_Do.grid(row=0, column=0, pady=8, padx=10)
        Button(fr_butImp, image=app.imglst.exit, compound=LEFT, text="  " + app.lg.get("g", "close"), width=100, command=self.destroy, padx= 10).grid(row=0, column=1, pady=8, padx=10)
        Button(fr_butImp, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=100, padx= 10,command=lambda: app.showHelp("import")).grid(row=0, column=2, pady=8, padx=10)
        
        # Barre de progression
        self.progr = lib.myprogbr.ProgressBar(self, width=380)
        self.progr.grid(row=r+1, column=0, columnspan=4, pady=5)
        self.progr.grid_remove()
        
        
        # --- Préremplissages si un chemin source est fourni (par la ligne de commande par ex.)
        #     sinon avec des valeurs par défaut
        
        self.__prefill(fichpath)
        
        return


    def __prefill(self, fichpath=""):
        
        u"""
        | Préremplissage de la fenêtre avec les données du                      
        | fichier source 'fichpath'.                                            
        |                                                                       
        | ARGUMENTS :                                                           
        |   'fichpath' : (facultatif) chemin du fichier Preling à importer.     
        |                 Si fichpath = "", des valeurs par défaut sont         
        |                 utilisées.                                            
        """
        
        # ------------------------------------------
        # --- Chemin du fichier preling à importer  
        # ------------------------------------------
        
        if fichpath != "":
            self.txt_path.delete(0,END)
            self.txt_path.insert(END, fichpath)
        
        
        # ----------------------------------------------------
        # --- Encodage et séparateur du fichier preling       
        # ----------------------------------------------------
        
        
        enc = "cp1252"      # encodage par défaut
        sep = "{tab}"       # séparateur par défaut
        
        if os.path.isfile(fichpath):
        
            # lire la première ligne du fichier preling
            f = open(fichpath, "r")
            ligne = f.readline().split("/")
            f.close()
            
            # encodage
            try:
                t = ligne[1].lower().strip(' \r\n"')
                if len(t) >0 : enc = t
            except:
                pass
            # séparateur
            try:
                t = ligne[2].lower().strip(' \r\n"')
                if len(t) >0 : sep = t
            except:
                pass
        
        self.txt_cp.setText(enc)
        self.txt_sep.delete(0,END)
        self.txt_sep.insert(END,sep)
        
        
        # --------------------------------------
        # --- Nom du fichier cible Ling         
        # --------------------------------------
        
        nameling = "import.ling" # par défaut
        
        if os.path.isfile(fichpath):
            nameling = os.path.splitext(os.path.basename(fichpath))[0] + ".ling"
        
        self.txt_namecible.delete(0,END)
        self.txt_namecible.insert(END, nameling)
        
        return
    
    
    def __onclicOptClip(self):
        
        u"""
        | Clic sur les boutons radio de choix entre importer à partir du        
        | presse-papiers ou du fichier.                                         
        """
        
        if self.vOptClip.get() == "clip":
            self.txt_path["state"] = "disabled"
            self.bt_browse["state"] = "disabled"
            self.opt_repnatif["state"] = "disabled"
        else:
            self.txt_path["state"] = "normal"
            self.bt_browse["state"] = "normal"
            self.opt_repnatif["state"] = "normal"
            
        
        
        return
    

    def selFile(self):
        
        u"""
        | Clic sur le bouton de sélection du fichier Preling à importer         
        """
        
        # Utiliser le chemin de recherche par défaut des dicos
        dirSearch = app.ini.get("DicSearchPath",os.path.expanduser('~'))
        
        fich = tkFileDialog.askopenfilename(parent=self,
                            title = app.lg.get("winimp", "title"),
                            filetypes=(
                            (app.lg.get("g", "flim"),'*.csv *.tab *.txt *.preling'),
                            (app.lg.get("g", "fall"),'*.*')),
                            initialdir=dirSearch
                            )
        
        if not fich: return   # L'utilisateur a cliqué 'Annuler' dans la boîte de dialogue
        
        self.__prefill(fich)
        
        return



    def __doImport(self):
        
        u"""
        | [ appelé par le clic sur le bouton 'Importer' ]                       
        |                                                                       
        | Importe un fichier texte Preling externe (dont la rédaction est       
        | manuelle généralement) en appelant la méthode statique de conversion  
        | Preling>Ling de l'objet Dictionnaire.                                 
        """
        
        # Nom du fichier source Preling
        fichscrpath = ""
        if self.vOptClip.get() != "clip":
            
            fichscrpath = self.txt_path.get()
            
            if fichscrpath.strip() == "":
                tkMessageBox.showwarning(parent=self,
                        title = app.lg.get("winimp", "title"),
                        message = app.lg.get("winimp", "msg1"))
                return
        
        
        # --------------------------------------------------------
        # --- Construire et vérifier le chemin du fichier cible   
        # --------------------------------------------------------
        
        
        # Chemin : enregistrer dans le répertoire de stockage des dictionnaires
        if self.vOptCibleLing.get() == "repdic":
            fichciblepath = os.path.join(app.ini.get('DicStorageFolder',''), self.txt_namecible.get())
        
        # Chemin : enregistrer dans le même répertoire que le fichier source
        else:
            fichciblepath = os.path.join(os.path.dirname(fichscrpath), self.txt_namecible.get())
        
        # Forcer l'extension ling
        if not fichciblepath.endswith(".ling"):
            fichciblepath += ".ling" 
        
        # Vérifier si le fichier existe déjà et si oui avertir
        if os.path.isfile(fichciblepath):
            r = tkMessageBox.askyesno(parent=self,
                    title = app.lg.get("winimp", "title"),
                    message = u"'" + fichciblepath + "'\n\n" + app.lg.get("winimp", "msg2") )
            if r: # Un fichier préexistant va être remplacé
                os.chmod(fichciblepath, 0777)
            else:
                return
            
        
        # -------------------------------------------------
        # --- Ouvrir le fichier source Preling             
        # --- et le recopier dans une chaîne               
        # -------------------------------------------------
        
        # Encodage du document source Preling, tel que saisi par l'utilisateur
        # ou lu dans le fichier lors de son choix par 'Parcourir' ou par la ligne de commande
        cp = self.txt_cp.get()
        
        # --- La source est le presse-papiers
        if self.vOptClip.get() == "clip":   
            
            strPreling = self.clipboard_get()
            
            if strPreling == "":
                tkMessageBox.showwarning(parent=self,
                        title = app.lg.get("winimp", "title"),
                        message = app.lg.get("winimp", "msg4") ) # document source introuvable
                return
            
            
        # --- La source est un fichier    
        else:               
            
            ff = ""
            try:
                ff = open(fichscrpath,'rb')
            except:
                if fichscrpath =="":    # fichier source non précisé
                    msg = app.lg.get("winimp", "msg3")
                else:                   # document source introuvable
                    msg = app.lg.get("winimp", "msg4")
                        
                tkMessageBox.showwarning(parent=self,
                        title = app.lg.get("winimp", "title"),
                        message = msg)
                return
            
            strPreling = ff.read()
            ff.close()
        
        # -------------------------------------------------
        # --- Résoudre les "include"                       
        # -------------------------------------------------
        
        self['cursor'] = "watch"
        app['cursor'] = "watch"
        self.update()
        app.update()
        
        # Sauter ce processus si inutile
        if strPreling.find("_include") != -1:
            
            lignes = strPreling.splitlines()
            
            # En fonction de la plateforme
            pf = sys.platform.lower()
            if pf[:3] == 'win':                             # Windows
                pf = "win"
            elif pf[:6] == 'darwin' or pf[:5] == 'linux':   # Unix (MacosX, Linux, )
                pf = "unix"
                
            
            # On scanne les lignes en remplacant les include au fur et à mesure
            newlignes = []
            for ligne in lignes:
                
                if ligne.startswith("_include"):
                    
                    # Lire le nom de fichier à inclure
                    f = ligne[8:].strip()
                    
                    # Ajouter le chemin si besoin
                    if pf == "win" and f[1] != ":" :    # chemin relatif Windows
                        f = os.path.join(os.path.dirname(fichscrpath), f)
                    elif pf == "unix" and f[0] != "/":  # chemin relatif Unix
                        f = os.path.join(os.path.dirname(fichscrpath), f)
                    
                    # remplacer la ligne include par le contenu du fichier
                    try:
                        newlignes.append(open(f,'rb').read())
                    except:
                        tkMessageBox.showwarning(parent=self,
                            title = app.lg.get("winimp", "title"),
                            message = u"'" + f + u"'\n\n" + app.lg.get("dic", "msg4"))# ("Fichier introuvable") 
                    
                else:
                    
                    newlignes.append(ligne)
                
            # On reconstitue la chaîne à la fin du scannage
            strPreling = "\n".join(newlignes)
        
        
        # -------------------------------------------------
        # --- Nettoyage et correction d'erreurs manuelles  
        # -------------------------------------------------
        
        # facilite les nettoyages qui suivent
        while strPreling.find("= ") > -1:
            strPreling = strPreling.replace("= ", "=")
            
        while strPreling.find(" =") > -1:
            strPreling = strPreling.replace(" =", "=")
        
        # =true > =True 
        strPreling = strPreling.replace("=true", "=True")
        strPreling = strPreling.replace("=vrai", "=True")
        strPreling = strPreling.replace("=Vrai", "=True")
        
        # =false > =False
        strPreling = strPreling.replace("=false", "=False")
        strPreling = strPreling.replace("=faux", "=False")
        strPreling = strPreling.replace("=Faux", "=False")
        
        
        # --------------------------------------------------
        # --- Convertir la chaîne Preling en chaîne Ling    
        # --------------------------------------------------
        
        sep = self.txt_sep.get()    # Séparateur interne des lignes de données
        if sep in("{tab}", ""):
            sep = "\t"              # tabulation par défaut
        
        # appel de la fonction de conversion de l'objet dictionnaire
        strLing = lib.mydic.DicObject.strPrelingToStrLing(strPreling=strPreling, cp=cp, sep=sep)
        
        
        if strLing.startswith("!"): # Echec de la conversion : la chaîne Ling est remplacée par un message
            tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("winimp", "title"),
                    message = app.lg.get("winimp", "msg5") + "\n\n" + strLing)
            
            self['cursor'] = ""
            app['cursor'] = ""
            self.destroy()
            return
        
        # -----------------------------------------
        # --- Enregistrer le nouveau fichier Ling  
        # -----------------------------------------
        
        try:
            ff = open(fichciblepath,'wb')
            ff.write(strLing)
            ff.close()
        except:
            tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("winimp", "title"),
                    message = app.lg.get("winimp", "msg6") )
            self['cursor'] = ""
            app['cursor'] = ""
            return
        
        
        
        # ----------------------------------------------------------------------
        # --- Message "conversion ok" et demander si ouverture du nouveau dico  
        # ----------------------------------------------------------------------
        
        r = tkMessageBox.askyesno(parent=self,
                title = app.lg.get("winimp", "title"),
                message = app.lg.get("winimp", "msg7") )
        
        if r == False:
            self['cursor'] = ""
            app['cursor'] = ""
            self.destroy()
            return
        
        # --- Charger le nouveau dico
        
        app.loadDico(fichciblepath, showSplash=True)
        
        self.destroy()
        
        return



class WindowSort(Toplevel):
    
    u"""
    | Fenêtre de tri du dictionnaire courant                                    
    |                                                                           
    | La fenêtre permet le paramétrage du tri                                   
    | Les paramètres de tri sont optionellement enregistrés dans le dico (format
    | Ling) ou dans le dossier des ressources du dico (autres formats).          
    """
    
    def __init__(self):
        
        u"""
        | Mise en place de l'interface graphique                                
        """
        
        # --- Contrôles préalables
        
        # Un Dict compressé est non triable > avertir et quitter
        if app.dic.type in ("dictdz", "dictgz"):
            app.hideProgr()
            tkMessageBox.showinfo(parent=self,
                    title = app.lg.get("winsort", "title"),
                    message = app.lg.get("dic", "msg34"))
            return
        
        # --- Fermer une éventuelle fenêtre d'édition en cours
        #     (car le tri va modifier les index)
        
        try:
            app.f_edit.destroy()
        except:
            pass
        
        
        # ---
        
        Toplevel.__init__(self, pady=5, padx=5)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+80)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winsort", "title") )
        self.resizable(width=NO, height=NO)
        #self.grab_set()            # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        r = 0
        # --- Zone texte des équivalences de tri             
        self.txt_equ = ScrolledText.ScrolledText(self, width=9, height=20, padx=4, background="white")
        self.txt_equ.grid(row=r, rowspan=5, column=0, sticky="W")
        self.txt_equ['font'] = app.lst_dico['font']
        
        
        # --- Etiquettes du mode d'emploi
        Label(self, text=app.lg.get("winsort", "s1"), justify=LEFT).grid(row=0, column=1, padx=3)
        r += 1
        Label(self, text=app.lg.get("winsort", "s2"), justify=LEFT).grid(row=r, column=1, padx=3, sticky="W")
        
        # Case à cocher 'Sauvegarder les paramètres de tri'
        r += 1
        self.vSaveEqu = IntVar()
        Checkbutton(self, text=app.lg.get("winsort", "s3"), variable=self.vSaveEqu).grid(row=r, column=1, pady=5, sticky="NW")
        self.vSaveEqu.set(1)
        
        # Case à cocher 'Négliger les paramètres de tri'
        r += 1
        self.vDiscardEqu = IntVar()
        Checkbutton(self, text=app.lg.get("winsort", "s6"), variable=self.vDiscardEqu).grid(row=r, column=1, pady=5, sticky="NW")
        self.vSaveEqu.set(1)
        
        # Boutton 'Restaurer l'état antérieur'
        r += 1
        self.bt_restore=Button(self, text=" " + app.lg.get("winsort", "s5") + " ", width="45", command=self.__restore)
        self.bt_restore.grid(row=r, column=1, sticky="N")
        self.bt_restore['state'] = "disabled"
        
        
        # -------------------------
        # --- Frame des Boutons    
        # -------------------------
        r += 1
        fr_butOpt=Frame(self)
        fr_butOpt.grid(row=r, column=0, columnspan=4, pady=8, sticky="WENS")
        
        self.bt_sort=Button(fr_butOpt, image=app.imglst.sortcr, compound=LEFT, text="  " + app.lg.get("winsort", "s4"), width=100, padx= 10, command=self.__okSort)
        self.bt_sort.grid(row=0, column=0, pady=8, padx=10)
        self.bt_esc=Button(fr_butOpt, image=app.imglst.exit, compound=LEFT, text="  " + app.lg.get("g", "close"), width=100, padx= 10, command=self.destroy)
        self.bt_esc.grid(row=0, column=1, pady=8, padx=10)
        Button(fr_butOpt, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=100, padx= 10,command=lambda: app.showHelp("sortdic")).grid(row=0, column=2, pady=8, padx=10)
        
        # "Afficher la table des caractères"
        bt_unicode=Button(fr_butOpt, image=app.imglst.carspec, command=app.showUnicode, height=20, width=20)
        bt_unicode.grid(row=0, column=3, pady=8, padx=10)
        lib.infobulle.InfoBulle(parent=bt_unicode, text=app.lg.get("win1", "ib20"))
        
        
        # -----------------------------------------------
        # --- Charger les motifs d'équivalence de tri    
        # -----------------------------------------------
        
        if app.dic.type.startswith("ling"):
            
            if len(app.dic.sortEquPatterns) > 0:
                if app.dic.sortEquPatterns[0] != "":
                    for ptrn in app.dic.sortEquPatterns:
                        ptrn = ptrn.replace(" ", "$$")
                        ptrn = ptrn.replace(":", " = ")
                        self.txt_equ.insert(END, ptrn + "\n")
        
        else:
            
            dicpath = app.dic.path
            
            # Homogénéiser les chemins dict (ifo, dict ...)
            if app.dic.type.startswith("dict"):
                dicpath = os.path.splitext(app.dic.path)[0]+ ".dict"
                
            
            try:
                ff = open(os.path.join(dicpath + "_res", "sort.txt"), 'rb')
                t = ff.read()
                # Homogénéiser les sauts de ligne
                t = t.replace("\r\n", "\n")
                t = t.replace("\r", "\n")
                self.txt_equ.insert(END, t)
                ff.close()
            except:
                pass
            
        
        return
    
    
    
    def __restore(self):
        u"""
        | Restaurer le dictionnaire à son état antérieur d'avant le tri         
        """
        
        app.dic.file.close()
        
        # restaurer le fichier
        fichpath = app.dic.path
        shutil.copy(fichpath + ".back", fichpath)
        
        # recharger le dictionnaire
        app.loadDico(fichpath, showSplash=False, cp1=app.dic.encoding1, cp2=app.dic.encoding2 )
        
        
        self.bt_restore['state'] = 'disabled'
        self.bt_sort['state'] = 'normal'
        self.txt_equ['state'] = 'normal'
        self.txt_equ['background'] = 'white'
        
        return
    
    
    def __okSort(self):
        
        u"""
        | [ appelé par le clic sur le bouton 'Trier' ]                          
        |                                                                       
        | Trier le dictionnaire                                                 
        """
        
        self.bt_sort['state'] = "disabled"
        self.bt_esc['state'] = "disabled"
        self.txt_equ['state'] = "disabled"
        self.txt_equ['background'] = self['background']
        
        
        self['cursor'] = "watch"
        app['cursor'] = "watch"
        self.update()
        app.update()
        
        
        # Enregistrer une copie de sauvegarde du fichier dictionnaire
        # pour le cas où le tri serait foireux ou insatisfaisant
        fichpath = app.dic.path
        shutil.copy(fichpath, fichpath + ".back")
        
        
        # ------------------------------------------------------------------
        # --- Construire le pyDictionnaire des équivalences de caractères   
        # ------------------------------------------------------------------
        
        lignes = self.txt_equ.get('1.0',END).encode('utf-8')
        lignes = lignes.splitlines()
        
        equs = {}
        for ligne in lignes:
            if '=' in ligne:
                chps = ligne.split('=')
                
                chp0 = chps[0].strip()
                chp0 = chp0.replace("$$", " ")
                
                chp1 = chps[1].strip()
                if chp1 == "%%":
                    chp1 = ""
                
                equs[chp0] = chp1
        
        
        # ---------------------------------------------------
        # --- Enregistrer les paramètres de tri (optionnel)  
        # ---------------------------------------------------
        if self.vSaveEqu.get() == 1:
            
            # --- Format LING                      
            if app.dic.type.startswith("ling"):
            
                # Confectionner la nouvelle valeur de la propriété (un tupple de string)
                # elle sera incorporé au fichier lors de sa reconstruction après le tri
                strequs = []
                for ligne in lignes:
                    if '=' in ligne:
                        chp = ligne.split('=')
                        strequs.append (chp[0].strip() + ":" + chp[1].strip())
                
                app.dic.sortEquPatterns = tuple(strequs)
                
                
                
            # --- Autres formats > utiliser un fichier de ressources
            else:
                
                flagDirResOk = False
                
                # --- Créer le répertoire de ressource s'il n'existe pas     
                
                dicpath = app.dic.path
                
                # Homogénéiser les chemins dict (ifo, dict ...)
                if app.dic.type.startswith("dict"):
                    dicpath = os.path.splitext(app.dic.path)[0]+ ".dict"
                
                repRes = dicpath + "_res"
                
                if not os.path.isdir(repRes):
                    try:
                        os.makedirs(repRes)
                    except: # Echec de la création du répertoire > avertir
                        tkMessageBox.showwarning(parent=self,
                            title = app.lg.get("winsort", "title"),
                            message = app.lg.get("winsort", "msg1") )
                    else:  # répertoire créé, ok
                        flagDirResOk = True
                else:
                    flagDirResOk = True
                    
                # --- Enregistrer le fichier ressource                  
                if flagDirResOk:
                    t = self.txt_equ.get('1.0',END).strip()
                    t = t.encode('utf-8')
                    
                    ff = open(os.path.join(repRes,"sort.txt"), 'wb')
                    ff.write(t)
                    ff.close()
        
        
        
        
        # -----------------
        # --- Trier        
        # -----------------
        
        app.showProgr()                     # Afficher la barre de progression de la fenêtre principale
        
        if self.vDiscardEqu.get() == 1:
            app.dic.sortdic(equs='ascii')   # Trier en pur ASCII
        else:
            app.dic.sortdic(equs=equs)      # Trier en utilisant les équivalences
        
        app.hideProgr()                     # Masquer la barre de progression de la fenêtre principale
        
        self.bt_restore['state'] = "normal" # Activer le bouton de restauration
        self.bt_esc['state'] = "normal"
        
        # ---
        
        self['cursor'] = ""
        app['cursor'] = ""
        
        
        return



class WindowFind(Toplevel):
    
    u"""
    | Fenêtre de recherche dans le dictionnaire                                 
    """

    def __init__(self):
        
        u"""
        | Mise en place de l'interface graphique                                
        """
        
        Toplevel.__init__(self, padx=5, pady=3)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+40)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winfnd", "title"))
        self.resizable(width=NO, height=NO)
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        
        self.focus_set()
        
        
        # ----------------------------
        # --- Interface graphique     
        # ----------------------------
        
        
        # --- Frame de la case de saisie et des boutons
        fr_top = Frame(self)
        fr_top.pack()
        
        # Case de recherche
        self.txt_motif = Entry(fr_top, width=30, background='white')
        self.txt_motif.grid(row=0, column=0, sticky="w")
        self.txt_motif.bind('<Return>', self.findClick)
        
        # Boutons
        self.bt_findrev = Button(fr_top, text="<< " + app.lg.get("winfnd", "s1"), width =14, command= lambda : self.findClick(None, reverse=True))
        self.bt_findrev.grid(row=0, column=1, sticky="w")
        
        self.bt_findall = Button(fr_top, text=app.lg.get("winfnd", "s12"), width= 28, command= lambda : self.findClick(None, decal=-1))
        self.bt_findall.grid(row=0, column=1, columnspan=2, sticky="w")
        self.bt_findall.grid_remove()
        
        self.bt_find = Button(fr_top, text=app.lg.get("winfnd", "s2") + " >>", width =14, command= lambda : self.findClick(None))
        self.bt_find.grid(row=0, column=2, sticky="w")
        
        
        Button(fr_top, text=app.lg.get("g", "close"), width =14, command=self.destroy).grid(row=0, column=3, sticky="w")
        Button(fr_top, image=app.imglst.hlp, command=lambda: app.showHelp("findword")).grid(row=0, column=4, sticky="w")
        
        
        # --- Frame général des options
        fr_opt = Frame(self, pady=2)
        fr_opt.pack(side=TOP, expand=True, fill=X)
        
        self.vOptCase = IntVar()
        self.vOptStart = IntVar()
        self.vOptLig = IntVar()
        self.vOptWords = IntVar()
        self.vOptWords.set(1)
        self.vOptNotices = IntVar()
        self.vOptIDs = IntVar()
        self.vOptToks = IntVar()
        self.vUseRegex = IntVar()
        self.vOptTyp = StringVar()
        self.vOptTyp.set("iter")
        self.vMotEntier = IntVar()
        
        
        # Sous-frame des critères de recherche
        fr_crit=LabelFrame(fr_opt, text=" " + app.lg.get("winfnd", "s3") + " ", relief=GROOVE,)
        fr_crit.pack(side=LEFT, expand=True, fill=BOTH)
        
        self.chk_case=Checkbutton(fr_crit, text=app.lg.get("winfnd", "s4"), variable=self.vOptCase)
        self.chk_case.grid(row=0, column=0, sticky="W")
        
        self.chk_start=Checkbutton(fr_crit, text=app.lg.get("winfnd", "s5"), variable=self.vOptStart)
        self.chk_start.grid(row=1, column=0,sticky="W")
        
        self.chk_lig=Checkbutton(fr_crit, text=app.lg.get("winfnd", "s6"), variable=self.vOptLig)
        self.chk_lig.grid(row=2, column=0,sticky="W")
        
        self.chk_motentier=Checkbutton(fr_crit, text=app.lg.get("winfnd", "s16"), variable=self.vMotEntier)
        self.chk_motentier.grid(row=3, column=0,sticky="W")
        self.chk_motentier.bind('<ButtonRelease-1>', self.onClickMotEntier)
        
        self.chk_regex=Checkbutton(fr_crit, text=app.lg.get("winfnd", "s11"), variable=self.vUseRegex)
        self.chk_regex.grid(row=4, column=0,sticky="W")
        self.chk_regex.bind('<ButtonRelease-1>', self.onClickRegex)
        
        
        # Sous-frame du domaine de recherche
        fr_dom=LabelFrame(fr_opt, text=" " + app.lg.get("winfnd", "s7") + " ", relief=GROOVE,)
        fr_dom.pack(side=LEFT, expand=True, fill=BOTH)
        
        self.chk_wd=Checkbutton(fr_dom, text=app.lg.get("winfnd", "s8"), variable=self.vOptWords)
        self.chk_wd.grid(row=0, column=0, sticky="W")
        
        self.chk_not=Checkbutton(fr_dom, text=app.lg.get("winfnd", "s9"), variable=self.vOptNotices)
        self.chk_not.grid(row=1, column=0, sticky="W")
        self.chk_not.bind('<ButtonRelease-1>', self.onClickNotices)
        
        self.chk_IDs=Checkbutton(fr_dom, text=app.lg.get("winfnd", "s10"), variable=self.vOptIDs)
        self.chk_IDs.grid(row=2, column=0, sticky="W")
        self.chk_IDs.bind('<ButtonRelease-1>', self.onClickIDs)
        
        self.chk_toks=Checkbutton(fr_dom, text=app.lg.get("winfnd", "s17"), variable=self.vOptToks)
        self.chk_toks.grid(row=3, column=0, sticky="W")
        self.chk_toks.bind('<ButtonRelease-1>', self.onClickToks)
        
        
        
        # --- Frame du type de recherche (itérative ou liste)
        
        fr_typ = LabelFrame(self, pady=2, text=" " + app.lg.get("winfnd", "s13") + " ", relief=GROOVE,)
        fr_typ.pack(side=TOP, expand=True, fill=BOTH)
        
        self.chk_iter = Radiobutton(fr_typ, text=app.lg.get("winfnd", "s14"), variable=self.vOptTyp, value="iter")
        self.chk_iter.grid(row=0, column=0, sticky="w")
        self.chk_iter.bind('<ButtonRelease-1>', self.onClickTyp)
        
        self.chk_lst = Radiobutton(fr_typ, text=app.lg.get("winfnd", "s15"), variable=self.vOptTyp, value="lst")
        self.chk_lst.grid(row=0, column=1)
        self.chk_lst.bind('<ButtonRelease-1>', self.onClickTyp)
        
        self.txt_nbfind = Label(fr_typ, text="")
        self.txt_nbfind.grid(row=0, column=2)
        
        self.bt_save = Button(fr_typ, image=app.imglst.save, borderwidth=1, command=self.saveResults, height=20, width=20)
        self.bt_save.grid(row=0, column=3, padx=10)
        self.bt_save.grid_remove()
        
        self.lst_result = lib.myscrlst.ScrolledList(fr_typ, width=80, height=18, onclic=self.selword, font="Helvetica 8 normal")
        self.lst_result.grid(row=1, column=0, columnspan=10)
        self.lst_result.grid_remove()
        
        self.progr=lib.myprogbr.ProgressBar(fr_typ, width= 480)
        self.progr.grid(row=2, column=0, columnspan=10, sticky='w')
        self.progr.setValue(-1)
        self.progr.grid_remove()
        
        # ---
        
        self.txt_motif.focus_set()
        
        return


    def saveResults(self):
        
        u"""
        | Enregistrer la liste des résultats dans un fichier texte              
        """
        
        fichpath = tkFileDialog.asksaveasfilename(parent=self,
                    title = app.lg.get("winfnd", "msg5"),
                    filetypes = ((app.lg.get("g", "ftxt"),'*.txt'),),
                    initialfile = "results.txt",
                    initialdir = os.path.expanduser('~'),
                    )
        
        if not fichpath: return   # L'utilisateur a cliqué 'Annuler' dans la boîte de dialogue
        
        
        # Extraire la liste
        lst = self.lst_result.getlist()
        newlst= []
        
        
        # Nettoyer la liste de ses index
        for ligne in lst:
            newlst.append(ligne.split("%%%")[0].strip())
        
        
        motif = self.txt_motif.get()
        
        
        try   : motif = motif.encode('utf-8')
        except: pass
        
        newlst = "\n".join(newlst)
        
        try   : newlst = newlst.encode('utf-8')
        except: pass
        
        t = motif + "  --->  " + self.txt_nbfind['text'] + "\n" + "-"*50 + "\n\n" + newlst
        
        
        # Enregistrer
        f = open(fichpath, "w")
        f.write(t)
        f.close()
        
        return


    def selword(self, idxlst, idw):
        
        u"""
        | Clic sur un mot de la liste des résultats de recherche                
        | Affighage de l'élément cliqué dans la fenêtre principale              
        |                                                                       
        | ARGUMENTS :                                                           
        |     'idxlst' : index du mot cliqué dans la liste (inutile ici mais    
        |                nécessaire en tant que procédure 'onclic' de la liste).
        |                                                                       
        |     'idw' : ID du widget (inutile ici mais nécessaire à la            
        |             procédure 'onclic' de la liste).                          
        """
        
        # Extraire l'index du libellé
        try:
            i = self.lst_result.getselecteditem().split("%%%")[1]
        except:
            return
        
        # Afficher le mot du dictionnaire dans la fenêtre principale
        app.dic.lstbox.activate(i)
        app.dic.lstbox.selection_set(i)
        app.dic.lstbox.see(i)
        app.selDisplayData(None)
        
        return
    
    
    
    def onClickTyp(self, event):
        
        u"""
        | Clic sur les boutons radio du type de recherche
        """
        
        # Nb : sous Windows le changement de valeur de la variable Tkinter
        # se produit après le ButtonRelease
        # on teste donc son état antérieur !
        if app.pf in ("win", "osx"):
            testvalue = "lst"
        else:
            testvalue = "iter"
        
        
        if self.vOptTyp.get() == testvalue:
            self.lst_result.grid_remove()
            self.bt_findall.grid_remove()
            self.bt_findrev.grid()
            self.bt_find.grid()
            self.txt_nbfind['text'] = ""
            self.bt_save.grid_remove()
        else:
            self.bt_findall.grid()
            self.bt_findrev.grid_remove()
            self.bt_find.grid_remove()
        
        
        return

    def onClickMotEntier(self, event):
        
        u"""
        | Clic sur la case à cocher 'Recherche des mots entiers uniquement'     
        """
        
        # Nb : sous Windows le changement de valeur de la variable Tkinter
        # se produit après l'évènement ButtonRelease
        # on teste donc son état antérieur !
        if app.pf in ("win", "osx"):
            testvalue = 0
        else:
            testvalue = 1
        
        if self.vMotEntier.get() == testvalue:
            # désactiver la recherche en début de mot
            self.vOptStart.set(0)
            self.chk_start['state'] = 'disabled'
            # imposer la sensibilité aux ligatures
            self.vOptLig.set(1)
            self.chk_lig['state'] = 'disabled'
        else:
            # réactiver la recherche en début de mot
            self.chk_start['state'] = 'normal'
            # réactiver la sensibilité aux ligatures
            self.chk_lig['state'] = 'normal'
        
        
    def onClickRegex(self, event):
        
        u"""
        | Clic sur la case à cocher 'Recherche par expression rationnelle'      
        """
        
        # Nb : sous Windows le changement de valeur de la variable Tkinter
        # se produit après l'évènement ButtonRelease
        # on teste donc son état antérieur !
        if app.pf in ("win", "osx"):
            testvalue = 0
        else:
            testvalue = 1
        
        if self.vUseRegex.get() == testvalue:
            # désactiver la recherche en début de mot
            self.vOptStart.set(0)
            self.chk_start['state'] = 'disabled'
            # désactiver la sensibilité aux ligatures
            self.vOptLig.set(0)
            self.chk_lig['state'] = 'disabled'
            # désactiver la recherche de mot entier
            self.vMotEntier.set(0)
            self.chk_motentier['state'] = 'disabled'
        else:
            # réactiver la recherche en début de mot
            self.chk_start['state'] = 'normal'
            # réactiver la sensibilité aux ligatures
            self.chk_lig['state'] = 'normal'
            # réactiver la recherche de mot entier
            self.chk_motentier['state'] = 'normal'
            
        return


    def onClickToks(self, event):
        u"""
        | Clic sur la case à cocher 'Recherche dans les Attributs'                    
        """
        
        # Nb : sous Windows le changement de valeur de la variable Tkinter
        # se produit après l'évènement ButtonRelease
        # on teste donc son état antérieur !
        if app.pf in ("win", "osx"):
            testvalue = 0
        else:
            testvalue = 1
        
        if self.vOptToks.get() == testvalue:
            # désactiver la recherche dans les entrées, notices et wordIDs
            self.vOptNotices.set(0)
            self.chk_not['state'] = 'disabled'
            self.vOptWords.set(0)
            self.chk_wd['state'] = 'disabled'
            self.vOptIDs.set(0)
            self.chk_IDs['state'] = 'disabled'
            # désactiver la sensibilité à la casse
            self.vOptCase.set(1)
            self.chk_case['state'] = 'disabled'
            # désactiver la recherche en début de mot
            self.vOptStart.set(0)
            self.chk_start['state'] = 'disabled'
            # désactiver la sensibilité aux ligatures
            self.vOptLig.set(1)
            self.chk_lig['state'] = 'disabled'
            # désactiver la recherche de mot entier
            self.vMotEntier.set(0)
            self.chk_motentier['state'] = 'disabled'
            # désactiver la recherche regex
            self.chk_regex['state'] = 'disabled'
        else:
            # réactiver la recherche des entrées, notices et wordIDs
            self.chk_not['state'] = 'normal'
            self.vOptWords.set(1)
            self.chk_wd['state'] = 'normal'
            self.chk_IDs['state'] = 'normal'
            # réactiver la sensibilité à la casse
            self.vOptCase.set(0)
            self.chk_case['state'] = 'normal'
            # réactiver la recherche en début de mot
            self.chk_start['state'] = 'normal'
            # réactiver la sensibilité aux ligatures
            self.vOptLig.set(0)
            self.chk_lig['state'] = 'normal'
            # résactiver la recherche de mot entier
            self.chk_motentier['state'] = 'normal'
            # désactiver la recherche regex
            self.chk_regex['state'] = 'normal'
        

    def onClickIDs(self, event):
        
        u"""
        | Clic sur la case à cocher 'Recherche dans les IDs'                    
        """
        
        # Nb : sous Windows le changement de valeur de la variable Tkinter
        # se produit après l'évènement ButtonRelease
        # on teste donc son état antérieur !
        if app.pf in ("win", "osx"):
            testvalue = 0
        else:
            testvalue = 1
        
        if self.vOptIDs.get() == testvalue:
            # désactiver la recherche des entrées, notices et tokens
            self.vOptNotices.set(0)
            self.chk_not['state'] = 'disabled'
            self.vOptWords.set(0)
            self.chk_wd['state'] = 'disabled'
            self.vOptToks.set(0)
            self.chk_toks['state'] = 'disabled'
            # réactiver la recherche en début de mot sauf si regex
            if self.vUseRegex.get() == 0:
                self.chk_start['state'] = 'normal'
        else:
            # réactiver la recherche des entrées, notices et tokens
            self.chk_not['state'] = 'normal'
            self.vOptWords.set(1)
            self.chk_wd['state'] = 'normal'
            self.chk_toks['state'] = 'normal'
        
        return



    def onClickNotices(self, event):
        
        u"""
        | Clic sur la case à cocher 'Recherche dans les notices'                
        """
        
        # Nb : sous Windows le changement de valeur de la variable Tkinter
        # se produit après l'évènement ButtonRelease
        # on teste donc son état antérieur !
        if app.pf in ("win", "osx"):
            testvalue = 0
        else:
            testvalue = 1
        
        if self.vOptNotices.get() == testvalue:
            # désactiver la recherche en début de mot
            self.vOptStart.set(0)
            self.chk_start['state'] = 'disabled'
        else:
            # réactiver la recherche en début de mot sauf si regex
            if self.vUseRegex.get() == 0:
                self.chk_start['state'] = 'normal'
        
        
        return
    

    def findClick(self, event, reverse=False, decal=None):
        
        u"""
        | Chercher un motif dans le dictionnaire                                
        |                                                                       
        | ARGUMENTS :                                                           
        |   'event' : évènement déclenchant l'appel de la méthode               
        |                                                                       
        |   'reverse' : (booléen) la recherche est effectée à rebours si        
        |               'reverse' est True.                                     
        |                                                                       
        |   'decal' : index de l'entrée à partir duquel débute la recherche.    
        """
        
        motif = self.txt_motif.get()# Motif à rechercher
        
        if self.vUseRegex.get() == 0:
            motif = motif.strip()            
        
        if len(motif) == 0: return
        
        
        app.dic.lstbox.selection_clear(0, END)          # Désélectionner tout dans la listbox des entrées
        
        
        # --------------------------------------------
        # --- Index de départ de la recherche         
        # --------------------------------------------
        
        if decal == -1: # recherche globale
            pass
            
        else:           # recherche itérative
            
            if reverse:
                decal = int(app.dic.curIdx)-1 # décalage = index du mot précédant celui en sélection
            else:
                decal = int(app.dic.curIdx)+1 # décalage = index du mot suivant celui en sélection
                
            if decal > app.dic.lstbox.size()-1:
                decal = 0
            elif decal < 0:
                decal = 0
        
        
        # ---------------------------------
        # --- Options de la recherche      
        # ---------------------------------
        
        # Sens de la recherche
        #   (passé dans le paramètre-argument 'reverse')
        
        
        # Domaine de la recherche
        if self.vOptWords.get() and self.vOptNotices.get():
            dom = 'both'
        elif self.vOptWords.get():
            dom = 'idx'
        elif self.vOptNotices.get():
            dom = 'notice'
        elif self.vOptIDs.get():
            dom = "IDs"
        elif self.vOptToks.get():
            dom = "toks"
        
        # Sensibilité à la casse
        if self.vOptCase.get() == 1:
            ignorecase = False
        else:
            ignorecase = True
        
        # Recherche des débuts de mots
        if self.vOptStart.get() == 1:
            debut = True
        else:
            debut = False
        
        # Sensibilité aux ligatures
        if self.vOptLig.get() == 1:
            ignorelig = False
        else:
            ignorelig = True
        
        # Recherche de mot entier
        if self.vMotEntier.get() == 1:
            motentier = True
        else:
            motentier = False
        
        # recherche par expression rationnelle
        if self.vUseRegex.get() == 1:
            regex = True
        else:
            regex = False
        
        
        
        # ---------------------
        # --- Chercher         
        # ---------------------
        
        self['cursor'] = 'watch'
        app['cursor'] = 'watch'
        self.update()
        
        i = app.dic.idxfind(motif=motif, dom=dom, decal=decal, debut=debut, ignorecase=ignorecase, ignorelig=ignorelig, reverse=reverse, motentier=motentier, regex=regex)
        
        
        # -------------------------------------------------------
        # --- Résultats de la recherche                          
        # -------------------------------------------------------
        if not i is None:
            
            if isinstance(i, list):     # --- Recherche globale > liste d'index
                
                nb = 0
                self.progr.grid()
                self.progr.setMax(len(i))
                self.progr.setValue(nb)
                
                self.lst_result.grid()
                self.lst_result.clear()
                self.txt_nbfind['text'] = "  " + str(len(i))
                
                getdata = app.dic.getdata # accélérateur local
                
                oRegex = re.compile(r"<[^>]+?>")
                
                esp = "     >      "
                
                for idx in i:
                    
                    nb += 1
                    self.progr.setValue(nb)
                    
                    data = getdata(idx)
                    
                    if dom == "IDs":
                        t = data['mot'] + esp + data['ID'] + esp + data['short']
                    elif dom == "toks":
                        t = data['mot'] + esp + data['tok'] + esp + data['short']
                    else:
                        
                        if data['long'] == "" :
                            dl = ""
                        else:
                            dl = " ( ... )"
                        
                        t = data['mot'] + esp + data['short'] + dl
                        # épurer le texte de ses éventuelles balises
                        t = re.sub(oRegex, "", t)
                    
                    
                    self.lst_result.add(t + "           %%%" + str(idx))
                
                
                
                self.bt_save.grid()         # afficher le bouton d'enregistrement des résultats
                self.progr.grid_remove()    # masquer la barre de progression
                
                
            else:                       # --- Recherche itérative > index isolé
                
                app.txt_search['foreground']='black'
                
                # Sélectionner l'entrée dans la fenêtre principale
                app.dic.lstbox.activate(i)
                app.dic.lstbox.selection_set(i)
                app.dic.lstbox.see(i)
                app.selDisplayData(event)
            
            
            self['cursor'] = ''
            app['cursor'] = ''
            
            
        # -------------------------------------------------
        # --- Rien n'a été trouvé (retour = None)          
        # -------------------------------------------------
        else:                           
            
            
            if decal == -1:     # --- Recherche globale
            
                self.lst_result.grid()
                self.lst_result.clear()
                self.lst_result.add("(recherche négative)")
                self.txt_nbfind['text'] = "  0"
                
                self['cursor'] = ''
                app['cursor'] = ''
                
            else:               # --- Recherche itérative
                
                self['cursor'] = ''
                app['cursor'] = ''
                
                if reverse:
                    t = app.lg.get("winfnd", "msg1")    # ('le début du dictionnaire est atteint')
                else:
                    t = app.lg.get("winfnd", "msg2")    # ('la fin du dictionnaire est atteinte')
                
                tkMessageBox.showinfo(parent=self,
                        title = app.lg.get("winfnd", "title"),
                        message = t + u"\n\n" + app.lg.get("winfnd", "msg3") + " '" + motif + "' " + app.lg.get("winfnd", "msg4") )
            
        
        return



class WindowAbout(Toplevel):
    u"""
    | Fenêtre d'informations à propos de Linguae                                
    """
    
    def __init__(self):
        
        u"""
        | Mise en place de l'interface graphique                                
        """
        
        Toplevel.__init__(self, padx=5, pady=5, background="white")
        
        # masquer la fenêtre (minimise le bref pop-up avant centrage de la fenêtre)
        self.withdraw()
        
        
        self.title(app.lg.get("menu", "m25"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        
        
        self.logo = PhotoImage(data="""R0lGODlhUABQALMAAAAAABgYGDU1NU5OTmtra39/f5iYmK2trbW1tcHBwc7Oztra2ufn5+/v7/f39////ywAAAAAUABQAAAE/vDJSau91s2maXsdJo5kiYWS032mw5pwPKGXKr1yrreMtkwJR4+W2hmPNhzowjk6RUpM47P42K7PrHGBSBQMBEOh2mD8iI/fTCvqaN4jx+JAGBAQjMKAy1g+omwkGmUgNDgOCHQDAgYHCg95AgQHYAllbmhogUUbbwwKAwUABg4EDQoOBwwJCAUMBwACCQcpIT0zNpu1hRldBZKJ
        CgxNLggaCgUJBgoGEwcqDH27g5tuFBqsBosBBAK0fy9WQhyzBAUNBwgPB2eQvNJIfhgKAAUBAQ/1ifITyzUFX4a5cAHp0S4dKjTBSUUAAIADDZqtsVCg0C13CAQEMKAkxIoc/nCuvfBxIACAOzcgqeG05MqgPggGqJNni1+LIh5rDUPQ0EAQTTdQ5CqSqIDBQkMzCJo4xULEAaEgCa3g4CgJPUan/QF64g1BeB0EIgigJiRQIRb6KOs2YN0hqTZJcHAxN+26AAL6EHGxoEeDvgIVZLQjIFadWCYlosIVNw44XLn6
        GBg1MemBdAS6aTSpMRSBIBPq0Io2ESEVDsQm9AFFytkUAvcAmHTocAC3ZqCJIOAJookEeDJCPBroZ4EBAwLszKYdS0ByA2bqVLTyR1pCDSWt/tmaMLi1C4VjNx8AUTskOwUwHaT5Z8GjYU06shT52w31B4tGJfjBYmEZDs+N/vRdB6zQwsF7WOQSUgbW5OSMAMJwMIwECHDRyH6fCLCOAixMMhWFlkxhHQjR+MYVLyp1N4UGdyiwwBv/BfSDi9FM1kwfCwQwAACMuZAMDk1BQksSE57wQZH9/QYKAX65wMCObSlA
        wBx8AdBWHwdA1dZ3B/ySgBkSLLDSdvOhIM0tMK7wl5deqSCKUQqw8wgXYbyxAEAEVNAHA91AchEqOXlVA4lF9KWgAcYtk5SLCngx2n4DSFTGJy92l0oAX8AV1Hyc1kJQb0JosAokDU3pB2p++uWWAeokkQJ8KiRwzwAioqnDB6hUAQ0ZIeyIKZovmCEsCLK66CRdgkpwz5dm/mBxwUUM+nFMqBMgIBten9hpojDRyJrAdir8ZVETDgFx3RAlYNJmddA2wJOOBwQhTjRV/dWXRqwq4OJ/fmBZTxnulbhif3Wh6JEP
        OonKwRwOdbNYiFWkseID9lAR8YpuMHCPT/GqeIYVUwQ5X1PEfGoQLQZwVmGoZaBiiXsLaKQKoCm59YBJBAxEr4gcRpyLb5xAo2KoaG11yj2qCOtiAvoSVMckr26gzCsaVWTLQAQ1Bcdb48y1Z2/yTNHoSUaJiSNdw9gTwCw+aQ32jnmGs69ATZ54XUKoJQtJGchBWCECxBxp7R4foNrSAYV9M9e64F7SmIKWpjGIqNG4qNGU/vq29EYBmQGqVwhqu9KfED/0gC4vQIkTLpGQ3eKcjiWG8EE3TMrRhCV/vK4pUpqD
        7aDmMEoLDjV8lZHAYWOg+p4CAlSUwPMteSFb8kWEzELBvzPmO9ZyqClVVbZxY9zXEkhJyikPfAuCtQAgIAyZ69DL+yWZfzhD3SuImsI3gsEGgGDUQdST2FG43zBADABwgOhqUYXPUSFog+pEybhTQJA9QBtWClUPhLEA8mSudH0ojIYcoL5LSMgvBdMeVfp1neEN40wJwYMoICSMQehLAO6hwyRW0bdIwWdIKugLIaQxl5GQAIhFS4MSQ/KlBtiGR88TkxcawRbnCOYBMgPc/pGGQjQO+cZdcUDB4igXsQm9hBmF
        MUoApAQb8d0pTtABAw6fsZUKbQUe3xpHmICjlJ+Fi2fu8Iq7SKix2uzIIZyhTXI28xBLHGsQhftOYzp1tyAhQlzcE4gCGQmVwvjKIZI4CTemtLgl/OdFj2FPcPL2GEy4BxI8yUj7hNENBIjBDrBJjgfVtRoOWcos6VLKf1jWm8J96Qs7Og6rBnA8wjQCZ6iY0J5YYCwbZGtBIFFNU4ZjBX3FaRV1QA/b8DIlB0zPQ0JAYUL2M0SBJMkxHhCUikD1lwhx4XWvoETznkiWhkHnjnpRCXyQwkV4eup7xEFRA4XQBT7t
        85a0Od4C/k6iL8cBbXF6GQIg4Dk5UO2lePpqo0y0wTSoOOA4+Minn3Ch0Urd4i18hOBU5LBCQqxPDLDJyD28MQdmQuUkGOOQTpqVUZcEM0GomucLUOkOVOjhdQVAnHNEcRI8sMARusIGf64DtJvcDUVowlpAy9AlViwgl8cBSD4e8oq/dM+a38LeJNtQBIEc1B0TOIMQkDMb8lgCIlFFjjlUITkyFOI9KLKJ3aiyEFQEa28piRRylqHMHdlDIkp0z19CtjeMtQRoJyqNUPpQQKRUzgE41APtCECPzIQhCoX7xEv3
        Eg/NVapMYsoSI35qB1/hSxzRkmSnYjBTxgZxAo/oRkrZ1GeUSBVioyfQBS+CdbUDIueTbVmEDzswk+F6IBCyS0r1poCV2HzhF4bZyC0kIl7pVgBkNE1BfFIipr904yS1SU7HyPEq+7lXtHDBaJYoVixj1HIAIwKMk0rz35qGwFDx6hLz0tGWz5jiC+2A31cb3JVr9AZLeb3qjdqrSg4bFDB3GoBBmsGIcyRRuCZOV4n255wwdKkPd4hrBGNMXOqQNjOtoAQd5srjHYTreRJWMRYNReQi72AIrP0B4JpIYifvuEzX
        AIuVt8zlLnv5y2AOs5itHAEAADs=""")
        
        
        font1 = "Helvetica 8 normal"
        
        # --- Frame du logo et du titre
        fr_logo = Frame (self, background=self['background'])
        fr_logo.grid()
        
        Label(fr_logo, image=self.logo, background=self['background']).grid(row=0, rowspan=10, column=0,)
        
        Label(fr_logo, text="Linguae", font="Helvetica 14 bold", foreground='red', background=self['background']).grid(row=1, column=1, sticky="w")
        Label(fr_logo, text="Version " + app.version, font=font1, background=self['background']).grid(row=2, column=1, sticky="w")
        Label(fr_logo, text=app.lg.get("winabt", "s1"), font=font1, background=self['background']).grid(row=3, column=1, sticky="w")
        
        # ---
        
        self.lab_linkWeb = Text(self, width=56, height=1, font=font1, relief=FLAT, highlightbackground=self['background'], background=self['background'])
        self.lab_linkWeb.tag_config("normal", justify="center")
        self.lab_linkWeb.tag_config("link", foreground="blue", underline=1, justify="center")
        self.lab_linkWeb.insert(END, "Web : ", "normal")
        self.lab_linkWeb.insert(END, "http://linguae.stalikez.info", "link")
        self.lab_linkWeb.tag_bind("link", '<ButtonRelease-1>', self.onClickWeb)
        self.lab_linkWeb.tag_bind("link", '<Enter>', lambda event : self.onEnter(event))
        self.lab_linkWeb.tag_bind("link", '<Leave>', lambda event: self.onLeave(event))
        self.lab_linkWeb['state']="disabled"
        self.lab_linkWeb.grid()
        
        self.lab_linkMail = Text(self, width=56, height=1, font=font1, relief=FLAT, highlightbackground=self['background'], background=self['background'])
        self.lab_linkMail.tag_config("normal", justify="center")
        self.lab_linkMail.tag_config("link", foreground="blue", underline=1, justify="center")
        self.lab_linkMail.insert(END, "E-mail : ", "normal")
        if app.pf == 'win':
            self.lab_linkMail.insert(END, "linguae@stalikez.info", "link")
        else:
            self.lab_linkMail.insert(END, "linguae@stalikez.info", "normal")
        self.lab_linkMail.tag_bind("link", '<ButtonRelease-1>', self.onClickMail)
        self.lab_linkMail.tag_bind("link", '<Enter>', lambda event : self.onEnter(event))
        self.lab_linkMail.tag_bind("link", '<Leave>', lambda event: self.onLeave(event))
        self.lab_linkMail['state']="disabled"
        self.lab_linkMail.grid()
      
        
        Label(self, background=self['background']).grid()
        
        Label(self, text=app.lg.get("winabt", "s2"), font=font1, background=self['background']).grid()
        
        self.lab_linkCecill = Text(self, width=56, height=1, font=font1, relief=FLAT, highlightbackground=self['background'], background=self['background'])
        self.lab_linkCecill.tag_config("normal", foreground="blue", underline=1, justify="center")
        if app.lg.getlgcode() == "fr":
            self.lab_linkCecill.insert(END, "http://www.cecill.info/licences/Licence_CeCILL_V2-fr.txt", "normal")
        else:
            self.lab_linkCecill.insert(END, "http://www.cecill.info/licences/Licence_CeCILL_V2-en.txt", "normal")
        self.lab_linkCecill.bind('<ButtonRelease-1>', self.onClickCecill)
        self.lab_linkCecill.bind('<Enter>', lambda event: self.onEnter(event))
        self.lab_linkCecill.bind('<Leave>', lambda event: self.onLeave(event))
        self.lab_linkCecill['state']="disabled"
        self.lab_linkCecill.grid()
        
        Label(self, background=self['background']).grid()
        
        Label(self, text="Billig - 2008-2010", font=font1, background=self['background']).grid()
        
        # --- Frame des boutons
        fr_but = Frame(self, background=self['background'])
        fr_but.grid(pady=8)
        
        Button(fr_but,text="Changelog.txt", width=20, command=self.seeChangelog, pady=2).grid(row=0, column=0, padx=5)
        Button(fr_but,text=app.lg.get("g", "close"), width=20, command=self.destroy, pady=2).grid(row=0, column=1, padx=5)
        
        # --- Chemin de l'interpréteur Python
        Label(self, text="Python Path : " + sys.executable, font=font1, background=self['background']).grid()
        
        self.update()
        self.deiconify()
        self.focus_set()
        lib.mytools.centerWin(self)
        
        return
    
    def onEnter(self, event):
        event.widget['cursor'] = "hand2"
    
    def onLeave(self, event):
        event.widget['cursor'] = ""
        
    def onClickWeb(self, event):
        
        app.toWebLing()
        
        return
    
    def onClickMail(self, event):
        
        # Quitter si non Windows
        if app.pf != 'win':
            return
        
        # Ouvrir le maileur par défaut
        try:
            os.startfile('mailto:linguae@stalikez.info')
        except:
            pass
        
        
        return


    def onClickCecill(self, event):
        
        try:
            webbrowser.open(event.widget.get("1.0", END))
        except:
            pass
        
        return
    
    
    def seeChangelog(self):
        
        u"""
        | Afficher le fichier changelog.txt, présent dans le répertoire d'application
        """
        
        # chemin complet de changelog.txt
        fich = os.path.join(os.path.dirname(os.path.realpath(sys.argv[0])), "changelog.txt")
        
        
        r = shellopen(fich)
        
        if r != 0:
            tkMessageBox.showwarning(parent=self,
            title = "Linguae",
            message = "Can't open...\n\n'" + fich + "'")
        
        
        return
        


class WindowSetIcon(Toplevel):
    
    u"""
    | Fenêtre de modification des icônes de langue du dictionnaire courant      
    """

    def __init__(self):
        
        u"""
        | Mise en place de l'interface graphique                                
        """
        
        Toplevel.__init__(self, padx=5, pady=5)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winic", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        
        
        # ---
        
        # Afficher l'image de la Langue source
        Label(self, text=app.lg.get("winic", "s1") + " ").grid(row=0, column=0, sticky="W")
        self.lab_ic1=Label(self, pady=5)
        self.lab_ic1.grid(row=0, column=2)
        
        if app.dic.img1b64 != "" :
            try:
                self.ic1 = ImageTk.PhotoImage(Image.open(StringIO.StringIO(base64.decodestring(app.dic.img1b64))))
            except:
                self.ic1 = None
            
            self.lab_ic1['image'] = self.ic1
        else:
            self.lab_ic1['text'] = app.lg.get("winic", "s2")
        
        # Image de la Langue cible
        Label(self, text=app.lg.get("winic", "s3") + " ").grid(row=1, column=0, sticky="W")
        self.lab_ic2=Label(self, pady=5)
        self.lab_ic2.grid(row=1, column=2)
        
        if app.dic.img2b64 != ""  :
            try:
                self.ic2 = ImageTk.PhotoImage(Image.open(StringIO.StringIO(base64.decodestring(app.dic.img2b64))))
            except:
                self.ic2 = None
            
            self.lab_ic2['image'] = self.ic2
        else:
            self.lab_ic2['text'] = app.lg.get("winic", "s2")
        
        
        # -------------------------
        # --- Frame des Chemins    
        # -------------------------
        
        fr_path=Frame(self)
        fr_path.grid(row=2, column=0, columnspan=4, padx=5, pady=10, sticky="WENS")
        
        # Chemin de l'image 1
        Label(fr_path, text=app.lg.get("winic", "s4")).grid(row=3, column=0, sticky="W")
        self.txt_pathimg1=Entry(fr_path,width=60, background="white")
        self.txt_pathimg1.grid(row=4, column=0, sticky="W")
        Button(fr_path, text=" " + app.lg.get("g", "brw"), command=lambda:self.__selImgFile(1)).grid(row=4, column=1, sticky="W")
        
        # Chemin de l'image 2
        Label(fr_path, text=app.lg.get("winic", "s5")).grid(row=5, column=0, sticky="W")
        self.txt_pathimg2=Entry(fr_path,width=60, background="white")
        self.txt_pathimg2.grid(row=6, column=0, sticky="W")
        Button(fr_path, text=" " + app.lg.get("g", "brw"), command=lambda:self.__selImgFile(2)).grid(row=6, column=1, sticky="W")
        
        
        # -------------------------
        # --- Frame des Boutons    
        # -------------------------
        r = 3
        fr_but=Frame(self)
        fr_but.grid(row=r, column=0, columnspan=4, pady=8)
        
        # Bouton 'Modifier'
        self.bt_Do=Button(fr_but, image=app.imglst.ok, compound=LEFT, text="  " + app.lg.get("winic", "s6"), width=100, padx= 10, command=self.__doModifIc)
        self.bt_Do.grid(row=0, column=0, pady=8, padx=10)
        # ..
        Button(fr_but, image=app.imglst.exit, compound=LEFT, text="  " + app.lg.get("g", "close"), width=100, command=self.destroy, padx= 10).grid(row=0, column=1, pady=8, padx=10)
        Button(fr_but, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=100, padx= 10, command=lambda: app.showHelp("editic")).grid(row=0, column=2, pady=8, padx=10)
        
        return


    def __selImgFile(self, n):
        
        u"""
        | [ appelé par les boutons 'Parcourir' ]                                
        |                                                                       
        | Sélection du fichier graphique à inclure par un sélecteur de fichier  
        | Affichage du chemin dans la case et prévisualisation de l'image       
        |                                                                       
        | ARGUMENTS :                                                           
        |   'n' : (integer) numéro de la langue (1 ou 2)                        
        """
        
        fich = tkFileDialog.askopenfilename(parent=self,
                        title = app.lg.get("winic", "msg1"),
                        filetypes=(
                            (app.lg.get("g", "fgraph"), '*.gif *.jpeg *.jpg *.png *.bmp *.tiff *.tif'),
                            (app.lg.get("g", "fgif"),   '*.gif'),
                            (app.lg.get("g", "fjpeg"),  '*.jpeg *.jpg'),
                            (app.lg.get("g", "fpng"),   '*.png'),
                            (app.lg.get("g", "fbmp"),   '*.bmp'),
                            (app.lg.get("g", "ftiff"),  '*.tiff *.tif'),
                            (app.lg.get("g", "fall"),   '*.*') )
                        )
        
        if not fich: return   # L'utilisateur a cliqué 'Annuler' dans la boîte de dialogue
        
        if n == 1:
            
            try:
                self.txt_pathimg1.delete(0,END)
                self.txt_pathimg1.insert(END, fich)
                # Convertir en objet Photoimage Tk (utilise PIL)
                self.ic1 = ImageTk.PhotoImage(Image.open(fich))
            except:
                self.txt_pathimg1.delete(0,END)
                self.ic1 = None
            
            # Préaffichage local
            self.lab_ic1['image'] =  self.ic1
        
        else:
            try:
                self.txt_pathimg2.delete(0,END)
                self.txt_pathimg2.insert(END, fich)
                # Convertir en objet Photoimage Tk (utilise PIL)
                self.ic2 = ImageTk.PhotoImage(Image.open(fich))
                
            except:
                self.txt_pathimg2.delete(0,END)
                self.ic2 = None
            
            # Préaffichage local
            self.lab_ic2['image'] =  self.ic2
        
        return


    def __doModifIc(self):
        
        u"""
        | Valider la modification des icônes dans le fichier dictionnaire       
        | courant                                                               
        """
        
        img1path = self.txt_pathimg1.get().strip()
        img2path = self.txt_pathimg2.get().strip()
        
        if (img1path == "") and (img2path == ""):
            tkMessageBox.showinfo(parent=self,
                    title = app.lg.get("winic", "title"),
                    message = app.lg.get("winic", "msg2") )
            return
        
        
        # ------------------------------------------------------
        # --- Construire les chaînes base64 des blocs d'images  
        # --- et les intégrer à l'objet dictionnaire            
        # ------------------------------------------------------
        
        self['cursor'] = 'watch'
        app['cursor'] = 'watch'
        self.update()
        
        imgBin = ""
        
        if img1path != "":
            try:
                ff = open(img1path, "rb")
            except:
                self['cursor'] = ''
                app['cursor'] = ''
                tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("winic", "title"),
                    message = "'" + img1path + "'\n\n" + app.lg.get("winic", "msg3") )
                self.txt_pathimg1.focus_set()
                return
            
            imgBin = ff.read()
            ff.close()
            
            app.dic.img1b64 = base64.encodestring(imgBin)
            app.dic.img1type = os.path.splitext(img1path)[1][1:].lower()
            
        imgBin = ""
        
        if img2path != "":
            try:
                ff = open(img2path, "rb")
            except:
                self['cursor'] = ''
                app['cursor'] = ''
                tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("winic", "title"),
                    message = "'" + img2path + "'\n\n" + app.lg.get("winic", "msg3") )
                self.txt_pathimg2.focus_set()
                return
            
            imgBin = ff.read()
            ff.close()
            
            app.dic.img2b64 = base64.encodestring(imgBin)
            app.dic.img2type = os.path.splitext(img2path)[1][1:].lower()
        
        
        # ------------------------------------------------
        # --- Mettre à jour le fichier dictionnaire Ling  
        # ------------------------------------------------
        
        # Mémoriser l'index de l'entrée en cours
        try:
            i = int(app.lst_dico.curselection()[0]) # index du mot en sélection
        except:
            i = -1
        
        # Confectionner la nouvelle chaîne Preling du dictionnaire
        
        strPreling = app.dic.toStrPreling(progr=None)
        
        # Confectionner la nouvelle chaîne Ling
        
        strLing = lib.mydic.DicObject.strPrelingToStrLing(strPreling=strPreling)
        
        # Enregistre le nouveau fichier Ling
        fichpath = app.dic.path
        app.dic.file.close()
        ff = open(fichpath, 'wb')
        ff.write(strLing)
        ff.close()
        
        # Recharge le dictionnaire avec le nouveau fichier
        app.loadDico(fichpath, showSplash=True)
        
        # Réaffiche le mot sélectionné
        
        if i != -1:
            app.dic.lstbox.activate(i)
            app.dic.lstbox.selection_set(i)
            app.dic.lstbox.see(i)
            app.selDisplayData(None)
        
        self['cursor'] = ''
        app['cursor'] = ''
        
        self.destroy()
        
        return



class WindowHerit(Toplevel):
    u"""
    Fenêtre de construction d'un dictionnaire par héritage
    """
    
    def __init__(self):
        
        # Message d'info sur la fonctionnalité et ses limites
        # Nb : Message dépendant de app et non de self car avant instanciation de Toplevel
        tkMessageBox.showinfo(parent=app,
            title = app.lg.get("winher", "title"),
            message = app.lg.get("winher", "msg1"))
        
        
        Toplevel.__init__(self, padx=3)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winher", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        
        
        # ----------------------------------
        # --- Frame des dicos disponibles   
        # ----------------------------------
        
        wl=40
        fr_dic=Frame(self)
        fr_dic.grid(row=0, column=0, ipadx=5, ipady=5, sticky='W')
        Label(fr_dic, image=app.imglst.dicx, compound=LEFT, text=" " + app.lg.get("winher", "s1") + " 1<>2").grid(column=0)
        self.lab_dic1=Label(fr_dic, width=wl, borderwidth=1, relief=SOLID, background='white', anchor='w')
        self.lab_dic1.grid(column=0, pady=2)
        self.lst_dic1=lib.myscrlst.ScrolledList(fr_dic, height=23, width=wl, onclic=self.onclicDico)
        self.lst_dic1.grid(column=0)
        Label(fr_dic, image=app.imglst.dicx, compound=LEFT, text=" " + app.lg.get("winher", "s1") + " 2<>3").grid(row=0, column=1)
        self.lab_dic2=Label(fr_dic, width=wl, borderwidth=1, relief=SOLID, background='white', anchor='w')
        self.lab_dic2.grid(row=1, column=1, pady=2)
        self.lst_dic2=lib.myscrlst.ScrolledList(fr_dic, height=23, width=wl, onclic=self.onclicDico)
        self.lst_dic2.grid(row=2, column=1)
        
        # ---------------------
        # --- Frame droit      
        # ---------------------
        
        fr_D=Frame(self)
        fr_D.grid(row=0, column=1, ipadx=5)
        
        # Nom du dictionnaire hérité
        Label(fr_D, image=app.imglst.dicling, compound=LEFT, text=" " + app.lg.get("winher", "s2") + " 1<>3").grid(row=0, column=0)
        self.txt_name=Entry(fr_D, width=25, background="white")
        self.txt_name.grid(row=1, column=0)
        self.txt_name.insert(END, "heritdic")
        
        # Bouttons
        self.bt_make=Button(fr_D, width=90, image=app.imglst.herit, compound=LEFT, text=" " + app.lg.get("winher", "s3"), command=self.makeHeritDic, state='disabled')
        self.bt_make.grid(column=0, pady=8)
        self.bt_cancel=Button(fr_D, width=90, image=app.imglst.exit, compound=LEFT, text=" " + app.lg.get("g", "close"), command=self.destroy)
        self.bt_cancel.grid(column=0, pady=8)
        Button(fr_D, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=90, command=lambda: app.showHelp("herit")).grid(column=0, pady=8)
        
        # Affichage de l'avancement
        self.lab_step=Label(fr_D, borderwidth=2, text=app.lg.get("winher", "s4"), relief=SUNKEN, background='white', width=40, height=14, justify=LEFT, anchor="n", font=("Helvetica",8,"normal"))
        self.lab_step.grid(column=0)
        
        
        # ----------------------------------------------------------------------------
        # --- Options : choix du séparateur de signifiance et sensibilité à la casse  
        # ----------------------------------------------------------------------------
        
        fr_sep = Frame(self)
        fr_sep.grid(row=1, column=0, columnspan=10, ipady=3)
        
        # séparateur de signifiance
        Label(fr_sep, text=app.lg.get("winher", "s5")).grid(row=0, column=0)
        self.txt_sep=Entry(fr_sep,width=8, background="white")
        self.txt_sep.grid(row=0, column=1)
        
        # sensibilité à la casse
        self.vCasse=IntVar()
        Checkbutton(fr_sep, text=app.lg.get("winher", "s6"), variable=self.vCasse).grid(row=1, column=0, sticky="w")
        
        
        # --- Barre de progression
        self.progr=lib.myprogbr.ProgressBar(self, width= 750)
        self.progr.grid(row=2, column=0, columnspan=10, sticky='w')
        
        
        # ----------------------------------
        # --- Remplir les listes de dicos   
        # ----------------------------------
        
        dicosPath = app.ini.get('DicStorageFolder','') # Répertoire de stockage des dicos
        
        self.listDirDic(dicosPath, self.lst_dic1)
        self.listDirDic(dicosPath, self.lst_dic2)
        
        # Avertir si listes vides (c.à.d. aucun dico dans le répertoire des dicos)
        if self.lst_dic1.listcount() == 0:
            tkMessageBox.showinfo(parent=app,
            title = app.lg.get("winher", "title"),
            message = app.lg.get("winher", "msg12"))
        
        
        return
    
    
    
    def onclicDico(self, i, idwidget):
        u"""
        Sélection d'un dico dans la liste
        """
        
        if idwidget == id(self.lst_dic1):
            self.lab_dic1['text']=self.lst_dic1.getselecteditem()
        else:
            self.lab_dic2['text']=self.lst_dic2.getselecteditem()
        
        if self.lab_dic1['text'] != "" and self.lab_dic2['text'] != "":
            self.bt_make['state'] = 'normal'
        
        return
    

    def listDirDic(self,dicosPath, lstbox):
        u"""
        Remplit une liste de dictionnaires avec le contenu du répertoire des dicos
        """
        
        lstdic=[]
        
        for rootDir, dirs, files in os.walk(dicosPath): 
            for f in files: 
                if os.path.splitext(f)[1].lower() in (".ling", ".dict", ".wb", ".ini", ".csv", ".txt", ".tab", ".xdxf"):
                    if not rootDir.endswith("_res"): # Sauter les répertoires de ressources associées aux dicos
                        lstdic.append(os.path.join(rootDir[len(dicosPath)+1 :],f)) 
        
        lstdic.sort(lambda x,y: cmp(x.lower(),y.lower())) # tri alphabétique insensible à la casse
        
        for f in lstdic:
            lstbox.add(f)
        
        return


    def makeHeritDic(self):
        u"""
        Construit le dictionnaire hérité
        """
        
        # ------------------------------------------------
        # --- Contrôle du chemin du fichier à construire  
        # ------------------------------------------------
        
        dicrep = app.ini.get('DicStorageFolder','') # Répertoire de stockage des dicos
        
        fichpath = os.path.join(dicrep, self.txt_name.get())
        
        if not fichpath.lower().endswith(".ling"):
            fichpath += ".ling"
        
        if os.path.isfile(fichpath): # Le fichier existe déjà > remplacer ?
            r = tkMessageBox.askyesno(parent=self,
                    title = app.lg.get("winher", "title"),
                    message = "'" + fichpath + "' " + app.lg.get("winher", "msg2") )
            if r == False: return
        
        self.bt_make['state']='disabled'
        self.bt_cancel['state']='disabled'
        
        
        # --------------------------------------------------
        # --- Instancier les deux objets dicos à hériter    
        # --------------------------------------------------
        
        self.lab_step['text'] += u"\n"
        self.lab_step['text'] += app.lg.get("winher", "msg3")           # 'Démarrage du traitement global'
        self.lab_step['text'] += u"\n"
        
        
        # --- Instancier le dico 1
        
        self.lab_step['text'] += "(1) " + app.lg.get("winher", "msg4") + " 1..." # Instanciation dico 1
        
        dic1 = lib.mydic.DicObject( fichPath = os.path.join(dicrep, self.lab_dic1['text']),
                                    lgget = app.lg.get,
                                    winparent = self,
                                    prgbar = self.progr,
                                    cachedir = app.appdata.cache )
        
        if dic1.path == "" or dic1.file is None:
            tkMessageBox.showinfo(parent=self,
                title = app.lg.get("winher", "title"),
                message = self.lab_dic1['text'] + u"\n\n" + app.lg.get("winher", "msg13") )
            return # échec de l'instanciation
        
        self.lab_step['text'] += u"\n"
        self.lab_step['text'] += u"> " + app.lg.get("winher", "msg5")   # 'Terminé !'
        
        # Contrôler la protection
        # Si le fichier est protégé > avertir et quitter
        if dic1.protected1 !="" or dic1.protected2 !="":
            self.progr.setValue(-1)
            tkMessageBox.showinfo(parent=self,
                title = app.lg.get("winher", "title"),
                message = self.lab_dic1['text'] + u"\n\n" + app.lg.get("winher", "msg6") )
            self.bt_make['state']='normal'
            self.bt_cancel['state']='normal'
            self.lab_step['text']=""
            return    
        
        
        # ---- Instancier le dico 2
        
        self.lab_step['text'] += u"\n"
        self.lab_step['text'] += "(2) " + app.lg.get("winher", "msg4") + " 2..." # Instanciation dico 2
        
        dic2 = lib.mydic.DicObject( fichPath = os.path.join(dicrep, self.lab_dic2['text']),
                                    lgget = app.lg.get,
                                    winparent = self,
                                    prgbar = self.progr,
                                    cachedir = app.appdata.cache )
        
        if dic2.path == "" or dic1.file is None:
            tkMessageBox.showinfo(parent=self,
                title = app.lg.get("winher", "title"),
                message = self.lab_dic2['text'] + u"\n\n" + app.lg.get("winher", "msg13") )
            return # échec de l'instanciation
        
        self.lab_step['text'] += u"\n"
        self.lab_step['text'] += u"> " + app.lg.get("winher", "msg5")   # 'Terminé !'
        
        # Contrôler la protection
        # Si le fichier est protégé > avertir et quitter
        if dic2.protected1 !="" or dic2.protected2 !="":
            self.progr.setValue(-1)
            tkMessageBox.showinfo(parent=self,
                title = app.lg.get("winher", "title"),
                message = self.lab_dic2['text'] + u"\n\n" + app.lg.get("winher", "msg6") )
            self.bt_make['state']='normal'
            self.bt_cancel['state']='normal'
            return    
        
        # ------------------------------------------
        
        
        sepsign = self.txt_sep.get().strip()
        if sepsign == "":
            sepsign = " " # Espace, par défaut
        
        flagcasse = self.vCasse.get()
        
        
        # -------------------------------------------------------------------------------
        # --- Construire une liste minimale du dico 2 (accélère la recherche ultérieure) 
        # -------------------------------------------------------------------------------
        
        self.lab_step['text'] += u"\n"
        self.lab_step['text'] += u"(3) " + app.lg.get("winher", "msg7") # 'Construire un index temporaire'
        
        words2=[]
        
        # Ne garder que la partie signifiante de l'entrée = jusqu'au premier espace par défaut
        # et mettre en minuscule (optionnel)
        if flagcasse:
            for w in dic2.innerlst:
                words2.append(w.split(sepsign)[0].strip())
        else:
            for w in dic2.innerlst:
                words2.append(w.split(sepsign)[0].strip().lower())
        
        self.lab_step['text'] += u"\n"
        self.lab_step['text'] += u"> " + app.lg.get("winher", "msg5")   # 'Terminé !'
        
        
        # ----------------------------------------------------------------------
        # --- Construire une liste recevant les données du dictionnaire hérité  
        # ----------------------------------------------------------------------
        
        self.lab_step['text'] += u"\n"
        self.lab_step['text'] += u"(4) " + app.lg.get("winher", "msg8") # 'Analyse des données, processus long' 
        
        strHerit=[]
        
        subsep1 = dic1.subsep
        if subsep1 == "" : subsep1=";"
        
        # accélérateurs locaux
        word1get = dic1.innerlst.__getitem__
        data1get = dic1.getdata
        data2get = dic2.getdata
        dic1wcount = dic1.wordcount
        dic2wcount = dic2.wordcount
        
        self.progr.setMax(dic1wcount)
        
        #for i1 in range(200): # durant phase de mise au point 
        for i1 in range(dic1wcount):     # scanner les traductions du dico 1
            
            self.progr.setValue(i1)
            
            traducs1 = data1get(i1)['short'].split(subsep1) # champ des traductions du dico 1 > liste
            
            for traduc in traducs1: # Scanner les traductions élémentaires de chaque champ "traduction"     
                
                # Partie signifiante de la traduction = jusqu'au premier espace par défaut
                if flagcasse:
                    traduc = traduc.split(sepsign)[0].strip()
                else:
                    traduc = traduc.split(sepsign)[0].strip().lower()
                
                # rechercher une concordance de la traduction du dico1
                # dans les entrées du dico2
                
                try:
                    i2 = words2.index(traduc)
                except:
                    pass
                else:# Concordance trouvée ! 
                    t = data2get(i2)['short'].replace("\t","  ")
                    t = t.replace("\r\n","<br>")
                    t = t.replace("\n","<br>")
                    t = t.replace("\r","<br>")
                    strHerit.append(word1get(i1) + "\t" + t)
        
        self.lab_step['text'] += u"\n"
        self.lab_step['text'] += u"> " + app.lg.get("winher", "msg5")   # 'Terminé !'
        
        
        # -------------------------------------------------------
        # --- Convertir la liste en nouveau dictionnaire Ling    
        # -------------------------------------------------------
        
        self.lab_step['text'] += u"\n"
        self.lab_step['text'] += u"(5) " + app.lg.get("winher", "msg9") # 'Construction du dictionnaire hérité...'
        
        strHerit = "\n".join(strHerit)
        
        strLing = lib.mydic.DicObject.strPrelingToStrLing(strPreling=strHerit)
        
        # --- Enregistrer le nouveau fichier
        ff = open(fichpath,"wb")
        ff.write(strLing)
        ff.close()
        
        self.lab_step['text'] += u"\n"
        self.lab_step['text'] += u"> " + app.lg.get("winher", "msg5")   # 'Terminé !'
        self.lab_step['text'] += u"\n"
        self.lab_step['text'] += app.lg.get("winher", "msg10")          # 'Fin du traitement global'
        
        self.update()
        
        
        # -----------------------------------------------------
        # --- Demander pour charger le nouveau dico            
        # -----------------------------------------------------
        
        r = tkMessageBox.askyesno(parent=self,
                    title = app.lg.get("winher", "title"),
                    message = app.lg.get("winher", "msg11") )
        
        if r == False:
            self.destroy()
            return
        
        # --- Charger
        
        try   : app.dic.file.close()
        except: pass
        
        app.loadDico(fichpath, showSplash=True)
        
        app.update()
        
        # app.dic.sortdic()  # Trier le nouveau dictionnaire (inutile si dic 1 est trié au départ)
        
        app.updateMenuDic()
        
        self.destroy()
        
        
        return
    


class WindowAlpha(Toplevel):
    
    u"""
    | Fenêtre de réglage du niveau de transparence (canal alpha) de la          
    | fenêtre principale.                                                       
    """
    
    def __init__(self):
        
        Toplevel.__init__(self)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winalpha", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        self.sl_trans = Scale(self, from_=0, to=20, resolution=1, orient=HORIZONTAL, borderwidth=1, sliderlength=40, length=450, tickinterval=1, width=12)
        self.sl_trans.bind('<ButtonRelease-1>', self.setAlpha)
        self.sl_trans.pack()
        
        Label(self, font='Helvetica 8 normal', text=app.lg.get("winalpha", "warning"), justify=LEFT).pack()
        
        # Afficher le niveau de transparence en cours
        
        try:
            a = app.wm_attributes('-alpha')
            if a == 0:
                v = 20
            else:
                v = int(20 - (20 * a))
            
            self.sl_trans.set(v)
        except:
            pass
        
        return
    
    
    def setAlpha(self,event):
        
        a = (20 - self.sl_trans.get())/20.0
        try:
            app.wm_attributes('-alpha', a)
        except:
            tkMessageBox.showwarning(parent=self,
                    title="Linguae",
                    message=app.lg.get("winalpha", "fail"))
            return
        
        app.lift()
        
        # Nb : ne pas mémoriser la valeur dans l'ini,
        # car une fenêtre trop transparente est dure à récupérer au lancement...
        
        return
    


class WindowReverse(Toplevel):
    
    u"""
    | Fenêtre de construction du dictionnaire inverse                           
    | avec choix du séparateur des traductions et du chemin/nom de fichier      
    """
    
    
    def __init__(self):
        
        
        # ---------------------------------------------------------
        # --- Contrôles préliminaires des flags du dico source :   
        # ---       flag isReversedic (False par défaut)           
        # ---       flag doReversedic (True par défaut)            
        # ---------------------------------------------------------
        
        msg = ""
        
        # Vérifier si le dictionnaire est déjà un dico inverse
        if app.dic.isReverseDic:
            msg = app.lg.get("winrev", "msg1") + "\n\n"
        
        # Vérifier si les données sont prévues pour être inversées
        if not app.dic.doReverseDic:    
            msg += app.lg.get("winrev", "msg2") + "\n\n"
        
        # Prévenir..    
        if msg != "":    
            msg += app.lg.get("winrev", "msg3")
            r = tkMessageBox.askyesno(parent=app,
                    title = app.lg.get("winrev", "title"),
                    message = msg)
            if r == False: return
        
        
        # ----------------------------------
        # --- Mise en place de la fenêtre   
        # ----------------------------------
        
        Toplevel.__init__(self)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        
        self.geometry('+' + left + '+' + top)
        self.title(app.lg.get("winrev", "title"))
        self.resizable(width=NO, height=NO)
        self.grab_set()             # fenêtre modale
        self.transient(master=app)  # fenêtre dépendante
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        
        
        ww = 80
        r = 0 # rangée pour grid
        
        # Bouton interface avancée>simplifiée
        self.bt_adv = Button(self, text="", command=self.seeadvanced)
        self.bt_adv.grid(row=r, column=0, sticky="e", padx=10, pady=3)
        
        # --------------------------------------------------------
        # --- Frame du type (format) de fichier du dico inverse   
        # --------------------------------------------------------
        r += 1
        self.fr_type=LabelFrame(self, text=app.lg.get("winrev", "s1"))
        self.fr_type.grid(row=r,column=0)
        
        Label(self.fr_type,width=ww).grid(row=0, column=0) #dimensionneur
        
        self.vFileType = StringVar()
        RB_ling = Radiobutton(self.fr_type, text="Ling", variable=self.vFileType, value="ling", command=self.__onclicFileType)
        RB_ling.grid(row=0,column=0, padx=5, sticky='W')
        RB_dict = Radiobutton(self.fr_type, text="Dict", variable=self.vFileType, value="dict", command=self.__onclicFileType)
        RB_dict.grid(row=1,column=0, padx=5, sticky='W')
        RB_xdxf = Radiobutton(self.fr_type, text="XDXF", variable=self.vFileType, value="xdxf", command=self.__onclicFileType)
        RB_xdxf.grid(row=2,column=0, padx=5, sticky='W')
        RB_wb = Radiobutton(self.fr_type, text="WB", variable=self.vFileType, value="wb", command=self.__onclicFileType)
        RB_wb.grid(row=3,column=0, padx=5, sticky='W')
        RB_csv = Radiobutton(self.fr_type, text=app.lg.get("winrev", "s2"), variable=self.vFileType, value="csv", command=self.__onclicFileType)
        RB_csv.grid(row=4,column=0, padx=5, sticky='W')
        
        
        # Si le fichier est protégé > avertir des limitations
        if app.dic.protected1 !="" or app.dic.protected2 !="":
            tkMessageBox.showinfo(parent=self,
                title = app.lg.get("winrev", "title"),
                message = app.lg.get("winrev", "msg4"))
            self.vFileType.set('ling')
            RB_dict['state']='disabled'
            RB_xdxf['state']='disabled'
            RB_wb['state']='disabled'
            RB_csv['state']='disabled'
            
        # Si le fichier est non protégé : préselectionner le même format que le dico d'origine
        elif app.dic.type.startswith('wb'):
            self.vFileType.set('wb')
        elif app.dic.type.startswith('dict'):
            self.vFileType.set('dict')
        elif app.dic.type.startswith('xdxf'):
            self.vFileType.set('xdxf')
        elif app.dic.type.startswith('csv'):
            self.vFileType.set('csv')
        else:
            self.vFileType.set('ling')
        
        
        # ---------------------------
        # --- Frame du séparateur    
        # ---------------------------
        
        r +=1
        self.fr_sp=LabelFrame(self, text=app.lg.get("winrev", "s3"))
        self.fr_sp.grid(row=r, column=0, padx=5, pady=5)
        
        Label(self.fr_sp, width=ww, height=2).grid(row=0, column=0, columnspan=10) #dimensionneur
        
        self.vSp = StringVar()
        Radiobutton(self.fr_sp, text=app.lg.get("winrev", "s4"), variable=self.vSp, value=";").grid(row=0, column=0, sticky='W')
        Radiobutton(self.fr_sp, text=app.lg.get("winrev", "s5"), variable=self.vSp, value=",").grid(row=1, column=0, sticky='W')
        
        # présélectionner le séparateur en fonction du format de dico
        if app.dic.type.startswith('wb'):
            self.vSp.set(",")
        else:
            self.vSp.set(";")
        
        
        # --------------------------------
        # --- Frame du mode d'inversion   
        # --------------------------------
        
        r +=1
        self.fr_md=LabelFrame(self, text=app.lg.get("winrev", "s6"))
        self.fr_md.grid(row=r, column=0, padx=5, pady=5)
        
        Label(self.fr_md, width=ww, height=2).grid(row=0, column=0, columnspan=10) #dimensionneur
        
        self.vInv = StringVar()
        self.RB_std=Radiobutton(self.fr_md, text=app.lg.get("winrev", "s7"), variable=self.vInv, value="std")
        self.RB_std.grid(row=0, column=0, sticky='W')
        self.RB_lg=Radiobutton(self.fr_md, text=app.lg.get("winrev", "s8"), variable=self.vInv, value="lg")
        self.RB_lg.grid(row=1, column=0, sticky='W')
        self.vInv.set("std")
        
        
        # ---------------------------
        # --- Frame du répertoire    
        # ---------------------------
        
        r +=1
        fr_rep=LabelFrame(self, text=app.lg.get("winrev", "s9"))
        fr_rep.grid(row=r, column=0, padx=4, pady=2)
        
        Label(fr_rep, width=ww, height=2).grid(row=0, column=0, columnspan=10) #dimensionneur
        
        # Sélecteur de répertoire
        self.fb_folder=lib.myfldbrw.FolderBrowser(fr_rep, width=75)
        self.fb_folder.grid(row=0, column=0, padx=5, sticky='WN', pady=5)
        
        self.vChkDicFolder = IntVar()
        ChkDicFolder=Checkbutton(fr_rep, text=app.lg.get("winrev", "s11"), variable=self.vChkDicFolder, command=self.onclicChkDicFolder)
        ChkDicFolder.grid(row=1, column=0, sticky='WN')
        
        
        # Présélectionner le répertoire de stockage des dicos
        dp = app.ini.get('DicStorageFolder','')
        if dp != "":
            ChkDicFolder.select()
            self.fb_folder.config(initialdir = dp,
                                  state = 'disabled')
        else:
            ChkDicFolder['state']='disabled'
        
        
        # -------------------------------------------------------
        # --- Frame du nom de fichier (ou de sous-rep. si xdxf)  
        # -------------------------------------------------------
        
        r +=1
        fr_name=LabelFrame(self, text=app.lg.get("winrev", "s12"))
        fr_name.grid(row=r, column=0, padx=4, pady=2)
        
        Label(fr_name,width=ww, height=4).grid(row=0, column=0) #dimensionneur
        
        self.txt_name=Entry(fr_name, width=35, background='white')
        self.txt_name.grid(row=0, column=0)
        
        
        if app.dic.reverseDicFileName != "":
            # Le dico-maître contient le nom de fichier du dico inverse : on l'affiche
            self.txt_name.insert(END, os.path.splitext(app.dic.reverseDicFileName)[0])
        else:
            
            if self.vFileType.get() == 'xdxf':
                # On construit le nom de dico inverse à partir du nom du répertoire du dico maître + "_rev"
                rep = os.path.dirname(app.dic.path) + "_rev"
                rep = rep.replace ("\\", "/")
                rep = rep.split("/")[-1]
                self.txt_name.insert(END, rep)
            else:
                # On construit le nom de dico inverse à partir du nom du dico maître + "_rev"
                self.txt_name.insert(END, os.path.splitext(os.path.basename(app.dic.path))[0] + "_rev")
        
        
        # -------------------------
        # --- Frame des Boutons    
        # -------------------------
        
        r +=1
        fr_but=Frame(self)
        fr_but.grid(row=r, column=0, columnspan=10, padx=4, pady=2)
        
        Button(fr_but, image=app.imglst.reverse, compound=LEFT, text="  " + app.lg.get("winrev", "s13"), width=100, padx= 10, command=self.makeRevDic).grid(row=0, column=0, pady=8, padx=10)
        Button(fr_but, image=app.imglst.exit, compound=LEFT, text="  " + app.lg.get("g", "close"), width=100, padx= 10, command=self.destroy).grid(row=0, column=1, pady=8, padx=10)
        Button(fr_but, image=app.imglst.hlp, compound=LEFT, text="  " + app.lg.get("g", "hlp"), width=90, padx= 7,command=lambda: app.showHelp("inverse")).grid(row=0, column=2, pady=8, padx=10)
        
        # --- Barre de progression
        r +=1
        self.progr = lib.myprogbr.ProgressBar(self, width=380)
        self.progr.grid(row=r, column=0, columnspan=4, pady=5)
        self.progr.grid_remove()
        
        # ---- Interface simplifiée par défaut
        self.bt_adv['text'] = "<<"
        self.seeadvanced()
        
        return


    def seeadvanced(self):
        
        u"""
        | Afficher/masquer l'interface avancée                                  
        """
        
        # Afficher
        if self.bt_adv['text'].find(">>") >= 0:
            
            self.fr_type.grid()
            self.fr_sp.grid()
            self.fr_md.grid()
            self.bt_adv['text'] = "<< " + app.lg.get("g", "basic") +" "
            
        # Masquer    
        else:
            
            self.fr_type.grid_remove()
            self.fr_sp.grid_remove()
            self.fr_md.grid_remove()
            self.bt_adv['text'] = " " + app.lg.get("g", "adv") +" >> "
        
        return
    
    
    def __onclicFileType(self):
        
        u"""
        | (appelé par 'command' des radiobuttons)                               
        | Clic sur les options de format de fichier cible                       
        """
        
        # Activer/désactiver les cases du mode d'inversion
        if self.vFileType.get() in ("ling", "xdxf", "dict"):
            self.RB_std['state'] = "normal"
            self.RB_lg['state'] = "normal"
        else:
            self.vInv.set('std')
            self.RB_std['state'] = "disabled"
            self.RB_lg['state'] = "disabled"
        return


    def onclicChkDicFolder(self):
        
        u"""
        | Clic sur la case à cocher 'utiliser le dossier de stockage des        
        | dictionnaires'                                                        
        """
        
        if self.vChkDicFolder.get() == 1:
            self.fb_folder.config(initialdir = app.ini.get('DicStorageFolder',''),
                                  state = 'disabled')
        else:
            self.fb_folder.config(state = 'normal')
        
        return

    

    def makeRevDic(self):
        
        u"""
        | Construire le dictionnaire inverse                                    
        """
        
        newDicType = self.vFileType.get()
        
        # ----------------------------------------------------------------
        # --- Confectionner le chemin du fichier du dictionnaire inverse  
        # ----------------------------------------------------------------
        
        if newDicType == 'xdxf':
            
            repxdxf = os.path.join(self.fb_folder.getpath(), self.txt_name.get())
            fichpath = os.path.join(repxdxf, "dict.xdxf")
            
        else :
            
            fichpath = os.path.join(self.fb_folder.getpath(), self.txt_name.get()) + "." + newDicType
        
        
        # Avertir si un fichier existe déjà sous ce nom
        if os.path.isfile(fichpath):
            r = tkMessageBox.askyesno(parent=self,
                    title = app.lg.get("winrev", "title"),
                    message = app.lg.get("winrev", "msg5") )
            if r == False:
                return
            else:
                # modifier les droits pour permettre son écrasement
                try   : os.chmod(fichpath, 0777)
                except: pass
        
        
        # -------------------------------------------------------
        # --- Construire un pyDictionnaire inverse temporaire    
        # --- à partir des traductions courtes                   
        # --- (clefs et données du pyDictionnaire en Utf-8)      
        # -------------------------------------------------------
        
        self['cursor']='watch'
        app['cursor']='watch'
        
        self.progr.grid()
        self.progr.setMax(app.dic.lstbox.size())
        
        # (variables locales pour accélérer la boucle)
        getdata = app.dic.getdata 
        lstget = app.dic.lstbox.get
        
        sp = self.vSp.get()
        if sp == ',': sp = ', '
        if sp == ';': sp = ' ; '
        
        if self.vInv.get() == "lg":
            flagAddInfo = True
        else:
            flagAddInfo = False
        
        data = {}       # pyDictionnaire des données de l'entrée
        dicRev = {}     # pyDictionnaire global inverse
        dicInfo = {}    # pyDictionnaire global des infos (optionnel)
        
        for i in range(app.dic.lstbox.size()):      # Scanner la liste des entrées du dico source
            
            self.progr.setValue(i+1)                # barre de progression
            
            data = getdata(i)                       # extraire les données de l'entrée
            
            if 'r' in data['tok'].split(";"):       # sauter les entrées marquées comme "à ne pas inverser"
                continue
            
            trads = data['short'].strip(sp)         # Nettoyer éventuels séparateurs trainant en tête ou queue
            trads = trads.split(sp)                 # Traductions courtes de l'entrée (séparées par 'sp')
            
            for trad in trads:                      # Scanner les traductions individuelles de l'entrée
                
                trad = trad.strip()
                try:
                    trad = trad.encode('utf-8')     # 'Try+pass' car le retour est parfois ascii et non utf-8
                except:
                    pass
                
                if dicRev.has_key(trad):            # La traduction est présente > on complète avec l'entrée du dico source
                    wd = sp + lstget(i)
                    wd = wd.encode('utf-8') 
                    dicRev[trad] += wd
                else:                               # La traduction est absente > on ajoute l'entrée du dico source
                    wd = lstget(i).encode('utf-8')
                    dicRev[trad] = wd
                
                
                if flagAddInfo:                     # Prise en compte optionnelle des traductions longues de l'entrée
                    
                    if dicInfo.has_key(trad): 
                        dicInfo[trad] += "\n......\n" + data['long']
                    else:
                        dicInfo[trad] = data['long']
        
        
        # ------------------------------------------------------------------------------
        # --- Convertir le pyDictionnaire inverse en chaîne Dictionnaire (aiguillage)   
        # ------------------------------------------------------------------------------
        
        cp1 = app.dic.encoding1
        cp2 = app.dic.encoding2
        
        
        strfich = "" # Cette chaîne recevra le contenu du fichier après inversion
        
        if newDicType == "ling":
        
            strFich = self.__doLing(dicRev, dicInfo, flagAddInfo)
        
        elif newDicType == "csv":
            
            strFich = self.__doCSV(dicRev, cp=cp1)
        
        elif newDicType == "xdxf":
            
            strFich = self.__doXDXF(dicRev, repxdxf, dicInfo, flagAddInfo)
        
        elif newDicType == "wb":
            
            # Demander un nouvel encodage si la source est en UTF
            if cp1.lower().startswith('utf') or cp2.lower().startswith ('utf') or 1:
                cp2 = tkSimpleDialog.askstring(
                    title = app.lg.get("winrev", "msg6") + " " + app.lg.get("g", "msg5"),
                    prompt = app.lg.get("winrev", "msg7") + "\n",
                    initialvalue = "cp1252")
                if not cp2:
                    return
            
                cp1 = tkSimpleDialog.askstring(parent=self,
                        title = app.lg.get("winrev", "msg6") + " " + app.lg.get("g", "msg6"),
                        prompt = app.lg.get("winrev", "msg9") + "\n",
                        initialvalue = "cp1252")
                if not cp1:
                    return
            
            strFich = self.__doWB(dicRev, cp1=cp1, cp2=cp2)
        
        elif newDicType == "dict":
            
            strFich = self.__doDict(dicRev, fichpath, dicInfo, flagAddInfo)
        
        
        if strFich.startswith("!"):
            self['cursor']=''
            app['cursor']=''
            tkMessageBox.showwarning(parent=self,
                    title=app.lg.get("winrev", "msg10"),
                    message=strFich)
            return
        
        
        
        # ----------------------------------------------
        # --- Enregistre le nouveau fichier inversé     
        # ----------------------------------------------
        
        ff = open(fichpath, 'wb')
        ff.write(strFich)
        ff.close()
        
        
        # ----------------------------------------------------------------
        # --- Mémoriser le nom du fichier inverse dans le fichier source  
        # --- si le format source le permet                               
        # ----------------------------------------------------------------
        
        app.dic.reverseDicFileName = self.txt_name.get().encode('utf-8') + "." + newDicType
        
        if app.dic.type.startswith("ling"):
            
            strMaster = app.dic.toStrPreling()
            
            if strMaster[0] == "!": # Echec
                tkMessageBox.showwarning(parent=self,
                    title = app.lg.get("winrev", "title"),
                    message = app.lg.get("winrev", "msg11") + "\n\n" + strMaster)
            
            else: # ok, on continue
                
                strLingMaster = lib.mydic.DicObject.strPrelingToStrLing(strPreling=strMaster)
                
                # NB il n'est pas nécessaire de recharger le dico source
                app.dic.file.close()
                
                ff = open(app.dic.path,'wb')
                ff.write(strLingMaster)
                ff.close()
                
                app.dic.file = open(app.dic.path, 'rb')
            
        else:
            pass # pour le moment, aucun autre format source ne le permet
        

        # ---------------------------------------------------------------
        # -- Recharge le dictionnaire avec le nouveau fichier inversé    
        # ---------------------------------------------------------------
        
        try   : app.dic.file.close()
        except: pass
        
        app.loadDico(fichpath, cp1=cp2, cp2=cp1, showSplash=True)
        
        app.update()
        
        app.dic.sortdic()       # Trier le nouveau dictionnaire inversé
        
        app.updateMenuDic()     # Mettre à jour le menu des dictionnaires
        
        
        tkMessageBox.showinfo(parent=self,
                title = app.lg.get("winrev", "title"),
                message = app.lg.get("winrev", "msg12") )
        
        self.destroy()
        
        return
    
    
    
    def __doCSV(self, dicRev, cp):
        
        u"""
        | Convertit le pyDictionnaire inverse en chaîne csv                     
        """
        
        strFich = ""
        
        for k, x in dicRev.items():
        # k = entrée, x = traduction
            
            k = k.decode('utf-8')
            try:
                k = k.encode(cp)
            except:
                return app.lg.get("winrev", "s14")
            
            x = x.decode('utf-8')
            try:    
                x = x.encode(cp) 
            except:
                return app.lg.get("winrev", "s14")
                
            strFich += k + "\t" + x + "\n"
        
        
        return strFich
    
    
    
    def __doLing(self, dicRev, dicInfo, flagAddInfo=False):
        
        u"""
        | Convertit le pyDictionnaire inverse en chaîne Ling                    
        | (conversion en chaîne PreLing puis > Ling)                            
        |                                                                       
        | ARGUMENTS :                                                           
        |   'dicRev'        : pyDictionnaire inverse.                           
        |                                                                       
        |   'dicInfo'       : pyDictionnaire des infos/traductions longues      
        |                     associées (non inversées).                        
        |                                                                       
        |   'flagAddInfo'   : flag permettant la prise en compte ou non des     
        |                     traductions longues contenues dans  'dicInfo'.    
        """
        
        
        # --------------------------------------------
        # --- Confection de la chaîne Preling brute   
        # --------------------------------------------
        
        strPreling = ""
        
        for k, x in dicRev.items():
        # k = entrée, x = traduction
            
            if flagAddInfo:
                strPreling += k + "\t" + x + "\t" + dicInfo[k].replace("\n", "<br>") + "\n"
            else:
                strPreling += k + "\t" + x + "\n"
           
        #app.clipboard_clear()
        #app.clipboard_append(strPreling)
        
        
        # --------------------------------------------
        # --- Ajout du Header à la chaîne Preling     
        # --------------------------------------------
        
        hdr = "::isReverseDic=True\n::doReverseDic=False\n"
        hdr = hdr.encode('utf-8')
        
        # Nom du nouveau dico
        if app.dic.reverseDicName != "":
            hdr += "::dicName=" + app.dic.reverseDicName + "\n"
        elif app.dic.langName1 != "":
            hdr += "::dicName=" + app.dic.langName2 + " - " + app.dic.langName1 + "\n"
        else:
            hdr += "::dicName=" + app.lg.get("winrev", "s15") + "\n"
        
        # Nom de fichier du dico "inverse" ( = nom du dico-source)
        hdr += "::reverseDicFileName=" + os.path.basename(app.dic.path).encode('utf-8') + "\n"
        
        # N° de version du nouveau dico
        if app.dic.dicVersionNumber != "":
            hdr += "::dicVersionNumber=" + app.dic.dicVersionNumber + " (inverse)\n"
        else:
            hdr += "::dicVersionNumber=1.0 (inverse)\n"
        
        # Paramétres de tri (on les permutte)
        hdr += "::sortEquPatterns=" + '","'.join(app.dic.sortEquPatternsRev) + '"\n' 
        hdr += "::sortEquPatternsRev=" + '","'.join(app.dic.sortEquPatterns) + '"\n'
        
        # Autres données d'en-tête
        hdr += "::dicUrl=" + app.dic.dicUrl + "\n"
        hdr += "::langName1=" + app.dic.langName2 + "\n"
        hdr += "::langName2=" + app.dic.langName1 + "\n"
        hdr += "::langIso1=" + app.dic.langIso2 + "\n"
        hdr += "::langIso2=" + app.dic.langIso1 + "\n"
        hdr += "::langNameUser=" + app.dic.langNameUser + "\n"
        hdr += "::langIsoUser=" + app.dic.langIsoUser + "\n"
        hdr += "::langFamily1=" + app.dic.langFamily2 + "\n"
        hdr += "::langFamily2=" + app.dic.langFamily1 + "\n"
        hdr += "::dicStatus=" + app.lg.get("winrev", "s16") + "\n"
        hdr += "::showDicStatus=True" + "\n"
        hdr += "::copyright=" + app.lg.get("winrev", "s18") + "\n"
        hdr += "::dicInfo=" + app.lg.get("winrev", "s17") + "\n"
        hdr += "::showDicInfo=True" + "\n"
        hdr += "::displayFontName1=" + app.dic.displayFontName2 + "\n"
        hdr += "::displayFontName2=" + app.dic.displayFontName2 + "\n"
        
        
        # Protection des données du fichier ?
        if app.dic.protected1 != "":
            hdr += '::protected2=Linguae' +"\n"
        if app.dic.protected1 != "":
            hdr += '::protected1=Linguae' +"\n"
        
        
        # Ajouter le header
        strPreling = hdr + strPreling
        
        
        # ------------------------------------------------
        # --- Ajout des Icônes à la chaîne Preling        
        # ------------------------------------------------
        
        # on inverse aussi les icônes !
        if app.dic.img2b64 !="" :
            strPreling += "**img1begin:" + app.dic.img2type + "\n" + app.dic.img2b64 + "\n**img1end\n"
        
        if app.dic.img1b64 !="" :
            strPreling += "**img2begin:" + app.dic.img1type + "\n" + app.dic.img1b64 + "\n**img2end\n"
        
        
        # ----------------------------------------------------
        # --- Convertir en chaîne ling et retourner celle-ci  
        # ----------------------------------------------------
        
        
        strFich = lib.mydic.DicObject.strPrelingToStrLing(strPreling=strPreling)
        
        
        return strFich
    
    
    def __doXDXF(self, dicRev, repxdxf, dicInfo, flagAddInfo=False):
        u"""
        Convertit le pyDictionnaire inverse en chaîne XDXF
        
        dicRev      : pyDictionnaire inverse
        repxdxf     : répertoire du dico xdxf cible
        dicInfo     : pyDictionnaire des infos/traductions longues associées (non inversées)
        flagAddInfo : flag permettant la prise en compte ou non de dicInfo
        """
        
        strFich = '<?xml version="1.0" encoding="UTF-8" ?>\n<xdxf lang_from="" lang_to="" format="visual">\n'
        
        self.progr.setValue(0)
        self.progr.setMax(len(dicRev))
        
        wc = 1
        for k, x in dicRev.items():
        # k = entrée, x = traduction
            
            self.progr.setValue(wc)
            
            if flagAddInfo and dicInfo[k] != "":
                try:
                    strFich += "<ar><k>" + k + "</k>\n" + x + "\n-------\n" + dicInfo[k] + "</ar>\n"
                except:
                    return app.lg.get("winrev", "s14")
            
            else:
                
                try:
                    strFich += "<ar><k>" + k + "</k>\n" + x + "</ar>\n"
                except:
                    return app.lg.get("winrev", "s14")
            
            wc += 1
            
        
        strFich += "</xdxf>"
        
        if not os.path.isdir(repxdxf):
            os.mkdir(repxdxf) # Créer le répertoire du dico
        
        return strFich


    
    def __doWB(self, dicRev, cp1, cp2):
        u"""
        Convertit le pyDictionnaire inverse en chaîne WB
        """
        
        strFich = ""
        
        self.progr.setValue(0)
        
        wc = 1
        for k, x in dicRev.items():
        # k = nouvelle entrée, x = nouvelle traduction
            
            self.progr.setValue(wc)
            
            k = k.decode('utf-8')
            try:
                k = k.encode(cp2)
            except:
                print map(ord,k)
                return app.lg.get("winrev", "s14") + cp2 + "' (chp1/" + str(wc) + ") ! "
            
            k = k[:30].ljust(31,'\0')
            
            x = x.decode('utf-8')
            try:    
                x = x.encode(cp1) 
            except:
                print map(ord,x)
                return app.lg.get("winrev", "s14") + cp1 + "' (chp2/" + str(wc) + ")! "
            
            x = x [:50].ljust(53,'\0')
                
            strFich += k + x
            
            wc += 1
        
        return strFich
    
    
    
    def __doDict(self, dicRev, fichpath, dicInfo, flagAddInfo=False):
        u"""
        Convertit le pyDictionnaire inverse en chaînes Dict
        Enregistre le *ifo et le *idx et retourne la chaîne du *dict
        
        dicInfo     : pyDictionnaire des infos/traductions longues associées (non inversées)
        flagAddInfo : flag permettant la prise en compte ou non de dicInfo
        """
        
        radicfich = os.path.splitext(fichpath)[0]   # Radical des différents fichiers Dict
      
        
        # --------------------------------------
        # --- Scanner le pyDictionnaire         
        # --------------------------------------
        
        decal = 0
        wc = 0
        strdict = []
        stridx = []
        
        for k, x in dicRev.items():
            
            wc += 1
            
            if flagAddInfo and dicInfo[k] != "":
                x = x + "\n-------\n" + dicInfo[k]
            
            strdict.append(x)                       # Ajouter la traduction dans le *.dict
            stridx.append(k + '\0')                 # Ajouter l'entrée dans le *.idx
            
            stridx.append(numToStr32(decal))        # Ajouter le décalage (image chaîne en 32 bits) dans le *.idx
            stridx.append(numToStr32(len(x)))       # Ajouter la longueur de la traduction (image chaîne en 32 bits) dans le *.idx
            
            decal = decal + len(x)                  # Décalage (offset) de la traduction suivante
            
        
        # ---------------------------------------------
        # --- Enregistrer le fichier *idx              
        # ---------------------------------------------
        
        ff = open(radicfich + ".idx", 'wb')         # Enregistrer le fichier *.idx
        ff.write("".join(stridx))
        ff.close()
        
        
        # ------------------------------------------------
        # --- Construire et enregistrer le fichier *.ifo  
        # ------------------------------------------------
        
        t ="StarDict's dict ifo file\nversion=2.4.2\nbookname=" + os.path.basename(radicfich) +\
        "\nwordcount=" + str(wc) +\
        "\nidxfilesize=" + str(os.path.getsize(radicfich + ".idx")) +\
        "\nsynwordcount=\nsametypesequence=m\nidxoffsetbits=32\nauthor=\nemail=\nwebsite=\ndescription=\ndate=\n"
        
        try:
            t = t.encode('utf-8')
        except:
            return app.lg.get("winrev", "s19") # ("! Echec d'encodage utf-8 dans le fichier *.ifo !")
        
        ff = open(radicfich + ".ifo", 'wb')
        ff.write(t)
        ff.close()
        
        # ---------------------------------------------
        # --- Retourner la chaîne *dict                
        # ---------------------------------------------
        
        strdict = "".join(strdict)
        
        return strdict
    
    

class WindowUnicode(Toplevel):
    
    u"""
    | Fenêtre d'affichage des caractères Unicode d'une police donnée            
    | Permet la confection d'une chaîne qui est copiée dans le presse-papiers   
    """

    def __init__(self, ifont=0):
        u"""
        Mise en place de l'interface graphique
        ifont : 1 = police langue 1 / 2 = police langue 2
        """
        
        
        Toplevel.__init__(self)
        
        # Placement relatif à la fenêtre principale
        left = str(int(app.geometry().split('+')[1])+20)
        top = str(int(app.geometry().split('+')[2])+40)
        self.geometry('+' + left + '+' + top)
        
        self.title(app.lg.get("winuni", "title")) # ("Table de caractères UNICODE")
        self.resizable(width=NO, height=NO)
        try   : self.iconbitmap(app.icone)           
        except: pass
        self.focus_set()
        
        
        # Liste des sections
        self.lst_mnu = lib.myscrlst.ScrolledList(self, width=35, height=35, onclic=self.seeTable)
        self.lst_mnu.grid(row=0, column=0, rowspan=10)
        
        
        # Frame des options de police
        fr_font=Frame(self, borderwidth=2, relief=GROOVE)
        fr_font.grid(row=0, column=1, pady=5)
        
        self.vFnt = IntVar()
        opt_lg1 = Radiobutton(fr_font, text=app.lg.get("winuni", "s1"), variable=self.vFnt, value=1) # ("Police de la langue source")
        opt_lg1.grid(row=0, column=0, sticky='W', padx=10)
        opt_lg2 = Radiobutton(fr_font, text=app.lg.get("winuni", "s2"), variable=self.vFnt, value=2) # ("Police de la langue cible")
        opt_lg2.grid(row=0, column=1, sticky='W', padx=10)
        if ifont > 0:
            self.vFnt.set(ifont)
        opt_lg1.bind('<ButtonRelease-1>', self.swapLang)
        opt_lg2.bind('<ButtonRelease-1>', self.swapLang)
        
        
        Label(self, width=90, height=32).grid(row=1, column=1) # dimensionneur
        
        # Frame droit central
        self.fr_D = Frame(self)
        self.fr_D.grid(row=1, column=1, sticky='N')
        Label(self.fr_D, width=90).grid(row=0, column=0, sticky='N') # dimensionneur
        Label(self.fr_D, text=app.lg.get("winuni", "s4"), justify=LEFT, background='black', foreground='white').grid(row=0, column=0, pady=5) # (avertissement si police ne prenant pas en charge tous les caractères)
        
        # Frame des caractères
        self.fr_chr = Frame(self.fr_D, borderwidth=2, relief=GROOVE)
        self.fr_chr.grid(row=1, column=0, padx=4, pady=4)
        Label(self.fr_chr, text=app.lg.get("winuni", "s3"), width=70, height=10).grid(row=0, column=0, rowspan=10, columnspan=10) # ("Choisissez une sous-table dans la liste")
        
        # Frame de saisie
        fr_edit = Frame(self)
        fr_edit.grid(row=2, column=1, sticky='S')
        
        Label(fr_edit, text=app.lg.get("winuni", "s5") + " ").grid(row=0, column=0) # ("Double-cliquez sur un caractère pour l'ajouter ")
        
        # Case de la chaîne
        self.txt_str = Entry(fr_edit, width=25)
        self.txt_str.grid(row=0, column=1, sticky='S')
        
        Button(fr_edit, text=" " + app.lg.get("g", "cpy") + " ", command=self.copyStr).grid(row=0, column=2) # Copier
        Button(fr_edit, image=app.imglst.hlp, compound=LEFT, text=" "+ app.lg.get("g", "hlp"), width=40, padx=8,command=lambda: app.showHelp("chartab")).grid(row=0, column=3, padx=10)
        
        # ----
        
        self.loadUnicodeMenu() # Remplir la liste-menu
        
        return


    def swapLang(self,event):
        u"""
        Clic sur options de changement de langue entrées/notices
        """
#        # Compenser décalage évènement release et modif de la tkVariable
#        if self.vFnt.get() == 2:
#            self.vFnt.set(1)
#        else:
#            self.vFnt.set(2)
        
        # ---
        self.seeTable(self.lst_mnu.getselectedindex(), self.lst_mnu)
        
        
        return


    def loadUnicodeMenu(self):

        # --------------------------------------------------
        # --- "0000 FFFF Plan multilingue de base (BMP)"    
        # --------------------------------------------------
        
        self.lst_mnu.add("0000 007F Latin de base")
        #self.lst_mnu.add("0080 009F Non-utilisé")
        self.lst_mnu.add("00A0 00FF Supplément Latin-1")
        self.lst_mnu.add("0100 017F Latin étendu A")
        self.lst_mnu.add("0180 024F Latin étendu B")
        self.lst_mnu.add("0250 02AF Alphabet phonétique international")
        self.lst_mnu.add("02B0 02FF Lettres modificatives avec chasse")
        self.lst_mnu.add("0300 036F Diacritiques")
        self.lst_mnu.add("0370 03FF Grec et copte")
        self.lst_mnu.add("0400 04FF Cyrillique")
        self.lst_mnu.add("0500 052F Supplément cyrillique")
        self.lst_mnu.add("0530 058F Arménien")
        self.lst_mnu.add("0590 05FF Hébreu")
        self.lst_mnu.add("0600 06FF Arabe")
        self.lst_mnu.add("0700 074F Syriaque")
        self.lst_mnu.add("0780 07BF Thâna")
        self.lst_mnu.add("0900 097F Dévanâgarî")
        self.lst_mnu.add("0980 09FF Bengali")
        self.lst_mnu.add("0A00 0A7F Gourmoukhî")
        self.lst_mnu.add("0A80 0AFF Goudjerate")
        self.lst_mnu.add("0B00 0B7F Oriya")
        self.lst_mnu.add("0B80 0BFF Tamoul")
        self.lst_mnu.add("0C00 0C7F Télougou")
        self.lst_mnu.add("0C80 0CFF Kannara")
        self.lst_mnu.add("0D00 0D7F Malayalam")
        self.lst_mnu.add("0D80 0DFF Singhalais")
        self.lst_mnu.add("0E00 0E7F Thai")
        self.lst_mnu.add("0E80 0EFF Lao")
        self.lst_mnu.add("0F00 0FFF Tibétain")
        self.lst_mnu.add("1000 109F Birman")
        self.lst_mnu.add("10A0 10FF Géorgien")
        self.lst_mnu.add("1100 11FF Jamos hangûl")
        self.lst_mnu.add("1200 137F Éthiopien")
        self.lst_mnu.add("13A0 13FF Chérokî")
        self.lst_mnu.add("1400 167F Syllabaires autochtones canadiens unifiés")
        self.lst_mnu.add("1680 169F Ogam")
        self.lst_mnu.add("16A0 16FF Runes")
        self.lst_mnu.add("1700 171F Tagalog ou tagal")
        self.lst_mnu.add("1720 173F Hanounóo")
        self.lst_mnu.add("1740 175F Bouhide")
        self.lst_mnu.add("1760 177F Tagbanoua")
        self.lst_mnu.add("1780 17FF Khmer")
        self.lst_mnu.add("1800 18AF Mongol")
        self.lst_mnu.add("1900 194F Limbou")
        self.lst_mnu.add("1950 197F Taï-le")
        self.lst_mnu.add("19E0 19FF Symboles khmers")
        self.lst_mnu.add("1D00 1D7F Supplément phonétique")
        self.lst_mnu.add("1E00 1EFF Latin étendu additionnel")
        self.lst_mnu.add("1F00 1FFF Grec étendu")
        self.lst_mnu.add("2000 206F Ponctuation générale")
        self.lst_mnu.add("2070 209F Exposants et indices")
        self.lst_mnu.add("20A0 20CF Symboles monétaires")
        self.lst_mnu.add("20D0 20FF Signes combinatoires pour symboles")
        self.lst_mnu.add("2100 214F Symboles de type lettre")
        self.lst_mnu.add("2150 218F Formes numérales")
        self.lst_mnu.add("2190 21FF Flèches")
        self.lst_mnu.add("2200 22FF Opérateurs mathématiques")
        self.lst_mnu.add("2300 23FF Signes techniques divers")
        self.lst_mnu.add("2400 243F Pictogrammes de commande")
        self.lst_mnu.add("2440 245F Reconnaissance optique de caractères")
        self.lst_mnu.add("2460 24FF Alphanumériques cerclés")
        self.lst_mnu.add("2500 257F Filets")
        self.lst_mnu.add("2580 259F Pavés")
        self.lst_mnu.add("25A0 25FF Formes géométriques")
        self.lst_mnu.add("2600 26FF Symboles divers")
        self.lst_mnu.add("2700 27BF Casseau")
        self.lst_mnu.add("27C0 27EF Divers symboles mathématiques - A")
        self.lst_mnu.add("27F0 27FF Supplément A de flèches")
        self.lst_mnu.add("2800 28FF Combinaisons Braille")
        self.lst_mnu.add("2900 297F Supplément B de flèches")
        self.lst_mnu.add("2980 29FF Divers symboles mathématiques-B")
        self.lst_mnu.add("2A00 2AFF Opérateurs mathématiques supplémentaires")
        self.lst_mnu.add("2B00 2BFF Divers symboles et flèches")
        self.lst_mnu.add("2D30 2D6F Alphabet Tifinagh et néo-Tifinagh")
        self.lst_mnu.add("2E80 2EFF Formes supplémentaires des clés CJC")
        self.lst_mnu.add("2F00 2FDF Clés chinoises (K'ang-hsi ou Kangxi)")
        self.lst_mnu.add("2FF0 2FFF Description idéophonographique")
        self.lst_mnu.add("3000 303F Symboles et ponctuation CJC")
        self.lst_mnu.add("3040 309F Hiragana")
        self.lst_mnu.add("30A0 30FF Katakana")
        self.lst_mnu.add("3100 312F Bopomofo")
        self.lst_mnu.add("3130 318F Jamos de compatibilité hangûls")
        self.lst_mnu.add("3190 319F Kanboun")
        self.lst_mnu.add("31A0 31BF Bopomofo étendu")
        self.lst_mnu.add("31F0 31FF Extension phonétique katakana")
        
        # Sections suivantes masquées car la plupart sont trop grosses à charger...
        
        #self.lst_mnu.add("3200 32FF Lettres et mois CJC cerclés")
        #self.lst_mnu.add("3300 33FF Compatibilité CJC")
        #self.lst_mnu.add("3400 4DB5 Supplément A aux idéophonogrammes unifiés CJC")
        #self.lst_mnu.add("4DC0 4DFF Hexagrammes du Classique des mutations ou Yi-king")
        #self.lst_mnu.add("4E00 9FA5 Idéophonogrammes unifiés CJC")
        #self.lst_mnu.add("A000 A48F Syllabaire yi des Monts frais")
        #self.lst_mnu.add("A490 A4CF Clés yi")
        #self.lst_mnu.add("AC00 D7A3 Hangûl")
        
        #~ 'D800 DB7F Demi-zone haute ; non-caractères, points de code invalides isolément")
        #~ '---------------D800 à D83F : codets hauts utilisés en UTF-16 pour les points de code du plan multilingue supplémentaire")
        #~ '---------------D840 à D87F : codets hauts utilisés en UTF-16 pour les points de code du plan idéographique supplémentaire")
        #~ '---------------D880 à DB3F : codets hauts utilisés en UTF-16 pour les points de code des plans supplémentaires réservés")
        #~ '---------------D840 à D87F : codets hauts utilisés en UTF-16 pour les points de code du plan spécial supplémentaire")
        #~ 'DB80 DBFF Partie à usage privé de la demi-zone haute non-caractères, points de code invalides isolément
        #~ '---------------DB80 à DBBF : codets hauts utilisés en UTF-16 pour les points de code de la zone supplémentaire A à usage privé
        #~ '---------------DBC0 à DBFF : codets hauts utilisés en UTF-16 pour les points de code de la zone supplémentaire B à usage privé
        
        #~ 'DC00 DFFF Demi-zone basse ; non-caractères, points de code invalides isolément
        #~ '---------------DC80 à DFFD : codets bas utilisés en UTF-16 pour des points de code assignés aux caractères valides ou réservés des plans supplémentaires (assignés, réservés ou à usage privé)
        #~ '---------------DFFE à DFFF : codets bas pouvant être utilisés en UTF-16 pour la représentation de points de code assignés aux non-caractères en fin de chaque plan, lorsque le codet haut est le dernier assigné dans la demi-zone haute pour chaque plan supplémentaire (assigné, réservé ou à usage privé)
        
        #~ 'E000 F8FF Zone à usage privé
        
        #self.lst_mnu.add("F900 FAFF Idéogrammes de compatibilité CJC")
        self.lst_mnu.add("FB00 FB4F Formes de présentation alphabétiques")
        self.lst_mnu.add("FB50 FDFF Formes A de présentation arabes")
        #self.lst_mnu.add("FDD0 FDEF   non-caractères")
        self.lst_mnu.add("FE00 FE0F Sélecteurs de variante")
        self.lst_mnu.add("FE20 FE2F Demi-signes combinatoires")
        self.lst_mnu.add("FE30 FE4F Formes de compatibilité CJC")
        self.lst_mnu.add("FE50 FE6F Petites variantes de forme")
        self.lst_mnu.add("FE70 FEFF Formes B de présentation arabes")
        self.lst_mnu.add("FF00 FFEF Formes de demi et pleine chasse")
        self.lst_mnu.add("FFF0 FFFD Caractères spéciaux")
        #self.lst_mnu.add("FFFE FFFF non-caractères")
        
        # --------------------------------------------------------------
        # --- "10000 1FFFF Plan multilingue supplémentaire (SMP)"
        # --------------------------------------------------------------
        
        #~ 'le reste est inaffichable car le code dépasse la capacité de ChrW()
        
        
        #self.lst_mnu.add("10000 1007F Syllabaire linéaire B ou syllabaire mycénien")
        #self.lst_mnu.add("10080 100FF Idéogrammes du linéaire B")
        #self.lst_mnu.add("10100 1013F Nombres égéens")
        #self.lst_mnu.add("10300 1032F Alphabet italique")
        #self.lst_mnu.add("10330 1034F Gotique")
        #self.lst_mnu.add("10380 1039F Ougaritique")
        #self.lst_mnu.add("10400 1044F Déséret")
        #self.lst_mnu.add("10450 1047F Shavien")
        #self.lst_mnu.add("10480 104AF Osmanya")
        #self.lst_mnu.add("10800 1083F Syllabaire chypriote")
        #self.lst_mnu.add("1D000 1D0FF Symboles musicaux byzantins")
        #self.lst_mnu.add("1D100 1D1FF Symboles musicaux occidentaux")
        #self.lst_mnu.add("1D300 1D35F Symboles du Classique du mystère suprême")
        #self.lst_mnu.add("1D400 1D7FF Symboles mathématiques alphanumériques")
        #self.lst_mnu.add("1FFFE 1FFFF non-caractères")
        
        # --------------------------------------------------------------
        # --- "20000 2FFFF Plan idéographique supplémentaire (SIP)"
        # --------------------------------------------------------------
        
        #self.lst_mnu.add("20000 2A6D6 Supplément B aux idéogrammes unifiés CJC")
        #self.lst_mnu.add("2F800 2FA1F Supplément aux idéogrammes de compatibilité CJC")
        #self.lst_mnu.add("2FFFE 2FFFF non-caractères")
        
        # --------------------------------------------------------------
        # --- "30000 DFFFF Plans supplémentaires réservés"
        # --------------------------------------------------------------
        
        #self.lst_mnu.add("3FFFE 3FFFF non-caractères")
        #self.lst_mnu.add("4FFFE 4FFFF non-caractères")
        #self.lst_mnu.add("5FFFE 5FFFF non-caractères")
        #self.lst_mnu.add("6FFFE 6FFFF non-caractères")
        #self.lst_mnu.add("7FFFE 7FFFF non-caractères")
        #self.lst_mnu.add("8FFFE 8FFFF non-caractères")
        #self.lst_mnu.add("9FFFE 9FFFF non-caractères")
        #self.lst_mnu.add("AFFFE AFFFF non-caractères")
        #self.lst_mnu.add("BFFFE BFFFF non-caractères")
        #self.lst_mnu.add("CFFFE CFFFF non-caractères")
        #self.lst_mnu.add("DFFFE DFFFF non-caractères")
        
        # --------------------------------------------------------------
        # --- "E0000 EFFFF Plan spécial supplémentaire (SSP)"
        # --------------------------------------------------------------
        
        #self.lst_mnu.add("E0000 E007F Étiquettes")
        #self.lst_mnu.add("E0100 E01EF Supplément de sélecteurs de variante")
        #self.lst_mnu.add("EFFFE EFFFF   non-caractères")
        
        # --------------------------------------------------------------
        # --- "F0000 10FFFF Plans supplémentaires à usage privé"
        # --------------------------------------------------------------
        
        #self.lst_mnu.add("F0000 FFFFD Zone supplémentaire A à usage privé")
        #self.lst_mnu.add("FFFFE FFFFF non-caractères")
        #self.lst_mnu.add("100000 10FFFD Zone supplémentaire B à usage privé")
        #self.lst_mnu.add("10FFFE 10FFFF non-caractères")
        
        
        
        return


    def seeTable(self, i, sender):
        u"""
        Afficher la sous-table UNICODE  cliquée
        """
        
        
        # --- Clic sur noeud racine > ne rien faire
        #~ if xxxxxx:
            #~ afficher = "Choisissez une sous-table"
            #~ return
        
        
        # --- Extraire les codes Unicode
        
        codes = self.lst_mnu.getitem(i).split()
        c1 = int(codes[0],16)
        c2 = int(codes[1],16)
        
        
        # --------------------------------------
        # --- Charger les étiquettes            
        # --------------------------------------
        
        # Déterminer la police
        fnt = ""
        if self.vFnt.get() == 2:
            fnt = app.txt_notice['font']
        else:
            fnt = app.txt_search['font']

        # Effacer les étiquettes antérieures
        self.fr_chr.destroy()
        self.fr_D.update()
        
        # Charger les nouvelles étiquettes
        self.fr_chr = Frame(self.fr_D, borderwidth=2, relief=GROOVE)
        self.fr_chr.grid(row=1, column=0, padx=4, pady=4, ipadx=2, ipady=2)
        
        
        row = 0
        col = -1
        for code in range(c1,c2+1):
            col += 1
            if col > 31:
                row += 1
                col = 0
            
            w = Label(self.fr_chr, borderwidth=1, relief=SOLID, width=1, height=1, bg='white', font=fnt)
            w.grid(row=row, column=col, sticky='w', ipady=3, ipadx=3)
            w.bind('<Double-1>', self.dbClicOnChr)
            lib.infobulle.InfoBulle(parent=w, text= "UNICODE: " + hex(code)[2:].upper().zfill(4), temps=0, arg_enter=self.onEnter, arg_leave=self.onLeave)
            try:
                w['text'] = unichr(code)
            except:
                w['text'] =""
        
        return

    def onEnter(self, w):
        w['background'] = 'black'
        w['foreground'] = 'yellow'
        
    def onLeave(self, w):
        w['background'] = 'white'
        w['foreground'] = 'black'

    def dbClicOnChr(self,event):
        u"""
        Double-clic sur un caractère Unicode > l'ajouter à la case de texte
        """
        
        self.txt_str.insert(END, event.widget['text'])
        
        return


    def copyStr(self):
        u"""
        Copier le contenu  de la zone de texte dans le presse-papiers
        """
        
        self.txt_str.clipboard_clear()
        self.txt_str.clipboard_append(self.txt_str.get())
        
        return




class WindowMAIN(Tk):
    u"""
    | Fenêtre principale de l'application                                       
    """

    def __init__(self, version):
        
        u"""
        | CREER LA FENETRE PRINCIPALE DE L'APPLICATION                          
        """
        
        # Mémoriser la plateforme d'éxécution
        syspf = sys.platform.lower()
        if syspf[:3] == 'win':          # Windows
            self.pf = "win"
        elif syspf[:5] == 'linux':      # Linux
            self.pf = "linux"
        elif syspf[:6] == 'darwin':     # Mac osX
            self.pf = "osx"
        elif syspf[:3] == 'mac':        # Mac pre-X
            self.pf = "mac"
        elif syspf[:6] == 'cygwin':     # Cygwin
            self.pf = "cyg"
        elif syspf[:3] == 'os2':        # OS/2
            self.pf = "os2"
        elif syspf[:7] == 'freebsd':    # FreeBSD
            self.pf = "bsd"
        elif syspf[:6] == 'riscos':     # RiscOS
            self.pf = "risc"
        elif syspf[:6] == 'atheos':     # AtheOS
            self.pf = "athe"
        else:                           # autres
            self.pf = syspf
        
        
        # Objet répertoire des données d'application (en fonction de la plateforme)
        self.appdata = lib.myappdat.AppData("linguae")
        
        # Objet fichier ini 
        self.ini = Inifile(os.path.join(self.appdata.path, "linguae.ini"))
        
        # Objet langage d'interface
        lng = self.ini.get("language", None)
        if lng is None: # Demander la langue d'interface
            self.showAskLanguage() # La fenêtre inscrit le choix de l'utilisateur dans l'INI
            lng = self.ini.get("language", "fr")
        self.lg = lib.mylang.MultiLanguage(lng)
        
        
        # Objet Aide (on l'initialise avec le chemin complet du fichier d'aide et celui du fichier français par défaut)
        self.hlp = lib.adjutor.Adjutor(
            os.path.join(os.path.dirname(os.path.realpath(sys.argv[0])), "hlp", self.lg.getlgcode() + ".adj"),
            os.path.join(os.path.dirname(os.path.realpath(sys.argv[0])), "hlp", "fr.adj")
            )
        
        # Initialiser (si nécessaire ET possible) le chemin du dossier de stockage des dictionnaires
        dp = self.ini.get('DicStorageFolder','')
        
        if dp == "" or not os.path.isdir(dp):
            # Tester la présence d'un sous-dossier "dicos" dans le répertoire des données d'application
            # si présent, en faire le dossier de stockage des dictionnaires
            dp = os.path.join(self.appdata.path, "dicos")
            if os.path.isdir(dp):
                self.ini.write('DicStorageFolder', dp)
       
       
        # ============================================
        # === Interface graphique                     
        # ============================================
        
        Tk.__init__(self)
        
        # Afficher le splash
        self.splash = WindowSplash(version=version)
        
        
        self.title("Linguae")
        
        # Taille et position de la fenêtre : on applique les valeurs mémorisées dans l'ini
        # ou sinon des valeurs par défaut
        self.geometry(self.ini.get('Geometry','900x650+30+30')) 
        
        # Icône 16 couleurs (sera reprise par les fenêtres 'Toplevel')
        # en fonction de la plateforme
        if self.pf == 'win':                    # Windows
            icfile = "lingtk.ico"
        elif self.pf in ('linux', 'osx'):       # Unix (MacosX, Linux, )
            icfile = "lingtk.xbm"
        
        self.icone = os.path.join(os.path.dirname(os.path.realpath(sys.argv[0])), "img", icfile)
        
        
        try   : self.iconbitmap(self.icone)           
        except: self.icone = ""
        
        # Icônes de langue (seront complétées par des objets PhotoImage Tkinter)
        self.ic1 = None
        self.ic2 = None
        
        # ---
        
        self.imglst = lib.myimg.ImgList()       # Compiler les images de l'interface
        
        self.version = version                  # Version du logiciel (string)
        self.dic = None                         # objet dictionnaire courant (sera chargé par .loadDico)
        self.diclocaldatabase = []              # liste des dicos stockés (sera complété par .__scanrepdic)
        
        self.__makeToolBar()                    # Construction de la barre d'outils
        
        
        # ======================================
        # === Panneau redimensionnable général  
        # ======================================
        
        self.panM=PanedWindow(self, orient=HORIZONTAL, sashpad=4, sashwidth=6, sashrelief=RAISED)
        self.panM.pack(expand=True,fill=BOTH)
        
        
        # ============================================
        # === Frame des entrées de dico (à gauche)    
        # ============================================
        
        fr_dico = Frame(self.panM, borderwidth=0, padx=2, pady=2)
        self.panM.add(fr_dico)
        
        
        # -----------------------------------
        # --- Frame de recherche + drapeaux  
        # -----------------------------------
        
        fr_search = Frame(fr_dico, borderwidth=0)
        fr_search.pack(fill=X)
        
        # Case du drapeau 1
        self.lab_img1 = Label(fr_search)
        self.lab_img1.grid(row=0, padx=3, pady=6, column=0)
        
        # Case de recherche
        self.txt_search = Entry(fr_search, width=25, bg="white", borderwidth=2, highlightthickness=0)
        self.txt_search.bind('<KeyRelease>', self.onTheFlySearch)
        self.txt_search.grid(row=0, padx=3, pady=6, column=1)
        self.txt_search.ib=lib.infobulle.InfoBulle(parent=self.txt_search, text=self.lg.get("win1", "ib1"), temps=400)
        
        # Menu contextuel de la case de recherche
        self.popup_search = Menu(self,tearoff = 0)
        self.popup_search.add_command(label=self.lg.get("g", "pst"), command=self.pasteClipInSearch )
        self.popup_search.add_separator()
        self.popup_search.add_command(label="Remplacer", command=lambda: self.pasteClipInSearch(repl=True) )
        self.popup_search.add_separator()
        self.popup_search.add_command(label=self.lg.get("menu", "m15"), compound=LEFT, image=self.imglst.carspec, command=self.showUnicode)
        self.txt_search.bind("<ButtonRelease-3>",lambda event: self.popup_search.tk_popup(event.x_root+70, event.y_root+20, 0))
        
        # Case du drapeau 2
        self.lab_img2 = Label(fr_search)
        self.lab_img2.grid(row=0, padx=3, pady=6, column=2)
        
        
       
        # ---------------------------------
        # --- Liste des entrées du dico    
        # ---------------------------------
        
        r=1
        
        # nb : augmenter selectborderwidth permet d'espacer les mots dans la liste
        #      width se comporte en largeur mini de visibilité de la Scrollbar
        self.lst_dico = Listbox(fr_dico, selectborderwidth=3, width=5, borderwidth=2, bg="white", highlightthickness=0)
        self.lst_dico.bind('<ButtonRelease-1>', self.selDisplayData)
        self.lst_dico.pack(expand=True, fill=BOTH, side=LEFT)
        
        self.bind('<Up>', self.listDicoUpDown)
        self.bind('<Down>', self.listDicoUpDown)
        self.bind('<Prior>', self.listDicoUpDown)
        self.bind('<Next>', self.listDicoUpDown)
        self.bind('<MouseWheel>', self.scrollWheel)
        
        # Scrollbar des  entrées du dico
        self.scr = Scrollbar(fr_dico, command=self.lst_dico.yview)
        self.lst_dico['yscrollcommand'] = self.scr.set
        self.scr.pack(side=LEFT, fill=Y)
        
        
        # ====================================================
        # === Frame global Droit                              
        # ====================================================
        
        wOngl = 160
        hOngl = 20
        
        fr_D = Frame(self.panM, pady=2, padx=2)
        self.panM.add(fr_D)
        
        
        # --------------------------------------------------
        # --- Frame des faux-onglets (boutons)              
        # --- et frame dde leur conteneur cible d'affichage 
        # --------------------------------------------------
        
        r=0
        fr_ongl = Frame(fr_D)
        fr_ongl.pack(fill=X)
        
        # Onglets
        self.ongl_0 = Button(fr_ongl, text=self.lg.get("win1", "s1"), image=self.imglst.puceS, compound=LEFT, height=hOngl, width=wOngl, borderwidth=0, background='white')
        self.ongl_0['font']=("Helvetica",9,"normal")
        self.ongl_0.pack(side=LEFT, anchor=W, padx=3)
        
        self.ongl_plugin = Button(fr_ongl, text=self.lg.get("win1", "s2"), image=self.imglst.puceX, compound=LEFT, height=hOngl, width=wOngl, borderwidth=0, foreground='white', background='#B4B4B4')
        self.ongl_plugin['font']=("Helvetica",9,"normal")
        self.ongl_plugin.pack(side=LEFT, padx=3)
        
        # Frame conteneur cible d'affichage
        self.fr_tabs = Frame(fr_D, borderwidth=2, relief='ridge', padx=4, pady=4)
        self.fr_tabs.pack(expand=True, fill=BOTH)
        
        
        # ------------------------------------------------------------
        # --- Frame des Traductions & Définitions (panneau/onglet 1)  
        # ------------------------------------------------------------
        
        fr_def = Frame(self.fr_tabs)
        fr_def.pack(expand=True, fill=BOTH)
        
        
        # Case de la notice
        # (la largeur affectée se comporte en largeur minimale) 
        self.txt_notice = ScrolledText.ScrolledText(fr_def, highlightthickness=0, width=20, borderwidth=1, relief=SOLID, wrap=WORD, state='disabled', cursor="")
        self.txt_notice.pack(side=LEFT, expand=True, fill=BOTH)
        
        # Styles d'affichage de la notice
        # (les styles de police sont dans appliquerFont)
        self.txt_notice.tag_config("normal", lmargin1=5, lmargin2=5, spacing1=5)
        self.txt_notice.tag_config("ttr", lmargin1=5, lmargin2=5, spacing1=5, spacing3=2, foreground="black")
        self.txt_notice.tag_config("miroir", lmargin1=5, lmargin2=5, spacing1=5, spacing3=5, borderwidth=2, relief=SOLID)
        self.txt_notice.tag_config("short", lmargin1=5, lmargin2=5, spacing1=5, spacing3=2)
        self.txt_notice.tag_config("long", lmargin1=5, lmargin2=5, spacing1=5)
        self.txt_notice.tag_config("phon", lmargin1=5, lmargin2=5, spacing1=5)
        self.txt_notice.tag_config("u", underline=1)
        self.txt_notice.tag_config("ety", lmargin1=5, lmargin2=5, spacing1=5)
        self.txt_notice.tag_config("syn", lmargin1=5, lmargin2=5, spacing1=5)
        self.txt_notice.tag_config("anto", lmargin1=5, lmargin2=5, spacing1=5)
        self.txt_notice.tag_config("url", foreground="blue", underline=1)
        self.txt_notice.tag_config("mail", foreground="blue", underline=1)
        self.txt_notice.tag_config("tohw", foreground="blue", underline=1)
        self.txt_notice.tag_config("torel", lmargin1=15, spacing1=5, foreground="blue")
        self.txt_notice.tag_config("blanc", foreground = self.txt_notice['background'])
        
        self.txt_notice.tag_bind("url", "<ButtonRelease-1>", lambda event : onclickUrl(self.txt_notice) )
        self.txt_notice.tag_bind("mail", "<ButtonRelease-1>", lambda event : onclickMail(self.txt_notice) )
        self.txt_notice.tag_bind("tohw", "<ButtonRelease-1>", self.__onclickLink)
        self.txt_notice.tag_bind("torel", "<ButtonRelease-1>", self.__onclickRel)
        
        self.txt_notice.tag_bind("url", "<Leave>", lambda event : onLeaveLink(self.txt_notice))
        self.txt_notice.tag_bind("mail", "<Leave>", lambda event : onLeaveLink(self.txt_notice))
        self.txt_notice.tag_bind("tohw", "<Leave>", lambda event : onLeaveLink(self.txt_notice))
        self.txt_notice.tag_bind("torel", "<Leave>", lambda event : onLeaveLink(self.txt_notice))
        
        self.txt_notice.tag_bind("url", "<Enter>", lambda event : onEnterLink(self.txt_notice))
        self.txt_notice.tag_bind("mail", "<Enter>", lambda event : onEnterLink(self.txt_notice))
        self.txt_notice.tag_bind("tohw", "<Enter>", lambda event : onEnterLink(self.txt_notice))
        self.txt_notice.tag_bind("torel", "<Enter>", lambda event : onEnterLink(self.txt_notice))
        
        
        # --- Frame des listes latérales
        
        #fr_lst=Frame(fr_def, padx=3)
        #fr_lst.pack(side=RIGHT, fill=BOTH)
        
        
        
        # ---------------------------------------------------
        # --- Frame du plugin (panneau/onglet)               
        #             Emplacement du greffon = Widget        
        #     (le plugin est chargé par le menu des plugins) 
        # ---------------------------------------------------
        
        # le Frame est construit mais non affiché (non "packé")
        # il se sera lors d'une action sur les onglets
        self.fr_plugin  = Frame(self.fr_tabs)
        
        # (info : aucun greffon n'est chargé)
        Message(self.fr_plugin, text="\n" + self.lg.get("win1", "s9"), justify=LEFT, width=250).grid(row=0, column=0)
        
        
        # -------------------------
        # --- Gestion des onglets  
        # -------------------------
        
        listOngl = [ (self.ongl_0, fr_def), (self.ongl_plugin, self.fr_plugin )]
        self.ongl_0['command'] = lambda: onglClick(0, listOngl, self.imglst, self, 'p')
        self.ongl_plugin['command'] = lambda: onglClick(1, listOngl, self.imglst, self, 'p')
        
        
        # ---------
        self.__makeStatusBar()              # Construction de la barre de statut
        self.__makeMainMenu()               # Construction de la barre de menus
        
        
        # Barre de progression principale (masquée = non packée)
        # elle sera ensuite affichée et masquée par showProgr() et hideProgr()
        self.progr = lib.myprogbr.ProgressBar(self)
        
        
        
        # ================================================================
        # ===                                                             
        # ===  Suite au chargement de l'interface graphique...            
        # ===                                                             
        # ================================================================
        
        
        # --- Appliquer à l'interface les polices mémorisées dans l'ini   
        self.appliquerFont(self.ini.get('dicofont', '<defaut>?9?normal'), self.ini.get('traducfont','<defaut>?9?normal'))
        
        # --- Appliquer à l'interface les couleurs mémorisées dans l'ini 
        self.applyColor()
        
        # --- Placement par défaut de la coulisse de redimensionnement
        self.panM.sash_place(0, int(self.ini.get('Xsash', '260')), 0)
        
        self.update()
        
        # --------------------------------------------------------------
        # -- Contrôler les nouvelles versions en mode échec silencieux  
        # --------------------------------------------------------------
        
        # Paramétrage par défaut en fonction de la plateforme
        
        if self.ini.get("CheckNewVersion", "rien") == "rien":
            if sys.platform.lower()[:5] == 'linux':
                self.ini.write("CheckNewVersion", "0")
            else:
                self.ini.write("CheckNewVersion", "1")
        
        # Contrôler en ligne
        
        if self.ini.get("CheckNewVersion", "1") == "1":
            self.__checkProgVersion(mute=True)
        
        
        # --------------------------------------------
        # --- Ouverture automatique d'un plugin       
        # --------------------------------------------
        
        # Rechercher la présence d'un plugin de démarrage
        
        f = self.__importPluginFromStart() # Retourne le nom du plugin chargé ou ""
        
        if f != "" :
            # Ouvrir le plugin
            self.runPlugin(f)
        
        else: # Rouvrir le dernier plugin ouvert (optionnel)          
        
            if self.ini.get("OpenLastPlugin", "1") == "1":
                f = self.ini.get("lastopenplugin", "")
                if f:
                    self.runPlugin(f)
        
        
        
        return
    
    
    def __onclickRel(self, event):
        
        u"""
        | Click sur un lien vers une relation (racine, synonyme, voir-aussi)    
        | Affiche le mot en relation cliqué                                     
        """
        
        # Borner le lien cliqué
        
        # Libellé de la ligne de relation
        txt = self.txt_notice.get("insert linestart", "insert lineend") 
        
        
        # Extraire le wordID de la racine dans la liste concernée, en déduire l'index
        idx = self.dic.wordIDs[ txt.split()[-1].strip('()') ][0]
        
        # Afficher le mot du dictionnaire
        self.lst_dico.selection_clear(0, END)       # Désélectionner tout dans la Listbox
        self.dic.lstbox.activate(idx)
        self.dic.lstbox.selection_set(idx)
        self.dic.lstbox.see(idx)
        self.selDisplayData(None)
        
        
        return

    
    
    def __onclickIcRel(self, event):
        
        u"""
        | Click sur l'icône d'un lien vers une relation (rac., syn., voir-aussi)
        | Affiche le mot en relation cliqué                                     
        """
        
        # Borner le lien cliqué
        
        # Nb : pour pouvoir utiliser un label comme source de lien, on utilise
        # l'index des coordonnées du clic dans le parent plutôt que l'index "insert"
        
        # Coordonnées souris relative à la textBox
        idx = "@"+ str(event.x_root - self.txt_notice.winfo_rootx()) + "," + str(event.y_root - self.txt_notice.winfo_rooty())
        
        # Libellé de la ligne de relation
        txt = self.txt_notice.get(idx + " linestart", idx + " lineend")
        
        # Extraire le wordID de la racine dans la liste concernée, en déduire l'index
        idx = self.dic.wordIDs[ txt.split()[-1].strip('()') ][0]
        
        # Afficher le mot du dictionnaire
        self.lst_dico.selection_clear(0, END)       # Désélectionner tout dans la Listbox
        self.dic.lstbox.activate(idx)
        self.dic.lstbox.selection_set(idx)
        self.dic.lstbox.see(idx)
        self.selDisplayData(None)
    
    
    
    def __onclickLink(self, event):
        u"""
        | Click sur un lien vers un mot-clé
        """
        
        
        # Borner le lien cliqué
        try:
            [idx1,idx2] = self.txt_notice.tag_prevrange('tohw',INSERT)
            hw = self.txt_notice.get(idx1,idx2)
        except:
            pass
        
        hw = hw.lower()
        
        # ---------------------------------------------------------
        # --- Chercher l'index de l'entrée correspondant au lien   
        # ---------------------------------------------------------
        
        i = None
        
        # --- 1ère étape : chercher l'entrée de manière stricte
        
        for n in range(self.dic.lstbox.size()):
            txt = self.dic.lstbox.get(n).lower()
            if hw == txt:
                i = n
                break
        
        
        # --- 2ème étape : si échec, chercher le début d'une entrée par la méthode de l'objet dico
        if i is None:
            
            i = self.dic.idxfind(motif=hw, dom='idx', decal=0, debut=True, ignorecase=True, ignorelig=True)
        
        
        # --------------------------------------------
        # --- Sélectionner l'entrée dans la listbox   
        # --------------------------------------------
        
        if not i is None:
            
            self.lst_dico.selection_clear(0, END)       # Désélectionner tout dans la Listbox
            
            self.lst_dico.activate(i)
            self.lst_dico.selection_set(i)
            self.lst_dico.see(i)
            self.selDisplayData(event)
        else:
            pass
        
        
        return
    
    def pasteClipInSearch(self, repl=False):
        u"""
        | Coller le contenu du presse-papiers dans la case de recherche         
        """
        
        w = self.txt_search
        
        try:
            txt = w.clipboard_get()
        except:
            return
        
        
        if repl :                   # Remplacer le contenu de la case
            w.delete(0, END)
            
        elif w.selection_present(): # Remplacer la sélection
            
            if w.index(INSERT) < w.index(ANCHOR):
                w.delete(INSERT, ANCHOR)
            elif w.index(INSERT) > w.index(ANCHOR):
                w.delete(ANCHOR, INSERT)
        
        # Coller le contenu du presse-papiers
        
        try:
            w.insert(INSERT, txt)
        except:
            return
        
        # Chercher dans le dico
        
        self.onTheFlySearch(event=None)
        
        return
    
    
    def applyColor(self, flagdef=False):
        u"""
        | Applique à l'interface les couleurs mémorisées dans L'INI             
        | Applique des couleurs par défaut si rien dans l'INI ou si             
        | 'flagdef' est 'True'                                                  
        """
        
        # Notice : mot d'entrée
        cf = self.ini.get('HeadwordFgColor', "")
        if cf == "" or flagdef: cf = 'black'
        cb = self.ini.get('HeadwordBgColor', "")
        if cb == "" or flagdef: cb = 'yellow'
        
        self.txt_notice.tag_config('miroir', foreground = cf, background = cb)
        
        # Notice : phonétique
        cf = self.ini.get('PhonFgColor', "")
        if cf == "" or flagdef: cf = 'grey'
        cb = self.ini.get('PhonBgColor', "")
        if cb == "" or flagdef: cb = 'white'
        
        self.txt_notice.tag_config('phon', foreground = cf, background = cb)
        
        # Notice : traductions courtes
        cf = self.ini.get('ShortFgColor', "")
        if cf == "" or flagdef: cf = 'maroon'
        cb = self.ini.get('ShortBgColor', "")
        if cb == "" or flagdef: cb = 'white'
        
        self.txt_notice.tag_config('short', foreground = cf, background = cb)        
        
        # Notice : traductions longues
        cf = self.ini.get('LongFgColor', "")
        if cf == "" or flagdef: cf = 'navy'
        cb = self.ini.get('LongBgColor', "")
        if cb == "" or flagdef: cb = 'white'
        
        self.txt_notice.tag_config('long', foreground = cf, background = cb)
        
        # Notice : conteneur étymologie (<etym>)
        cf = self.ini.get('EtymFgColor', "")
        if cf == "" or flagdef: cf = 'blue'
        cb = self.ini.get('EtymBgColor', "")
        if cb == "" or flagdef: cb = 'white'
        
        self.txt_notice.tag_config('ety', foreground = cf, background = cb)
        
        # Notice : conteneur synonymes (<synonym>)
        cf = self.ini.get('SynFgColor', "")
        if cf == "" or flagdef: cf = '#008800'
        cb = self.ini.get('SynBgColor', "")
        if cb == "" or flagdef: cb = '#EEEEEE'
        
        self.txt_notice.tag_config('syn', foreground = cf, background = cb)
        
        # Notice : conteneur antonymes (<antonym>)
        cf = self.ini.get('AntoFgColor', "")
        if cf == "" or flagdef: cf = 'red'
        cb = self.ini.get('AntoBgColor', "")
        if cb == "" or flagdef: cb = '#EEEEEE'
        
        self.txt_notice.tag_config('anto', foreground = cf, background = cb)
        
        # Liste des entrées
        cf = self.ini.get('ListFgColor', "")
        if cf == "" or flagdef: cf = 'black'
        cb = self.ini.get('ListBgColor', "")
        if cb == "" or flagdef: cb = 'white'
        
        self.lst_dico.config(foreground = cf, background = cb)
        
        # Fond de notice
        cb = self.ini.get('NoticeBgColor', "")
        if cb == "" or flagdef: cb = 'white'
        
        self.txt_notice['background'] = cb
        
        return
    
    
    def showProgr(self):
        u"""
        Affiche la barre de progression de la fenêtre principale
        à la place de la barre de statut
        """
        self.fr_status.pack_forget()
        self.progr.setWidth(self.winfo_width()-20)
        
        self.progr.pack(side=BOTTOM, fill=X)
        
        return
    
    
    def hideProgr(self):
        u"""
        Masque la barre de progression de la fenêtre principale
        et réaffiche la barre de statut
        """
        self.progr.pack_forget()
        self.fr_status.pack(side=BOTTOM,fill=X)
        
        return
    
    
    
    def __makeStatusBar(self):
        u"""
        Mise en place de la barre de statut
        """
        
        self.fr_status=Frame(self)
        self.fr_status.pack(side=BOTTOM,fill=X)
        
        # case de l'index de l'entrée sélectionnée
        self.status0 = Label(self.fr_status, text="...", width=6, borderwidth=1, relief=SUNKEN)
        self.status0.pack(side=LEFT, padx=2)
        lib.infobulle.InfoBulle(parent=self.status0, text=self.lg.get("win1", "ib7"))
        
        # case de l'ID de l'entrée
        self.status3 = Label(self.fr_status, text="...", width=6, borderwidth=1, relief=SUNKEN)
        self.status3.pack(side=LEFT, padx=2)
        lib.infobulle.InfoBulle(parent=self.status3, text=self.lg.get("win1", "ib8"))
        
        # Case de l'encodage du dico
        self.status1 = Label(self.fr_status, text="(aucun dictionnaire chargé)", width=22, borderwidth=1, relief=SUNKEN)
        self.status1.pack(side=LEFT, padx=2)
        lib.infobulle.InfoBulle(parent=self.status1, text=self.lg.get("win1", "ib9"))
        
        # Case de l'indicateur de protection
        self.status4 = Label(self.fr_status, text="", image=self.imglst.caden0, width=18, borderwidth=1, relief=SUNKEN)
        self.status4.pack(side=LEFT, padx=2)
        self.status4.ib=lib.infobulle.InfoBulle(parent=self.status4, text=self.lg.get("win1", "ib10"))
        
        # Case de la version du programme
        status2 = Label(self.fr_status, text="Linguae "+ self.version, borderwidth=1, relief=SUNKEN)
        status2.pack(side=LEFT, padx=2, expand=True, fill=X)
        
        # Poignée de redimensionnement
        Label(self.fr_status, image=self.imglst.poign).pack(side=LEFT)
        
        self.status0['font']="Helvetica 8 normal"
        self.status1['font']="Helvetica 8 normal"
        status2['font']="Helvetica 8 normal"
        self.status3['font']="Helvetica 8 normal"
        
        return


    def scrollWheel(self, event):
        u"""
        Scroll avec la roulette de souris
        """
        
        if event.delta <0:
            self.lst_dico.yview_scroll(3, 'units')
        else:
            self.lst_dico.yview_scroll(-3, 'units')
        
        return


    def listDicoUpDown(self, event):
        u"""
        Action sur les touches haut-bas :
        déplacer le curseur dans la liste des entrées
        """
        
        try:
            i = int(self.lst_dico.curselection()[0])   # index du mot en sélection
        except:
            return
        
        if event.keysym == "Up":
            # Correction d'une différence de comportement entre Tkinter 2.5 et 2.6
            if str(hex(sys.hexversion))[2:5] == "206":
                v = 0
            else:
                v = -1
        elif event.keysym == "Down":
            # Correction d'une différence de comportement entre Tkinter 2.5 et 2.6
            if str(hex(sys.hexversion))[2:5] == "206":
                v = 0
            else:
                v = 1
        elif event.keysym == "Prior":
            v = -20
        elif event.keysym == "Next":
            v = 20
        else: return
        
        self.lst_dico.selection_clear(0, END)
        
        i= i + int(v)
        
        if i < 0: i = 0
        if i >= self.lst_dico.size(): i = self.lst_dico.size()-1
        
        self.lst_dico.activate(i)
        self.lst_dico.selection_set(i)
        self.lst_dico.see(i)
        self.selDisplayData(None)
        
        return



    def playWord(self):
        u"""
        | [ Appelé par le clic sur le bouton "Ecouter"]                         
        |                                                                       
        | Ecouter la prononciation du mot en sélection.                         
        """
        
        # Librairie audio Snack activée ?
        if not self.snackisactive:
            tkMessageBox.showwarning(parent = self,
                    title = self.lg.get("win1", "msg1"),
                    message = self.lg.get("win1", "msg2")) # ("fonctions audio désactivées")
            return
        # ---
        
        id = self.status3['text']
        
        # Chemin du fichier audio
        try:
            fich = glob.glob(os.path.join(self.dic.path + "_res", "audio", id + ".*"))[0]
        except:
            return
        
        # -------------------
        # --- Ecouter        
        # -------------------
        
        try:
            self.mysound = tkSnack.Sound()
            self.mysound.read(fich) 
            self.mysound.play()
        except:
            tkMessageBox.showwarning(parent = self,
                title = self.lg.get("win1", "msg1"),
                message = self.lg.get("win1", "msg3")) # ("échec lecture fichier audio")
            try:
                self.mysound.stop()
            except:
                pass
            return
        
        return




    def __onTop(self):
        u"""
        | Bascule de la commande "Toujours au premier plan" de la fenêtre principale"
        """
        
        if self.pf == "win":
            self.wm_attributes("-topmost", self.vTopmost.get())
        
        #else: # Variante pour Linux, nébessite l'installation de wmctrl
        #        INUTILE car une commande est dans le menu système standard
        #
        #    os.system( "wmctrl -r :ACTIVE: -b add,above" )
        
        return


    def __addToFav(self):
        u"""
        | Ajoute le dictionnaire courant à la liste des favoris
        """
        
        
        
        return
    
    
    def __checkDicVersion(self, mute=False):
        
        u"""
        Contrôle la disponibilité d'une nouvelle version téléchargeable du dictionnaire courant.
        Pour cela on recherche un petit fichier d'information réferencé par l'attribut .verUrl de l'objet dico
        
        NB : ce contrôle ne peut se faire de manière fiable par accès direct au fichier dictionnaire en ligne
             et lecture de son numéro de version car ce fichier est très souvent protégé par des
             dispositifs anti-leeching/hotlinking.
        
        Si 'mute' est True :
            - L'échec de connexion est silencieux
            - Le résultat de la recherche est silencieux s'il n'y a pas de nouvelle version disponible
        """
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title=self.lg.get("win1", "msg4"),
                    message=self.lg.get("g", "loadfst")) # ("Chargez d'abord un dictionnaire !")
            return
        
        
        # ---------------------------------------------------------------
        # --- Récupérer le n° de la version disponible sur le Web        
        # ---------------------------------------------------------------
        
        # --- Ouvrir l'url du mini-fichier d'info
        
        try:
            lignes = urllib.urlopen(self.dic.verUrl).readlines()
        except:
            if not mute:
                tkMessageBox.showwarning(parent=self,
                        title = self.lg.get("win1", "msg6"),
                        message = self.lg.get("win1", "msg7")) # ("échec de la connexion")
            return
        
        newvlit = ""
        newv = ""
        
        
        # --- Balayage des lignes du fichier
        
        motif = self.dic.dicID + "_version"
        
        for ligne in lignes:
            if ligne.startswith(motif):
                
                # extraire le libellé littéral (avec mentions beta ou autres)
                newvlit = ligne.split('=')[1]
                newvlit = newvlit.strip(' "')
                newvlit = newvlit.strip("'")
                
                # ne conserver que la liste des composants numériques
                newv = newvlit.split()[0].split(".")
                
                break
        
        
        # ------------------------------------------------
        # --- Comparer avec le n° de la version locale    
        # ------------------------------------------------
        
        oldv = self.dic.dicVersionNumber.split()[0].split(".") # liste des composants numériques
        
        flagnew = False
        
        try:
            if int(newv[0]) > int(oldv[0]):
                flagnew = True
            elif int(newv[0]) == int(oldv[0]):
                if int(newv[1]) > int(oldv[1]):
                    flagnew = True
        except:
            pass
            
        if not flagnew: # Rien de neuf
        
            if mute:
                return
            else:
                tkMessageBox.showinfo(parent=self,
                        title = self.lg.get("win1", "msg6"),
                        message = self.lg.get("win1", "msg8")) # ("La version utilisée est la plus récente disponible.")
                return
        
        
        # ----------------------------------------
        # --- Avertissement de nouvelle version   
        # ----------------------------------------
        
        r = tkMessageBox.askyesno(parent=self,
                title=self.lg.get("win1", "msg6"),
                message=self.lg.get("win1", "msg9") + " " + self.dic.dicVersionNumber + "\n" +self.lg.get("win1", "msg10") + " " + newvlit + "\n\n" + self.lg.get("win1", "msg11"))
        
        if r:
            self.toWebDic()# Connexion au site web du dictionnaire courant   
        
        
        return



    
    def __checkProgVersion(self, mute=False):
        
        u"""
        Contrôle la disponibilité d'une nouvelle version en ligne du programme.
        
        Si 'mute' est True :
            - L'échec de connexion est silencieux
            - Le résultat de la recherche est silencieux s'il n'y a pas de nouvelle version disponible
        """
        
        # --------------------------------------------------------
        # --- Récupérer le n° de la nouvelle version sur le Web   
        # --------------------------------------------------------
        
        try:
            lignes = urllib.urlopen('http://stalikez.info/linguae/inc/version.ver').readlines()
        except:
            if not mute:
                tkMessageBox.showwarning(parent=self,
                        title = self.lg.get("win1", "msg14"),
                        message = self.lg.get("win1", "msg12")) # ("échec de la connexion")
            return
        
        newvlit = ""
        newv = ""
        
        for ligne in lignes:
            if ligne.startswith("$linguaeVer"):
                
                newvlit = ligne.split('"')[1]           # libellé littéral (avec mentions beta ou autres
                newv = newvlit.split()[0].split(".")    # liste des composants numériques
                
                break
        
        # -----------------------------------------------------------
        # --- Comparer avec le n° de la version locale de programme  
        # -----------------------------------------------------------
        
        oldv = self.version.split()[0].split(".") # liste des composants numériques
        
        flagnew = False
        
        try:
            if int(newv[0]) > int(oldv[0]):
                flagnew = True
            elif int(newv[0]) == int(oldv[0]):
                if int(newv[1]) > int(oldv[1]):
                    flagnew = True
                elif int(newv[2]) > int(oldv[2]):
                    flagnew = True
        except:
            pass
            
        if not flagnew: # Rien de neuf
        
            if mute:
                return
            else:
                tkMessageBox.showinfo(parent=self,
                        title = self.lg.get("win1", "msg14"),
                        message = self.lg.get("win1", "msg13") + "\n\n" + self.version) # ("La version utilisée est la plus récente")
                return
        
        # ----------------------------------------
        # --- Avertissement de nouvelle version   
        # ----------------------------------------
        
        r = tkMessageBox.askyesno(parent=self,
                title = self.lg.get("win1", "msg6"),
                message = self.lg.get("win1", "msg9") + " " + self.version + self.lg.get("win1", "msg10") + " " + newvlit + "\n\n" + self.lg.get("win1", "msg15"))
        
        if r:
            self.toWebLing(cible="maj") # Connexion à la page de téléchargement du site web du programme   
        
        
        return
    
    

    def __makeMainMenu(self):
        
        u"""
        | Construction de la barre de menu de la fenêtre principale             
        """
        
        self.menubar = Menu(self)
        
        
        # Forcer la police en "normal" (car vilain "gras" par défaut avec anciens Tkinter/Linux)
        try:
            strfont = str(self.menubar['font'])
            
            if strfont.startswith("{"):     # nom de police à termes multiples
                mnufont = strfont.split("}")
                mnufont  = (mnufont[0][1:] , int(mnufont[1].split()[0]), "normal")
            else:                           # nom de police à terme unique
                mnufont = strfont.split()
                mnufont = (mnufont[0], mnufont[1], "normal")
        except: 
            # erreur générée avec Tkinter/Linux récent ( ['font'] retourne TkFont et non un descripteur de police)
            # > on laisse la police par défaut car elle n'est plus en "gras" dans la version récente
            pass
        
        
        self.menubar['font'] = mnufont
        
        
        # -------------------------
        # --- Menu 'Fichier'       
        # -------------------------
        
        self.m_file = Menu(self.menubar, tearoff=0, font=mnufont, background=self.menubar['background'])
        
        # "Ouvrir un dictionnaire..."
        self.m_file.add_command(label=self.lg.get("menu", "m1"), compound=LEFT, image=self.imglst.open, command=self.openDicFromDialog)
        # "Créer un nouveau dictionnaire..."
        self.m_file.add_command(label=self.lg.get("menu", "m2"), compound=LEFT, image=self.imglst.open, command=self.showOpenNewDic)
        # "Propriétés..."
        self.m_file.add_command(label=self.lg.get("menu", "m3"), compound=LEFT, image=self.imglst.propr, command=self.showProperties)
        # -------------------------
        self.m_file.add_separator()
        # "Copier sous..."
        self.m_file.add_command(label=self.lg.get("menu", "m3b"), compound=LEFT, image=self.imglst.save, command=self.copyAs)
        # -------------------------
        self.m_file.add_separator()
        # "Importer Preling..."
        self.m_file.add_command(label=self.lg.get("menu", "m4"), compound=LEFT, image=self.imglst.imprt, command=self.showImportPreling)
        # "Importer..."
        self.m_file.add_command(label=self.lg.get("menu", "m4b"), compound=LEFT, image=self.imglst.imprt, command=self.showImportVarious)
        # "Exporter..."
        self.m_file.add_command(label=self.lg.get("menu", "m5"), compound=LEFT, image=self.imglst.export, command=self.showExport)
        # -------------------------
        self.m_file.add_separator()
        # "Construire le dictionnaire inverse..."
        self.m_file.add_command(label=self.lg.get("menu", "m6"), compound=LEFT, image=self.imglst.reverse, command=self.showReverse)
        # "Voir le dictionnaire inverse..."
        self.m_file.add_command(label=self.lg.get("menu", "m7"), compound=LEFT, image=self.imglst.seerev, command=self.openReverseDic)
        # -------------------------
        self.m_file.add_separator()
        self.m_file.add_command(label=self.lg.get("menu", "m7b"), compound=LEFT, image=self.imglst.dwnld, command=self.showDwnld)
        # -------------------------
        self.m_file.add_separator()
        # "Quitter"
        self.m_file.add_command(label=self.lg.get("menu", "m8"), compound=LEFT, image=self.imglst.exit, command=self.queryUnload)
        
        self.menubar.add_cascade(label=self.lg.get("menu", "mfich"), underline=0, menu=self.m_file)
        
        
        # -------------------------
        # --- Menu 'Dictionnaires' 
        # -------------------------
        x=0
        self.m_dic = Menu(self.menubar, tearoff=0, title="mDic", font=mnufont, background=self.menubar['background'])
        
        # "(Aucun dictionnaire)"
        self.m_dic.add_command(label=self.lg.get("menu", "m9"), state='disabled', command=self.doNothing) # commande nécessaire pour action de .delete (bug Tkinter)
        
        self.menubar.add_cascade(label=self.lg.get("menu", "mdic"), underline=0, menu=self.m_dic)
        
        self.updateMenuDic()
        
        
        # -------------------------
        # --- Menu 'Favoris'       
        # -------------------------
        # A FAIRE
        #self.m_fav = Menu(self.menubar, tearoff=1, font=mnufont, background=self.menubar['background'])
        
        #self.m_fav.add_command(label="Ajouter le dictionnaire aux Favoris", command=self.__addToFav)
        
        #self.menubar.add_cascade(label="Favoris", underline=0, menu=self.m_fav)
        
        
        # -------------------------
        # --- Menu 'Chercher'      
        # -------------------------
        
        self.menubar.add_command(label=self.lg.get("menu", "msearch"), underline=0, command=self.showFind, font=mnufont)
        
        
        # -------------------------
        # --- Menu 'Edition'       
        # -------------------------
        
        self.m_edit = Menu(self.menubar, tearoff=0, font=mnufont, background=self.menubar['background'])
        
        # "Trier le dictionnaire..."
        self.m_edit.add_command(label=self.lg.get("menu", "m10"), compound=LEFT, image=self.imglst.sortcr, command=self.showSort)
        # -------------------------
        self.m_edit.add_separator()
        # "Editer l'entrée de dictionnaire..."
        self.m_edit.add_command(label=self.lg.get("menu", "m11"), compound=LEFT, image=self.imglst.edit, command=self.showEdit)
        # "Supprimer l'entrée..."
        self.m_edit.add_command(label=self.lg.get("menu", "m12"), compound=LEFT, image=self.imglst.suppr, command=self.editDel)
        # "Déplacer l'entrée..."
        self.m_edit.add_command(label=self.lg.get("menu", "m13"), compound=LEFT, image=self.imglst.wmove, command=self.editMove)
        # "Ajouter une nouvelle entrée..."
        self.m_edit.add_command(label=self.lg.get("menu", "m14"), compound=LEFT, image=self.imglst.add, command=self.showEditAdd)
        # -------------------------
        self.m_edit.add_separator()
        # "Table des caractères..."
        self.m_edit.add_command(label=self.lg.get("menu", "m15"), compound=LEFT, image=self.imglst.carspec, command=self.showUnicode)
        # -------------------------
        self.m_edit.add_separator()
        # "Compléter les identifiants des entrées (WordIDs)"
        self.m_edit.add_command(label="Compléter les identifiants des entrées (WordIDs)", command=self.completeWordIDs)
        # -------------------------
        self.m_edit.add_separator()
        # "Modifier les icônes du dictionnaire..."
        self.m_edit.add_command(label=self.lg.get("menu", "m16"), compound=LEFT, image=self.imglst.setic, command=self.showSetIcon)
        
        self.menubar.add_cascade(label=self.lg.get("menu", "medit"), underline=0, menu=self.m_edit)
        
        
        # -------------------------
        # --- Menu 'Options'       
        # -------------------------
        
        self.m_opt = Menu(self.menubar, tearoff=0, font=mnufont, background=self.menubar['background'])
        
        # 'Passer à la ligne les " ; "'
        self.vPv2br = IntVar()
        self.m_opt.add_checkbutton(label=self.lg.get("menu", "m17"), variable=self.vPv2br)
        self.vPv2br.set(1)
       
        # Toujours au premier plan
        if self.pf == "win":
            # ------------------------
            self.m_opt.add_separator()
            self.vTopmost = IntVar()
            self.m_opt.add_checkbutton(label=self.lg.get("menu", "m17a"), variable=self.vTopmost, command=self.__onTop)
       
        # ------------------------
        self.m_opt.add_separator()
        
        # "Transparence..."
        self.m_opt.add_command(label=self.lg.get("menu", "m18"), compound=LEFT, image=self.imglst.rien, command=self.showAlpha)       
        
        
        # ------------------------
        self.m_opt.add_separator()
        
        # "Préférences..."
        self.m_opt.add_command(label=self.lg.get("menu", "m19"), compound=LEFT, image=self.imglst.tools, command=self.showOptions)
        
        
        self.menubar.add_cascade(label=self.lg.get("menu", "mopt"), underline=0, menu=self.m_opt)
        
        
        # -------------------------
        # --- Menu Outils          
        # -------------------------
        
        self.m_tool = Menu(self.menubar, tearoff=0, font=mnufont, background=self.menubar['background'])
        # "Aide à la traduction..."
        self.m_tool.add_command(label=self.lg.get("menu", "m20"), compound=LEFT, image=self.imglst.traduc, command=self.showTranslate)
        # -------------------------
        self.m_tool.add_separator()
        # "Contruire un dictionnaire par héritage..."
        self.m_tool.add_command(label=self.lg.get("menu", "m21"), compound=LEFT, image=self.imglst.herit, command=self.showHerit)
        # -------------------------
        self.m_tool.add_separator()
        # "Contrôler les liens du dictionnaire"
        self.m_tool.add_command(label=self.lg.get("menu", "m21b"), command=self.showChkLinks)
        # -------------------------
        self.m_tool.add_separator()
        # "Extraire les modifications du dictionnaire..."
        self.m_tool.add_command(label=self.lg.get("menu", "m22"), compound=LEFT, image=self.imglst.export, command=self.showExtractModif)
        # -------------------------
        self.m_tool.add_separator()
        # "Convertir un gif en base64..."
        self.m_tool.add_command(label=self.lg.get("menu", "m23"), compound=LEFT, image=self.imglst.rien, command=self.convGifToBase64)
        
        
        self.menubar.add_cascade(label=self.lg.get("menu", "mtools"), underline=1, menu=self.m_tool)
        
        
        # -------------------------
        # --- Menu Plugins         
        # -------------------------
       
        self.m_plug = Menu(self.menubar, tearoff=0, font=mnufont, background=self.menubar['background'])
        
        self.menubar.add_cascade(label=self.lg.get("menu", "mplug"), underline=0, menu=self.m_plug)
        
        self.updateMenuPlugin()
        
        
        
        # -------------------
        # --- Menu Aide      
        # -------------------
        # (Nb : certains menus sont activés par LoadDico et l'instanciation de la fenêtre d'info)
        
        self.m_hlp = Menu(self.menubar, tearoff=0, font=mnufont, background=self.menubar['background'])
        
        # "A propos de Linguae..."
        self.m_hlp.add_command(label=self.lg.get("menu", "m25"), compound=LEFT, image=self.imglst.info, command=self.showAbout)
        # "Aide de Linguae..."
        self.m_hlp.add_command(label=self.lg.get("menu", "m26"), compound=LEFT, image=self.imglst.hlp, command=self.showHelp)
        # "Site Web de Linguae..."
        self.m_hlp.add_command(label=self.lg.get("menu", "m27"), compound=LEFT, image=self.imglst.web, command=self.toWebLing)
        # "Rechercher une nouvelle version de Linguae..."
        self.m_hlp.add_command(label=self.lg.get("menu", "m28"), compound=LEFT, image=self.imglst.chknewver, command=self.__checkProgVersion)
        
        # -----------------------
        self.m_hlp.add_separator()
        
        # "A propos de ce dictionnaire..."
        self.m_hlp.add_command(label=self.lg.get("menu", "m29"), compound=LEFT, image=self.imglst.info, command=self.showAboutDic, state='disabled')
        # "Contacter l'auteur de ce dictionnaire..."
        self.m_hlp.add_command(label=self.lg.get("menu", "m30"), compound=LEFT, image=self.imglst.mail, command=self.sendMailDic, state='disabled')
        # "Site Web de ce dictionnaire..."
        self.m_hlp.add_command(label=self.lg.get("menu", "m31"), compound=LEFT, image=self.imglst.web, command=self.toWebDic, state='disabled')
        # "Rechercher une nouvelle version de ce dictionnaire..."
        self.m_hlp.add_command(label=self.lg.get("menu", "m32"), compound=LEFT, image=self.imglst.chknewver, command=self.__checkDicVersion, state='disabled')
        
        # ------------------------
        self.m_hlp.add_separator()
        
        # "Chercher des dictionnaires sur le Web..."
        self.m_hlp.add_command(label=self.lg.get("menu", "m33"), compound=LEFT, image=self.imglst.web, command=self.toWebPolyglotte)
        
        self.menubar.add_cascade(label=self.lg.get("menu", "mhlp"), underline=0, menu=self.m_hlp)
        
        # ---
        
        self['menu'] = self.menubar
        
        
        return


    def doNothing(self):
        pass
    

    def __importPluginFromMenu(self):
        
        u"""
        | Importer un greffon, c.à.d. recopier son fichier dans le répertoire   
        | des greffons et dans la librairie de l'éxécutable le cas échéant.     
        """
        
        
        # -------------------------------------
        # --- Boîte de sélection de fichier    
        # -------------------------------------
        
        dirSearch = os.path.expanduser('~') # dossier personnel de l'utilisateur
        
        fichpath = tkFileDialog.askopenfilename(parent=self,
                    title = self.lg.get("menu", "m24a"),
                    filetypes = (
                    (app.lg.get("g", "fpy"),'*.py *.pyc'),
                    (app.lg.get("g", "fall"),'*.*'),
                                ),
                    initialdir = dirSearch
                    )
        
        if not fichpath: return   # L'utilisateur a cliqué 'Annuler' dans la boîte de dialogue
        
        
        # --------------------
        # --- Importer        
        # --------------------
        
        self.__importPlugin(fichpath)
        
        
        # ---------------------------
        # --- Avertir du succès      
        # ---------------------------
        
        tkMessageBox.showinfo(parent = self,
                        title = "Linguae",
                        message = self.lg.get("win1", "msg57") )
        
        return



    def __importPlugin(self, fichpath):
        u"""
        Importer un plugin à partir de son chemin source 'fichpath',
        c.à.d. recopier son fichier dans le répertoire des plugins
        et dans la librairie de l'éxécutable le cas échéant.
        Le fichier originel 'fichpath' est conservé.
        """
        
        
        if not os.path.isfile(fichpath):
            print fichpath + " n'existe pas !"
        
        
        # --------------------------------------------------------------------------
        # --- Recopier dans le répertoire des greffons (sous-rep de l'application)  
        # --------------------------------------------------------------------------
        
        # Chemin du répertoire des greffons de l'utilisateur
        dirplug = os.path.join(os.path.dirname(os.path.realpath(sys.argv[0])),'plugins')
        
        # Nom du fichier greffon
        fichplug = os.path.basename(fichpath)
        # Chemin du greffon cible
        fichplugpath = os.path.join(dirplug, fichplug)
        
        # Copier le greffon
        # Nb : un greffon n'étant pas destiné à être modifié par l'utilisateur,
        # il n'est pas nécessaire d'en faire une sauvegarde
        # on peut donc écraser "à la sauvage" le greffon préexistant
        if os.path.isfile(fichplugpath):
            # modifier les droits (nécessaire sous Linux)
            try   : os.chmod(fichplugpath, 0777)
            except: pass
            try   : os.remove(fichplugpath)
            except: print "\n'" + fichplugpath + "'\nEchec de la suppression du greffon originel dans le repertoire d'application !"
        
        try   : shutil.copy(fichpath, fichplugpath)
        except: print "\n'" + fichpath + "'\nEchec de la copie du greffon dans le repertoire d'application !"
        
        
        # -------------------------------------------------------------------
        # --- Recopier dans l'archive-bibliothèque de l'exécutable           
        # --- (si fonctionnement à partir d'un *.exe Windows)                
        # -------------------------------------------------------------------
        
        
        # Tester la présence de 'lib.zip' dans le répertoire de l'application
        libzippath = os.path.join(os.path.dirname(os.path.realpath(sys.argv[0])),'lib.zip')
        
        if os.path.isfile(libzippath): # le zip est présent, donc Linguae fonctionne en exe Windows
            
            import zipfile
            
            libzip = zipfile.ZipFile(libzippath, 'a')               # Instancier l'objet fichier Zip en mode "append"
            
            if os.path.splitext(fichpath)[1].startswith("py"):      # Le plugin est un module Python
                
                fichpath = os.path.splitext(fichpath)[0] + ".pyc"   # Privilégier le *.pyc s'il existe
                fichplug = os.path.splitext(fichplug)[0] + ".pyc"   
                if not os.path.isfile(fichpath):
                    fichpath = os.path.splitext(fichpath)[0] + ".py"
                    fichplug = os.path.splitext(fichplug)[0] + ".py" 
            
            libzip.write(fichpath, "plugins\\" + fichplug)          # Ajouter le greffon au Zip-bibliothèque
        
        
        # Rafraîchir le menu des plugins
        
        self.updateMenuPlugin()
        
        return



    def doNothing(self):
        pass


    def __scanrepdic(self, rep, m_parent, mnufont, flagdicname=True):
        
        u"""
        | Scannage RECURSIF du répertoire des dictionnaire                      
        | avec complémentation parallèle du menu 'Dictionnaires'                
        | retourne le nombre d'éléments (dictionnaire ou dossier) trouvés.      
        |                                                                       
        | Complète .diclocaldatabase  (nb la réinitialisation  de cette liste   
        | doit être effectué dans la procédure appelante du fait du             
        | fonctionnement récursif de la présente procédure)                     
        |                                                                       
        | ARGUMENTS :                                                           
        |   'rep' : répertoire à scanner                                        
        |                                                                       
        |   'm_parent' : menu parent, menu dans lequel seront placées les lignes
        |                de menu.                                               
        |                                                                       
        |   'mnufont' : police du menu                                          
        |                                                                       
        |   'flagdicname' : si 'True' les noms conviviaux sont inscrits dans le
        |                   menu, si 'False' les noms de fichier                
        """
        
        # accélérateurs locaux
        getproprLING = lib.mydic.DicObject.getPropertiesLing
        getproprXDXF = lib.mydic.DicObject.getPropertyXDXF
        getproprDICT = lib.mydic.DicObject.getPropertiesDict
        addcommmand = m_parent.add_command
        isfich = os.path.isfile
        getext = os.path.splitext
        addtodicbase = self.diclocaldatabase.append
        # ---
        
        try:
            lstfich = os.listdir(rep)    # liste des entrées (fichiers et dossiers) du répertoire lié au menu
        except:
            print "### Echec listage rep dicos ###" 
            return
        
        # Trier la liste des entrées sans prise en comte des préfixes "stardict-"
        
        for n in range(len(lstfich)):
            if lstfich[n].startswith("stardict-"):
                lstfich[n] = lstfich[n][9:] + "*"
        
        
        lstfich.sort(lambda x,y: cmp(x.lower(),y.lower())) # tri alphabétique insensible à la casse
        
        for n in range(len(lstfich)):
            if lstfich[n].endswith("*"):
                lstfich[n] = "stardict-" + lstfich[n][:-1]
        
        
        # Scanner la liste pour remplir le menu
        n=0
        for f in lstfich:
            
            fpath = os.path.join(rep,f)
            
            # ==================================================================
            if isfich(fpath): # === C'est un fichier                            
            # ==================================================================
                
                flagaddtobase = False
                
                ext = getext(f)[1].lower()
                
                dicdate = ""
                dicversion = ""
                
                # --------------------------------------------------------------
                if ext == ".ling": # -------------------------------------------
                # --------------------------------------------------------------
                    try:
                        propr = getproprLING(filepath=fpath) # pyDictionnaire des propriétés du dico
                    except:
                        pass    # echec = fichier foireux > on le masque
                    else:
                        
                        try:
                            dicdate = propr['versionDate']
                        except:
                            pass
                        
                        try:
                            dicversion = propr['dicVersionNumber']
                        except:
                            pass
                        
                        if flagdicname:
                            
                            
                            # Extraire le nom convivial + (auteur)
                            try:
                                nm = propr['dicName'].strip('"').strip("'")
                            except:
                                nm = f
                            
                            if nm == "":
                                nm = f
                            
                            try:
                                auth = propr['shortAuthors'].strip('"').strip("'")
                            except:
                                auth = ""
                            
                            if auth != "":
                                nm = nm +" (" + auth + ")"
                            
                            
                        else:
                            nm = f
                        
                        # ---
                        
                        addcommmand(label=nm, compound=LEFT, image=self.imglst.dicling, command=lambda arg1=f, arg2=m_parent : self.openDicFromMenuDic(arg1, arg2))
                        n += 1
                        flagaddtobase = True
                    
                    
                # ------------------------------------------------------------------
                elif (ext == ".dict") or (f[-8:] in (".dict.dz", ".dict.gz")): # ---
                # ------------------------------------------------------------------
                    
                    propr = getproprDICT(filepath=fpath) # pyDictionnaire des propriétés du dico
                    
                    try:
                        dicdate = propr['date']
                    except:
                        pass
                    
                    # Attention ! la propriété 'version' d'un dico dic contient la version Startdict et non celle du dico !
                    # > Non ! : dicversion = propr['version']
                    
                    if flagdicname:
                        
                        
                        # Extraire le nom convivial + (auteur)
                        try:
                            nm = propr['bookname'].strip('"').strip("'")
                        except:
                            nm = f
                        
                        if nm == "":
                            nm = f
                        
                        try:
                            auth = propr['author'].strip('"').strip("'")
                        except:
                            auth = ""
                        
                        if auth != "":
                            nm = nm +" (" + auth + ")"
                        
                    else:
                        nm = f
                    
                    # ---
                    
                    addcommmand(label=nm, compound=LEFT, image=self.imglst.dicdict, command=lambda arg1=f, arg2=m_parent : self.openDicFromMenuDic(arg1, arg2))
                    n += 1
                    flagaddtobase = True
                    
                    
                # --------------------------------------------------------------
                elif ext == ".xdxf": # -----------------------------------------
                # --------------------------------------------------------------
                    
                    dicdate = getproprXDXF(filepath=fpath, proprname="date", rootproprname="description")
                    
                    if dicdate is None:
                        dicdate = ""
                    
                    if flagdicname:
                        
                        # Extraire le nom convivial + (auteur)
                        nm = getproprXDXF(filepath=fpath, proprname="full_name")
                        
                        if nm:
                            if nm == "":
                                nm = f
                        else:
                            nm = f
                        
                        try:
                            nm = nm.encode('utf-8')
                        except:
                            pass
                        
                        auth = getproprXDXF(filepath=fpath, proprname="author")
                        if auth:
                            if auth != "":
                                nm = nm + " (" + auth + ")"
                    
                    else:
                        nm = f
                    
                    # ---
                    
                    addcommmand(label=nm, compound=LEFT, image=self.imglst.dicxdxf, command=lambda arg1=f, arg2=m_parent : self.openDicFromMenuDic(arg1, arg2))
                    n += 1
                    flagaddtobase = True
                    
                    
                # --------------------------------------------------------------
                elif ext == ".wb": # -------------------------------------------
                # --------------------------------------------------------------
                    
                    addcommmand(label=f, compound=LEFT, image=self.imglst.dicwb, command=lambda arg1=f, arg2=m_parent : self.openDicFromMenuDic(arg1, arg2))
                    n += 1
                    flagaddtobase = True
                    
                    
                # --------------------------------------------------------------
                elif ext in (".csv", ".tab", ".txt"): # ------------------------
                # --------------------------------------------------------------
                    
                    addcommmand(label=f, compound=LEFT, image=self.imglst.diccsv, command=lambda arg1=f, arg2=m_parent : self.openDicFromMenuDic(arg1, arg2))
                    n += 1
                    flagaddtobase = True
                    
                    
                # --------------------------------------------------------------
                elif ext == ".ini": # ------------------------------------------
                # --------------------------------------------------------------
                    
                    addcommmand(label=f, compound=LEFT, image=self.imglst.dicini, command=lambda arg1=f, arg2=m_parent : self.openDicFromMenuDic(arg1, arg2))
                    n += 1
                    flagaddtobase = True
                
                
                # --------------------------------------------------------------------
                # --- Compléter la base des dictionnaires locaux (nom, date, version) 
                # --------------------------------------------------------------------
                
                if dicdate and dicdate != "":
                        dicdate = dicdate.replace("-", "")
                        dicdate = dicdate.replace("/", "")
                        dicdate = dicdate.replace(".", "")
                
                if ext ==".xdxf":
                    # ajouter le nom du répertoire parent
                    addtodicbase( (os.path.basename(rep), dicdate, dicversion ) )
                else:
                    # ajouter le nom du fichier
                    addtodicbase( (f, dicdate, dicversion) )
                
                
                
            # ==================================================================
            else: # === C'est un répertoire                                     
            # ==================================================================
                
                if not f.endswith("_res"): # Sauter les répertoires de ressources associées aux dicos
                    
                    # Créer un sous-menu
                    m = Menu(m_parent, tearoff=0, title=m_parent['title'] + '|' + f, font=mnufont)
                    m_parent.add_cascade(label=f, compound=LEFT, image=self.imglst.folder, menu=m)
                    n += 1
                    
                    # ---> Scannage récursif de ce sous-répertoire
                    subrep = os.path.join(rep,f)              
                    self.__scanrepdic(subrep, m, mnufont, flagdicname=flagdicname)
         
         
        if n == 0:
            addcommmand(label=self.lg.get("menu", "m9"), state='disabled') # ("(Aucun dictionnaire)")      
            
        return n
    
    
    
    def copyAs(self):
        u"""
        Copier le dictionnaire courant sous un autre nom de fichier
        """
        
        # --------------------------------------------
        # --- Boîte de sélection du nom de fichier    
        # --------------------------------------------
        
        fichpath = tkFileDialog.asksaveasfilename(parent=self,
                    title = self.lg.get("menu", "m3b"),
                    filetypes = ((app.lg.get("g", "fall"),'*.*'),),
                    initialfile = os.path.basename(self.dic.path),
                    initialdir = os.path.expanduser('~'),
                    )
        
        if not fichpath: return   # L'utilisateur a cliqué 'Annuler' dans la boîte de dialogue
        
        # -------------------
        # --- Copier         
        # -------------------
        
        # Nb l'avertissemnt anti-écrasement est fourni par le système
        
        shutil.copy2(self.dic.path, fichpath)
        
        
        
        return
    
    
    def updateMenuDic(self):
        u"""
        | Met à jour le menu des dictionnaires                                  
        | à partir du contenu du répertoire des dictionnaires                   
        |                                                                       
        | Met à jour .diclocaldatabase                                          
        """
        
        mnufont = self.menubar['font']
        
        
        # -------------------------
        # --- Vider le menu        
        # -------------------------
        
        self.m_dic.delete(0, END)
        
        flagvide = True
        
        # ------------------------------------------------------
        # --- Définir le dossier de stockage des dictionnaires  
        # ------------------------------------------------------
        
        dp = self.ini.get('DicStorageFolder','')
        
        if dp == "" or not os.path.isdir(dp):
            self.m_dic.add_command(label=self.lg.get("menu", "m34"), command=lambda : self.showOptions(seefirst=1)) # '(chemin non paramétré : voir "Options")'
            return
        
        
        # ---------------------------
        # --- Initialiser le menu    
        # ---------------------------
        
        if self.pf in ('win', 'linux'):
            self.m_dic.add_command(label=self.lg.get("menu", "m9b"), command=self.__openRepDic)
            self.m_dic.add_separator()
        
        
        # --------------------------------------------------------
        # --- Scanner le dossier de stockage des dictionnaires    
        # --------------------------------------------------------
        
        
        # Option noms conviviaux ou noms de fichier
        if self.ini.get('DicNamesInMenu', '1') == '0':
            flagdicname = False
        else:
            flagdicname = True
        
        # Réinitialiser la base des dicos stockés
        self.diclocaldatabase = []  
        
        # Scanner et reconstruire (procédure récursive)
        self.__scanrepdic(dp, m_parent=self.m_dic, mnufont=mnufont, flagdicname=flagdicname) 
        
        return


    def __openRepDic(self):
        
        u"""
        | Ouvrir le dossier de stockage des dictionnaires dans le gestionnaire  
        | de fichiers de la plateforme.                                         
        """
        
        rep = self.ini.get('DicStorageFolder','')
        
        r = shellopen(rep)
        
        if r != 0:
            tkMessageBox.showwarning(parent=self,
            title = "Linguae",
            message = "Can't open...\n\n'" + rep + "'")
        
        return


    def updateMenuPlugin(self):
        u"""Met à jour le menu des greffons
        à partir du contenu du répertoire des greffons 'plugins'
        """
        
        
        # --- Vider le menu (seulement les lignes de nom de greffons)        
        
        self.m_plug.delete(0, END)
        
        
        
        # Importer un greffon
        self.m_plug.add_command(label=self.lg.get("menu", "m24a"), compound=LEFT, command=self.__importPluginFromMenu)
        # -------------------------
        self.m_plug.add_separator()
        # "Aucun"
        self.m_plug.add_command(label=self.lg.get("menu", "m24"), compound=LEFT, image=self.imglst.plugnone, command=self.stopPlugin)
        
        
        
        # Chemin du répertoire des plugins
        dirplug = os.path.join(os.path.dirname(os.path.realpath(sys.argv[0])),'plugins')
        
        # Scanner le répertoire des plugins
        if os.path.isdir(dirplug):
            
            self.lstplug = {}   # pyDictionnaire [titre] : (nom, icône)
            
            
            for f in os.listdir(dirplug):
                
                if not f.startswith("__init__") and (f.endswith(".py") or f.endswith(".pyc")):
                    f = f.replace(".pyc", "")           # Masquer l'extension
                    f = f.replace(".py", "")
                    t = f.capitalize()                  # Première lettre en majuscule pour l'affichage dans le menu
                    
                    # Importer immédiatement le plugin (nécessaire pour accèder à son icône)
                    try:
                        exec ("import plugins." + f) in globals()
                        ic = PhotoImage(data= eval("plugins." + f +".Widget.codeImage")) # icône du plugin
                        
                        if not self.lstplug.has_key(t): # éviter les doublons
                            self.lstplug[t] = (f, ic)
                    except:
                        if not self.lstplug.has_key(t): # éviter les doublons
                            self.lstplug[t] = (f, None)
                    
            
            # Compléter le menu des plugins
            for t, (f, ic) in self.lstplug.items():
                self.m_plug.add_command(label=t, compound=LEFT, image=ic, command= lambda arg=f: self.runPlugin(arg))
        
        
        return


    def __makeToolBar(self):
        
        u"""
        | Constuire la barre d'outils                                           
        | de la fenêtre principale                                              
        """
        x = 1
        y = 3
        ix = 1
        iy = 1
        
        tb = Frame(self, borderwidth=1, relief=RAISED)
        #tb.grid(row=0, column=0, columnspan=10, sticky='WE')
       
        # "Ouvrir un dictionnaire"
        B1 = Button(tb, image=self.imglst.open, borderwidth=1, relief=FLAT, command=self.openDicFromDialog, height=20, width=20)
        B1.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        lib.infobulle.InfoBulle(parent=B1, text=self.lg.get("win1", "ib11"), arg_enter=self.enterMenuButton, arg_leave=self.leaveMenuButton)
        
        # "Propriétés du dictionnaire"
        B2=Button(tb, image=self.imglst.propr, borderwidth=1, relief=FLAT, command=self.showProperties, height=20, width=20)
        B2.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        lib.infobulle.InfoBulle(parent=B2, text=self.lg.get("win1", "ib12"), arg_enter=self.enterMenuButton, arg_leave=self.leaveMenuButton)
        
        # "Exporter le dictionnaire",
        B3=Button(tb, image=self.imglst.export, borderwidth=1, relief=FLAT, command=self.showExport, height=20, width=20)
        B3.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        lib.infobulle.InfoBulle(parent=B3, text=self.lg.get("win1", "ib13"), arg_enter=self.enterMenuButton, arg_leave=self.leaveMenuButton)
        
        # séparateur
        Label(tb, image=self.imglst.toolsep).pack(side=LEFT) 
        
        # "Ouvrir le dictionnaire inverse"
        B11=Button(tb, image=self.imglst.seerev, borderwidth=1, relief=FLAT, command=self.openReverseDic, height=20, width=20)
        B11.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        lib.infobulle.InfoBulle(parent=B11, text=self.lg.get("win1", "ib14"), arg_enter=self.enterMenuButton, arg_leave=self.leaveMenuButton)
        
        # séparateur
        Label(tb, image=self.imglst.toolsep).pack(side=LEFT) 
        
        B4=Button(tb, image=self.imglst.find, borderwidth=1, relief=FLAT, command=self.showFind, height=20, width=20)
        B4.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        lib.infobulle.InfoBulle(parent=B4, text=self.lg.get("win1", "ib15"), arg_enter=self.enterMenuButton, arg_leave=self.leaveMenuButton)
        
        # séparateur
        Label(tb, image=self.imglst.toolsep).pack(side=LEFT) 
        
        # "Editer l'entrée de dictionnaire"
        B5=Button(tb, image=self.imglst.edit, borderwidth=1, relief=FLAT, command=self.showEdit, height=20, width=20)
        B5.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        lib.infobulle.InfoBulle(parent=B5, text=self.lg.get("win1", "ib16"), arg_enter=self.enterMenuButton, arg_leave=self.leaveMenuButton)
        
        # "Ajouter une nouvelle entrée de dictionnaire"
        B7=Button(tb, image=self.imglst.add, borderwidth=1, relief=FLAT, command=self.showEditAdd, height=20, width=20)
        B7.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        lib.infobulle.InfoBulle(parent=B7, text=self.lg.get("win1", "ib17"), arg_enter=self.enterMenuButton, arg_leave=self.leaveMenuButton)
        
        # "Supprimer l'entrée de dictionnaire sélectionnée"
        B8=Button(tb, image=self.imglst.suppr, borderwidth=1, relief=FLAT, command=self.editDel, height=20, width=20)
        B8.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        lib.infobulle.InfoBulle(parent=B8, text=self.lg.get("win1", "ib18"), arg_enter=self.enterMenuButton, arg_leave=self.leaveMenuButton)
        
        # "Trier le dictionnaire"
        B10=Button(tb, image=self.imglst.sortcr, borderwidth=1, relief=FLAT, command=self.showSort, height=20, width=20)
        B10.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        lib.infobulle.InfoBulle(parent=B10, text=self.lg.get("win1", "ib19"), arg_enter=self.enterMenuButton, arg_leave=self.leaveMenuButton)
        
        # "Afficher la table des caractères"
        B9=Button(tb, image=self.imglst.carspec, borderwidth=1, relief=FLAT, command=self.showUnicode, height=20, width=20)
        B9.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        lib.infobulle.InfoBulle(parent=B9, text=self.lg.get("win1", "ib20"), arg_enter=self.enterMenuButton, arg_leave=self.leaveMenuButton)
        
        # séparateur
        Label(tb, image=self.imglst.toolsep).pack(side=LEFT) 
        
        # Gestionnaire d'historique de navigation
        self.hist = lib.mynavig.HistorNav(tb, gethistory=self.getHistory, background=tb['background'])
        self.hist.pack(padx=x, side=LEFT)
        lib.infobulle.InfoBulle(parent=self.hist, text=self.lg.get("win1", "ib25"))
        
        # séparateur
        Label(tb, image=self.imglst.toolsep).pack(side=LEFT) 
        
        # "Télécharger des dictionnaires"
        B12=Button(tb, image=self.imglst.dwnld, borderwidth=1, relief=FLAT, command=self.showDwnld, height=20, width=20)
        B12.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        lib.infobulle.InfoBulle(parent=B12, text=self.lg.get("menu", "m7b"), arg_enter=self.enterMenuButton, arg_leave=self.leaveMenuButton)
        
        # "Voir l'aide de Linguae"
        B6=Button(tb, image=self.imglst.hlp, borderwidth=1, relief=FLAT, command=self.showHelp, height=20, width=20)
        B6.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        lib.infobulle.InfoBulle(parent=B6, text=self.lg.get("win1", "ib21"), arg_enter=self.enterMenuButton, arg_leave=self.leaveMenuButton)
        
        # séparateur
        Label(tb, image=self.imglst.toolsep, width=40).pack(side=LEFT) 
        
        
        # "Interroger SWAC"
        B13=Button(tb, image=self.imglst.audio, compound=LEFT, text= "SWAC", borderwidth=1, relief=FLAT, command=self.showSwac, height=20, width=60)
        #B13.pack(padx=x, pady=y, side=LEFT, ipadx=ix, ipady=iy)
        lib.infobulle.InfoBulle(parent=B13, text="Interroger SWAC", arg_enter=self.enterMenuButton, arg_leave=self.leaveMenuButton)
        
        tb.pack(fill=X)
        
        return


    def getHistory(self, histitem):
        
        u"""
        | Fonction passée au navigateur d'historique, ce dernier l'invoque      
        | lors de l'action sur les touches de navigation                        
        """
        
        if histitem is None:
            return
        
        # on récupère l'index
        i = histitem[0]
        
        
        # Sélectionner dans la listbox
            
        self.lst_dico.selection_clear(0, END)       # Désélectionner tout dans la Listbox
            
        self.lst_dico.activate(i)
        self.lst_dico.selection_set(i)
        self.lst_dico.see(i)
            
        self.selDisplayData(event=None)
        
        
        return



    def toWebLing(self, cible=None):
        
        u"""
        | Ouvrir la page web de Linguae dans le navigateur par défaut.          
        | Affiche une boîte de message si échec.
        |                                                                       
        | ARGUMENTS :                                                           
        |   'cible' : détermine la page cible du site                           
        |               = "maj"     ---> page de téléchargement                 
        |               = <autre>   ---> page d'accueil                         
        |                                                                       
        """
        
        # --------------------------------------------------
        # --- Connexion pour Mise à jour du programme       
        # --------------------------------------------------
        
        if cible == "maj":
            
            # Ouverture de la page de téléchargement
            # Le n° de la version actuellement utilisée est envoyée au serveur par l'url
            try:
                webbrowser.open('http://stalikez.info/linguae/dwnld.php?ex=' + self.version.split()[0])
            except:
                tkMessageBox.showwarning(parent=self,
                        title=self.lg.get("win1", "msg16"),
                        message=self.lg.get("win1", "msg17") ) # ("échec de la connexion")
        
        
        # ---------------------------------------------------
        # --- Connexion pour simple consultation du site     
        # ---------------------------------------------------
        
        else:
            # Ouverture de la page d'accueil
            try:
                webbrowser.open('http://stalikez.info/linguae')
            except:
                tkMessageBox.showwarning(parent=self,
                        title=self.lg.get("win1", "msg18"),
                        message=self.lg.get("win1", "msg17") ) # ("échec de la connexion")
        
        return
    
    
    
    def toWebPolyglotte(self, event=None):
        
        u"""
        | Ouvrir la page web de Polyglotte dans le navigateur par défaut.       
        """
        
        r = tkMessageBox.askyesno(parent=self,
                    title=self.lg.get("win1", "msg19"),
                    message=self.lg.get("win1", "msg20")) # ("Linguae va vous connecter à Polyglotte, continuer ?")
        if r == False: return
        
        try:
            webbrowser.open('http://polyglotte.tuxfamily.org')
        except:
            pass
        
        return
    
    
    def toWebDic(self):
        
        u"""
        Ouvrir la page Web du dictionnaire dans le navigateur par défaut
        """
        
        try:
            webbrowser.open(self.dic.dicUrl)
        except:
            pass
        
        return


    def sendMailDic(self):
        
        u"""
        Envoyer un e-mail à l'auteur du dictionnaire
        """
        
        targetAddr = self.dic.contactAuthor.strip()
        obj = self.lg.get("win1", "s10") + " " #("A propos de votre dictionnaire")
        
        if self.dic.dicName != "":
            obj += self.dic.dicName
        
        if self.pf == 'win':  
            os.startfile('mailto:'+ targetAddr + "?subject=" + obj)
        else:
            tkMessageBox.showwarning(parent=self,
                    title = "Linguae",
                    message = self.lg.get("win1", "msg21") + " \n" + targetAddr + "\n" + self.lg.get("win1", "msg22") ) # ("fonctionnalité non disponible, utilisez votre messagerie habituelle")
        
        return
    

    def enterMenuButton(self, wButton):
        
        u"""
        | Entrée de la souris sur un bouton de menu                             
        |  > afficher la bordure du bouton                                      
        """
        
        wButton['relief']=RAISED 
        
        return


    def leaveMenuButton(self, wButton):
        
        u"""
        | Sortie de la souris d'un bouton de menu                               
        |  > masquer la bordure du bouton                                       
        """
        
        wButton['relief']=FLAT
        
        return



    def editMove(self):
        
        u"""
        | Déplacer l'entrée de dictionnaire en sélection                        
        """
        
        # --- Contrôles préalables
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title=self.lg.get("win1", "msg24"),
                    message=self.lg.get("g", "loadfst")) # ("Chargez d'abord un dictionnaire !")
            return
        
        try:
            isource = int(app.lst_dico.curselection()[0]) # index du mot en sélection
        except:
            tkMessageBox.showinfo(parent=self,
                    title=self.lg.get("win1", "msg24"),
                    message=self.lg.get("win1", "msg25") ) # ("Sélectionnez d'abord une entrée !")
            return
        
        # --- Demander l'index cible
        
        imax = self.dic.wordcount - 1
        
        icible = tkSimpleDialog.askstring(parent=self,
                title=self.lg.get("win1", "msg24"),
                prompt=self.lg.get("win1", "msg26") + " " + str(isource) + "\n\n" + self.lg.get("win1", "msg27") + "\n\n   0 - " + str(imax) + "\n",
                initialvalue=str(isource))
        
        # --- Contrôles de la valeur fournie
        
        if not icible:
            return
        elif icible == isource:
            return
        
        flagbad = False 
        try:
            icible = int(icible)
        except:
            flagbad = True
            
        if icible >= imax:
            flagbad = True
        
        if flagbad:
            tkMessageBox.showwarning(parent=self,
                    title=self.lg.get("win1", "msg24"),
                    message=self.lg.get("win1", "msg28") + " " + str(imax)) # ("Valeur incorrecte")
            return
        
        # --- Déplacer
        
        self['cursor']="watch"
        
        i = self.dic.moveindic(isource, icible)
        
        # --- Sélectionner l'entrée déplacée
        if not i is None:
            self.dic.lstbox.activate(i)
            self.dic.lstbox.selection_set(i)
            self.dic.lstbox.see(i)
            self.selDisplayData(None)
        
        self['cursor']=""
        
        return
    

    def editDel(self):
        
        u"""
        | Supprimer l'entrée de dictionnaire en sélection                       
        """
        
        # --- Contrôles préalables
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title=self.lg.get("win1", "msg23"),
                    message=self.lg.get("g", "loadfst") ) # ("Chargez d'abord un dictionnaire !")
            return
        
        try:
            i = int(self.lst_dico.curselection()[0]) # index du mot en sélection
        except:
            tkMessageBox.showinfo(parent=self,
                    title=self.lg.get("win1", "msg23"),
                    message=self.lg.get("win1", "msg25") ) # ("Sélectionnez d'abord une entrée !")
            return
        
        # --- Confirmer la suppression
        # (ne pas afficher le libellé de l'entrée : possibilité de problèmes d'encodages insolubles...)
        r = tkMessageBox.askokcancel(default='cancel',
                title = self.lg.get("win1", "msg23"),
                message = self.lg.get("win1", "msg29") + " " + str(i) + " ?\n" + self.lg.get("win1", "msg30") )
        
        if not r: return
        
        # ------------------------------------
        # --- Aiguillage de la suppression    
        # ------------------------------------
        
        app['cursor'] = "watch"
        
        i = int(self.lst_dico.curselection()[0])    # index du mot en sélection à supprimer
        ID = self.status3['text']                   # ID du mot en sélection à supprimer
        
        if app.dic.type.startswith("ling"):
            self.editDelLing(i)
        
        elif app.dic.type.startswith("wb"):
            self.editDelWB(i)
        
        elif app.dic.type.startswith("dict"):
            self.editDelDict(i)
        
        elif app.dic.type.startswith("xdxf"):
            self.editDelCSVorINIorXDXF(i)
        
        elif app.dic.type.startswith("csv"):
            self.editDelCSVorINIorXDXF(i)
        
        elif app.dic.type.startswith("ini"):
            self.editDelCSVorINIorXDXF(i)
        
        
        # ------------------------------------------------
        # --- Rafraîchit l'affichage des données          
        # ------------------------------------------------
        # (affiche l'entrée suivante puisque i a été supprimé)
        
        self.dic.lstbox.update()
        if i > self.lst_dico.size()-1 : i == self.lst_dico.size()-1
        
        self.dic.lstbox.activate(i)
        self.dic.lstbox.selection_set(i)
        self.dic.lstbox.see(i)
        self.selDisplayData(None)
        
        
        # -----------------------------------------------------------------------
        # --- Effacement des ressources externes associées à l'entrée supprimée  
        # -----------------------------------------------------------------------
        
        
        # --- audio (prononciation)
        lf = glob.glob(os.path.join(self.dic.path + "_res", "audio", ID + ".*"))
        for f in lf:
            
            try   : os.chmod(f, 0777)   # Ouvrir tous les droits sur le fichier
            except: pass
            
            try   : os.remove(f)        # Supprimer le fichier
            except: pass
        
        # --- illustrations
        
        lf = glob.glob(os.path.join(self.dic.path + "_res", "img", ID + "_*.*"))
        for f in lf:
            
            try   : os.chmod(f, 0777)   # Ouvrir tous les droits sur le fichier
            except: pass
            
            try   : os.remove(f)        # Supprimer le fichier
            except: pass
        
        
        # ---
        
        app['cursor'] = ""
        
        return



    def editDelLing(self, i):
        
        u"""
        | Supprimer l'entrée d'index i d'un dictionnaire Ling                   
        """
        
        # Confectionner la nouvelle chaîne Preling du dictionnaire en sautant
        # l'entrée à supprimer
        strPreling = self.dic.toStrPreling(progr=None, iEdit=i, contentEdit="---")
        
        # Confectionner la nouvelle chaîne Ling
        
        strLing = lib.mydic.DicObject.strPrelingToStrLing(strPreling=strPreling)
        
        # Enregistre le nouveau fichier
        fichpath = self.dic.path
        app.dic.file.close()
        ff = open(fichpath, 'wb')
        ff.write(strLing)
        ff.close()
        
        # Recharge le dictionnaire avec le nouveau fichier
        self.loadDico(fichpath, showSplash=False)
        
        
        return


    def editDelWB(self, i):
        
        u"""
        | Supprimer l'entrée d'index i d'un dictionnaire WB                     
        """
        
        # Mise à jour de la liste des entrées dans l'interface
        app.lst_dico.delete(i)
        
        
        # Confectionner la nouvelle chaîne du fichier
        
        fichpath = self.dic.path
        self.dic.file.seek(0)
        part1 = self.dic.file.read(84*i)
        self.dic.file.seek(84*(i+1))
        part2 = self.dic.file.read(os.path.getsize(fichpath))
        
        strfile = part1 + part2
        
        
        # Enregistre le nouveau fichier WB
        fichpath = self.dic.path
        app.dic.file.close()
        ff = open(fichpath, 'wb')
        ff.write(strfile)
        ff.close()
        
        
        # Recharge le dictionnaire avec le nouveau fichier
        cp1 = app.dic.encoding1
        cp2 = app.dic.encoding2
        self.loadDico(fichpath, cp1=cp1, cp2=cp2, showSplash=False)
        
        return ""


    def editDelDict(self, i):
        
        u"""
        | Supprimer l'entrée d'index i d'un dictionnaire Dict                   
        """
        
        if self.dic.type in ("dictdz", "dictgz"):
            app.hideProgr()
            tkMessageBox.showinfo(parent=self,
                    title=self.lg.get("win1", "msg23"),
                    message=self.lg.get("win1", "msg31") ) # ("format DICT compressé > convertissez d'abord")
            return
        
        
        # Confectionner les nouvelles chaînes du dictionnaire Dict en sautant
        # l'entrée à supprimer
        strs = self.dic.toStrsDict(progr=None, iEdit=i, contentEdit="---")
        
        
        # si strs est une chaine et non un tupple => problème !
        if type(strs) is type("xxx"):
            return strs
        
        
        # ------------------------------------------------------
        # --- Enregistrer les nouveaux fichiers *.idx et *.dict
        # ------------------------------------------------------
        
        radicfich = os.path.splitext(app.dic.path)[0]     # Radical des différents fichiers Dict
        
        app.dic.file.close()
        
        ff = open(radicfich + '.idx', 'wb')   # Enregistrer le *idx
        ff.write(strs[0])
        ff.close()
        
        ff = open(radicfich + '.dict', 'wb')  # Enregistrer le *dict
        ff.write(strs[1])
        ff.close()
        
        
        # ------------------------------------------------
        # --- Reconstruire le fichier *.ifo               
        # ------------------------------------------------
        lg = ""
        strifo = ""
        ff = open(radicfich + '.ifo', 'rU')
        
        for ligne in ff:
            
            if ligne.startswith("wordcount="):
                lg = "wordcount=" + strs[2] + "\n"
            elif ligne.startswith("idxfilesize="):
                lg = "idxfilesize=" + str(os.path.getsize(radicfich + ".idx")) + "\n"
            else:
                lg = ligne
                
            strifo += lg 
        
        ff.close()
        ff = open(radicfich + '.ifo', 'wb')   # Enregistrer le *ifo
        ff.write(strifo)
        ff.close()
        
        
        
        # --------------------------------------------------------------
        # --- Recharger le dictionnaire avec le nouveau fichier Dict    
        # --------------------------------------------------------------
        
        app.loadDico(radicfich + '.dict', showSplash=False)
        
        
        return ""



    def editDelCSVorINIorXDXF(self, i):
        
        u"""
        | Supprimer l'entrée d'index i d'un dictionnaire CSV, INI, XDXF         
        """
        
        
        # -----------------------------------------------------
        # --- Confectionner les blocs du fichier, à conserver  
        # -----------------------------------------------------
        
        fichpath = app.dic.path
        
        ii = i-1
        if ii<0: ii=0
        
        app.dic.file.seek(0)
        part1 = app.dic.file.read(app.dic.datamap[ii][0] + app.dic.datamap[ii][1])
        
        
        app.dic.file.seek(app.dic.datamap[i][0] + app.dic.datamap[i][1])
        part2 = app.dic.file.read(os.path.getsize(fichpath)) # lit jusqu'au bout du fichier
        
        
        # -------------------------------------------------
        # --- Mise à jour du fichier                       
        # -------------------------------------------------
        
        # Confectionner la nouvelle chaîne du fichier
        strfile = part1 + part2
        
        # Enregistrer le fichier
        app.dic.file.close()
        app.dic.file = open(fichpath, 'wb')
        app.dic.file.write(strfile)
        app.dic.file.close()
        app.dic.file = open(fichpath, 'rb')
        
        
        # Recharge le dictionnaire avec le nouveau fichier
        cp = app.dic.encoding1
        app.loadDico(fichpath, cp1=cp, showSplash=False)
        
        
        return ""


    def openReverseDic(self):
        
        u"""
        | Recherche et charge le dictionnaire inverse                           
        """
        
        # Aucun dico n'est chargé > avertir et quitter
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("win1", "msg32"),
                    message = self.lg.get("win1", "msg33") ) # ("Chargez d'abord un dictionnaire de référence !")
            return
        
        
        # ------------------------------------------------------------------------------
        # --- Si le nom de fichier du dico inverse est inscrit dans le dico courant :   
        # ------------------------------------------------------------------------------
        
        if app.dic.reverseDicFileName != "":
            
            # gestion de la présence de caractères étendus Utf-8 dans reverseDicFileName
            f = app.dic.reverseDicFileName
            f = f.decode('utf-8')
            revfichpath = os.path.join(os.path.dirname(app.dic.path), f)
            
            if self.pf == 'win':
                revfichpath = revfichpath.encode('cp1252')
            else:
                revfichpath = revfichpath.encode('utf-8')
        
        
        # ------------------------------------------------------------------------------
        # --- Si le nom de fichier du dico courant se termine par "_rev"                
        # ------------------------------------------------------------------------------
        
        elif os.path.splitext(app.dic.path)[0].endswith("_rev"):
            
            # On enlève le "_rev" et on ajoute l'extension
            revfichpath = os.path.splitext(app.dic.path)[0][:-4] + os.path.splitext(app.dic.path)[1]
        
        
        # ----------------------------------------------------------------------------
        # --- Cas du xdxf : prendre en compte le répertoire et non le nom de fichier  
        # ----------------------------------------------------------------------------
        
        elif app.dic.type.startswith("xdxf"):
            rep = os.path.dirname(app.dic.path)
            fich = os.path.basename(app.dic.path)
            
            if rep.endswith("_rev"):
                rep = rep[:-4]
            else:
                rep = rep + "_rev"
            
            revfichpath = os.path.join(rep, fich)
        
        
        # -----------------------------------------------------------
        # --- Tenter de deviner le nom de fichier du dico inverse    
        # -----------------------------------------------------------
        
        else:
            
            f = os.path.splitext(os.path.basename(app.dic.path))
            
            fichname = f[0]
            fichext = f[1]
            revfich = ""
            revfichpath = ""
            
            for sp in (" - ", "-", " _ ", "_", "  ", " "):
                p = fichname.find(sp)
                if p>0:
                    
                    revfich = fichname[p+1:]+ sp + fichname[:p ] + fichext
                    revfichpath = os.path.join(os.path.dirname(app.dic.path), revfich)
                    if os.path.isfile(revfichpath): 
                        break
        
        
        # ------------------------------------------------------------
        # --- On quitte si le fichier du dico inverse n'existe pas    
        # ------------------------------------------------------------
        
        # On demande pour construire le dico inverse immédiatement
        if not os.path.isfile(revfichpath):
                r = tkMessageBox.askyesno(parent=self,
                        title = self.lg.get("win1", "msg32"),
                        message = self.lg.get("win1", "msg58")) 
                
                if r == False:
                    return              # On quitte sans rien faire
                else:
                    self.showReverse()  # On quite en ouvrant la fenêtre d'inversion
                return
        
        
        # -------------------------------------------------
        # --- Rechercher les encodages du dico si besoin   
        # -------------------------------------------------
        
        ext = os.path.splitext(revfichpath)[1].lower() # Extension du fichier du dico
        
        ret = None
        cp1 = ""
        cp2 = ""
        flagcancel = False
        
        if not ext in ('.dict', '.ifo', '.gz', '.dz', '.ling', '.xdxf'):
            ret = self.getEncodings(revfichpath)
            cp1 = ret[0]
            cp2 = ret [1]
            flagcancel = ret[2]
        
        
        # -------------------------------------
        # --- Charger/Ouvrir le dico inverse   
        # -------------------------------------
        
        # Mémoriser le numéro de version source s'il existe
        sourceVersion = app.dic.dicVersionNumber
        
        self.loadDico(revfichpath, cp1=cp1, cp2=cp2, showSplash=False)
        
        # Mémoriser la version du dico inverse si elle existe
        revVersion = app.dic.dicVersionNumber
        
        # Prévenir si le dico inverse est obsolète
        if (app.dic.isReverseDic and (revVersion != '') and (sourceVersion != '') ):
            if not revVersion.startswith(sourceVersion) :
                tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("win1", "msg32"),
                    message = "Src : " + sourceVersion + "\nInv : " + revVersion + "\n\n" + self.lg.get("win1", "msg60"))
                
        
        
        # ----------------------------------------------------
        # --- Mémoriser les encodages du dico si nécessaire   
        # ----------------------------------------------------
        
        if not ret is None:
            encfile = Inifile(os.path.join(self.appdata.path, "encodings"))
            
            k = os.path.normpath(revfichpath).lower()
            encfile.write(k, cp1 + "|" + cp2)
            
            encfile = None
        
        
        return
    
    
    
    def openDicFromMenuDic(self, fichname, m_parent):
        
        u"""
        | Charge le dictionnaire cliqué dans le menu "Dictionnaires".           
        | Affiche la fenêtre de choix des encodages si besoin.                  
        |                                                                       
        | ARGUMENTS :                                                           
        |   'fichname' : libellé du dico dans le menu                           
        |   'm_parent' : objet Menu contenant la ligne du dico                  
        """
        
        dicospath = self.ini.get('DicStorageFolder','') # dossier de stockage des dictionnaires
        
        
        # ------------------------------------------------------------------------
        # --- Extraire l'arborescence du dico à partir du menu "Dictionnaires"    
        # ------------------------------------------------------------------------
      
        path = dicospath
        
        if m_parent['title'] != "mDic":
            
            pathitems = m_parent['title'].split("|")
            
            for i in range(1,len(pathitems)):   # on néglige le premier élément ("mDic")
                path = os.path.join(path, pathitems[i])
        
        fichpath = os.path.join(path, fichname) # chemin du dico à ouvrir
        
        
        # -----------------------------------------
        # --- Rechercher les encodages si besoin   
        # -----------------------------------------
        
        ext = os.path.splitext(fichpath)[1].lower() # Extension du fichier du dico
        
        ret = None
        cp1 = ""
        cp2 = ""
        flagcancel = False
        
        if not ext in ('.dict', '.ifo', '.gz', '.dz', '.ling', '.xdxf'):
            ret = self.getEncodings(fichpath)
            cp1 = ret[0]
            cp2 = ret [1]
            flagcancel = ret[2]
        
        
        # -------------------------------
        # --- Charger le dictionnaire    
        # -------------------------------
        
        if flagcancel:
            encfile = None
            return
        
        self.loadDico(fichpath, cp1=cp1, cp2=cp2, showSplash=True)
        
        
        # --------------------------------------------
        # --- Mémoriser les encodages si nécessaire   
        # --------------------------------------------
        
        if not ret is None:
            encfile = Inifile(os.path.join(self.appdata.path, "encodings"))
            
            k = os.path.normpath(fichpath).lower()
            encfile.write(k, cp1 + "|" + cp2)
            
            encfile = None
        
        return



    def showOpenNewDic(self):
        u"""
        | Affiche (instancie) la fenêtre de création d'un nouveau dico          
        """
        
        WindowNewDic()   # NB : fenêtre modale
        
        
        return



    def appliquerFont(self, strFontDico, strFontTraduc, flagmemo=True):
        
        u"""
        | Applique à l'affichage du dictionnaire les polices passées en         
        | arguments, sous forme de chaînes "<nom police>?<taille>?<graisse>".   
        |                                                                       
        | Affecte des polices par défaut en cas d'échec,                        
        | puis mémorise les polices dans l'ini si 'flagmemo' est True           
        """
        
        flagDicoDef=False
        flagTraducDef=False
        
        # ----------------------------------------------
        # --- Splittage des chaînes des paramètres      
        # ----------------------------------------------
        
        fntDico = strFontDico.split("?")
        fntTraduc = strFontTraduc.split("?")
        
        try:
            fntDico=(fntDico[0], int(fntDico[1]), fntDico[2])
        except:       # le splittage a échoué
            flagDicoDef = True
        
        try:
            fntTraduc=(fntTraduc[0], int(fntTraduc[1]), fntTraduc[2])
        except:       # le splittage a échoué
            flagTraducDef = True
        
        
        # -----------------------------------------------------------
        # --- Appliquer les polices en cas de succès du splittage    
        # -----------------------------------------------------------
        
        if not flagDicoDef:
            try:
                # Liste des entrées
                self.lst_dico['font'] = fntDico
                
                # Appliquer la police des entrées aux listes de relations
                self.txt_notice.tag_config("torel", font=fntDico)
            
            except:
                flagDicoDef = True
        
        if not flagTraducDef:
            try:
                self.txt_notice['font'] = fntTraduc
                
                self.txt_notice.tag_config("b", font=(fntTraduc[0], int(fntTraduc[1]), "bold"))
                self.txt_notice.tag_config("i", font=(fntTraduc[0], int(fntTraduc[1]), "italic"))
                self.txt_notice.tag_config("small", font=(fntTraduc[0], int(fntTraduc[1])-2, fntTraduc[2]))
                self.txt_notice.tag_config("big", font=(fntTraduc[0], int(fntTraduc[1])+3, fntTraduc[2]))
                
            except:
                flagTraducDef = True
        
        
        # ------------------------------------------------
        # --- Echecs : appliquer les polices par défaut   
        # ------------------------------------------------
        
        if flagDicoDef:
            
            # Chaîne pour l'INI
            strFontDico="<defaut>?9?normal"
            
            # Liste des entrées
            self.lst_dico['font'] =('<defaut>', 9, 'normal')
            
            # Appliquer la police des entrées aux listes de relations
            self.txt_notice.tag_config("torel", font=('<defaut>', 9, 'normal'))
        
        
        if flagTraducDef:
            strFontTraduc = "<defaut>?9?normal"
            
            self.txt_notice['font'] = ('<defaut>', 9, 'normal')
            
            self.txt_notice.tag_config("b", font=('<defaut>', 9, 'bold'))
            self.txt_notice.tag_config("i", font=('<defaut>', 9, 'italic'))
            self.txt_notice.tag_config("small", font=('<defaut>', 7, 'normal'))
            self.txt_notice.tag_config("big", font=('<defaut>', 12, 'normal'))
        
        
        # -------------------------------------------
        # --- Mémoriser les polices dans l'ini       
        # -------------------------------------------
        
        if flagmemo:
            self.ini.write('dicofont', strFontDico)
            self.ini.write('traducfont', strFontTraduc)
        
        
        return


    def loadDico(self, fichPath, cp1="", cp2="", showSplash=True):
        
        u"""
        | 1) Lit le ou les fichiers du dictionnaire :                           
        |   - charge les entrées d'index dans la listBox                        
        |   - crée l'objet app.dic et sa séquence 'app.dic.datamap' en mémoire  
        |     (liste de tuples contenant les décalages et tailles des données)  
        |                                                                       
        | 2) Ouvre et laisse ouvert le fichier des données du dico,             
        |    accessible par l'objet fichier 'app.dic.file'.                     
        |                                                                       
        | 'showSplash' : booléen déterminant si la fenêtre des Infos&Statut     
        |  s'affiche au chargement.                                             
        |                                                                       
        | RETOUR :                                                              
        |   0 si succès                                                         
        |   1 si problème ou échec                                              
        """
        
        self['cursor'] = "watch"
        
        # --------------------------------------
        # --- Réinitialiser l'interface         
        # --------------------------------------
        
        self.title("Linguae")                               # Barre de titre sans nom de fichier
        self.txt_notice['state'] = 'normal'
        self.txt_notice.delete("1.0", END)                  # Vider la case de la notice
        self.txt_notice['state'] = 'disabled'
        self.status1['text'] = ""                           # Vider la case "encodages" de la StatusBar
        self.status0['text'] = ""                           # Vider la case "index" de la StatusBar
        self.status3['text'] = ""                           # Vider la case "ID" de la StatusBar
        self.status4['image'] = self.imglst.caden0          # Icône de dico non protégé
        self.status4.ib.libel("Dictionnaire non protégé")
        self.lab_img1['image'] = None                       # Effacer l'image de langue 1
        self.ic1 = None
        self.lab_img2['image'] = None                       # Effacer l'image de langue 2
        self.ic2 = None
        
        try   : self.greffon.display("")                    # Envoyer une chaîne vide au plugin
        except: pass
        
        self.hist.reinit()                                  # Réinitialiser l'historique                                      
        
        self.progr.setValue(0)
        self.showProgr()                                    # Afficher la barre de progression
        
        try:
            self.f_transl.terminate()                       # Ferme une eventuelle fenêtre de traduction en cours
        except:
            pass
        
        
        # ----------------------------------------
        # --- Fermer une éventuelle fenêtre SWAC  
        # ----------------------------------------
        
        try:
            self.f_swac.destroy()
        except:
            pass
        
        self.f_swac = None
        
        
        # --------------------------------------------------------------------------
        # --- Réinitialiser l'objet dictionnaire (l'initialisation charge le dico)  
        # --------------------------------------------------------------------------
        
        
        self.dic = lib.mydic.DicObject( fichPath,
                                        lgget = self.lg.get,
                                        winparent = self,
                                        lstbox = self.lst_dico,
                                        prgbar = self.progr,
                                        cachedir = self.appdata.cache,
                                        cp1 = cp1, cp2 = cp2,
                                        hideprogress = self.hideProgr )
        
        if self.dic is None or self.dic.file is None: # Le chargement a échoué
            
            self.dic = None
            self['cursor'] = ""
            tkMessageBox.showwarning(parent=self,
                    title = u'Linguae',
                    message = self.lg.get("win1", "msg34") + "\n\n" + fichPath) # ("échec du chargement")
            return 1
        
        
        # -----------------------------------------------------------
        # --- Mise à jour de l'interface avec les données du dico    
        # -----------------------------------------------------------
        
        # --- Appliquer les polices du dico si présentes,
        #     sinon celles de l'ini, sinon celles par défaut
        
        if self.dic.displayFontName1 != "":
            f1 = self.dic.displayFontName1
        else:
            f1= self.ini.get('dicofont','<defaut>?9?normal')
        
        if self.dic.displayFontName2 != "":
            f2 = self.dic.displayFontName2
        else:
            f2= self.ini.get('traducfont','<defaut>?9?normal')
        
        self.appliquerFont(f1, f2, flagmemo=False) # appliquer sans mémoriser dans l'ini
        
        
        # --- Mémoriser dans l'ini le chemin du fichier ouvert
        self.ini.write("lastopenfile", fichPath)                
        
        # --- Afficher le chemin du dico dans la barre de titre
        self.title("Linguae [" + self.dic.path + "]")           
        
        
        # --- Mise à jour de la StatusBar
        
        # Noter l'encodage du fichier dans la StatusBar
        self.status1['text'] = self.dic.encoding1 + " | " + self.dic.encoding2
        
        # Affichage de l'Icône de protection du dico (cadenas) dans la StatusBar
        if self.dic.protected1 != "" or self.dic.protected2 != "" :  
            self.status4['image'] = self.imglst.caden1          
            self.status4.ib.libel(self.lg.get("win1", "ib22") ) # ("Dictionnaire protégé")
        
        
        # --- Création et affichage des images Tk des langues (utilise PIL)
        
        if self.dic.img1b64 != "":
            try:
                self.ic1 = ImageTk.PhotoImage(Image.open(StringIO.StringIO(base64.decodestring(self.dic.img1b64))))
            except:
                self.ic1 = None
                
            self.lab_img1['image'] = self.ic1                       
            if self.dic.langName1 != "":                            # Infobulle de l'image de langue 1
                t = self.lg.get("win1", "ib23") + " " + self.dic.langName1 # ("Langue source :")
                self.lab_img1.ib=lib.infobulle.InfoBulle(parent=self.lab_img1, text=t, temps=400)
            
        if self.dic.img2b64 != "":
            try:
                self.ic2 = ImageTk.PhotoImage(Image.open(StringIO.StringIO(base64.decodestring(self.dic.img2b64))))
            except:
                self.ic2 = None
            
            self.lab_img2['image'] = self.ic2                       
            if self.dic.langName2 != "":                            # Infobulle de l'image de langue 2
                t = self.lg.get("win1", "ib24") + " " + self.dic.langName2 # ("Langue cible :")
                self.lab_img2.ib=lib.infobulle.InfoBulle(parent=self.lab_img2, text=t, temps=400)
        
        
        # --- Activation des menus déroulants
        
        # Activer le menu "url du dico"
        if self.dic.dicUrl != "":                               
            self.m_hlp.entryconfigure(7, state='normal')
        else:
            self.m_hlp.entryconfigure(7, state='disabled')
        
        # Activer le menu "e-mail à l'auteur du dico"
        if self.dic.contactAuthor != "":                        
            self.m_hlp.entryconfigure(6, state='normal')
        else:
            self.m_hlp.entryconfigure(6, state='disabled')
        
        # Activer le menu "chercher une nouvelle version du dico"
        if self.dic.verUrl != "":                               
            self.m_hlp.entryconfigure(8, state='normal')
        else:
            self.m_hlp.entryconfigure(8, state='disabled')
       
        
        # --- Masquer la barre de progression
        self.hideProgr()                                        
        
        
        
        # -----------------------------------------------------------------
        # --- Comportement par défaut du point-virgule suivant le format   
        # -----------------------------------------------------------------
        
        if self.dic.type.startswith("wb") or self.dic.type.startswith("ling"):
            self.vPv2br.set(1)
        else:
            self.vPv2br.set(0)
        
        
        # ----------------------------------------------------------------
        # --- Affichage optionnel du splash des Infos & Statut du dico    
        # ----------------------------------------------------------------
        
        if showSplash:
            
            # Instancier la fenêtre
            
            WindowInfo()   # NB : fenêtre modale
        
        # ---
        
        self['cursor'] = ""
        
        return 0



    def onTheFlySearch(self, event):
        
        u"""
        | Chercher le début du mot dans la Listbox des entrées à l'aide de la   
        | case de recherche rapide.                                             
        """
        
        self.txt_search.update()
        
        motif = self.txt_search.get().lower()       # Motif tapé dans la case (en minuscule)
        
        self.lst_dico.selection_clear(0, END)       # Désélectionner tout dans la Listbox
        
        
        # Chercher l'index par la méthode de l'objet dico
        
        i = self.dic.idxfind(motif=motif, dom='idx', decal=0, debut=True, ignorecase=True, ignorelig=True)
        
        # Sélectionner dans la listbox
        if not i is None:
            self.lst_dico.activate(i)
            self.lst_dico.selection_set(i)
            self.lst_dico.see(i)
            self.selDisplayData(event)
            self.txt_search['foreground']='black'
        else:
            self.lst_dico.selection_clear(0, END)   # Désélectionner tout dans la liste
            self.lst_dico.see(0)                    # Afficher le début de la liste
            self.txt_search['foreground']='red'     # Motif incorrect en rouge dans la TextBox
        
        return



    def getEncodings(self, fichpath, flagforce=False):
        
        u"""
        | Recherche si des encodages sont mémorisés pour le dictionnaire de     
        | chemin 'fichpath'. Si rien n'est mémorisé, on affiche la boîte de     
        | dialogue de demande des encodages.                                    
        |                                                                       
        | ARGUMENTS :                                                           
        |   'fichpath' : chemin du dictionnaire                                 
        |   'flagforce' : (booléen) si True les encodages sont demandés même    
        |                 s'ils sont mémorisés.                                 
        | RETOUR :                                                              
        |   Un tuple (cp1, cp2, flagcancel)                                     
        |                                                                       
        |       'cp1' et 'cp2' : encodages du fichier, langue 1 et langue 2.    
        |                                                                       
        |       'flagcancel' : (booléen) True si l'utilisateur à cliqué sur     
        |                      'Annuler' dans la fenêtre de choix d'encodages.  
        """
        
        
        # -------------------------------------------------------------------
        # --- Rechercher si des encodages ont été antérieurement mémorisés   
        # -------------------------------------------------------------------
        
        cp1 = ""
        cp2 = ""
        flagcancel = False
        
        
        # Nb : les encodages sont mémorisés dans le fichier "encodings"
        # de type ini simplifié, présent dans Appdata
        
        
        encfile = Inifile(os.path.join(self.appdata.path, "encodings"))
        
        k = os.path.normpath(fichpath).lower()
        
        try   : k = k.encode('utf-8')
        except: pass
        
        cps = encfile.get(k,"") # recupère les encodages du dico
        
        if cps != "":
            cps = cps.split("|")
            cp1 = cps[0]
            cp2 = cps[1]
        
        
        
        # ---------------------------------------------------------
        # --- Afficher la Fenêtre de choix des encodages           
        # ---------------------------------------------------------
        
        if flagforce or cps == "":
        
            
            # Afficher (fenêtre modale bloquante)
            f_enc = WindowEncodeOpen(cp1=cp1, cp2=cp2)
            
            # Récupérer les données de la fenêtre
            cp1 = f_enc.cp1
            cp2 = f_enc.cp2
            flagcancel = f_enc.annuler # l'utilisateur a cliqué sur 'Annuler'
            
            # Détruire la fenêtre
            f_enc.destroy()
        
        
        return (cp1, cp2, flagcancel)



    def __importPluginFromStart(self):
        
        u"""
        | Charger un greffon dit "de démarrage", s'il est présent, dans le      
        | répertoire des greffons.                                              
        |                                                                       
        | Un "greffon de démarrage" est un greffon présent dans le répertoire   
        | 'linguae_start/loadplugin'                                            
        |                                                                       
        | On recopie le "greffon de démarrage" dans le répertoire des greffons  
        | puis on l'efface de '/loadplugin'                                     
        """
        
        
        # ----------------------------------------------------------------
        # --- Rechercher la présence d'un éventuel greffon de démarrage   
        # ----------------------------------------------------------------
        
        # Déterminer le chemin du répertoire du greffon de démarrage en fonction de la plateforme
        
        if self.pf == 'win':                # Windows
            repstart = os.path.join(self.appdata.path, "linguae_start", "loadplugin")
        elif self.pf in('osx', 'linux'):    # Unix (MacosX, Linux, )
            repstart = "/var/tmp/linguae_start/loadplugin"
        else:
            return "" # = Aucun greffon de démarrage n'a été chargé
        
        if os.path.isdir(repstart):
            
            # rechercher la présence d'un greffon dans ce répertoire
            startplug = os.listdir(repstart)
            if len(startplug) > 0:
                startplug = os.path.join(repstart, startplug[0])
            else:
                return ""
        else:
            return ""
        
        
        # ------------------------------------------------
        # --- Importer le greffon                         
        # ------------------------------------------------
        
        self.__importPlugin(startplug)
        
        
        # -------------------------------------
        # --- Faire le ménage                  
        # -------------------------------------
        
        
        for f in os.listdir(repstart):
            fich = os.path.join(repstart, f)
            # modifier les droits (nécessaire sous Linux)
            try   : os.chmod(fich, 0777)
            except: pass
            # effacer
            try   : os.remove(fich)
            except: print "\n'" + fich + "'\nEchec de l'effacement !"
        
        
        # -------------------------------------------------------
        # --- Retouner le nom du greffon                          
        # -------------------------------------------------------
        
        
        f = os.path.basename(startplug).lower()
        f = f.replace(".pyc", "")
        f = f.replace(".py", "")
        
        return f


    
    def openDicFromStart(self):
        
        u"""
        | Ouvrir un dico dit "de démarrage" s'il est présent.                   
        |                                                                       
        | Un "dico de démarrage" est un dico présent dans le répertoire         
        | 'linguae_start/loaddic'                                               
        |                                                                       
        | Le "dico de démarrage" sera recopié dans le dossier de stockage des   
        | dictionnaires (qui sera crééé si besoin) et lancé, puis le            
        | dictionnaire sera effacé de '/loaddic'.                               
        |                                                                       
        | RETOUR :                                                              
        |  'True' si un dico a été trouvé et ouvert, sinon 'False'              
        """
        
        
        
        # -----------------------------------------------
        # --- Rechercher un éventuel dico de démarrage   
        # -----------------------------------------------
        
        # Déterminer le chemin du répertoire du dico en fonction de la plateforme
        
        if self.pf == 'win':                # Windows
            repstart = os.path.join(self.appdata.path, "linguae_start", "loaddic")
        elif self.pf in ('osx', 'linux'):   # Unix (MacosX, Linux, )
            repstart = "/var/tmp/linguae_start/loaddic"
        else:
            return False # Aucun dico de démarrage n'a été ouvert
        
        if os.path.isdir(repstart):
            
            # rechercher la présence d'un dico dans ce répertoire
            startdic = os.listdir(repstart)
            if len(startdic) > 0:
                startdic = os.path.join(repstart, startdic[0])
            else:
                return False
        else:
            return False
        
        
        
        # ------------------------------------------------------------
        # --- Créer un dossier de stockage des dicos si besoin        
        # ------------------------------------------------------------
        
        stordir = self.ini.get('DicStorageFolder','')
        
        if stordir == "":
            
            stordir = os.path.join(self.appdata.path, "dicos")
            try:
                os.mkdir(stordir)
            except:
                return False
            
            # Mémoriser ce répertoire dans l'INI
            app.ini.write('DicStorageFolder', stordir)
        
        
        
        # --------------------------------------------------
        # --- Déplacer le dico dans le dossier de stockage  
        # --------------------------------------------------
        
        # Chemin du fichier cible
        fichpath = os.path.join(stordir, os.path.basename(startdic))
        
        # le fichier cible existe déjà dans le dossier de stockage de l'utilisateur
        # > on le renomme pour pouvoir le restaurer si problème
        if os.path.isfile(fichpath):
            try   : os.chmod(fichpath, 0777)
            except: pass
            try:
                os.rename(fichpath, fichpath + "_tmpback")
            except:
                print "Impossible de renommer la cible du dico de demarrage !"
                return False
        
        # on copie le dico de démarrage dans le dossier de stockage
        try:
            shutil.copy(startdic, fichpath)
        except:
            print "Echec de la copie du dico de demarrage !"
            # échec > on restaure la sauvegarde du fichier cible
            try   :  os.rename(fichpath + "_tmpback", fichpath)
            except: pass
            return False
            
        # X---> Si ce point est atteint, c'est que l'importation s'est bien passée,
        #       on peut maintenant essayer de faire du ménage :
        
        # on supprime l'éventuel contenu restant du dossier de démarrage
        
        for f in os.listdir(repstart):
            fich = os.path.join(repstart, f)
            try   : os.chmod(fich, 0777)
            except: pass
            # on efface le fichier
            try   : os.remove(fich)
            except: print "\n'" + fich + "'\n" + "Echec de l'effacement !"
        
        
        # on supprime la sauvegarde de la cible
        try   : os.remove(fichpath + "_tmpback")
        except: print "Echec de la suppression de la sauvegarde temporaire de la cible du dico de démarrage !"
        
        
        # On met à jour le menu des dicos
        self.updateMenuDic()
        
        
        # -----------------------------------------
        # --- Rechercher les encodages si besoin   
        # -----------------------------------------
        
        ext = os.path.splitext(fichpath)[1].lower() # Extension du fichier du dico
        
        ret = None
        cp1 = ""
        cp2 = ""
        flagcancel = False
        
        if not ext in ('.dict', '.ifo', '.gz', '.dz', '.ling', '.xdxf'):
            ret = self.getEncodings(fichpath)
            cp1 = ret[0]
            cp2 = ret [1]
            flagcancel = ret[2]
        
        
        # ----------------------------------------
        # --- Tenter de rouvrir le dico           
        # ----------------------------------------
        
        if flagcancel:
            return False
        
        try:
            self.loadDico(fichpath, cp1=cp1, cp2=cp2, showSplash=True) # NB : le splash active le menu "à propos du dico"
            
        except: # Echec de l'ouverture automatique du dictionnaire
            self['cursor'] = ""
            tkMessageBox.showwarning(parent=self,
                    title = u"Linguae",
                    message = self.lg.get("win1", "msg35") + "\n\n" + fichpath + "\n\n" + str(sys.exc_info()[0]) + " : " + str(sys.exc_info()[1]))
            return False
        
        
        # --------------------------------------------
        # --- Mémoriser les encodages si nécessaire   
        # --------------------------------------------
        
        if not ret is None:
            encfile = Inifile(os.path.join(self.appdata.path, "encodings"))
            
            k = os.path.normpath(fichpath).lower()
            encfile.write(k, cp1 + "|" + cp2)
            
            encfile = None
        
        
        
        
        return True


    def openDicFromLastOpen(self):
        
        u"""
        Rouvrir le dernier dico ouvert (son chemin a été mémorisé dans l'ini)   
        """
        
        if self.ini.get("OpenLastFile", "1") != "1":
            return
        
        # ------------------------------------------------------
        # --- Récupérer le chemin du fichier du dico à rouvrir  
        # ------------------------------------------------------
        
        fichpath = self.ini.get("lastopenfile", "")
        
        if fichpath == "":
            return
        
        if not os.path.isfile(fichpath):
            
            # Tenter d'ajouter le chemin du répertoire de stockage des dictionnaires
            # (utile en cas de premier lancement du programme avec un ini par défaut)
            try:
                fichpath = os.path.join(self.ini.get('DicStorageFolder',''), fichpath )
            except:
                pass
            
            if not os.path.isfile(fichpath):
                return
        
        
        # -----------------------------------------
        # --- Rechercher les encodages si besoin   
        # -----------------------------------------
        
        ext = os.path.splitext(fichpath)[1].lower() # Extension du fichier du dico
        
        ret = None
        cp1 = ""
        cp2 = ""
        flagcancel = False
        
        if not ext in ('.dict', '.ifo', '.gz', '.dz', '.ling', '.xdxf'):
            ret = self.getEncodings(fichpath)
            cp1 = ret[0]
            cp2 = ret [1]
            flagcancel = ret[2]
        
        
        # ----------------------------------------
        # --- Tenter de rouvrir le dico           
        # ----------------------------------------
        
        if flagcancel:
            return
        
        try:
            self.loadDico(fichpath, cp1=cp1, cp2=cp2, showSplash=True) # NB : le splash active le menu "à propos du dico"
            
        except: # Echec de l'ouverture automatique du dictionnaire
            self['cursor'] = ""
            tkMessageBox.showwarning(parent=self,
                    title = u"Linguae",
                    message = self.lg.get("win1", "msg35") + "\n\n" + fichpath + "\n\n" + str(sys.exc_info()[0]) + " : " + str(sys.exc_info()[1]))
            return
        
        
        # --------------------------------------------
        # --- Mémoriser les encodages si nécessaire   
        # --------------------------------------------
        
        if not ret is None:
            encfile = Inifile(os.path.join(self.appdata.path, "encodings"))
            
            k = os.path.normpath(fichpath).lower()
            encfile.write(k, cp1 + "|" + cp2)
            
            encfile = None
        
        
        
        return



    def openDicFromDialog(self):
        
        u"""
        | - Affiche la boîte standard de sélection de fichier                   
        |   (choix du dico à charger)                                           
        | - Affiche, si besoin, la fenêtre de choix des encodages               
        | - Appelle la procédure de chargement de dictionnaire                  
        """
        
        
        # -------------------------------------
        # --- Boîte de sélection de fichier    
        # -------------------------------------
        
        dirSearch = self.ini.get("DicSearchPath",os.path.expanduser('~')) # Chemin de recherche par défaut
        
        fichpath = tkFileDialog.askopenfilename(parent=self,
                    title = self.lg.get("win1", "msg36"),
                    filetypes = (
                    (app.lg.get("g", "fling"),'*.ling'),
                    (app.lg.get("g", "fdict"),'*.ifo *.dict'),
                    (app.lg.get("g", "fddz"),'*.ifo.gz *.dict.dz *.dict.gz'),
                    (app.lg.get("g", "fwb"),'*.wb'),
                    (app.lg.get("g", "fxdxf"),'*.xdxf'),
                    (app.lg.get("g", "flim"),'*.csv *.tab *.txt'),
                    (app.lg.get("g", "fini"),'*.ini'),
                    (app.lg.get("g", "fsup"),'*.ling *.ifo *.dict *.ifo.gz *.dict.dz *.dict.gz *.wb *.xdxf *.csv *.tab *.txt *.ini'),
                    (app.lg.get("g", "fall"),'*.*')),
                    initialdir = dirSearch
                    )
        
        if not fichpath: return   # L'utilisateur a cliqué 'Annuler' dans la boîte de dialogue
        
        
        # ---------------------------------------------------------------
        # --- Si le dictionnaire n'est pas dans le dossier de stockage   
        # ---  demander s'il faut l'y recopier                           
        # ---------------------------------------------------------------
        
        repstordic = self.ini.get('DicStorageFolder','')
        flagrecopier = False
        
        # Demander
        if repstordic != "" and not fichpath.lower().startswith(repstordic.lower()):
            r = tkMessageBox.askyesno(parent=self,
                        title = self.lg.get("win1", "msg36"),
                        message = self.lg.get("win1", "msg59"))
            
            if r:
                # Chemin cible : vérifier si un fichier homonyme existe
                newfichpath = os.path.join(repstordic, os.path.basename(fichpath))
                
                if os.path.isfile(newfichpath):
                    r = tkMessageBox.askyesno(parent=self,
                            title = self.lg.get("win1", "msg36"),
                            message = self.lg.get("winimp", "msg2"))
                    if r:
                        flagrecopier = True # écraser
                else:
                    flagrecopier = True
        
        # Recopier (l'original est laissé en place dans son dossier d'origine)        
        if flagrecopier:
            
            try   : os.chmod(newfichpath, 0777) # Donner tous les droits
            except: pass
            
            try:
                shutil.copy(fichpath, newfichpath)
            
            except: # échec de la copie, l'original sera ouvert
                pass
            
            else:   # succès de la copie, la copie sera ouverte
                fichpath = newfichpath
        
        
        # -----------------------------------------
        # --- Rechercher les encodages             
        # -----------------------------------------
        
        ext = os.path.splitext(fichpath)[1].lower() # Extension du fichier du dico
        
        ret = None
        cp1 = ""
        cp2 = ""
        flagcancel = False
        
        # Si le dico n'est pas à encodage imposé, 'getEncodings' cherche dans le fichier de mémorisation des encadages
        # et affiche une fenêtre de choix si rien n'a été trouvé
        if not ext in ('.dict', '.ifo', '.gz', '.dz', '.ling', '.xdxf'):
            ret = self.getEncodings(fichpath, flagforce=True)
            cp1 = ret[0]
            cp2 = ret [1]
            flagcancel = ret[2] # True si l'utilisateur clique sur 'Annuler' dans la fenêtre de choix d'encodage
        
        
        
        # ---------------------------------
        # --- Chargement du dictionnaire   
        # ---------------------------------
        
        if flagcancel:
            return
        
        # Charge le dictionnaire dans l'interface
        self.loadDico(fichpath, cp1=cp1, cp2=cp2, showSplash=True)
        
        
        
        # --------------------------------------------
        # --- Mémoriser les encodages si nécessaire   
        # --------------------------------------------
        
        if not ret is None:
            encfile = Inifile(os.path.join(self.appdata.path, "encodings"))
            
            k = os.path.normpath(fichpath).lower()
            encfile.write(k, cp1 + "|" + cp2)
            
            encfile = None
        
        return



    def openDicFromCommandLine(self):
        
        u"""
        | Ouvre un dico dont le nom du fichier est passé en argument de la      
        | ligne de commande.                                                    
        |                                                                       
        | - Un nom de dico passé sans chemin est recherché dans le répertoire   
        |   des dictionnaires, puis dans le chemin de recherche des dicos, puis 
        |   enfin sur le bureau de l'utilisateur.                               
        |                                                                       
        | - Affiche, si besoin, la fenêtre de choix des encodages.              
        |                                                                       
        | - Appelle la procédure de chargement de dictionnaire.                 
        """
        
        
        # ----------------------------------------------------
        # --- Récupérer le chemin du dico passé en argument   
        # ----------------------------------------------------
        
        try:
            ficharg = sys.argv[1]
        except:
            return
        
        # (1) On recherche le dico avec son chemin tel quel
        fichpath = ficharg
        
        if not os.path.isfile(ficharg):
            
            # (2) On recherche le dico dans le dossier de stockage des dictionnaires
            fichpath = os.path.join(self.ini.get('DicStorageFolder',''), ficharg)
            
            if not os.path.isfile(fichpath):
            
            # (3) On recherche le dico dans le chemin de recherche par défaut des dictionnaires
                fichpath = os.path.join(self.ini.get('DicSearchPath',''), ficharg)
                
                if not os.path.isfile(fichpath):
                    
                    # (4) On recherche le dico sur le bureau de l'utilisateur
                    fichpath = os.path.join(os.path.expanduser('~'), "Bureau", ficharg)
                    
                    if not os.path.isfile(fichpath):
                        msg = "'" + ficharg + "'\n\n" + self.lg.get("dic", "msg4") # ('fichier introuvable')
                        tkMessageBox.showwarning(parent=self,
                            title = u"Linguae",
                            message = msg)
                        print u"\n" + msg # Echo en console
                        
                        return
        
        
        # -----------------------------------------------------------------
        # --- Aiguillage importation Preling (sinon : ouverture du dico)   
        # -----------------------------------------------------------------
        
        ext = os.path.splitext(fichpath)[1].lower() # Extension du fichier du dico
        
        if ext == ".preling":
            
            self.showImportPreling(fichpath)
            
            return
        
        # -------------------------------------------
        # --- Rechercher les encodages des langues   
        # -------------------------------------------
        
        
        ret = None
        cp1 = ""
        cp2 = ""
        flagcancel = False
        
        # Si le dico n'est pas à encodage imposé, 'getEncodings()' cherche dans le fichier de mémorisation des encodages
        # et affiche une fenêtre de choix si rien n'a été trouvé
        if not ext in ('.dict', '.ifo', '.gz', '.dz', '.ling', '.xdxf'):
            ret = self.getEncodings(fichpath, flagforce=True)
            cp1 = ret[0]
            cp2 = ret [1]
            flagcancel = ret[2] # True si l'utilisateur clique sur 'Annuler' dans la fenêtre de choix d'encodage
        
        
        
        # ---------------------------------
        # --- Chargement du dictionnaire   
        # ---------------------------------
        
        if flagcancel:
            return
        
        # Charge le dictionnaire dans l'interface
        self.loadDico(fichpath, cp1=cp1, cp2=cp2, showSplash=True)
        
        
        
        # --------------------------------------------
        # --- Mémoriser les encodages si nécessaire   
        # --------------------------------------------
        
        if not ret is None:
            encfile = Inifile(os.path.join(self.appdata.path, "encodings"))
            
            k = os.path.normpath(fichpath).lower()
            encfile.write(k, cp1 + "|" + cp2)
            
            encfile = None
        
        return
    
    


    def runPlugin(self, f):
        
        u"""
        | Charge un plugin.                                                     
        | Le nom du plugin est enregistré dans l'INI en tant que dernier        
        | plugin ouvert.                                                        
        |                                                                       
        | ARGUMENTS :                                                           
        |   'f' : nom du fichier dans le répertoire des plugins                 
        """
        
        if f=='(none)':
            self.stopPlugin(memo=True)
            return
        
        self.stopPlugin(memo=False)                             # Clore le plugin actif (sans mémo dans l'ini)
        
        try:
            exec ("import plugins." + f) in globals()           # Importer le module du plugin/greffon
        
        except:                                                 # Echec du chargement du plugin/greffon
            tkMessageBox.showwarning(parent=self,
                    title = self.lg.get("win1", "msg37"),
                    message = self.lg.get("win1", "msg38") + " '" + unicode(f) + "' " + self.lg.get("win1", "msg39") )
            return

        # ------------------------------------
        # --- Instancier le plugin            
        # ------------------------------------
        try:
            self.greffon = eval("plugins." + f + ".Widget(self.fr_plugin, getlist=self.getList, getfile=self.getfile, getAppDataPath=self.getAppDataPath, getdata=self.senddata, getlgcode=self.getlgcode)")
        
        except:                                                 # Echec du chargement du plugin/greffon
            tkMessageBox.showwarning(parent=self,
                    title = self.lg.get("win1", "msg37"),
                    message = self.lg.get("win1", "msg38") + " '" + unicode(f) + "' " + self.lg.get("win1", "msg39") )
            return
        
        
        self.greffon.grid(row=0, column=0, padx=6, pady=3)      # Afficher le plugin
        
        try:
            self.ongl_plugin['text'] = self.greffon.getTitle()  # Afficher le titre du greffon dans l'onglet des greffons
        except:
            self.ongl_plugin['text'] = "(plugin)"
            
        self.ini.write("lastopenplugin", f)                     # Mémoriser dans l'ini le plugin actif
        
        return



    def stopPlugin(self, memo=True):
        
        u"""
        | Décharge le plugin actif                                              
        |                                                                       
        | ARGUMENTS :                                                           
        |   'memo' : (booléen) si ce flag est True, le nom du plugin est        
        |            enregistré dans l'INI en tant que dernier plugin ouvert.   
        """
        
        try:
            exec("app.greffon.destroy()") in globals()
        except:
            pass
        
        self.ongl_plugin['text'] = self.lg.get("win1", "s2")
        
        if memo : self.ini.write("lastopenplugin", "(none)")    # Mémoriser dans l'ini le dernier plugin ouvert
        
        return



    def selDisplayData(self, event):
        
        u"""
        | Afficher les données de la notice de l'entrée de dictionnaire en      
        | sélection.                                                            
        |                                                                       
        | Les données sont extraites du pyDictionnaire 'data' de l'objet        
        | Dictionnaire.                                                         
        """
        
        # -----------------------------
        # --- Récupérer les données    
        # -----------------------------
        
        self.lst_dico.update()
        
        try:
            i = int(self.lst_dico.curselection()[0])    # Index du mot en sélection
        except:
            return
        
        if i <0 : return                                # quitter si rien en sélection
        
        self.dic.curIdx = i                             # Mémoriser l'index courant dans le dictionnaire
        
        data = self.dic.getdata(i)                      # Récupère les données dans le pyDictionnaire 'data'
        
        wID = data['ID']                                # Mémoriser le wordID courant dans le dictionnaire
        self.dic.curWordID = wID
        
        
        mot = data['mot']
        
        
        # --------------------------------
        # --- Envoi du mot au plugin      
        # --------------------------------
        
        try:
            self.greffon.display(self.lst_dico.get(i))
        except:
            pass
        
        # ----------------------------------------------------------------
        # --- Interroger SWAC (seulement si la fenêtre SWAC est visible)  
        # ----------------------------------------------------------------
        
        try:
            if not self.f_swac is None:
                self.f_swac.askfromsel(mot=mot)
        except:
            pass
        
        
        # ----------------------------------
        # --- Préparer l'interface          
        # ----------------------------------
        
        self.status0['text'] = str(i)                   # Afficher l'index dans la barre de statut
        
        # --- Activer les cases d'affichages pour permettre l'écriture
        
        self.txt_notice['state'] = 'normal'
        
        # --- Effacer les contenus antérieurs de l'interface
        
        self.txt_notice.delete("1.0", END)
        self.status3['text'] = "" # wordID
        
        
        # ---------------------------------------
        # --- Case du wordID dans la statusBar   
        # ---------------------------------------
        
        if wID != "":
            self.status3['text'] = wID
        
        
        # --------------------------------------------------------
        # --- Afficher la répétition du mot en tête de la notice  
        # --------------------------------------------------------
        
        if self.dic.type.startswith('ini'):  
            if mot.startswith("["):             # titre de section INI
                self.txt_notice.insert(END, mot + "\n", "miroir")
            else:
                sec = ""
                for s in range(i, -1, -1):      # Rechercher le titre de la section
                    if self.dic.lstbox.get(s).startswith("["):
                        sec = self.dic.lstbox.get(s)
                        break
                self.txt_notice.insert(END, sec + "  " + mot.strip() + "\n", "miroir")
        else:
            mot = mot.split("[", 1)
            self.txt_notice.insert(END, "<b>" + mot[0] + "</b>", "miroir")
            if len(mot) > 1 :
                self.txt_notice.insert(END, "[" + mot[1] + "\n", "miroir")
            else:
                self.txt_notice.insert(END, "\n", "miroir")
        
        
        # --------------------------
        # --- Bouton Audio          
        # --------------------------
        
        if wID != "":
            
            # Tester l'existence d'un fichier audio
            if len(glob.glob(os.path.join(self.dic.path + "_res", "audio", wID + ".*"))) > 0:
                
                # Créer un bouton "embedded" dans la textBox
                bt_audio = Button(self.txt_notice, width=110, compound=LEFT, text=" " + self.lg.get("win1", "s3") + " ", image=self.imglst.audio, borderwidth=1, command=self.playWord, font=("Helvetica",8,"normal"), pady=2)
                self.txt_notice.window_create(END, window=bt_audio, padx=4, pady=4)
        
        
        
        # ------------------------
        # --- Phonétique          
        # ------------------------
        
        t = data['phon'].strip()
        if t != "" and t[0:3] != "|!|":
            self.txt_notice.insert(END, "[ " + t + " ]\n", "phon")
        else:
            self.txt_notice.insert(END, "\n")
        
        
        # ----------------------------------
        # --- Traductions courtes           
        # ----------------------------------
        
        # convertir les éventuelles entités AVANT le remplacement des ';'
        t = entToChar(data['short']) 
        
        # gestion des ';' > convertir ou non en sauts de ligne
        if self.vPv2br.get():
            t = t.replace(";", "\n")
        t = t.replace("\n ", "\n")
        
        # Uniformiser les <kref>...</kref> en {{...}}
        t = t.replace("<kref>", "{{")
        t = t.replace("</kref>", "}}")
        
        # afficher
        self.txt_notice.insert(END, t + "\n", "short")
        
        
        # --------------------------------------------
        # --- Traductions longues et infos            
        # --------------------------------------------
        
        # convertir les éventuelles entités
        t = entToChar(data['long'])
        
        # Uniformiser les <kref>...</kref> en liens par {{...}}
        t = t.replace("<kref>", "{{")
        t = t.replace("</kref>", "}}")
        
        # afficher
        if t != "" and t[0:3] != "|!|":
            
            self.txt_notice.insert(END, "-"*30 + "\n", "normal") # séparateur
            
            self.txt_notice.insert(END, t + "\n", "long")
        
        
        # ----------------------------------------------------
        # --- Formater le contenu des balises de la notice    
        # ----------------------------------------------------
        
        # Reconnaissance automatique des urls > pose du tag "url"
        addTagToUrl(self.txt_notice, "url")
        
        # Reconnaissance automatique des adresses mail > pose du tag "mail"
        addTagToMail(self.txt_notice, "mail")
        
        
        # formatage des balises de couleurs xdxf et html
        # (à effectuer avant tagsConv car celle-ci supprime toutes les balises qui lui sont inconnues)
        xdxfColorConv(self.txt_notice)
        htmlColorConv(self.txt_notice)
        
        # formatage des balises de format de police (<b>, <i>, etc.)
        tagsConv(self.txt_notice,
                btag="b",
                itag="i",
                utag="u",
                bigtag="big",
                smalltag="small",
                etymtag="ety",
                syntag="syn",
                antotag="anto",
                hwtag="tohw")
        
        
        # ---------------------------------------------------------------------
        # --- Listes des relations (racines, synonymes, antonymes, voir-aussi) 
        # ---------------------------------------------------------------------
        
        for relname, strttr in (('rac', 's5'), ('syn', 's6'), ('ant', 's7'), ('see', 's8')):
        
            if data[relname] != "" and not data[relname].startswith ("|!|"):
                self.txt_notice.insert(END, "\n" + app.lg.get("win1", strttr) + "\n", ("ttr", "b"))
                
                chps = data[relname].split(";")               # Chaîne des wordIDs des Racines
                for chp in chps:
                    try:
                        # Convertir chaque wordID en Index
                        idx = self.dic.wordIDs[chp][0]
                        # Icône de lien (dans un Label pour permettre le clic)
                        self.txt_notice.insert(END, "     ")
                        lab_torel = Label(self.txt_notice, image=self.imglst.torel, cursor="hand2", background='white')
                        lab_torel.bind("<ButtonRelease-1>", self.__onclickIcRel)
                        self.txt_notice.window_create(END, window=lab_torel)
                        # Convertir chaque Index en texte de l'entrée (cliquable)
                        t = "  " + self.dic.lstbox.get(idx)
                        self.txt_notice.insert(END, t, "torel")
                        # Ecrire le wordID cible blanc sur blanc
                        self.txt_notice.insert(END, " "+ chp +"\n", "blanc")    
                    except KeyError:
                        self.txt_notice.insert(END, "??? : " + chp)
        
        
        # -------------------------------------------
        # --- Images illustrant la notice            
        # -------------------------------------------
        
        if wID != "":
            
            self.txt_notice.insert(END, "\n")
            
            # Liste des chemins des images
            imgfiles = glob.glob(os.path.join(self.dic.path + "_res", "img", wID + "_*.*"))
            
            self.txt_notice.update()
            
            for n in range(len(imgfiles)):
                
                
                
                # Convertir le fichier graphique en objet PhotoImage à l'aide de PIL
                try:
                    img = ImageTk.PhotoImage(Image.open(imgfiles[n]))
                    n = str(n)
                    exec("self.img" + n + " = img ")
                    
                    
                    # Créer une image "embedded" dans la textBox
                    exec("self.txt_notice.image_create(END, image=self.img" + n +", align=CENTER, padx=10, pady=5)")
                    self.txt_notice.insert(END, "\n")
                    
                except:
                    # Afficher l'image par défaut en cas d'échec
                    self.txt_notice.image_create(END, image=self.imglst.photo, align=CENTER, padx=10, pady=5)
                    self.txt_notice.insert(END, " ???\n")
        
        
        # ------------------------------
        # --- Affichage terminé         
        # ------------------------------
        
        # Désactiver les cases après leur remplissage
        # (évite la modification manuelle du contenu)
        self.txt_notice['state'] = 'disabled'
        
        
        # Compléter l'historique    
        self.hist.add(i, data['mot'])
        
        
        return

    
    def completeWordIDs(self):
        u"""    
        | Ajoute des wordIDs à toutes les entrées qui n'en ont pas
        """
        
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title = "Linguae : WordIDs",
                    message = self.lg.get("g", "loadfst") ) # ("Chargez d'abord un dictionnaire !")
            return
        
        if self.dic.type == "": 
            tkMessageBox.showinfo(parent=self,
                    title = "Linguae : WordIDs",
                    message = self.lg.get("win1", "msg51") ) # ("Type de dictionnaire non spécifié. Extraction impossible !")
            return
        
        elif not self.dic.type.startswith("ling"):
            tkMessageBox.showinfo(parent=self,
                    title = "Linguae : WordIDs",
                    message = self.lg.get("win1", "msg61") ) # ("possible seulement pour format Ling")
            return
        
        self.progr.setMax(self.dic.wordcount)
        self.progr.setValue(0)
        self.showProgr()                                    # Afficher la barre de progression
        
        self['cursor'] = "watch"
        app.dic.makeWordIDs(prgbar=self.progr)
        self['cursor'] = ""
        
        self.hideProgr()
        
        return
    
    
    def convGifToBase64(self):
        
        u"""
        | Conversion d'un fichier graphique en texte base64,                     
        | le texte est ensuite copié dans le presse-papiers.                    
        """
        
        # -----------------------------------------
        # --- Message d'intro (infos)              
        # -----------------------------------------
        
        r = tkMessageBox.askyesno(parent=self,
                    title = self.lg.get("win1", "msg40"),
                    message = self.lg.get("win1", "msg41") )
        
        if r == False:
            return
        
        # -------------------------------------
        # --- Choisir le fichier à convertir   
        # -------------------------------------
          
        fichpath = tkFileDialog.askopenfilename(
                        title = self.lg.get("win1", "msg40"),
                        filetypes=(
                            (app.lg.get("g", "fgraph"), '*.gif *.jpeg *.jpg *.png *.bmp *.tiff *.tif'),
                            (app.lg.get("g", "fgif"),   '*.gif'),
                            (app.lg.get("g", "fjpeg"),  '*.jpeg *.jpg'),
                            (app.lg.get("g", "fpng"),   '*.png'),
                            (app.lg.get("g", "fbmp"),   '*.bmp'),
                            (app.lg.get("g", "ftiff"),  '*.tiff *.tif'),
                            (app.lg.get("g", "fall"),   '*.*') )
                        )
        
        # L'utilisateur a cliqué 'Annuler' dans la boîte de dialogue
        if not fichpath:
            return   
        
        
        # ---------------------------------
        # --- Lire la chaîne binaire       
        # ---------------------------------
        
        ff = open(fichpath, "rb")
        strBin = ff.read() 
        ff.close()
        
        # le format de fichier est tout d'abord reconnu par son extension
        typefich = os.path.splitext(fichpath)[1][1:].lower()
        
        
        # ---------------------------------
        # --- Contrôles interne de format  
        # ---------------------------------
        
        if typefich == "gif":
            
            if strBin[:4] != "GIF8":
                tkMessageBox.showwarning(parent=self,
                        title = self.lg.get("win1", "msg40"),
                        message = self.lg.get("win1", "msg42"))
                return
        else:
            pass
        
        
        # ----------------------------------------
        # --- Convertir en chaîne texte base64    
        # ----------------------------------------
        
        t = base64.encodestring(strBin)
        
        
        # ----------------------------------------------------
        # --- Copier le texte base64 dans le presse-papiers   
        # ----------------------------------------------------
        
        self.clipboard_clear()
        self.clipboard_append(t)
        
        tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("win1", "msg40"),
                    message = self.lg.get("win1", "msg44") ) # Informer du succès
        
        return
    


    def getfile(self):
        
        u"""
        | Retourne l'objet fichier du dictionnaire.                             
        |                                                                       
        | Nb : la référence à cette méthode est passée au greffon lors de son   
        | instanciation pour qu'il puisse ensuite récupèrer l'objet fichier.    
        """
        
        if not self.dic is None:
            return self.dic.file
        else:
            return None


    def getList(self):
        
        u"""
        | Retourne le contenu de la liste des entrées.                          
        |                                                                       
        | Nb : la référence à cette méthode est passée au greffon lors de son   
        | instanciation pour qu'il puisse ensuite récupèrer la liste.           
        """
        
        return self.lst_dico.get(0, END)


    def getAppDataPath(self):
        
        u"""
        | Retourne le chemin du répertoire des données d'application.           
        |                                                                       
        | Nb : la référence à cette méthode est passée au greffon lors de son   
        | instanciation pour qu'il puisse ensuite récupèrer le chemin.          
        """
       
        return self.appdata.path
    
    
    def getlgcode(self):
        
        u"""
        | Retourne le code de la langue d'interface.                            
        |                                                                       
        | Nb : la référence à cette méthode est passée au greffon lors de son   
        | instanciation pour qu'il puisse ensuite récupèrer ce code.            
        """
        
        return self.lg.getlgcode()
    

    def queryUnload(self):
        
        u"""
        | Suite d'actions à effectuer avant la fermeture définitive de la       
        | fenêtre principale.                                                   
        """
        
        # -------------------------------------------------------
        # --- Boîte de message de confirmation de fermeture      
        # -------------------------------------------------------
        
        # Echappatoire provisoirement annulé car bogue de tkinter2.6/Linux
        #r = tkMessageBox.askyesno(
        #        title="Quitter Linguae",
        #        message=u"Merci de signaler tout problème rencontré à :\n\n\tlinguae@stalikez.info\n\n\nQuitter ?")
        #if r == False: return
        #tkMessageBox.showinfo(
        #        title = self.lg.get("win1", "msg46"),
        #        message = self.lg.get("win1", "msg47") )
        
        
        
        # ------------------------------------------
        # --- Détruire l'éventuelle fenêtre d'aide  
        # ------------------------------------------
        
        self.hlp.terminate() 
        
        
        # -------------------------------------------------------
        # --- Mémoriser la géométrie de l'interface dans l'ini   
        # -------------------------------------------------------
        
        # Taille et position de la fenêtre 
        if app.wm_state() == "zoomed":
            g = self.geometry().split("+")[0] + "+0+0"
        else:
            g = self.geometry()
        self.ini.write('Geometry', g)
        
        # Position de la coulisse
        self.ini.write('Xsash', str(self.panM.sash_coord(0)[0]))
        
        
        # ------------------------------------------
        # --- Vider le cache de l'application       
        # ------------------------------------------
        
        for f in glob.glob(os.path.join(self.appdata.cache, "*")):
            try:
                if os.path.isfile(f):
                    os.remove(f)
                else:
                    shutil.rmtree(f) # supprime un répertoire même non vide
            except:
                pass
        
        # ------------------------------------------------------------------------------
        # --- Nettoyer le fichier des encodings de ses entrées obsolètes (le réécrire)  
        # ------------------------------------------------------------------------------
        
        #    ..... (à faire) .....
        
        
        
        # -----------------------------------------------------------------------
        # --- Afficher un message "Ok" dans la console et fermer l'application   
        # -----------------------------------------------------------------------
        
        print "\n Linguae " + self.version + " :\t" + self.lg.get("win1", "msg48")
        
        self.destroy()
    
    


    def senddata(self, i):
        
        u"""
        | Retourne le contenu de l'entrée d'index 'i' du dico courant           
        | (s'il existe).                                                        
        |                                                                       
        | Nb : la référence à cette méthode est passée au greffon lors de son   
        | instanciation pour qu'il puisse ensuite récupèrer les données d'un    
        | mot quelconque.                                                       
        """
        
        if app.dic is None:
            return None
        else:
            return self.dic.getdata(i)



    def showSort(self):
        
        u""" 
        | Afficher la fenêtre de tri du dictionnaire                            
        """
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title= self.lg.get("winsort", "title"),
                    message = self.lg.get("g", "loadfst")) # ("Chargez d'abord un dictionnaire !")
            return
        
        try:
            self.f_sort.focus_set()           # Tenter d'activer (fenêtre non modale)
        except:
            self.f_sort = WindowSort()        # Echec de l'activation > instancier la fenêtre
        
        return


    def showAskLanguage(self):
        
        u"""
        | Affiche (instancie) la fenêtre de choix du langage de l'interface     
        """
        
        self.f_lg = WindowAskLanguage(iniobj=self.ini)      # NB : fenêtre modale
        self.f_lg.destroy()
        
        return 


    def showFind(self):
        
        u"""
        | Afficher (instancier ou activer) la fenêtre de recherche              
        """
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("winfnd", "title"),
                    message = self.lg.get("g", "loadfst") ) # ("Chargez d'abord un dictionnaire !")
            return
        
        
        try:
            self.f_find.focus_set()           # Tenter d'activer (fenêtre non modale)
        except:
            self.f_find = WindowFind()        # Echec de l'activation > instancier la fenêtre
        
        return


    def showImportPreling(self, fichpath=""):
        
        u"""
        | Affiche (instancie) la fenêtre d'importation Preling                  
        """
        
        WindowImportPreling(fichpath)      # NB : fenêtre modale
        
        return
    
    
    def showImportVarious(self):
        
        u"""
        | Affiche (instancie) la fenêtre d'importation des formats non gérés                  
        """
        
        WindowImportVarious()      # NB : fenêtre modale
        
        return
    
    
    def showAlpha(self):
        
        u"""
        | Affiche (instancie) la fenêtre du réglage de la transparence          
        """
        
        WindowAlpha()   # NB : fenêtre modale
        
        return
    

    def showOptions(self, seefirst=0):
        
        u"""
        | Affiche (instancie) la fenêtre des réglages et options                
        |                                                                       
        | ARGUMENTS :                                                           
        |   'seefirst" : index du panneau à afficher au démarrage               
        """
        
        WindowOptions(seefirst=seefirst)   # NB : fenêtre modale
        
        return


    def showReverse(self):
        
        u"""
        | Afficher la fenêtre de confection du dico inverse                     
        """
        
        # Avertisement de copyright
        r = tkMessageBox.askyesno(parent=self,
                title = self.lg.get("winrev", "title"),
                message = self.lg.get("win1", "msg49") )
        if r == False : return
        
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("winrev", "title"),
                    message = self.lg.get("g", "loadfst")) # ("Chargez d'abord un dictionnaire !")
            return
        
        if self.dic.type == "":
            return
        elif self.dic.type.startswith("ini"):
            app.hideProgr()
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("winrev", "title"),
                    message = self.lg.get("win1", "msg50") ) # (INI non inversable)
            return
        
        # Instancier la fenêtre
        
        WindowReverse()   # NB : fenêtre modale
        
        
        return


    def showProperties(self):
        
        u"""
        | Afficher la fenêtre des propriétés du dictionnaire                    
        """
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("winprop", "title"),
                    message = self.lg.get("g", "loadfst") ) # ("Chargez d'abord un dictionnaire !")
            return
        
        if self.dic.type == "": return
        
        # Instancier la fenêtre
        
        WindowProperties()   # NB : fenêtre modale
        
        return



    def showExtractModif(self):
        
        u"""
        | Afficher la fenêtre d'extraction des modifications                    
        """
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("winext", "title"),
                    message = self.lg.get("g", "loadfst") ) # ("Chargez d'abord un dictionnaire !")
            return
        
        if self.dic.type == "": 
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("winext", "title"),
                    message = self.lg.get("win1", "msg51") ) # ("Type de dictionnaire non spécifié. Extraction impossible !")
            return
        
        elif not self.dic.type.startswith("ling"):
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("winext", "title"),
                    message = self.lg.get("win1", "msg52") ) # ("extraction seulement pour format Ling")
            return
        
        # Instancier la fenêtre
        
        WindowExtract()   # NB : fenêtre modale
        
        
        return


    def showExport(self):
        
        u"""
        | Afficher la fenêtre d'exportation                                     
        """
        
        # Avertisement de copyright
        r = tkMessageBox.askyesno(parent=self,
                title = self.lg.get("winexp", "title"),
                message = self.lg.get("win1", "msg49") )
        if r == False : return
        
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("winexp", "title"),
                    message = self.lg.get("g", "loadfst") ) # ("Chargez d'abord un dictionnaire !")
            return
        
        if self.dic.type == "": 
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("winexp", "title"),
                    message = self.lg.get("win1", "msg53")) # ("Type de dictionnaire non spécifié. Exportation impossible !")
            return
        
        # Instancier la fenêtre
        
        WindowExport()   # NB : fenêtre modale
        
        return


    def showChkLinks(self):
        
        u"""
        | Afficher la fenêtre de contrôle des liens                             
        """
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                title = self.lg.get("winlk", "title"),
                message = self.lg.get("g", "loadfst") ) # ("Chargez d'abord un dictionnaire !")
            return
        
        try:
            self.f_lnk.focus_set()             # Tenter d'activer (fenêtre non modale)
        except:
            self.f_lnk = WindowChkLinks()      # Echec de l'activation > instancier la fenêtre
        
        return

    
    def showDwnld(self):
        
        u"""
        | Afficher la fenêtre de téléchargement des dictionnaires               
        """
        
        # Vérifier l'existence du dossier de stockage des dictionnaires
        if self.ini.get('DicStorageFolder','') == "":
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("windwn", "title"),
                    message = self.lg.get("win1", "msg55") ) # ("fonction dispo uniquement après définition d'un dossier des dicos")
            return
        
        indexurl = "http://download.tuxfamily.org/polyglotte/dicos/index_dicos_polyglotte.tab"
        #indexurl = "http://linguae.stalikez.info/testdwn/index_dicos_polyglotte.tab"
        
        WindowDicDownload(indexurl=indexurl)
        
        # NB : fenêtre modale
        
        return
    
    
    def showEdit(self):
        
        u"""
        | Afficher la fenêtre d'édition d'une entrée de dictionnaire            
        """
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                title = self.lg.get("wined", "title"),
                message = self.lg.get("g", "loadfst") ) # ("Chargez d'abord un dictionnaire !")
            return
        
        # Si la fenêtre est restée ouverte, on la ferme
        try:
            self.f_edit.destroy()
        except:
            pass
        
        # On crée la fenêtre en lui passant l'index du mot courant
        try:
            i = int(app.lst_dico.curselection()[0]) # index du mot en sélection
        except:
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("wined", "title1"),
                    message = self.lg.get("win1", "msg25") ) # "Sélectionnez d'abord une entrée !"
            return
        
        self.f_edit = WindowEdit(i)
        
        return
    
    
    
    
    def showEditAdd(self):
        
        u"""
        | Afficher la fenêtre d'édition pour ajouter une entrée de dictionnaire 
        """
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("wined", "title2"),
                    message = self.lg.get("g", "loadfst") ) # ("Chargez d'abord un dictionnaire !")
            return
        
        
        # Si la fenêtre est restée ouverte, on la ferme
        try:
            self.f_edit.destroy()
        except:
            pass
        
        
        # On crée la fenêtre en lui passant le pseudo index '-1'(= ajouter une entrée)
        
        app.lst_dico.selection_clear(0,END)     # Désélectionner tout dans la liste
        
        app.f_edit = WindowEdit(-1)
        
        return


    def showSetIcon(self):
        
        u"""
        | Affiche la fenêtre de modification des icônes du dictionnaire         
        """
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("winic", "title"),
                    message = self.lg.get("g", "loadfst") ) # ("Chargez d'abord un dictionnaire !")
            return
        
        if not self.dic.type.startswith("ling"):
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("winic", "title"),
                    message = self.lg.get("win1", "msg54") ) # ("ajout ou modif des icônes possible que pour format Ling")
            return
        
        
        # Instancier la fenêtre
        
        WindowSetIcon()   # NB : fenêtre modale
        
        
        return


    def showHerit(self):
        
        u"""
        Afficher la fenêtre de construction d'un dictionnaire par héritage      
        """
        
        # Vérifier l'existence du dossier de stockage des dictionnaires
        if self.ini.get('DicStorageFolder','') == "":
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("winher", "title"),
                    message = self.lg.get("win1", "msg55") ) # ("fonction dispo uniquement après définition d'un dossier des dicos")
            return
        
        
        WindowHerit()   # NB : fenêtre modale
        
        return


    def showSwac(self):
        
        u"""
        | Afficher/activer la fenêtre d'interrogation de Swac                   
        """
        
        
        mot = self.lst_dico.get(ACTIVE)
        
        
        lg = self.dic.langIso1
        if ":" in lg:
            lg = lg.split(":")[1]
        
        
        isopen = False
        
        try: # --- Tenter d'activer (fenêtre non modale)
            
            self.f_swac.focus_set()                  
            self.f_swac.askfromsel(mot=mot, lg=lg)
        
        except:# --- Echec de l'activation > instancier la fenêtre   
            
            if lg == "": 
                
                # Demander le code de la langue si nécessaire
                lg = tkSimpleDialog.askstring(
                        title = app.lg.get("winsw", "title"),
                        prompt = "Ce dictionnaire ne contient aucun code de langue.\nQuel est le code ISO-639 de la langue reccherchée ?" + "\n",
                        initialvalue = "")
                if not lg:
                    return
            
            self.f_swac = WindowSwac(mot=mot, lg=lg) 
        
        
        
        return



    def showTranslate(self):
        
        u"""
        | Afficher/activer la fenêtre d'aide à la traduction                    
        """
        
        if self.dic is None:
            tkMessageBox.showinfo(parent=self,
                    title = self.lg.get("wintrl", "title"),
                    message = self.lg.get("g", "loadfst") ) # ("Chargez d'abord un dictionnaire !")
            return
        
        try:
            self.f_transl.focus_set()             # Tenter d'activer (fenêtre non modale)
        except:
            self.f_transl = WindowTranslate()     # Echec de l'activation > instancier la fenêtre
        
        
        return



    def showUnicode(self):
        
        u"""
        | Afficher/activer la fenêtre des caractères Unicode                    
        """
        
        try:
            self.f_unic.focus_set()                 # Tenter d'activer (fenêtre non modale)
        except:
            self.f_unic = WindowUnicode(ifont=1)    # Echec de l'activation > instancier la fenêtre avec la police langue1
        
        return


    def showAbout(self):
        
        u"""
        | Afficher la fenêtre "A propos de Linguae"
        """
        
        WindowAbout()   # NB : fenêtre modale
        
        
        return


    def showAboutDic(self):
        
        u"""
        | Afficher la fenêtre "A propos de ce dictionnaire"                     
        """
        
        # Instancier la fenêtre
        
        WindowInfo()   # NB : fenêtre modale
        
        return


    def showHelp(self, contextID=""):
        
        u"""
        | Afficher la fenêtre d'aide contextuelle                               
        """
        
        self.hlp.showHelp(contextID)
        
        return




# //////////////////////////////////////////////////////////////////////////
# /// MAIN : Lancement du corps de l'application ///////////////////////////
# //////////////////////////////////////////////////////////////////////////

# Contexte : ce module a été directement lancé par l'utilisateur
# ou par le lanceur linguae.py(w)


# Crée et affiche la fenêtre principale de l'application
app = WindowMAIN(versionProgr)


# ---------------------------------------------
# --- Importer la bibliothèque audio Snack     
# ---------------------------------------------

#try:
#    import tkSnack
#    # IMPORTANT : l'initialisation de Snack DOIT obligatoirement
#    # survenir APRES celle de Tk() (=app) car Snack est une extension de Tk/Tcl
#    tkSnack.initializeSnack(app)  
#    app.snackisactive = True
#    
#except: # échec > avertir de la nécessité de Snack
#    
#    msg = app.lg.get("g", "msg1") + "\n"
#    if sys.platform.lower()[:3] == 'win':        
#        msg += "\n" + app.lg.get("g", "msg2") + "\n"
#    msg += "\n" + app.lg.get("g", "msg3")
#
#    r = tkMessageBox.askyesno(parent=app,
#            title = app.lg.get("g", "msg4"),
#            message = msg)
#    app.snackisactive = False
#    if r: app.showHelp("dep")


# ----------------------------------------------------------
# --- Importer la bibliothèque PIL (Python Imaging Library) 
# ----------------------------------------------------------


#try:
#    import Image
#    import ImageTk
#except:
#    print "\n!!! PIL (Python Imaging Library) absent !!!\n Download PIL : http://effbot.org/downloads/#pil\n"
    


# -----------
# -----------
# -----------


# Nécessaire car l'utilisation de la classe "infobulle" fait,
# pour d'obscures raisons, démarrer l'application sans focus...
app.focus_force()


# Procédure qui sera appelée à la tentative de fermeture de la fenêtre principale
app.protocol('WM_DELETE_WINDOW', app.queryUnload)


# -------------------------------------------------------------
# --- Ouverture automatique d'un dictionnaire                  
#     Ordre de priorité :                                      
#       (1) dico indiqué par la ligne de commande/double-clic  
#       (2) dico "de démarrage"                                
#       (3) dico antérieurement ouvert (mémorisé dans l'INI)   
# -------------------------------------------------------------




# Si un chemin de dico est passé en argument de ligne de commande, on l'ouvre
# (ligne de commande proprement dite ou double-clic sur un dico en mode graphique)
if len(sys.argv) > 1:
    app.openDicFromCommandLine()

else:
    
    # Si aucun dico n'est passé en argument, on recherche la présence d'un dico de démarrage
    # si un tel dico est trouvé et ouvert, 'True' est retourné
    if app.openDicFromStart() == False:
        
        # S'il n'y a pas de dico de démarrage, on rouvre le dernier dico ouvert
        app.openDicFromLastOpen()

# -------------------------------------------------
# --- Lancer la boucle de capture des évènements   
# -------------------------------------------------

# effacer le splash de lancement de l'application
try:
    app.splash.destroy()
except:
    pass

app.mainloop()
