#!/usr/bin/env python
# -*- coding:utf-8 -*-

# /////////////////////////////////////////////////////////////////////////
# //                                                                       
# // INFOBULLE pour Tkinter                                                
# //                                                                       
# // Code originel publié dans les codes-source de Developpez.com          
# // code mentionné comme "libre de droits"                                
# //                                                                       
# // auteur originel : "pierjean"                                          
# //                                                                       
# // + quelques modifs/ajouts perso (callbacks, désactivation, édition)    
# //                                                                       
# /////////////////////////////////////////////////////////////////////////


import Tkinter as Tk

class InfoBulle(Tk.Toplevel):
    
    def __init__(self, parent=None, text='', temps=700, arg_enter="", arg_leave=""):
        
        u"""
        | ARGUMENTS :                                                           
        |   'parent' : widget concerné par l'infobulle                          
        |   'text' : texte de l'infobulle                                       
        |   'temps' : délai de latence d'apparition de l'infobulle              
        |                                                                       
        | * les deux arguments suivants permettent de contourner le fait que    
        |   l'infobulle capture à son profit les évènements <Enter> et <Leave>  
        |   du widget concerné :                                                 
        |                                                                       
        |   'arg_enter' : reférence d'une fonction appelée par l'évènement      
        |                 <Enter> du widget                                     
        |   'arg_leave' : reférence d'une fonction appelée par l'évènement      
        |                <Leave> du widget.                                     
        """
        
        Tk.Toplevel.__init__(self, parent, bd=1, bg='black')
        
        self.tps = temps
        self.parent = parent
        self.withdraw()
        self.overrideredirect(1)  # permet que la fenêtre n'ait pas de bordure
        self.transient()     
        
        self.lab = Tk.Label(self, text=text, bg="yellow", justify='left', font=('Helvetica',9,'normal'))
        self.lab.update_idletasks()
        self.lab.pack()
        self.lab.update_idletasks()
        
        self.tipwidth = self.lab.winfo_width()
        self.tipheight = self.lab.winfo_height()
        self.parent.bind('<Enter>', self.delai)
        self.parent.bind('<Button-1>', self.efface)
        self.parent.bind('<Leave>', self.efface)
        
        self.activityIsOn = True # L'affichage de l'infobulle est activé par défaut
        
        self.callbackEnter = arg_enter
        self.callbackLeave = arg_leave
        self.parentWidget = parent
    
    
    def libel(self, txt=""):
        u"""
        | Modifie secondairement le libellé de l'infobulle                      
        """
        self.lab['text'] = txt
        
        return
    
    
    def delai(self,event):
        u"""
        | On attend self.tps avant d'afficher l'infobulle                       
        """
        
        if self.activityIsOn:
            self.action = self.parent.after(self.tps, self.affiche)
        
        # Appeller le callback de <Enter> s'il existe
        if self.callbackEnter != "":
            self.callbackEnter(self.parentWidget)


    def affiche(self):
        u"""
        |Affichage de l'infobulle                                               
        """
        
        self.update_idletasks()
        posX = self.parent.winfo_rootx()+self.parent.winfo_width()
        posY = self.parent.winfo_rooty()+self.parent.winfo_height()
        if posX + self.tipwidth > self.winfo_screenwidth():
            posX = posX-self.winfo_width()-self.tipwidth
        if posY + self.tipheight > self.winfo_screenheight():
            posY = posY-self.winfo_height()-self.tipheight
        self.geometry('+%d+%d'%(posX,posY))
        self.deiconify()


    def efface(self,event):
        u"""
        | Cacher l'infobulle ou annuler son affichage                           
        """
        
        if self.activityIsOn:
            self.withdraw()
            try:
                self.parent.after_cancel(self.action)
            except:
                pass
        
        # Appeller le callback de <Leave> s'il existe
        if self.callbackLeave != "":
            self.callbackLeave(self.parentWidget)
        

    def deactivate(self):
        u"""
        | Désactive l'infobulle                                                 
        """
        
        self.efface(None)
        self.activityIsOn = False


    def activate(self):
        u"""
        | Réactive l'infobulle                                                  
        """
        
        self.activityIsOn = True


 
if __name__ == '__main__':
    root = Tk.Tk()
    root.title("Exemple de création d'une classe InfoBulle")
    lab1 = Tk.Label(root, text='Infobulle 1')
    lab1.pack()
    lab2 = Tk.Label(root, text='Infobulle 2')
    lab2.pack()
    i1 = InfoBulle(parent=lab1, text="Infobulle 1")
    i2 = InfoBulle(parent=lab2, text="Infobulle 2")
    root.mainloop()
