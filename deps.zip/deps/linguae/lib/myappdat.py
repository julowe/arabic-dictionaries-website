#!/usr/bin/env python
# -*- coding:utf-8 -*-


# ////////////////////////////////////////////////////////////////////////
#                                                                         
#   sous licence CeCILL-2 (GNU-GPL compatible) : http://www.cecill.info/  
#                                                                         
#   Auteur   : Billig - 2008-2009                                         
#   Contact  : linguae@stalikez.info                                      
#   Site Web : http://linguae.stalikez.info                               
#                                                                         
# ////////////////////////////////////////////////////////////////////////

import sys
import os.path


class AppData():
    
    u"""
    | Classe de gestion du répertoire des données d'application de l'utilisateur
    | et de son contenu.                                                        
    | L'emplacement de ce répertoire est variable suivant la plateforme.        
    |                                                                           
    | On initialise l'objet avec le nom interne de l'application, ce nom servant
    | de libellé à ce répertoire.                                               
    |                                                                           
    | On peut ensuite invoquer les attributs :                                  
    |                                                                           
    |     .path   : chemin complet du répertoire des données d'application      
    |                                                                           
    |     .cache  : chemin complet du répertoire de cache (sous-répertoire du   
    |               répertoire des données d'application)                       
    |                                                                           
    | Ces deux répertoires sont créés lors de l'instanciation, s'ils n'existent
    | pas déjà.                                                                 
    |                                                                           
    """
    
    def __init__(self, appname):
        
        self.path = ""      # Chemin complet du répertoire de données d'application
        self.cache = ""     # Chemin complet du répertoire de cache (sous-rép. du précédent)
        
        
        # ---------------------------------------------------------------------
        # --- Déterminer le chemin du répertoire en fonction de la plateforme  
        # ---------------------------------------------------------------------
        
        pf = sys.platform.lower()
        
        # --- Windows
        if pf[:3] == 'win':
            
            repAppData = os.path.join(os.path.expanduser('~'), "Application Data", appname)
        
        # --- Unix (MacosX, Linux, )
        elif pf[:6] == 'darwin' or pf[:5] == 'linux':
            
            repAppData = os.path.join(os.path.expanduser('~'), "." + appname) # le "." rend un répertoire masqué
            
        # --- (autres plateformes)
        else:
            # Pour les autres plateformes, on utilise le répertoire de l'application,
            # en attente de documentation sur les chemins précis pour ces plateformes
            # (autres valeurs possibles : 'mac', 'sunos5', 'PalmOS3', 'hp-ux11', etc.)
            repAppData = os.path.dirname(os.path.realpath(sys.argv[0]))
        
        
        if not os.path.isdir(repAppData): os.mkdir(repAppData)  # Si ce répertoire n'existe pas > le créer
        
        
        # ------------------------------
        # --- Répertoire du cache       
        # ------------------------------
        
        repCache = os.path.join(repAppData, "cache")
        
        if not os.path.isdir(repCache): os.mkdir(repCache)  # Si ce répertoire n'existe pas > le créer
        
        
        # ---
        
        self.path = repAppData      # Chemin complet du répertoire de données d'application
        self.cache = repCache       # Chemin complet du répertoire de cache
        
        return
        
